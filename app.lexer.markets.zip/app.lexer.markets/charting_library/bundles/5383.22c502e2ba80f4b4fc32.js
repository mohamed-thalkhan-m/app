(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [5383], {
        5383: function(e, t, n) {
            var r, o, i;
            e.exports = (r = n(67294), o = n(73935), i = n(1529), function(e) {
                function t(r) {
                    if (n[r]) return n[r].exports;
                    var o = n[r] = {
                        exports: {},
                        id: r,
                        loaded: !1
                    };
                    return e[r].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports
                }
                var n = {};
                return t.m = e, t.c = n, t.p = "dist/", t(0)
            }([function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = void 0;
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(1));
                t.default = r.default, e.exports = t.default
            }, function(e, t, n) {
                "use strict";

                function r(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }
                Object.defineProperty(t, "__esModule", {
                    value: !0
                });
                var o = function() {
                        function e(e, t) {
                            for (var n = 0; n < t.length; n++) {
                                var r = t[n];
                                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                            }
                        }
                        return function(t, n, r) {
                            return n && e(t.prototype, n), r && e(t, r), t
                        }
                    }(),
                    i = n(2),
                    u = (r(i), n(3)),
                    a = r(u),
                    s = r(n(13)),
                    c = r(n(14)),
                    f = r(n(15)),
                    l = function(e) {
                        function t(e) {
                            ! function(e, t) {
                                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                            }(this, t);
                            var n = function(e, t) {
                                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return !t || "object" != typeof t && "function" != typeof t ? e : t
                            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                            return n.measure = function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n.props.includeMargin;
                                if (n.props.shouldMeasure) {
                                    n._node.parentNode || n._setDOMNode();
                                    var t = n.getDimensions(n._node, e),
                                        r = "function" == typeof n.props.children;
                                    n._propsToMeasure.some((function(e) {
                                        if (t[e] !== n._lastDimensions[e]) return n.props.onMeasure(t), r && void 0 !== n && n.setState({
                                            dimensions: t
                                        }), n._lastDimensions = t, !0
                                    }))
                                }
                            }, n.state = {
                                dimensions: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0
                                }
                            }, n._node = null, n._propsToMeasure = n._getPropsToMeasure(e), n._lastDimensions = {}, n
                        }
                        return function(e, t) {
                            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
                            e.prototype = Object.create(t && t.prototype, {
                                constructor: {
                                    value: e,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
                        }(t, e), o(t, [{
                            key: "componentDidMount",
                            value: function() {
                                var e = this;
                                this._setDOMNode(), this.measure(), this.resizeObserver = new c.default((function() {
                                    return e.measure()
                                })), this.resizeObserver.observe(this._node)
                            }
                        }, {
                            key: "componentWillReceiveProps",
                            value: function(e) {
                                var t = (e.config, e.whitelist),
                                    n = e.blacklist;
                                this.props.whitelist === t && this.props.blacklist === n || (this._propsToMeasure = this._getPropsToMeasure({
                                    whitelist: t,
                                    blacklist: n
                                }))
                            }
                        }, {
                            key: "componentWillUnmount",
                            value: function() {
                                this.resizeObserver.disconnect(this._node), this._node = null
                            }
                        }, {
                            key: "_setDOMNode",
                            value: function() {
                                this._node = s.default.findDOMNode(this)
                            }
                        }, {
                            key: "getDimensions",
                            value: function() {
                                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : this._node,
                                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : this.props.includeMargin;
                                return (0, f.default)(e, {
                                    margin: t
                                })
                            }
                        }, {
                            key: "_getPropsToMeasure",
                            value: function(e) {
                                var t = e.whitelist,
                                    n = e.blacklist;
                                return t.filter((function(e) {
                                    return n.indexOf(e) < 0
                                }))
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var e = this.props.children;
                                return i.Children.only("function" == typeof e ? e(this.state.dimensions) : e)
                            }
                        }]), t
                    }(i.Component);
                l.propTypes = {
                    whitelist: a.default.array,
                    blacklist: a.default.array,
                    includeMargin: a.default.bool,
                    useClone: a.default.bool,
                    cloneOptions: a.default.object,
                    shouldMeasure: a.default.bool,
                    onMeasure: a.default.func
                }, l.defaultProps = {
                    whitelist: ["width", "height", "top", "right", "bottom", "left"],
                    blacklist: [],
                    includeMargin: !0,
                    useClone: !1,
                    cloneOptions: {},
                    shouldMeasure: !0,
                    onMeasure: function() {
                        return null
                    }
                }, t.default = l, e.exports = t.default
            }, function(e, t) {
                e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) {
                        var o = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;
                        e.exports = n(5)((function(e) {
                            return "object" === (void 0 === e ? "undefined" : r(e)) && null !== e && e.$$typeof === o
                        }), !0)
                    } else e.exports = n(12)()
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n() {
                    throw new Error("setTimeout has not been defined")
                }

                function r() {
                    throw new Error("clearTimeout has not been defined")
                }

                function o(e) {
                    if (c === setTimeout) return setTimeout(e, 0);
                    if ((c === n || !c) && setTimeout) return c = setTimeout, setTimeout(e, 0);
                    try {
                        return c(e, 0)
                    } catch (t) {
                        try {
                            return c.call(null, e, 0)
                        } catch (t) {
                            return c.call(this, e, 0)
                        }
                    }
                }

                function i() {
                    y && p && (y = !1, p.length ? d = p.concat(d) : h = -1, d.length && u())
                }

                function u() {
                    if (!y) {
                        var e = o(i);
                        y = !0;
                        for (var t = d.length; t;) {
                            for (p = d, d = []; ++h < t;) p && p[h].run();
                            h = -1, t = d.length
                        }
                        p = null, y = !1,
                            function(e) {
                                if (f === clearTimeout) return clearTimeout(e);
                                if ((f === r || !f) && clearTimeout) return f = clearTimeout, clearTimeout(e);
                                try {
                                    f(e)
                                } catch (t) {
                                    try {
                                        return f.call(null, e)
                                    } catch (t) {
                                        return f.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function a(e, t) {
                    this.fun = e, this.array = t
                }

                function s() {}
                var c, f, l = e.exports = {};
                ! function() {
                    try {
                        c = "function" == typeof setTimeout ? setTimeout : n
                    } catch (e) {
                        c = n
                    }
                    try {
                        f = "function" == typeof clearTimeout ? clearTimeout : r
                    } catch (e) {
                        f = r
                    }
                }();
                var p, d = [],
                    y = !1,
                    h = -1;
                l.nextTick = function(e) {
                    var t = new Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
                    d.push(new a(e, t)), 1 !== d.length || y || o(u)
                }, a.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, l.title = "browser", l.browser = !0, l.env = {}, l.argv = [], l.version = "", l.versions = {}, l.on = s, l.addListener = s, l.once = s, l.off = s, l.removeListener = s, l.removeAllListeners = s, l.emit = s, l.prependListener = s, l.prependOnceListener = s, l.listeners = function(e) {
                    return []
                }, l.binding = function(e) {
                    throw new Error("process.binding is not supported")
                }, l.cwd = function() {
                    return "/"
                }, l.chdir = function(e) {
                    throw new Error("process.chdir is not supported")
                }, l.umask = function() {
                    return 0
                }
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                            return typeof e
                        } : function(e) {
                            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                        },
                        o = n(6),
                        i = n(7),
                        u = n(8),
                        a = n(9),
                        s = n(10),
                        c = n(11);
                    e.exports = function(e, n) {
                        function f(e, t) {
                            return e === t ? 0 !== e || 1 / e == 1 / t : e != e && t != t
                        }

                        function l(e) {
                            this.message = e, this.stack = ""
                        }

                        function p(e) {
                            function r(r, c, f, p, d, y, h) {
                                if (p = p || w, y = y || f, h !== s)
                                    if (n) i(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use `PropTypes.checkPropTypes()` to call them. Read more at http://fb.me/use-check-prop-types");
                                    else if ("production" !== t.env.NODE_ENV && "undefined" != typeof console) {
                                    var v = p + ":" + f;
                                    !o[v] && a < 3 && (u(!1, "You are manually calling a React.PropTypes validation function for the `%s` prop on `%s`. This is deprecated and will throw in the standalone `prop-types` package. You may be seeing this warning due to a third-party PropTypes library. See https://fb.me/react-warning-dont-call-proptypes for details.", y, p), o[v] = !0, a++)
                                }
                                return null == c[f] ? r ? new l(null === c[f] ? "The " + d + " `" + y + "` is marked as required in `" + p + "`, but its value is `null`." : "The " + d + " `" + y + "` is marked as required in `" + p + "`, but its value is `undefined`.") : null : e(c, f, p, d, y)
                            }
                            if ("production" !== t.env.NODE_ENV) var o = {},
                                a = 0;
                            var c = r.bind(null, !1);
                            return c.isRequired = r.bind(null, !0), c
                        }

                        function d(e) {
                            return p((function(t, n, r, o, i, u) {
                                var a = t[n];
                                return h(a) !== e ? new l("Invalid " + o + " `" + i + "` of type `" + v(a) + "` supplied to `" + r + "`, expected `" + e + "`.") : null
                            }))
                        }

                        function y(t) {
                            switch (void 0 === t ? "undefined" : r(t)) {
                                case "number":
                                case "string":
                                case "undefined":
                                    return !0;
                                case "boolean":
                                    return !t;
                                case "object":
                                    if (Array.isArray(t)) return t.every(y);
                                    if (null === t || e(t)) return !0;
                                    var n = function(e) {
                                        var t = e && (b && e[b] || e[g]);
                                        if ("function" == typeof t) return t
                                    }(t);
                                    if (!n) return !1;
                                    var o, i = n.call(t);
                                    if (n !== t.entries) {
                                        for (; !(o = i.next()).done;)
                                            if (!y(o.value)) return !1
                                    } else
                                        for (; !(o = i.next()).done;) {
                                            var u = o.value;
                                            if (u && !y(u[1])) return !1
                                        }
                                    return !0;
                                default:
                                    return !1
                            }
                        }

                        function h(e) {
                            var t = void 0 === e ? "undefined" : r(e);
                            return Array.isArray(e) ? "array" : e instanceof RegExp ? "object" : function(e, t) {
                                return "symbol" === e || "Symbol" === t["@@toStringTag"] || "function" == typeof Symbol && t instanceof Symbol
                            }(t, e) ? "symbol" : t
                        }

                        function v(e) {
                            if (null == e) return "" + e;
                            var t = h(e);
                            if ("object" === t) {
                                if (e instanceof Date) return "date";
                                if (e instanceof RegExp) return "regexp"
                            }
                            return t
                        }

                        function m(e) {
                            var t = v(e);
                            switch (t) {
                                case "array":
                                case "object":
                                    return "an " + t;
                                case "boolean":
                                case "date":
                                case "regexp":
                                    return "a " + t;
                                default:
                                    return t
                            }
                        }
                        var b = "function" == typeof Symbol && Symbol.iterator,
                            g = "@@iterator",
                            w = "<<anonymous>>",
                            O = {
                                array: d("array"),
                                bool: d("boolean"),
                                func: d("function"),
                                number: d("number"),
                                object: d("object"),
                                string: d("string"),
                                symbol: d("symbol"),
                                any: p(o.thatReturnsNull),
                                arrayOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new l("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside arrayOf.");
                                        var u = t[n];
                                        if (!Array.isArray(u)) return new l("Invalid " + o + " `" + i + "` of type `" + h(u) + "` supplied to `" + r + "`, expected an array.");
                                        for (var a = 0; a < u.length; a++) {
                                            var c = e(u, a, r, o, i + "[" + a + "]", s);
                                            if (c instanceof Error) return c
                                        }
                                        return null
                                    }))
                                },
                                element: p((function(t, n, r, o, i) {
                                    var u = t[n];
                                    return e(u) ? null : new l("Invalid " + o + " `" + i + "` of type `" + h(u) + "` supplied to `" + r + "`, expected a single ReactElement.")
                                })),
                                instanceOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if (!(t[n] instanceof e)) {
                                            var u = e.name || w;
                                            return new l("Invalid " + o + " `" + i + "` of type `" + function(e) {
                                                return e.constructor && e.constructor.name ? e.constructor.name : w
                                            }(t[n]) + "` supplied to `" + r + "`, expected instance of `" + u + "`.")
                                        }
                                        return null
                                    }))
                                },
                                node: p((function(e, t, n, r, o) {
                                    return y(e[t]) ? null : new l("Invalid " + r + " `" + o + "` supplied to `" + n + "`, expected a ReactNode.")
                                })),
                                objectOf: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        if ("function" != typeof e) return new l("Property `" + i + "` of component `" + r + "` has invalid PropType notation inside objectOf.");
                                        var u = t[n],
                                            a = h(u);
                                        if ("object" !== a) return new l("Invalid " + o + " `" + i + "` of type `" + a + "` supplied to `" + r + "`, expected an object.");
                                        for (var c in u)
                                            if (u.hasOwnProperty(c)) {
                                                var f = e(u, c, r, o, i + "." + c, s);
                                                if (f instanceof Error) return f
                                            }
                                        return null
                                    }))
                                },
                                oneOf: function(e) {
                                    return Array.isArray(e) ? p((function(t, n, r, o, i) {
                                        for (var u = t[n], a = 0; a < e.length; a++)
                                            if (f(u, e[a])) return null;
                                        return new l("Invalid " + o + " `" + i + "` of value `" + u + "` supplied to `" + r + "`, expected one of " + JSON.stringify(e) + ".")
                                    })) : ("production" !== t.env.NODE_ENV && u(!1, "Invalid argument supplied to oneOf, expected an instance of array."), o.thatReturnsNull)
                                },
                                oneOfType: function(e) {
                                    if (!Array.isArray(e)) return "production" !== t.env.NODE_ENV && u(!1, "Invalid argument supplied to oneOfType, expected an instance of array."), o.thatReturnsNull;
                                    for (var n = 0; n < e.length; n++) {
                                        var r = e[n];
                                        if ("function" != typeof r) return u(!1, "Invalid argument supplied to oneOfType. Expected an array of check functions, but received %s at index %s.", m(r), n), o.thatReturnsNull
                                    }
                                    return p((function(t, n, r, o, i) {
                                        for (var u = 0; u < e.length; u++)
                                            if (null == (0, e[u])(t, n, r, o, i, s)) return null;
                                        return new l("Invalid " + o + " `" + i + "` supplied to `" + r + "`.")
                                    }))
                                },
                                shape: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var u = t[n],
                                            a = h(u);
                                        if ("object" !== a) return new l("Invalid " + o + " `" + i + "` of type `" + a + "` supplied to `" + r + "`, expected `object`.");
                                        for (var c in e) {
                                            var f = e[c];
                                            if (f) {
                                                var p = f(u, c, r, o, i + "." + c, s);
                                                if (p) return p
                                            }
                                        }
                                        return null
                                    }))
                                },
                                exact: function(e) {
                                    return p((function(t, n, r, o, i) {
                                        var u = t[n],
                                            c = h(u);
                                        if ("object" !== c) return new l("Invalid " + o + " `" + i + "` of type `" + c + "` supplied to `" + r + "`, expected `object`.");
                                        var f = a({}, t[n], e);
                                        for (var p in f) {
                                            var d = e[p];
                                            if (!d) return new l("Invalid " + o + " `" + i + "` key `" + p + "` supplied to `" + r + "`.\nBad object: " + JSON.stringify(t[n], null, "  ") + "\nValid keys: " + JSON.stringify(Object.keys(e), null, "  "));
                                            var y = d(u, p, r, o, i + "." + p, s);
                                            if (y) return y
                                        }
                                        return null
                                    }))
                                }
                            };
                        return l.prototype = Error.prototype, O.checkPropTypes = c, O.PropTypes = O, O
                    }
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    return function() {
                        return e
                    }
                }
                var r = function() {};
                r.thatReturns = n, r.thatReturnsFalse = n(!1), r.thatReturnsTrue = n(!0), r.thatReturnsNull = n(null), r.thatReturnsThis = function() {
                    return this
                }, r.thatReturnsArgument = function(e) {
                    return e
                }, e.exports = r
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var n = function(e) {};
                    "production" !== t.env.NODE_ENV && (n = function(e) {
                        if (void 0 === e) throw new Error("invariant requires an error message argument")
                    }), e.exports = function(e, t, r, o, i, u, a, s) {
                        if (n(t), !e) {
                            var c;
                            if (void 0 === t) c = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
                            else {
                                var f = [r, o, i, u, a, s],
                                    l = 0;
                                (c = new Error(t.replace(/%s/g, (function() {
                                    return f[l++]
                                })))).name = "Invariant Violation"
                            }
                            throw c.framesToPop = 1, c
                        }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = n(6);
                    if ("production" !== t.env.NODE_ENV) {
                        var o = function(e) {
                            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                            var o = 0,
                                i = "Warning: " + e.replace(/%s/g, (function() {
                                    return n[o++]
                                }));
                            "undefined" != typeof console && console.error(i);
                            try {
                                throw new Error(i)
                            } catch (e) {}
                        };
                        r = function(e, t) {
                            if (void 0 === t) throw new Error("`warning(condition, format, ...args)` requires a warning message argument");
                            if (0 !== t.indexOf("Failed Composite propType: ") && !e) {
                                for (var n = arguments.length, r = Array(n > 2 ? n - 2 : 0), i = 2; i < n; i++) r[i - 2] = arguments[i];
                                o.apply(void 0, [t].concat(r))
                            }
                        }
                    }
                    e.exports = r
                }).call(t, n(4))
            }, function(e, t) {
                "use strict";

                function n(e) {
                    if (null == e) throw new TypeError("Object.assign cannot be called with null or undefined");
                    return Object(e)
                }
                var r = Object.getOwnPropertySymbols,
                    o = Object.prototype.hasOwnProperty,
                    i = Object.prototype.propertyIsEnumerable;
                e.exports = function() {
                    try {
                        if (!Object.assign) return !1;
                        var e = new String("abc");
                        if (e[5] = "de", "5" === Object.getOwnPropertyNames(e)[0]) return !1;
                        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
                        if ("0123456789" !== Object.getOwnPropertyNames(t).map((function(e) {
                                return t[e]
                            })).join("")) return !1;
                        var r = {};
                        return "abcdefghijklmnopqrst".split("").forEach((function(e) {
                            r[e] = e
                        })), "abcdefghijklmnopqrst" === Object.keys(Object.assign({}, r)).join("")
                    } catch (e) {
                        return !1
                    }
                }() ? Object.assign : function(e, t) {
                    for (var u, a, s = n(e), c = 1; c < arguments.length; c++) {
                        for (var f in u = Object(arguments[c])) o.call(u, f) && (s[f] = u[f]);
                        if (r) {
                            a = r(u);
                            for (var l = 0; l < a.length; l++) i.call(u, a[l]) && (s[a[l]] = u[a[l]])
                        }
                    }
                    return s
                }
            }, function(e, t) {
                "use strict";
                e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
            }, function(e, t, n) {
                (function(t) {
                    "use strict";
                    var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    };
                    if ("production" !== t.env.NODE_ENV) var o = n(7),
                        i = n(8),
                        u = n(10),
                        a = {};
                    e.exports = function(e, n, s, c, f) {
                        if ("production" !== t.env.NODE_ENV)
                            for (var l in e)
                                if (e.hasOwnProperty(l)) {
                                    var p;
                                    try {
                                        o("function" == typeof e[l], "%s: %s type `%s` is invalid; it must be a function, usually from the `prop-types` package, but received `%s`.", c || "React class", s, l, r(e[l])), p = e[l](n, l, c, s, null, u)
                                    } catch (e) {
                                        p = e
                                    }
                                    if (i(!p || p instanceof Error, "%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", c || "React class", s, l, void 0 === p ? "undefined" : r(p)), p instanceof Error && !(p.message in a)) {
                                        a[p.message] = !0;
                                        var d = f ? f() : "";
                                        i(!1, "Failed %s type: %s%s", s, p.message, null != d ? d : "")
                                    }
                                }
                    }
                }).call(t, n(4))
            }, function(e, t, n) {
                "use strict";
                var r = n(6),
                    o = n(7),
                    i = n(10);
                e.exports = function() {
                    function e(e, t, n, r, u, a) {
                        a !== i && o(!1, "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")
                    }

                    function t() {
                        return e
                    }
                    e.isRequired = e;
                    var n = {
                        array: e,
                        bool: e,
                        func: e,
                        number: e,
                        object: e,
                        string: e,
                        symbol: e,
                        any: e,
                        arrayOf: t,
                        element: e,
                        instanceOf: t,
                        node: e,
                        objectOf: t,
                        oneOf: t,
                        oneOfType: t,
                        shape: t,
                        exact: t
                    };
                    return n.checkPropTypes = r, n.PropTypes = n, n
                }
            }, function(e, t) {
                e.exports = o
            }, function(e, t) {
                e.exports = i
            }, function(e, t, n) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        n = e.getBoundingClientRect(),
                        o = void 0,
                        i = void 0,
                        u = void 0;
                    return t.margin && (u = (0, r.default)(getComputedStyle(e))), t.margin ? (o = u.left + n.width + u.right, i = u.top + n.height + u.bottom) : (o = n.width, i = n.height), {
                        width: o,
                        height: i,
                        top: n.top,
                        right: n.right,
                        bottom: n.bottom,
                        left: n.left
                    }
                };
                var r = function(e) {
                    return e && e.__esModule ? e : {
                        default: e
                    }
                }(n(16));
                e.exports = t.default
            }, function(e, t) {
                "use strict";
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.default = function(e) {
                    return {
                        top: n((e = e || {}).marginTop),
                        right: n(e.marginRight),
                        bottom: n(e.marginBottom),
                        left: n(e.marginLeft)
                    }
                };
                var n = function(e) {
                    return parseInt(e) || 0
                };
                e.exports = t.default
            }]))
        }
    }
]);