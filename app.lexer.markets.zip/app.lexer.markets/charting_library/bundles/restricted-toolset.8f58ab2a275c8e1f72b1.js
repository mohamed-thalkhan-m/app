(self.webpackChunktradingview = self.webpackChunktradingview || []).push([
    [5516, 3718], {
        33214: e => {
            e.exports = {
                loader: "loader-38qh0l_K",
                static: "static-38qh0l_K",
                item: "item-38qh0l_K",
                "tv-button-loader": "tv-button-loader-38qh0l_K",
                black: "black-38qh0l_K",
                white: "white-38qh0l_K",
                gray: "gray-38qh0l_K",
                primary: "primary-38qh0l_K",
                "loader-initial": "loader-initial-38qh0l_K",
                "loader-appear": "loader-appear-38qh0l_K"
            }
        },
        6920: e => {
            e.exports = {
                switcherWrapper: "switcherWrapper-ZOZ_o9xK",
                "size-small": "size-small-ZOZ_o9xK",
                "size-large": "size-large-ZOZ_o9xK",
                "intent-select": "intent-select-ZOZ_o9xK",
                switcherThumbWrapper: "switcherThumbWrapper-ZOZ_o9xK",
                input: "input-ZOZ_o9xK",
                switcherTrack: "switcherTrack-ZOZ_o9xK",
                "intent-default": "intent-default-ZOZ_o9xK",
                switcherThumb: "switcherThumb-ZOZ_o9xK",
                focus: "focus-ZOZ_o9xK"
            }
        },
        72227: e => {
            e.exports = {
                summary: "summary-3UYGeClB",
                hovered: "hovered-3UYGeClB",
                caret: "caret-3UYGeClB"
            }
        },
        77541: e => {
            e.exports = {
                wrapper: "wrapper-2wbe1KZX",
                labelRow: "labelRow-2wbe1KZX",
                label: "label-2wbe1KZX",
                labelHint: "labelHint-2wbe1KZX",
                labelOn: "labelOn-2wbe1KZX"
            }
        },
        79948: e => {
            e.exports = {
                wrapper: "wrapper-1Eudat6L",
                hovered: "hovered-1Eudat6L",
                labelRow: "labelRow-1Eudat6L",
                label: "label-1Eudat6L",
                labelHint: "labelHint-1Eudat6L",
                labelOn: "labelOn-1Eudat6L"
            }
        },
        35375: e => {
            e.exports = {
                button: "button-mPM2q3lb",
                withText: "withText-mPM2q3lb",
                withoutText: "withoutText-mPM2q3lb"
            }
        },
        27754: e => {
            e.exports = {
                button: "button-2YcRd2gv"
            }
        },
        28199: e => {
            e.exports = {
                form: "form-9dAINdeN",
                interacting: "interacting-9dAINdeN",
                input: "input-9dAINdeN",
                menu: "menu-9dAINdeN",
                add: "add-9dAINdeN",
                hovered: "hovered-9dAINdeN",
                hover: "hover-9dAINdeN",
                wrap: "wrap-9dAINdeN"
            }
        },
        75996: e => {
            e.exports = {
                spinnerWrap: "spinnerWrap-1dkAsm33"
            }
        },
        8809: e => {
            e.exports = {
                title: "title-2VoDfDWK"
            }
        },
        67177: e => {
            e.exports = {
                button: "button-2eVMAgh-",
                first: "first-2eVMAgh-",
                last: "last-2eVMAgh-"
            }
        },
        38733: e => {
            e.exports = {
                wrap: "wrap-3jbioG5e"
            }
        },
        85243: e => {
            e.exports = {
                hidden: "hidden-y5m62lMJ"
            }
        },
        90505: e => {
            e.exports = {
                "tablet-small-breakpoint": "screen and (max-width: 428px)",
                item: "item-NklSvNSQ",
                withIcon: "withIcon-NklSvNSQ",
                shortcut: "shortcut-NklSvNSQ",
                loading: "loading-NklSvNSQ",
                icon: "icon-NklSvNSQ"
            }
        },
        55632: e => {
            e.exports = {
                button: "button-3HNCAKoZ",
                menu: "menu-3HNCAKoZ"
            }
        },
        55879: e => {
            e.exports = {
                dropdown: "dropdown-3UuXmxSn",
                label: "label-3UuXmxSn",
                smallWidthTitle: "smallWidthTitle-3UuXmxSn",
                smallWidthMenuItem: "smallWidthMenuItem-3UuXmxSn",
                smallWidthWrapper: "smallWidthWrapper-3UuXmxSn"
            }
        },
        72017: e => {
            e.exports = {
                value: "value-2y-wa9jT",
                selected: "selected-2y-wa9jT"
            }
        },
        13097: e => {
            e.exports = {
                smallWidthMenuItem: "smallWidthMenuItem-2BP6_jxN"
            }
        },
        76864: e => {
            e.exports = {
                button: "button-2R6OKuTS",
                first: "first-2R6OKuTS",
                last: "last-2R6OKuTS",
                newStyles: "newStyles-2R6OKuTS",
                menu: "menu-2R6OKuTS",
                dropdown: "dropdown-2R6OKuTS",
                menuContent: "menuContent-2R6OKuTS",
                section: "section-2R6OKuTS",
                smallTabletSectionTitle: "smallTabletSectionTitle-2R6OKuTS",
                addCustomInterval: "addCustomInterval-2R6OKuTS",
                hovered: "hovered-2R6OKuTS"
            }
        },
        51274: e => {
            e.exports = {
                button: "button-2twPcS_V"
            }
        },
        16856: e => {
            e.exports = {
                button: "button-2DZWpSVr",
                isDisabled: "isDisabled-2DZWpSVr",
                text: "text-2DZWpSVr"
            }
        },
        19533: e => {
            e.exports = {
                opened: "opened-90gXp5JL",
                hover: "hover-90gXp5JL",
                autoSaveWrapper: "autoSaveWrapper-90gXp5JL",
                sharingWrapper: "sharingWrapper-90gXp5JL",
                button: "button-90gXp5JL",
                buttonSmallPadding: "buttonSmallPadding-90gXp5JL",
                hintPlaceHolder: "hintPlaceHolder-90gXp5JL",
                smallHintPlaceHolder: "smallHintPlaceHolder-90gXp5JL",
                popupItemRowTabletSmall: "popupItemRowTabletSmall-90gXp5JL",
                shortcut: "shortcut-90gXp5JL"
            }
        },
        14552: e => {
            e.exports = {
                button: "button-1iP43u_z",
                text: "text-1iP43u_z",
                logo: "logo-1iP43u_z"
            }
        },
        44649: e => {
            e.exports = {
                button: "button-1n0tF4SR",
                text: "text-1n0tF4SR",
                uppercase: "uppercase-1n0tF4SR"
            }
        },
        53257: e => {
            e.exports = {
                description: "description-2U1ZnBls"
            }
        },
        79236: e => {
            e.exports = {
                item: "item-2gtivim-",
                round: "round-2gtivim-"
            }
        },
        95247: e => {
            e.exports = {
                wrap: "wrap-3FnlLKfX",
                titleWrap: "titleWrap-3FnlLKfX",
                indicators: "indicators-3FnlLKfX",
                title: "title-3FnlLKfX",
                icon: "icon-3FnlLKfX",
                text: "text-3FnlLKfX",
                titleTabletSmall: "titleTabletSmall-3FnlLKfX",
                labelRow: "labelRow-3FnlLKfX",
                label: "label-3FnlLKfX"
            }
        },
        11597: e => {
            e.exports = {
                labelRow: "labelRow-2noQNU_F",
                toolbox: "toolbox-2noQNU_F",
                description: "description-2noQNU_F",
                descriptionTabletSmall: "descriptionTabletSmall-2noQNU_F",
                item: "item-2noQNU_F",
                titleItem: "titleItem-2noQNU_F",
                titleItemTabletSmall: "titleItemTabletSmall-2noQNU_F",
                itemTabletSmall: "itemTabletSmall-2noQNU_F",
                itemLabelTabletSmall: "itemLabelTabletSmall-2noQNU_F",
                wrap: "wrap-2noQNU_F",
                hovered: "hovered-2noQNU_F"
            }
        },
        76755: e => {
            e.exports = {
                menu: "menu-N-Iyk8ip",
                menuSmallTablet: "menuSmallTablet-N-Iyk8ip",
                menuItemHeaderTabletSmall: "menuItemHeaderTabletSmall-N-Iyk8ip",
                menuItemHeader: "menuItemHeader-N-Iyk8ip"
            }
        },
        29377: e => {
            e.exports = {
                wrap: "wrap-13GsG5XA",
                full: "full-13GsG5XA",
                first: "first-13GsG5XA",
                last: "last-13GsG5XA",
                medium: "medium-13GsG5XA",
                buttonWithFavorites: "buttonWithFavorites-13GsG5XA"
            }
        },
        51463: e => {
            e.exports = {
                icon: "icon-1sGQ7NAX"
            }
        },
        839: e => {
            e.exports = {
                buttonUndo: "buttonUndo-nGqa616C",
                buttonRedo: "buttonRedo-nGqa616C"
            }
        },
        32455: e => {
            e.exports = {
                "tablet-normal-breakpoint": "screen and (max-width: 768px)",
                "small-height-breakpoint": "screen and (max-height: 360px)",
                "tablet-small-breakpoint": "screen and (max-width: 428px)"
            }
        },
        84856: e => {
            e.exports = {
                footer: "footer-3r-9t_XG"
            }
        },
        4654: e => {
            e.exports = {
                dottedCloud: "dottedCloud-3RnJMRVd",
                check: "check-3RnJMRVd",
                spinningCloud: "spinningCloud-3RnJMRVd",
                arrow: "arrow-3RnJMRVd",
                arrowGap: "arrowGap-3RnJMRVd",
                container: "container-3RnJMRVd",
                unsaved: "unsaved-3RnJMRVd",
                hovered: "hovered-3RnJMRVd",
                saving: "saving-3RnJMRVd",
                saved: "saved-3RnJMRVd"
            }
        },
        69560: e => {
            e.exports = {
                favorite: "favorite-I_fAY9V2",
                disabled: "disabled-I_fAY9V2",
                active: "active-I_fAY9V2",
                checked: "checked-I_fAY9V2"
            }
        },
        15169: e => {
            e.exports = {
                button: "button-3B9fDLtm",
                disabled: "disabled-3B9fDLtm",
                active: "active-3B9fDLtm",
                hidden: "hidden-3B9fDLtm"
            }
        },
        37861: (e, t, a) => {
            "use strict";
            a.d(t, {
                useIsMounted: () => i
            });
            var n = a(67294);
            const i = () => {
                const e = (0, n.useRef)(!1);
                return (0, n.useEffect)(() => (e.current = !0, () => {
                    e.current = !1
                }), []), e
            }
        },
        73226: (e, t, a) => {
            "use strict";
            a.d(t, {
                Loader: () => h
            });
            var n, i = a(67294),
                s = a(94184),
                o = a(8596),
                l = a(33214),
                r = a.n(l);
            ! function(e) {
                e[e.Initial = 0] = "Initial",
                    e[e.Appear = 1] = "Appear", e[e.Active = 2] = "Active"
            }(n || (n = {}));
            class h extends i.PureComponent {
                constructor(e) {
                    super(e), this._stateChangeTimeout = null, this.state = {
                        state: n.Initial
                    }
                }
                render() {
                    const {
                        className: e,
                        color: t = "black",
                        staticPosition: a
                    } = this.props, n = s(r().item, {
                        [r()[t]]: Boolean(t)
                    });
                    return i.createElement("span", {
                        className: s(r().loader, a && r().static, e, this._getStateClass())
                    }, i.createElement("span", {
                        className: n
                    }), i.createElement("span", {
                        className: n
                    }), i.createElement("span", {
                        className: n
                    }))
                }
                componentDidMount() {
                    this.setState({
                        state: n.Appear
                    }), this._stateChangeTimeout = setTimeout(() => {
                        this.setState({
                            state: n.Active
                        })
                    }, 2 * o.dur)
                }
                componentWillUnmount() {
                    this._stateChangeTimeout && (clearTimeout(this._stateChangeTimeout), this._stateChangeTimeout = null)
                }
                _getStateClass() {
                    switch (this.state.state) {
                        case n.Initial:
                            return r()["loader-initial"];
                        case n.Appear:
                            return r()["loader-appear"];
                        default:
                            return ""
                    }
                }
            }
        },
        74818: (e, t, a) => {
            "use strict";

            function n(e) {
                return s(e, o)
            }

            function i(e) {
                return s(e, l)
            }

            function s(e, t) {
                const a = Object.entries(e).filter(t),
                    n = {};
                for (const [e, t] of a) n[e] = t;
                return n
            }

            function o(e) {
                const [t, a] = e;
                return 0 === t.indexOf("data-") && "string" == typeof a
            }

            function l(e) {
                return 0 === e[0].indexOf("aria-")
            }
            a.d(t, {
                filterDataProps: () => n,
                filterAriaProps: () => i,
                filterProps: () => s,
                isDataAttribute: () => o,
                isAriaAttribute: () => l
            })
        },
        99055: (e, t, a) => {
            "use strict";
            a.d(t, {
                CollapsibleSection: () => r
            });
            var n = a(67294),
                i = a(94184),
                s = a.n(i),
                o = a(88262),
                l = a(72227);

            function r(e) {
                return n.createElement(n.Fragment, null, n.createElement("div", {
                    className: s()(e.className, l.summary),
                    onClick: function() {
                        e.onStateChange && e.onStateChange(!e.open)
                    },
                    "data-open": e.open
                }, e.summary, n.createElement(o.ToolWidgetCaret, {
                    className: l.caret,
                    dropped: Boolean(e.open)
                })), e.open && e.children)
            }
        },
        84264: (e, t, a) => {
            "use strict";
            a.d(t, {
                DEFAULT_MENU_ITEM_SWITCHER_THEME: () => u,
                MenuItemSwitcher: () => m
            });
            var n = a(67294),
                i = a(94184),
                s = a.n(i),
                o = a(6920),
                l = a.n(o);

            function r(e) {
                const {
                    className: t = "",
                    intent: a = "default",
                    size: n = "small",
                    disabled: s
                } = e;
                return i(t, l().switcherWrapper, l()["size-" + n], !s && l()["intent-" + a])
            }
            class h extends n.PureComponent {
                render() {
                    const {
                        reference: e,
                        size: t,
                        intent: a,
                        ...s
                    } = this.props, o = i(l().input, -1 !== this.props.tabIndex && l().focus);
                    return n.createElement("div", {
                        className: r(this.props)
                    }, n.createElement("input", { ...s,
                        type: "checkbox",
                        className: o,
                        ref: e
                    }), n.createElement("div", {
                        className: l().switcherThumbWrapper
                    }, n.createElement("div", {
                        className: l().switcherTrack
                    }), n.createElement("div", {
                        className: l().switcherThumb
                    })))
                }
            }
            var c = a(74818),
                d = a(79948);
            const u = d;

            function m(e) {
                const {
                    className: t,
                    checked: a,
                    id: i,
                    label: o,
                    labelDescription: l,
                    value: r,
                    preventLabelHighlight: u,
                    reference: m,
                    switchReference: p,
                    theme: v = d,
                    disabled: g
                } = e, b = s()(v.label, a && !u && v.labelOn), S = s()(t, v.wrapper, a && v.wrapperWithOnLabel);
                return n.createElement("label", {
                    className: S,
                    htmlFor: i,
                    ref: m
                }, n.createElement("div", {
                    className: v.labelRow
                }, n.createElement("div", {
                    className: b
                }, o), l && n.createElement("div", {
                    className: v.labelHint
                }, l)), n.createElement(h, {
                    disabled: g,
                    className: v.switch,
                    reference: p,
                    checked: a,
                    onChange: function(t) {
                        const a = t.target.checked;
                        void 0 !== e.onChange && e.onChange(a)
                    },
                    value: r,
                    tabIndex: -1,
                    id: i,
                    ...(0, c.filterDataProps)(e)
                }))
            }
        },
        45650: (e, t, a) => {
            "use strict";
            a.d(t, {
                ToolWidgetIconButton: () => l
            });
            var n = a(67294),
                i = a(94184),
                s = a(47218),
                o = a(27754);
            const l = n.forwardRef((e, t) => {
                const {
                    className: a,
                    id: l,
                    ...r
                } = e;
                return n.createElement(s.ToolWidgetButton, {
                    "data-name": l,
                    ...r,
                    ref: t,
                    className: i(a, o.button)
                })
            })
        },
        24084: (e, t, a) => {
            "use strict";
            a.d(t, {
                INTERVALS: () => i
            });
            var n = a(79881);
            const i = [{
                name: "",
                label: (0, n.t)("minutes", {
                    context: "interval"
                })
            }, {
                name: "H",
                label: (0, n.t)("hours", {
                    context: "interval"
                })
            }, {
                name: "D",
                label: (0, n.t)("days", {
                    context: "interval"
                })
            }, {
                name: "W",
                label: (0, n.t)("weeks", {
                    context: "interval"
                })
            }, {
                name: "M",
                label: (0, n.t)("months", {
                    context: "interval"
                })
            }]
        },
        40916: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                getRestrictedToolSet: () => nn
            });
            var n = a(27490),
                i = a(67294),
                s = a(45697),
                o = a(79881),
                l = a(24287),
                r = a(74645),
                h = a(1495),
                c = a(65043),
                d = a(49775),
                u = a(95860),
                m = a(67842),
                p = a(94184),
                v = a.n(p),
                g = a(38733);
            class b extends i.PureComponent {
                render() {
                    const {
                        children: e,
                        className: t,
                        ...a
                    } = this.props;
                    return i.createElement("div", {
                        className: p(t, g.wrap),
                        ...a
                    }, e)
                }
            }
            var S = a(47218),
                C = a(74818),
                _ = a(67177);
            class w extends i.PureComponent {
                constructor() {
                    super(...arguments), this._handleClick = () => {
                        const {
                            onClick: e,
                            onClickArg: t
                        } = this.props;
                        e && e(t)
                    }
                }
                render() {
                    const {
                        isFirst: e,
                        isLast: t,
                        hint: a,
                        text: n,
                        icon: s,
                        isActive: o,
                        isDisabled: l,
                        className: r
                    } = this.props, h = (0, C.filterDataProps)(this.props);
                    return i.createElement(S.ToolWidgetButton, { ...h,
                        icon: s,
                        text: n,
                        title: a,
                        isDisabled: l,
                        isActive: o,
                        isGrouped: !0,
                        onClick: this._handleClick,
                        className: p(r, _.button, {
                            [_.first]: e,
                            [_.last]: t
                        })
                    })
                }
            }
            var f = a(10869),
                y = a(68521),
                k = a(72923),
                M = a(82879),
                E = a(53178),
                T = a(96675),
                x = a(55632);
            const I = {
                0: (0, o.t)("Bars"),
                1: (0, o.t)("Candles"),
                9: (0, o.t)("Hollow candles"),
                8: (0, o.t)("Heikin Ashi"),
                2: (0, o.t)("Line"),
                3: (0, o.t)("Area"),
                10: (0, o.t)("Baseline"),
                12: (0, o.t)("High-low")
            };
            const A = {
                    barsStyle: (0, o.t)("Bar's style"),
                    labels: I
                },
                N = (0, E.registryContextType)();

            function R(e) {
                var t;
                return !(null === (t = l.linking.supportedChartStyles.value()) || void 0 === t ? void 0 : t.includes(e))
            }
            class F extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleChangeStyle = e => {
                        const {
                            favorites: t,
                            lastSelectedNotFavorite: a,
                            activeStyle: n
                        } = this.state;
                        this.setState({
                            activeStyle: e,
                            lastSelectedNotFavorite: t.includes(n) ? a : n
                        })
                    }, this._handleSelectStyle = e => {
                        const {
                            chartWidgetCollection: t
                        } = this.context;
                        e !== t.activeChartStyle.value() && t.setChartStyleToWidget(e)
                    }, this._handleClickFavorite = e => {
                        this._isStyleFavorited(e) ? this._handleRemoveFavorite(e) : this._handleAddFavorite(e)
                    }, this._boundForceUpdate = () => {
                        this.forceUpdate()
                    }, this._handleQuickClick = e => {
                        this._handleSelectStyle(e), this._trackClick()
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired,
                        favoriteChartStylesService: s.any.isRequired
                    });
                    const {
                        chartWidgetCollection: a,
                        favoriteChartStylesService: n
                    } = t, i = a.activeChartStyle.value(), o = n.get(), l = (0, T.japaneseChartStyles)();
                    this.state = {
                        activeStyle: i,
                        favorites: o,
                        styles: (0, T.commonChartStyles)(),
                        japaneseStyles: l
                    }
                }
                componentDidMount() {
                    const {
                        chartWidgetCollection: e,
                        favoriteChartStylesService: t
                    } = this.context;
                    e.activeChartStyle.subscribe(this._handleChangeStyle), t.getOnChange().subscribe(this, this._handleChangeSettings), l.linking.supportedChartStyles.subscribe(this._boundForceUpdate)
                }
                componentWillUnmount() {
                    const {
                        chartWidgetCollection: e,
                        favoriteChartStylesService: t
                    } = this.context;
                    e.activeChartStyle.unsubscribe(this._handleChangeStyle), t.getOnChange().unsubscribe(this, this._handleChangeSettings), l.linking.supportedChartStyles.unsubscribe(this._boundForceUpdate)
                }
                render() {
                    const {
                        isShownQuicks: e,
                        displayMode: t = "full",
                        id: a
                    } = this.props, {
                        activeStyle: n,
                        favorites: s,
                        styles: o,
                        japaneseStyles: l,
                        lastSelectedNotFavorite: c
                    } = this.state, u = "small" !== t && e && 0 !== s.length, p = [...s];
                    p.includes(n) ? void 0 !== c && p.push(c) : p.push(n);
                    const v = u && p.length > 1;
                    return i.createElement(y.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, e => {
                        const t = o.map(t => this._renderPopupMenuItem(t, t === n, e)),
                            s = l.map(t => this._renderPopupMenuItem(t, t === n, e));
                        return i.createElement(b, {
                            id: a
                        }, v && p.map((e, t) => i.createElement(w, {
                            className: x.button,
                            icon: h.SERIES_ICONS[e],
                            isActive: u && n === e,
                            isDisabled: R(e),
                            key: t,
                            hint: A.labels[e],
                            isFirst: 0 === t,
                            isLast: t === p.length - 1,
                            onClick: u ? this._handleQuickClick : void 0,
                            onClickArg: e,
                            "data-value": r.STYLE_SHORT_NAMES[e]
                        })), i.createElement(m.ToolWidgetMenu, {
                            arrow: Boolean(v),
                            content: v ? void 0 : i.createElement(b, null, i.createElement(d.Icon, {
                                icon: h.SERIES_ICONS[n]
                            })),
                            title: v ? A.barsStyle : A.labels[n],
                            className: x.menu,
                            isDrawer: e,
                            onClick: this._trackClick
                        }, t, !!s.length && i.createElement(f.PopupMenuSeparator, null), s))
                    })
                }
                _renderPopupMenuItem(e, t, a) {
                    const {
                        isFavoritingAllowed: n
                    } = this.props, s = this._isStyleFavorited(e);
                    return i.createElement(u.PopupMenuItem, {
                        key: e,
                        theme: a ? M.multilineLabelWithIconAndToolboxTheme : void 0,
                        icon: h.SERIES_ICONS[e],
                        isActive: t,
                        isDisabled: R(e),
                        label: A.labels[e] || "",
                        onClick: this._handleSelectStyle,
                        onClickArg: e,
                        showToolboxOnHover: !s,
                        toolbox: n && i.createElement(c.FavoriteButton, {
                            isActive: t,
                            isFilled: s,
                            onClick: () => this._handleClickFavorite(e)
                        }),
                        "data-value": r.STYLE_SHORT_NAMES[e]
                    })
                }
                _handleChangeSettings(e) {
                    this.setState({
                        lastSelectedNotFavorite: void 0,
                        favorites: e
                    })
                }
                _isStyleFavorited(e) {
                    return -1 !== this.state.favorites.indexOf(e)
                }
                _handleAddFavorite(e) {
                    const {
                        favorites: t
                    } = this.state, {
                        favoriteChartStylesService: a
                    } = this.context;
                    a.set([...t, e])
                }
                _handleRemoveFavorite(e) {
                    const {
                        favorites: t
                    } = this.state, {
                        favoriteChartStylesService: a
                    } = this.context;
                    a.set(t.filter(t => t !== e))
                }
                _trackClick() {
                    0
                }
            }
            F.contextType = N;
            var z = a(35375);
            const H = ["medium", "small"];

            function L(e) {
                const {
                    text: t,
                    className: a,
                    displayMode: n,
                    collapseWhen: s = H,
                    ...o
                } = e, l = !s.includes(n);
                return i.createElement(S.ToolWidgetButton, { ...o,
                    text: l ? t : void 0,
                    className: p(a, z.button, l ? z.withText : z.withoutText)
                })
            }
            var D = a(87438),
                P = a(19470),
                W = a(84022);
            const O = {
                    compare: (0, o.t)("Compare"),
                    compareOrAddSymbol: (0, o.t)("Compare or Add Symbol")
                },
                U = (0, E.registryContextType)();
            class B extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._updateState = e => {
                        this.setState({
                            isActive: e
                        })
                    }, this._handleClick = () => {
                        var e;
                        (0,
                            D.trackEvent)("GUI", "Chart Header Toolbar", "compare"), null === (e = this._compareDialogRenderer) || void 0 === e || e.show()
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired
                    }), this.state = {
                        isActive: !1
                    }, this._compareDialogRenderer = this.context.chartWidgetCollection.getCompareDialogRenderer()
                }
                componentDidMount() {
                    var e;
                    null === (e = this._compareDialogRenderer) || void 0 === e || e.visible().subscribe(this._updateState)
                }
                componentWillUnmount() {
                    var e;
                    null === (e = this._compareDialogRenderer) || void 0 === e || e.visible().unsubscribe(this._updateState)
                }
                render() {
                    const {
                        isActive: e
                    } = this.state;
                    return i.createElement(L, { ...this.props,
                        icon: W,
                        isOpened: e,
                        onClick: this._handleClick,
                        text: P.hasNewHeaderToolbarStyles ? void 0 : O.compare,
                        title: O.compareOrAddSymbol,
                        collapseWhen: P.hasNewHeaderToolbarStyles ? ["full", "medium", "small"] : void 0
                    })
                }
            }
            B.contextType = U;
            var V = a(45650),
                K = a(19598),
                G = a(42998),
                q = a(72061),
                X = a(58448);
            const Q = {
                    hint: (0, o.t)("Fullscreen mode")
                },
                Z = (0, K.hotKeySerialize)({
                    keys: [(0, G.humanReadableModifiers)(G.Modifiers.Shift, !1), "F"],
                    text: "{0} + {1}"
                }),
                j = (0, E.registryContextType)();
            class J extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidgetCollection: e
                        } = this.context;
                        e.startFullscreen()
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e,
                        id: t
                    } = this.props;
                    return i.createElement(V.ToolWidgetIconButton, {
                        id: t,
                        icon: P.hasNewHeaderToolbarStyles ? X : q,
                        onClick: this._handleClick,
                        title: Q.hint,
                        className: p(e),
                        "data-tooltip-hotkey": Z
                    })
                }
            }
            J.contextType = j;
            var $ = a(16282);
            const Y = (0, a(65447).getLogger)("FavoritesInfo");

            function ee(e, t) {
                if (0 === e.length) return Promise.resolve([]);
                Y.logNormal("Requesting favorites info");
                const a = [],
                    n = new Map,
                    i = new Map,
                    s = new Map;
                return e.forEach(e => {
                    switch (e.type) {
                        case "java":
                            s.set(e.studyId, e);
                            break;
                        case "pine":
                            isPublishedPineId(e.pineId) ? n.set(e.pineId, e) : i.set(e.pineId, e);
                            break;
                        default:
                            (0, $.assert)(!1, "unknown favorite type " + JSON.stringify(e))
                    }
                }), 0 !== s.size && a.push(t.findAllJavaStudies().then(e => {
                    const t = new Map;
                    for (const a of e) !a.is_hidden_study && s.has(a.id) && t.set(a.id, {
                        name: a.description,
                        localizedName: a.description_localized,
                        studyMarketShittyObject: a
                    });
                    return t
                }).then(e => {
                    const t = function(e, t) {
                        const a = {
                            items: [],
                            notFoundItems: []
                        };
                        return e.forEach((e, n) => {
                            const i = t.get(n);
                            void 0 !== i ? a.items.push({
                                item: e,
                                info: i
                            }) : a.notFoundItems.push(e)
                        }), a
                    }(s, e);
                    if (0 !== t.notFoundItems.length) {
                        const e = t.notFoundItems.map(e => e.studyId);
                        Y.logWarn("Cannot find java scripts: " + JSON.stringify(e))
                    }
                    return t.items
                })), Promise.all(a).then(e => (Y.logNormal("Requesting favorites info finished"), e.reduce((e, t) => e.concat(t), [])))
            }
            var te = a(67945),
                ae = a(15521),
                ne = a(73226),
                ie = a(75996);

            function se(e) {
                const {
                    className: t
                } = e;
                return i.createElement("div", {
                    className: v()(ie.spinnerWrap, t)
                }, i.createElement(ne.Loader, null))
            }
            var oe = a(8809);

            function le(e) {
                return i.createElement("div", {
                    className: p(e.className, oe.title)
                }, e.children)
            }
            a(67869);
            var re = a(18437),
                he = a(60226),
                ce = a(55879);
            const de = {
                    text: (0, o.t)("Indicators"),
                    hint: (0, o.t)("Indicators & Strategies"),
                    favorites: (0, o.t)("Favorites")
                },
                ue = (0,
                    K.hotKeySerialize)({
                    keys: ["/"],
                    text: "{0}"
                }),
                me = (0, E.registryContextType)();
            class pe extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._promise = null, this._menu = i.createRef(), this._favoriteFundamentalsModel = null, this._setActiveState = e => {
                        this.setState({
                            isActive: e
                        })
                    }, this._handleClick = () => {
                        const {
                            studyMarket: e
                        } = this.props;
                        this.setState({
                            isActive: !0
                        }, () => {
                            e.visible().value() ? e.hide() : e.show()
                        }), this._trackClick()
                    }, this._handleSelectIndicator = e => {
                        e = (0, $.ensureDefined)(e), this._trackFavoriteAction("Favorite indicator from toolbar");
                        const {
                            chartWidgetCollection: t
                        } = this.context;
                        if ("java" === e.type) {
                            const t = (0, te.tryFindStudyLineToolNameByStudyId)(e.studyId);
                            if (null !== t) return void ae.tool.setValue(t)
                        }
                        t.activeChartWidget.value().insertStudy(e)
                    }, this._handleFavoriteIndicatorsChange = () => {
                        const {
                            favoriteScriptsModel: e
                        } = this.context, t = [...(0, $.ensureDefined)(e).favorites()];
                        this.setState({
                            favorites: t
                        }), this._clearCache()
                    }, this._handleFavoriteFundamentalsChange = () => {
                        var e;
                        const t = new Set((null === (e = this._favoriteFundamentalsModel) || void 0 === e ? void 0 : e.favorites()) || []);
                        this.setState({
                            favoriteFundamentals: t
                        }), this._clearCache()
                    }, this._handleMouseEnter = () => {
                        this._prefetchFavorites()
                    }, this._handleWrapClick = () => {
                        this._prefetchFavorites()
                    }, this._handleChangeActiveWidget = () => {
                        this._clearCache()
                    }, this._clearCache = () => {
                        this._promise = null, this.setState({
                            infos: []
                        })
                    }, this._handleScriptRenamed = e => {
                        const {
                            favoriteScriptsModel: t
                        } = this.context;
                        void 0 !== t && t.isFav(e.scriptIdPart) && this._clearCache()
                    }, this._handleFavoriteMenuClick = () => {
                        this._trackClick(), this._trackFavoriteAction("Select favorite indicators dropdown")
                    }, (0, E.validateRegistry)(t, {
                        favoriteScriptsModel: s.any,
                        chartWidgetCollection: s.any.isRequired
                    });
                    const {
                        favoriteScriptsModel: a
                    } = t, n = void 0 !== a ? a.favorites() : [];
                    this.state = {
                        isActive: !1,
                        isLoading: !1,
                        favorites: n,
                        favoriteFundamentals: void 0,
                        infos: []
                    }
                }
                componentDidMount() {
                    const {
                        studyMarket: e
                    } = this.props, {
                        favoriteScriptsModel: t,
                        chartWidgetCollection: a
                    } = this.context;
                    e.visible().subscribe(this._setActiveState), void 0 !== t && (t.favoritesChanged().subscribe(this, this._handleFavoriteIndicatorsChange), a.activeChartWidget.subscribe(this._handleChangeActiveWidget)), re.on("TVScriptRenamed", this._handleScriptRenamed, null)
                }
                componentWillUnmount() {
                    const {
                        studyMarket: e
                    } = this.props, {
                        favoriteScriptsModel: t,
                        chartWidgetCollection: a
                    } = this.context;
                    e.visible().unsubscribe(this._setActiveState), void 0 !== t && (t.favoritesChanged().unsubscribe(this, this._handleFavoriteIndicatorsChange), a.activeChartWidget.unsubscribe(this._handleChangeActiveWidget)), re.unsubscribe("TVScriptRenamed", this._handleScriptRenamed, null), this._promise = null
                }
                render() {
                    const {
                        isActive: e,
                        favorites: t,
                        favoriteFundamentals: a,
                        isLoading: n
                    } = this.state, {
                        className: s,
                        displayMode: l,
                        id: r,
                        isFake: h,
                        isAuthenticated: c
                    } = this.props, {
                        chartWidgetCollection: d
                    } = this.context;
                    return i.createElement(i.Fragment, null, i.createElement(b, {
                        id: r,
                        onMouseEnter: this._handleMouseEnter,
                        onClick: this._handleWrapClick
                    }, i.createElement(L, {
                        displayMode: l,
                        className: s,
                        icon: he,
                        isOpened: e,
                        onClick: this._handleClick,
                        text: de.text,
                        title: de.hint,
                        "data-role": "button",
                        "data-name": "open-indicators-dialog",
                        "data-tooltip-hotkey": ue
                    }), Boolean(t.length > 0 || (null == a ? void 0 : a.size)) && i.createElement(y.MatchMedia, {
                        rule: "screen and (max-width: 428px)"
                    }, e => i.createElement(m.ToolWidgetMenu, {
                        key: d.activeChartWidget.value().id(),
                        arrow: !0,
                        closeOnClickOutside: !0,
                        isDrawer: e,
                        drawerPosition: "Bottom",
                        title: de.favorites,
                        ref: this._menu,
                        onClick: this._handleFavoriteMenuClick,
                        "data-name": "show-favorite-indicators"
                    }, i.createElement("div", {
                        className: v()(ce.dropdown, e && ce.smallWidthWrapper)
                    }, i.createElement(le, {
                        className: e && ce.smallWidthTitle
                    }, (0, o.t)("Favorite Indicators")), n && i.createElement(se, null), !n && i.createElement(i.Fragment, null, this.state.infos.length > 0 ? this.state.infos.map(t => i.createElement(u.PopupMenuItem, {
                        className: v()(e && ce.smallWidthMenuItem),
                        theme: e ? M.multilineLabelWithIconAndToolboxTheme : void 0,
                        key: "java" === t.item.type ? t.item.studyId : t.item.pineId,
                        onClick: this._handleSelectIndicator,
                        onClickArg: t.item,
                        label: i.createElement("span", {
                            className: v()(!e && ce.label, e && ce.smallWidthLabel, "apply-overflow-tooltip")
                        }, ve(t))
                    })) : null !== this._promise && i.createElement(u.PopupMenuItem, {
                        isDisabled: !0,
                        label: (0, o.t)("You have no Favorites Indicators yet")
                    })))))), !h && c && !1)
                }
                _prefetchFavorites() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    if (null !== this._promise || !window.is_authenticated) return;
                    const t = e.activeChartWidget.value();
                    if (!t.hasModel()) return;
                    const a = t.model().model().studyMetaInfoRepository();
                    this.setState({
                        isLoading: !0
                    });
                    const n = this._promise = Promise.all([ee(this.state.favorites, a), void 0]).then(e => {
                        if (n !== this._promise) return;
                        const [t, a] = e;
                        let i = [...t];
                        if (a) {
                            const e = a.filter(e => {
                                var t;
                                return null === (t = this.state.favoriteFundamentals) || void 0 === t ? void 0 : t.has(e.scriptIdPart)
                            }).map(this._mapFundamentalToFavoriteItemInfo);
                            i.push(...e)
                        }
                        i = [...i].sort((e, t) => ve(e).localeCompare(ve(t))), this.setState({
                            infos: i,
                            isLoading: !1
                        }, () => {
                            this._menu.current && this._menu.current.update()
                        })
                    })
                }
                _trackClick() {
                    0
                }
                _trackFavoriteAction(e) {
                    (0, D.trackEvent)("GUI", "Chart Header Toolbar", e)
                }
                _mapFundamentalToFavoriteItemInfo(e) {
                    return {
                        item: {
                            type: "pine",
                            pineId: e.scriptIdPart
                        },
                        info: {
                            name: e.scriptName,
                            localizedName: getLocalizedFundamentalsName(e),
                            studyMarketShittyObject: void 0
                        }
                    }
                }
            }

            function ve(e) {
                return e.info.localizedName || (0, o.t)(e.info.name, {
                    context: "study"
                })
            }
            pe.contextType = me;
            var ge = a(1467),
                be = a(35001),
                Se = a(72017);

            function Ce(e) {
                return i.createElement("div", {
                    className: p(Se.value, {
                        [Se.selected]: e.isSelected
                    })
                }, e.value, e.metric)
            }
            var _e = a(76420),
                we = a(88262),
                fe = a(24084),
                ye = a(28199);
            class ke extends i.PureComponent {
                constructor(e) {
                    super(e), this._timeMenu = null, this._setMenuRef = e => {
                        this._timeMenu = e
                    }, this._handleChangeInput = e => {
                        const {
                            value: t
                        } = e.currentTarget;
                        /^[0-9]*$/.test(t) && this.setState({
                            inputValue: t
                        })
                    }, this._handleSelectTime = e => {
                        this.setState({
                            selectedIntervalSuffix: e
                        }), this._closeMenu()
                    }, this._handleClickAdd = () => {
                        const {
                            inputValue: e,
                            selectedIntervalSuffix: t
                        } = this.state;
                        this.props.onAdd(e, t)
                    }, this._toggleMenu = () => {
                        this.state.isOpenedMenu ? this._closeMenu() : this._openMenu()
                    }, this._closeMenu = () => {
                        this.props.onCloseMenu(), this.setState({
                            isOpenedMenu: !1
                        })
                    }, this._openMenu = () => {
                        this.props.onOpenMenu(), this.setState({
                            isOpenedMenu: !0
                        })
                    }, this._getMenuPosition = () => {
                        const e = (0, $.ensureNotNull)(this._timeMenu).getBoundingClientRect();
                        return {
                            overrideWidth: e.width,
                            x: e.left,
                            y: e.bottom + 1
                        }
                    }, this.state = {
                        inputValue: "1",
                        isOpenedMenu: !1,
                        selectedIntervalSuffix: fe.INTERVALS[0].name
                    }
                }
                render() {
                    const {
                        inputValue: e,
                        isOpenedMenu: t,
                        menuWidth: a,
                        selectedIntervalSuffix: n
                    } = this.state;
                    return i.createElement("div", {
                        className: p(ye.form, {
                            [ye.interacting]: t
                        })
                    }, i.createElement("input", {
                        className: ye.input,
                        maxLength: 7,
                        onChange: this._handleChangeInput,
                        value: e
                    }), i.createElement("div", {
                        className: ye.menu,
                        onClick: this._toggleMenu,
                        ref: this._setMenuRef
                    }, fe.INTERVALS.find(e => e.name === n).label, i.createElement(we.ToolWidgetCaret, {
                        dropped: t
                    })), i.createElement("div", {
                        className: ye.add,
                        onClick: this._handleClickAdd
                    }, (0, o.t)("Add")), i.createElement(_e.PopupMenu, {
                        doNotCloseOn: this,
                        isOpened: t,
                        minWidth: a,
                        onClose: this._closeMenu,
                        position: this._getMenuPosition
                    }, fe.INTERVALS.map(e => i.createElement(u.PopupMenuItem, {
                        dontClosePopup: !0,
                        key: e.name,
                        label: e.label,
                        onClick: this._handleSelectTime,
                        onClickArg: e.name
                    }))))
                }
            }
            var Me = a(14303),
                Ee = a(11086),
                Te = a(96404),
                xe = a(13097);

            function Ie(e) {
                const {
                    interval: t,
                    hint: a,
                    isActive: n,
                    isDisabled: s,
                    isFavorite: o,
                    isSignaling: l,
                    onClick: r,
                    onClickRemove: h,
                    onClickFavorite: d,
                    isSmallTablet: m
                } = e, p = (0, C.filterDataProps)(e), [g, b] = (0, Ee.useHover)(), S = i.useCallback(() => h(t), [h, t]), _ = i.useCallback(() => d(t), [d, t]), w = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    var e;
                    l && m && (null === (e = w.current) || void 0 === e || e.scrollIntoView())
                }, [l, m]), i.createElement("div", { ...b,
                    ref: w
                }, i.createElement(u.PopupMenuItem, { ...p,
                    className: v()(m && xe.smallWidthMenuItem),
                    theme: m ? M.multilineLabelWithIconAndToolboxTheme : void 0,
                    isActive: n,
                    isDisabled: s,
                    isHovered: l,
                    onClick: r,
                    onClickArg: t,
                    toolbox: function() {
                        const {
                            isRemovable: t,
                            isFavoritingAllowed: a
                        } = e, l = i.createElement(Me.RemoveButton, {
                            key: "remove",
                            isActive: n,
                            hidden: !Te.touch && !g,
                            onClick: S
                        }), r = i.createElement(c.FavoriteButton, {
                            key: "favorite",
                            isActive: n,
                            isFilled: o,
                            onClick: _
                        });
                        return [t && l, !s && a && r]
                    }(),
                    showToolboxOnHover: !o,
                    label: a
                }))
            }
            const Ae = {
                [be.ResolutionKind.Ticks]: (0, o.t)("Ticks", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Seconds]: (0, o.t)("Seconds", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Minutes]: (0, o.t)("Minutes", {
                    context: "interval_group_name"
                }),
                [be.SpecialResolutionKind.Hours]: (0, o.t)("Hours", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Days]: (0, o.t)("Days", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Weeks]: (0, o.t)("Weeks", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Months]: (0, o.t)("Months", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Range]: (0, o.t)("Ranges", {
                    context: "interval_group_name"
                }),
                [be.ResolutionKind.Invalid]: ""
            };

            function Ne(e, t = !1) {
                return {
                    id: e,
                    name: Ae[e],
                    items: [],
                    mayOmitSeparator: t
                }
            }
            var Re = a(99055),
                Fe = a(5729),
                ze = a.n(Fe),
                He = a(94884),
                Le = a(79424),
                De = a(76864);
            const Pe = {
                    openDialog: (0, o.t)("Open Interval Dialog"),
                    timeInterval: (0, o.t)("Time Interval")
                },
                We = (0, K.hotKeySerialize)({
                    keys: [","],
                    text: (0, o.t)("Number or {hotKey_0}")
                }),
                Oe = (0, E.registryContextType)(),
                Ue = new(ze()),
                Be = i.lazy(async () => ({
                    default: (await Promise.all([a.e(7039), a.e(4595), a.e(5698), a.e(4078), a.e(8193), a.e(9602), a.e(2778), a.e(8856), a.e(2402), a.e(3590), a.e(1829), a.e(7591), a.e(2391), a.e(4013)]).then(a.bind(a, 84954))).ToolWidgetIntervalsAddDialog
                }));

            function Ve(e) {
                {
                    const t = be.Interval.parse(e);
                    if (!(0, ge.isSecondsEnabled)() && t.isSeconds()) return !1;
                    if (!(0, ge.isTicksEnabled)() && t.isTicks()) return !1
                }
                return !0
            }
            class Ke extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._menu = i.createRef(), this._renderChildren = (e, t) => [...this._createMenuItems(e, t), ...this._createIntervalForm(t)], this._handleChangeInterval = e => {
                        const {
                            activeInterval: t,
                            lastNotQuicked: a
                        } = this.state, n = this._getQuicks();
                        this.setState({
                            activeInterval: (0, ge.normalizeIntervalString)(e),
                            lastNotQuicked: void 0 === t || n.includes(t) ? a : t
                        })
                    }, this._bindedForceUpdate = () => {
                        this.forceUpdate()
                    }, this._handleCloseMenu = () => {
                        this.setState({
                            isOpenedFormMenu: !1
                        })
                    }, this._handleOpenMenu = () => {
                        this.setState({
                            isOpenedFormMenu: !0
                        })
                    }, this._handleSelectInterval = e => {
                        void 0 !== e && e !== l.linking.interval.value() && this.context.chartWidgetCollection.setResolution(e), e && (0, D.trackEvent)("GUI", "Time Interval", e)
                    }, this._handleClickFavorite = e => {
                        e = (0, $.ensureDefined)(e), this._isIntervalFavorite(e) ? this._handleRemoveFavorite(e) : this._handleAddFavorite(e)
                    }, this._handleAddFavorite = e => {
                        const {
                            favorites: t
                        } = this.state;
                        this.context.favoriteIntervalsService.set([...t, e])
                    }, this._handleRemoveFavorite = e => {
                        const {
                            favorites: t
                        } = this.state;
                        this.context.favoriteIntervalsService.set(t.filter(t => t !== e))
                    }, this._handleAddInterval = (e, t) => {
                        const {
                            intervalService: a
                        } = this.context, n = a.add(e, t);
                        n && this.setState({
                            lastAddedInterval: n
                        })
                    }, this._handleRemoveInterval = e => {
                        const {
                            intervalService: t
                        } = this.context;
                        e && (t.remove(e), this._handleRemoveFavorite(e))
                    }, this._getHandleSectionStateChange = e => t => {
                        const {
                            menuViewState: a
                        } = this.state, {
                            intervalsMenuViewStateService: n
                        } = this.context;
                        n.set({ ...a,
                            [e]: !t
                        })
                    }, this._handleOpenAddIntervalDialog = () => {
                        this.setState({
                            isAddIntervalDialogOpened: !0
                        })
                    }, this._handleCloseAddIntervalDialog = () => {
                        this.setState({
                            isAddIntervalDialogOpened: !1
                        })
                    }, this._handleGlobalClose = () => {
                        const {
                            isFake: e
                        } = this.props, {
                            isAddIntervalDialogOpened: t
                        } = this.state;
                        e || t || Ue.fire()
                    }, this._handeQuickClick = e => {
                        this._handleSelectInterval(e), this._trackClick()
                    }, (0, E.validateRegistry)(t, {
                        chartApiInstance: s.any.isRequired,
                        favoriteIntervalsService: s.any.isRequired,
                        intervalService: s.any.isRequired,
                        intervalsMenuViewStateService: s.any.isRequired
                    });
                    const {
                        chartApiInstance: a,
                        favoriteIntervalsService: o,
                        intervalService: r,
                        intervalsMenuViewStateService: h
                    } = t;
                    this._customIntervals = n.enabled("custom_resolutions");
                    const c = l.linking.interval.value(),
                        d = c && (0, ge.normalizeIntervalString)(c),
                        u = o.get(),
                        m = r.getCustomIntervals(),
                        p = h.get();
                    this._defaultIntervals = a.defaultResolutions().filter(Ve).map(ge.normalizeIntervalString), this.state = {
                        isOpenedFormMenu: !1,
                        activeInterval: d,
                        favorites: u,
                        customs: m,
                        menuViewState: p,
                        isAddIntervalDialogOpened: !1
                    }
                }
                componentDidMount() {
                    const {
                        favoriteIntervalsService: e,
                        intervalService: t,
                        intervalsMenuViewStateService: a
                    } = this.context;
                    e.getOnChange().subscribe(this, this._handleChangeFavorites), a.getOnChange().subscribe(this, this._handleChangeMenuViewState), t.getOnChange().subscribe(this, this._handleChangeCustoms), l.linking.interval.subscribe(this._handleChangeInterval), l.linking.intraday.subscribe(this._bindedForceUpdate), l.linking.seconds.subscribe(this._bindedForceUpdate), l.linking.ticks.subscribe(this._bindedForceUpdate), l.linking.range.subscribe(this._bindedForceUpdate), l.linking.supportedResolutions.subscribe(this._bindedForceUpdate), Le.globalCloseDelegate.subscribe(this, this._handleGlobalClose)
                }
                componentWillUnmount() {
                    const {
                        favoriteIntervalsService: e,
                        intervalService: t,
                        intervalsMenuViewStateService: a
                    } = this.context;
                    e.getOnChange().unsubscribe(this, this._handleChangeFavorites), a.getOnChange().unsubscribe(this, this._handleChangeMenuViewState), t.getOnChange().unsubscribe(this, this._handleChangeCustoms), l.linking.interval.unsubscribe(this._handleChangeInterval), l.linking.intraday.unsubscribe(this._bindedForceUpdate), l.linking.seconds.unsubscribe(this._bindedForceUpdate), l.linking.ticks.unsubscribe(this._bindedForceUpdate), l.linking.range.unsubscribe(this._bindedForceUpdate), l.linking.supportedResolutions.unsubscribe(this._bindedForceUpdate), Le.globalCloseDelegate.unsubscribe(this, this._handleGlobalClose)
                }
                componentDidUpdate(e, t) {
                    this.state.lastAddedInterval && setTimeout(() => this.setState({
                        lastAddedInterval: void 0
                    }), 400)
                }
                render() {
                    const {
                        isShownQuicks: e,
                        id: t
                    } = this.props, {
                        activeInterval: a,
                        customs: n,
                        lastNotQuicked: s,
                        isAddIntervalDialogOpened: o
                    } = this.state, l = this._getQuicks(), r = (0, ge.sortResolutions)([...l]);
                    void 0 !== a && r.includes(a) ? void 0 !== s && r.push(s) : void 0 !== a && r.push(a);
                    const h = (!(!e || 0 === l.length) || void 0) && r.length > 1,
                        c = {},
                        d = (0, ge.mergeResolutions)(this._defaultIntervals, n);
                    (void 0 !== a ? d.concat(a) : d).filter(ge.isAvailable).forEach(e => c[e] = !0);
                    const u = void 0 !== a ? (0, ge.getTranslatedResolutionModel)(a) : null;
                    return i.createElement(b, {
                        id: t
                    }, h && r.map((e, t) => {
                        const n = (0, ge.getTranslatedResolutionModel)(e);
                        return i.createElement(w, {
                            key: t,
                            className: p(De.button, {
                                [De.first]: 0 === t,
                                [De.last]: t === r.length - 1,
                                [De.newStyles]: P.hasNewHeaderToolbarStyles
                            }),
                            text: i.createElement(Ce, {
                                value: n.mayOmitMultiplier ? void 0 : n.multiplier,
                                metric: n.shortKind
                            }),
                            hint: n.hint,
                            isActive: a === e,
                            isDisabled: !c[e] && e !== s,
                            onClick: this._handeQuickClick,
                            onClickArg: e,
                            "data-value": e
                        })
                    }), i.createElement(y.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, e => i.createElement(i.Fragment, null, i.createElement(He.CloseDelegateContext.Provider, {
                        value: Ue
                    }, i.createElement(m.ToolWidgetMenu, {
                        arrow: Boolean(h),
                        closeOnClickOutside: !0,
                        content: h || null === u ? void 0 : i.createElement(b, {
                            className: De.menuContent
                        }, i.createElement(Ce, {
                            value: u.mayOmitMultiplier ? void 0 : u.multiplier,
                            metric: u.shortKind
                        })),
                        title: h || null === u ? Pe.timeInterval : u.hint,
                        hotKey: h ? We : void 0,
                        className: De.menu,
                        ref: this._menu,
                        isDrawer: e,
                        onClick: this._trackClick
                    }, i.createElement("div", {
                        className: De.dropdown
                    }, this._renderChildren(d, e)))), e && o && i.createElement(i.Suspense, {
                        fallback: null
                    }, i.createElement(Be, {
                        onAdd: this._handleAddInterval,
                        onClose: this._handleCloseAddIntervalDialog,
                        onUnmount: this._handleCloseAddIntervalDialog
                    })))))
                }
                _createMenuItems(e, t) {
                    const a = function(e) {
                        const t = Ne(be.ResolutionKind.Ticks),
                            a = Ne(be.ResolutionKind.Seconds),
                            n = Ne(be.ResolutionKind.Minutes),
                            i = Ne(be.SpecialResolutionKind.Hours),
                            s = Ne(be.ResolutionKind.Days),
                            o = Ne(be.ResolutionKind.Range);
                        return e.forEach(e => {
                            const l = be.Interval.parse(e);
                            l.isMinuteHours() ? i.items.push(e) : l.isMinutes() ? (0, be.isHour)(Number(l.multiplier())) ? i.items.push(e) : n.items.push(e) : l.isSeconds() ? a.items.push(e) : l.isDWM() ? s.items.push(e) : l.isRange() ? o.items.push(e) : l.isTicks() && t.items.push(e)
                        }), [t, a, n, i, s, o].filter(e => 0 !== e.items.length)
                    }(e).map((e, a, n) => this._renderResolutionsGroup(e, 1 === n.length, t));
                    return function(e) {
                        let t = !1;
                        return e.filter((e, a, n) => {
                            let i = !0;
                            return e.type === f.PopupMenuSeparator && (0 !== a && a !== n.length - 1 || (i = !1), t && (i = !1)), t = e.type === f.PopupMenuSeparator, i
                        })
                    }([].concat(...a))
                }
                _createIntervalForm(e) {
                    if (this._customIntervals) {
                        const t = e ? i.createElement("div", {
                            key: "add-dialog",
                            className: De.addCustomInterval,
                            onClick: this._handleOpenAddIntervalDialog
                        }, (0, o.t)("Add custom interval") + "…") : i.createElement(ke, {
                            key: "add-form",
                            onAdd: this._handleAddInterval,
                            onCloseMenu: this._handleCloseMenu,
                            onOpenMenu: this._handleOpenMenu
                        });
                        return [i.createElement(f.PopupMenuSeparator, {
                            key: "custom-interval-separator"
                        }), t]
                    }
                    return []
                }
                _renderResolutionsGroup(e, t = !1, a) {
                    const n = [],
                        s = e.items.map(e => this._renderPopupMenuItem(e, a));
                    if (t) n.push(...s);
                    else if (a) {
                        const t = i.createElement("div", {
                            key: e.id
                        }, i.createElement("div", {
                            className: De.smallTabletSectionTitle
                        }, e.name), s);
                        n.push(t)
                    } else {
                        const {
                            intervalsMenuViewStateService: t
                        } = this.context, {
                            menuViewState: a
                        } = this.state;
                        if (!t.isAllowed(e.id)) return [];
                        const o = i.createElement(Re.CollapsibleSection, {
                            key: e.id,
                            className: De.section,
                            summary: e.name,
                            open: !a[e.id],
                            onStateChange: this._getHandleSectionStateChange(e.id)
                        }, s);
                        n.push(o)
                    }
                    return (!e.mayOmitSeparator || e.items.length > 1) && (n.unshift(i.createElement(f.PopupMenuSeparator, {
                        key: "begin-" + e.name
                    })), n.push(i.createElement(f.PopupMenuSeparator, {
                        key: "end-" + e.name
                    }))), n
                }
                _handleChangeFavorites(e) {
                    this.setState({
                        lastNotQuicked: void 0,
                        favorites: e
                    })
                }
                _handleChangeCustoms(e) {
                    this.setState({
                        customs: e
                    })
                }
                _handleChangeMenuViewState(e) {
                    this.setState({
                        menuViewState: e
                    }, () => {
                        this._menu.current && this._menu.current.update()
                    })
                }
                _renderPopupMenuItem(e, t) {
                    const {
                        isFavoritingAllowed: a
                    } = this.props, {
                        activeInterval: n,
                        lastAddedInterval: s
                    } = this.state, o = e === n, l = (0, ge.isAvailable)(e), r = this._isIntervalFavorite(e), h = this._isIntervalDefault(e), c = (0, ge.getTranslatedResolutionModel)(e);
                    return i.createElement(Ie, {
                        key: e,
                        isSmallTablet: t,
                        interval: e,
                        hint: c.hint,
                        isSignaling: s === e,
                        isFavoritingAllowed: a,
                        isDisabled: !l,
                        isFavorite: r,
                        isRemovable: !h,
                        isActive: o,
                        onClick: this._handleSelectInterval,
                        onClickRemove: this._handleRemoveInterval,
                        onClickFavorite: this._handleClickFavorite,
                        "data-value": e
                    })
                }
                _isIntervalDefault(e) {
                    return this._defaultIntervals.includes(e)
                }
                _isIntervalFavorite(e) {
                    return this.state.favorites.includes(e)
                }
                _getQuicks(e) {
                    return this.props.isShownQuicks && "small" !== this.props.displayMode ? void 0 === e ? this.state.favorites : e : []
                }
                _trackClick() {
                    0
                }
            }
            Ke.contextType = Oe;
            var Ge = a(51274),
                qe = a(19614);
            const Xe = {
                    hint: (0, o.t)("Open chart in popup")
                },
                Qe = (0, E.registryContextType)();
            class Ze extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidgetCollection: e,
                            windowMessageService: t,
                            isFundamental: a
                        } = this.context, n = e.activeChartWidget.value();
                        n.withModel(null, () => {
                            t.post(parent, "openChartInPopup", {
                                symbol: n.model().mainSeries().actualSymbol(),
                                interval: n.model().mainSeries().interval(),
                                fundamental: a
                            })
                        })
                    }, (0, E.validateRegistry)(t, {
                        isFundamental: s.any,
                        chartWidgetCollection: s.any.isRequired,
                        windowMessageService: s.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e
                    } = this.props;
                    return i.createElement(V.ToolWidgetIconButton, {
                        className: p(e, Ge.button),
                        icon: qe,
                        onClick: this._handleClick,
                        title: Xe.hint
                    })
                }
            }
            Ze.contextType = Qe;
            var je = a(84050);
            const Je = {
                    hint: (0, o.t)("Chart Properties")
                },
                $e = (0, E.registryContextType)();
            class Ye extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._handleClick = () => {
                        const {
                            chartWidgetCollection: e
                        } = this.context, t = e.activeChartWidget.value();
                        (0, D.trackEvent)("GUI", "Chart Header Toolbar", "chart properties"), t.showGeneralChartProperties()
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired
                    })
                }
                render() {
                    return i.createElement(V.ToolWidgetIconButton, { ...this.props,
                        icon: je,
                        title: Je.hint,
                        onClick: this._handleClick
                    })
                }
            }
            Ye.contextType = $e;
            var et = a(60934),
                tt = a(99432),
                at = a(83939),
                nt = a(4654);
            const it = "M21.5 21.5h-14a5 5 0 1 1 .42-9.983 7.5 7.5 0 0 1 14.57 2.106 4.002 4.002 0 0 1-.99 7.877z",
                st = 13.08991081237793,
                ot = {
                    strokeDashOffset: 49.242997817993164,
                    strokeDash: 49.866326904296876,
                    strokeGap: st,
                    strokeDashCheck: 0
                },
                lt = {
                    strokeDashOffset: 62.956237716674806,
                    strokeGap: 0,
                    strokeDash: 62.956237716674806,
                    strokeDashCheck: 200
                };
            class rt extends i.PureComponent {
                constructor(e) {
                    super(e), this.state = ot
                }
                componentDidMount() {
                    "saved" === this.props.state ? this.setState(lt) : this._goToNextState(this.props.state)
                }
                componentWillUnmount() {
                    this._currentAnimation = void 0
                }
                UNSAFE_componentWillReceiveProps(e) {
                    this.props.state !== e.state && this._goToNextState(e.state)
                }
                render() {
                    const {
                        strokeDashOffset: e,
                        strokeDash: t,
                        strokeGap: a,
                        strokeDashCheck: n
                    } = this.state, {
                        className: s,
                        size: o,
                        onClick: l,
                        state: r,
                        isHovered: h = !1
                    } = this.props, c = p(nt.container, s, h && nt.hovered, {
                        [nt.unsaved]: "unsaved" === r,
                        [nt.saving]: "saving" === r,
                        [nt.saved]: "saved" === r
                    });
                    return i.createElement("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        className: c,
                        version: "1.1",
                        width: o,
                        height: o,
                        viewBox: "0 0 28 28",
                        onClick: l
                    }, i.createElement("g", {
                        fill: "none"
                    }, i.createElement("path", {
                        className: nt.dottedCloud,
                        stroke: "currentColor",
                        strokeDasharray: "3.5,2.5",
                        d: it
                    }), i.createElement("path", {
                        className: nt.spinningCloud,
                        stroke: "currentColor",
                        strokeDasharray: `${t} ${a}`,
                        strokeDashoffset: e,
                        d: it
                    }), i.createElement("path", {
                        className: nt.arrowGap,
                        d: "M11 20h6v5h-6z"
                    }), i.createElement("g", {
                        className: nt.arrow,
                        stroke: "currentColor"
                    }, i.createElement("path", {
                        strokeLinecap: "square",
                        d: "M14.5 14.5v10"
                    }), i.createElement("path", {
                        d: "M11 17l3.5-3.5L18 17"
                    })), i.createElement("g", {
                        className: nt.check,
                        stroke: "currentColor"
                    }, i.createElement("path", {
                        strokeDasharray: `${n}% ${200-n}%`,
                        d: "M10 15l2.5 2.5L18 12"
                    }))))
                }
                _goToNextState(e) {
                    switch (e) {
                        case "unsaved":
                            this.setState(ot);
                            break;
                        case "saving":
                            "unsaved" !== this.props.state && this.setState(ot), this._currentAnimation = Promise.resolve(this._currentAnimation).then(() => this._createSpinAnimationWhile(() => "saving" === this.props.state));
                            break;
                        case "saved":
                            this._currentAnimation = Promise.resolve(this._currentAnimation).then(this._createFillGapAnimation.bind(this)).then(this._createCheckAnimation.bind(this))
                    }
                }
                _createSpinAnimationWhile(e) {
                    return this._createSpinAnimation().then(() => e() ? this._createSpinAnimationWhile(e) : Promise.resolve())
                }
                _createSpinAnimation() {
                    return new Promise(e => {
                        (0, tt.doAnimate)({
                            onStep: (e, t) => {
                                void 0 !== this._currentAnimation && this.setState({
                                    strokeDashOffset: t
                                })
                            },
                            onComplete: () => e(),
                            from: 49.242997817993164,
                            to: 111.57590644836426,
                            easing: at.easingFunc.linear,
                            duration: 1e3
                        })
                    })
                }
                _createCheckAnimation() {
                    return new Promise(e => {
                        (0, tt.doAnimate)({
                            onStep: (e, t) => {
                                void 0 !== this._currentAnimation && this.setState({
                                    strokeDashCheck: Math.round(t)
                                })
                            },
                            onComplete: () => e(),
                            from: 0,
                            to: 200,
                            easing: at.easingFunc.linear,
                            duration: 1e3
                        })
                    })
                }
                _createFillGapAnimation() {
                    return new Promise(e => {
                        (0, tt.doAnimate)({
                            onStep: (e, t) => {
                                void 0 !== this._currentAnimation && this.setState({
                                    strokeDashOffset: 62.956237716674806 - t,
                                    strokeGap: t,
                                    strokeDash: 62.956237716674806 - t
                                })
                            },
                            onComplete: () => e(),
                            from: st,
                            to: 0,
                            easing: at.easingFunc.linear,
                            duration: 200
                        })
                    })
                }
            }
            var ht = a(4598),
                ct = a(84264),
                dt = a(77541);
            (0, ht.mergeThemes)(ct.DEFAULT_MENU_ITEM_SWITCHER_THEME, dt);
            var ut = a(22675),
                mt = a(6577),
                pt = a(19533),
                vt = a(16856);
            a(79948);
            const gt = n.enabled("widget"),
                bt = (0, ht.mergeThemes)(S.DEFAULT_TOOL_WIDGET_BUTTON_THEME, vt),
                St = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    shortcut: pt.shortcut
                }),
                Ct = {
                    copy: (0, o.t)("Copy"),
                    makeCopy: (0, o.t)("Make a Copy"),
                    newChartLayout: (0, o.t)("New Chart Layout"),
                    loadChartLayout: (0, ut.appendEllipsis)((0, o.t)("Load Chart Layout")),
                    rename: (0, ut.appendEllipsis)((0, o.t)("Rename")),
                    renameChartLayout: (0, o.t)("Rename Chart Layout"),
                    saveAs: (0, ut.appendEllipsis)((0, o.t)("Make a Copy")),
                    saveChartLayout: (0, o.t)("Save"),
                    saveChartLayoutLong: (0, o.t)("Save all charts for all symbols and intervals on your layout"),
                    manageChartLayouts: (0, o.t)("Manage Chart Layouts")
                },
                _t = [],
                wt = (0, K.hotKeySerialize)({
                    keys: [(0, G.humanReadableModifiers)(G.Modifiers.Mod, !1), "S"],
                    text: "{0} + {1}"
                });
            class ft extends i.PureComponent {
                constructor(e) {
                    super(e), this._handleSaveHoverBegin = () => {
                        this.setState({
                            iconHovered: !0
                        })
                    }, this._handleSaveHoverEnd = () => {
                        this.setState({
                            iconHovered: !1
                        })
                    }, this._handleCloneClick = () => {
                        var e, t;
                        null === (t = (e = this.props).onCloneChart) || void 0 === t || t.call(e), this._trackClick()
                    }, this._handleSaveClick = () => {
                        var e, t;
                        null === (t = (e = this.props).onSaveChart) || void 0 === t || t.call(e), this._trackClick()
                    }, this.state = {
                        iconHovered: !1
                    }
                }
                render() {
                    const {
                        id: e,
                        isReadOnly: t,
                        displayMode: a,
                        isProcessing: n,
                        title: s,
                        chartId: o,
                        wasChanges: l,
                        hideMenu: r,
                        isTabletSmall: h
                    } = this.props, {
                        iconHovered: c
                    } = this.state, u = !t && !r;
                    let v = "saved";
                    return !l && s || (v = "unsaved"), n && (v = "saving"), i.createElement(b, null, t ? i.createElement(b, null, i.createElement(L, {
                        id: e,
                        displayMode: a,
                        icon: i.createElement(d.Icon, {
                            icon: mt
                        }),
                        isDisabled: n,
                        onClick: this._handleCloneClick,
                        text: Ct.copy,
                        title: Ct.makeCopy,
                        onMouseEnter: this._handleSaveHoverBegin,
                        onMouseLeave: this._handleSaveHoverEnd,
                        collapseWhen: _t
                    })) : i.createElement(b, null, i.createElement(L, {
                        id: e,
                        className: p(pt.button, u && pt.buttonSmallPadding),
                        displayMode: a,
                        icon: i.createElement(rt, {
                            size: 28,
                            state: v,
                            isHovered: c
                        }),
                        isDisabled: o && !l || n,
                        onClick: this._handleSaveClick,
                        text: s || Ct.saveChartLayout,
                        title: Ct.saveChartLayoutLong,
                        onMouseEnter: this._handleSaveHoverBegin,
                        onMouseLeave: this._handleSaveHoverEnd,
                        theme: bt,
                        collapseWhen: _t,
                        "data-tooltip-hotkey": gt ? "" : wt
                    }), u && i.createElement(m.ToolWidgetMenu, {
                        className: "js-save-load-menu-open-button",
                        arrow: !0,
                        isDrawer: h,
                        drawerPosition: "Bottom",
                        title: Ct.manageChartLayouts,
                        onClick: this._trackClick
                    }, this._renderMenuItems(Boolean(h)))))
                }
                _renderMenuItems(e) {
                    const {
                        wasChanges: t,
                        isProcessing: a,
                        chartId: n,
                        onSaveChartFromMenu: s,
                        onRenameChart: l,
                        onSaveAsChart: r,
                        onLoadChart: h,
                        onNewChart: c,
                        isAutoSaveEnabled: d,
                        autoSaveId: m,
                        sharingId: v,
                        onAutoSaveChanged: g,
                        isSharingEnabled: b,
                        onSharingChanged: S
                    } = this.props, C = e ? M.multilineLabelWithIconAndToolboxTheme : St, _ = e ? void 0 : (0, G.humanReadableHash)(G.Modifiers.Mod + 83), w = e ? void 0 : (0, o.t)("Dot", {
                        context: "hotkey"
                    }), y = [];
                    return y.push(i.createElement(u.PopupMenuItem, {
                        key: "save",
                        isDisabled: Boolean(a || !t && n),
                        label: Ct.saveChartLayout,
                        onClick: s,
                        shortcut: _,
                        labelRowClassName: p(e && pt.popupItemRowTabletSmall),
                        theme: C
                    })), void 0 !== n && (e || y.push(i.createElement(f.PopupMenuSeparator, {
                        key: "existing-chart-section-begin"
                    })), y.push(i.createElement(u.PopupMenuItem, {
                        key: "rename",
                        label: Ct.rename,
                        onClick: l,
                        labelRowClassName: p(e && pt.popupItemRowTabletSmall),
                        theme: C
                    }), i.createElement(u.PopupMenuItem, {
                        key: "save-as",
                        label: Ct.saveAs,
                        onClick: r,
                        labelRowClassName: p(e && pt.popupItemRowTabletSmall),
                        theme: C
                    }))), y.push(i.createElement(f.PopupMenuSeparator, {
                        key: "platform-section-begin"
                    })), y.push(i.createElement(u.PopupMenuItem, {
                        key: "load-chart",
                        className: "js-save-load-menu-item-load-chart",
                        label: Ct.loadChartLayout,
                        onClick: h,
                        labelRowClassName: p(e && pt.popupItemRowTabletSmall),
                        theme: C,
                        shortcut: w
                    })), y
                }
                _trackClick() {
                    0
                }
            }
            const yt = (0, E.registryContextType)();
            class kt extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._syncState = e => {
                        this.setState(e)
                    }, this._onChangeHasChanges = e => {
                        this.state.wasChanges !== e && this.setState({
                            wasChanges: e
                        })
                    }, this._onChangeAutoSaveEnabled = e => {
                        0
                    }, this._onChangeSharingEnabled = e => {
                        this.setState({
                            isSharingEnabled: e
                        })
                    }, this._onChangeTitle = e => {
                        this.setState({
                            title: e
                        })
                    }, this._onChangeId = e => {
                        this.setState({
                            id: e
                        })
                    }, this._onChartAboutToBeSaved = () => {
                        this.setState({
                            isProcessing: !0
                        })
                    }, this._onChartSaved = () => {
                        this.setState({
                            isProcessing: !1
                        })
                    }, this._handleAutoSaveEnabled = e => {
                        0
                    }, this._handleSharingEnabled = e => {
                        0
                    }, this._handleClickSave = () => {
                        this.context.saveChartService.saveChartOrShowTitleDialog(), this._trackEvent("Save click")
                    }, this._handleClickSaveFromMenu = () => {
                        this.context.saveChartService.saveChartOrShowTitleDialog(), this._trackEvent("Save From Menu")
                    }, this._handleClickClone = () => {
                        this.context.saveChartService.cloneChart()
                    }, this._handleClickSaveAs = () => {
                        this.context.saveChartService.saveChartAs(), this._trackEvent("Make a copy")
                    }, this._handleClickNew = () => {
                        this._trackEvent("New chart layout")
                    }, this._handleClickLoad = () => {
                        this.context.loadChartService.showLoadDialog(), this._trackEvent("Load chart layout")
                    }, this._handleHotkey = () => {
                        this.context.loadChartService.showLoadDialog()
                    }, this._handleClickRename = () => {
                        this.context.saveChartService.renameChart(), this._trackEvent("Rename")
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired,
                        chartChangesWatcher: s.any.isRequired,
                        saveChartService: s.any.isRequired,
                        sharingChartService: s.any,
                        loadChartService: s.any.isRequired
                    });
                    const {
                        chartWidgetCollection: a,
                        chartChangesWatcher: n,
                        saveChartService: i,
                        sharingChartService: o
                    } = t;
                    this.state = {
                        isAuthenticated: window.is_authenticated,
                        isProcessing: !1,
                        id: a.metaInfo.id.value(),
                        title: a.metaInfo.name.value(),
                        wasChanges: n.hasChanges(),
                        iconHovered: !1
                    }
                }
                componentDidMount() {
                    const {
                        chartSaver: e,
                        isFake: t,
                        stateSyncEmitter: a
                    } = this.props, {
                        chartWidgetCollection: n,
                        chartChangesWatcher: i,
                        saveChartService: s,
                        sharingChartService: l
                    } = this.context;
                    t ? a.on("change", this._syncState) : (i.getOnChange().subscribe(this, this._onChangeHasChanges), n.metaInfo.name.subscribe(this._onChangeTitle), n.metaInfo.id.subscribe(this._onChangeId), this._hotkeys = (0, et.createGroup)({
                        desc: "Save/Load"
                    }), this._hotkeys.add({
                        desc: (0, o.t)("Load Chart Layout"),
                        handler: this._handleHotkey,
                        hotkey: 190
                    }), e.chartSaved().subscribe(this, this._onChartSaved), e.chartAboutToBeSaved().subscribe(this, this._onChartAboutToBeSaved), window.loginStateChange.subscribe(this, this._onLoginStateChange))
                }
                componentDidUpdate(e, t) {
                    this.props.isFake || t !== this.state && this.props.stateSyncEmitter.emit("change", this.state)
                }
                componentWillUnmount() {
                    const {
                        chartSaver: e,
                        isFake: t,
                        stateSyncEmitter: a
                    } = this.props, {
                        chartWidgetCollection: n,
                        chartChangesWatcher: i,
                        saveChartService: s,
                        sharingChartService: o
                    } = this.context;
                    t ? a.off("change", this._syncState) : (i.getOnChange().unsubscribe(this, this._onChangeHasChanges), n.metaInfo.name.unsubscribe(this._onChangeTitle), n.metaInfo.id.unsubscribe(this._onChangeId), (0, $.ensureDefined)(this._hotkeys).destroy(), e.chartSaved().unsubscribe(this, this._onChartSaved), e.chartAboutToBeSaved().unsubscribe(this, this._onChartAboutToBeSaved), window.loginStateChange.unsubscribe(this, this._onLoginStateChange))
                }
                render() {
                    const {
                        isReadOnly: e,
                        displayMode: t,
                        id: a,
                        isFake: n
                    } = this.props, {
                        isProcessing: s,
                        isAuthenticated: o,
                        title: l,
                        id: r,
                        wasChanges: h,
                        isAutoSaveEnabled: c,
                        isSharingEnabled: d
                    } = this.state, u = {
                        displayMode: t,
                        isReadOnly: e,
                        isAuthenticated: o,
                        isProcessing: s,
                        wasChanges: h,
                        title: l,
                        id: a,
                        chartId: null !== r ? r : void 0,
                        onCloneChart: this._handleClickClone,
                        onSaveChart: this._handleClickSave,
                        onSaveChartFromMenu: this._handleClickSaveFromMenu,
                        onRenameChart: this._handleClickRename,
                        onSaveAsChart: this._handleClickSaveAs,
                        onLoadChart: this._handleClickLoad
                    };
                    return i.createElement(y.MatchMedia, {
                        rule: k.DialogBreakpoints.TabletSmall
                    }, e => i.createElement(ft, { ...u,
                        isTabletSmall: e
                    }))
                }
                _onLoginStateChange() {
                    this.setState({
                        isAuthenticated: window.is_authenticated
                    })
                }
                _trackEvent(e) {
                    0
                }
            }
            kt.contextType = yt;
            var Mt = a(84629),
                Et = a(74796),
                Tt = a(61125);
            const xt = new Et.DateTimeFormatter({
                    dateTimeSeparator: "_",
                    timeFormat: "%h-%m-%s"
                }),
                It = {
                    takeSnapshot: (0, o.t)("Take a snapshot")
                },
                At = (0, E.registryContextType)();
            const Nt = o.t("Loading...");

            function Rt(e, t, a) {
                return async function(e, t, a) {
                    const n = URL.createObjectURL(new Blob([`<!doctype html><html style="background-color:${getComputedStyle(document.documentElement).backgroundColor}"><head><meta charset="utf-8"><title>${Nt}</title></head><body style="background-color:${getComputedStyle(document.body).backgroundColor}"></body></html>`], {
                        type: "text/html"
                    }));
                    try {
                        const i = open(n, t, a);
                        if (!i) throw new Error("cound not open a new tab");
                        const s = await e.catch(() => {});
                        void 0 !== s ? i.location.replace(s) : i.close()
                    } finally {
                        URL.revokeObjectURL(n)
                    }
                }(e, t, a)
            }
            var Ft = a(33350),
                zt = a(63526),
                Ht = a(85243);

            function Lt(e) {
                const t = p(e.isLoading && Ht.hidden),
                    a = p(!e.isLoading && Ht.hidden);
                return i.createElement("div", null, i.createElement("span", {
                    className: t
                }, e.children), i.createElement("span", {
                    className: a
                }, i.createElement(ne.Loader, null)))
            }
            var Dt = a(37861),
                Pt = a(15155),
                Wt = a(58589),
                Ot = a(66146),
                Ut = a(18679),
                Bt = a(51382),
                Vt = a(90505);
            const Kt = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, Vt);

            function Gt(e) {
                const {
                    serverSnapshot: t,
                    clientSnapshot: n
                } = e, [s, l] = (0, i.useState)(!1), [r, h] = (0, i.useState)(!1), [c, d] = (0, i.useState)(!1), m = (0, Dt.useIsMounted)(), v = (0, i.useCallback)(async () => {
                    var e;
                    const t = n(),
                        a = t.then(e => new Promise(t => e.canvas.toBlob(e => {
                            null !== e && t(e)
                        })));
                    try {
                        await (0, Ft.writePromiseUsingApi)(a, "image/png"), re.emit("onClientScreenshotCopiedToClipboard")
                    } catch (a) {
                        const {
                            canvas: n
                        } = await t;
                        null === (e = window.open()) || void 0 === e || e.document.write(`<img width="100%" src="${n.toDataURL()}"/>`)
                    }
                }, [n]), g = (0, i.useCallback)(async () => {
                    const e = await n();
                    (0, zt.downloadFile)(e.name + ".png", e.canvas.toDataURL())
                }, [n]), b = e => Rt(e.then(e => e.imageUrl)), S = (0, i.useCallback)(async (e = !1) => {
                    const a = t();
                    try {
                        if (e) await b(a);
                        else {
                            const e = a.then(e => new Blob([e.imageUrl], {
                                type: "text/plain"
                            }));
                            await (0, Ft.writePromiseUsingApi)(e, "text/plain"), re.emit("onServerScreenshotCopiedToClipboard")
                        }
                        return !0
                    } catch (e) {
                        return b(a), !0
                    } finally {
                        m.current && (h(!1), l(!1), (0, Le.globalCloseMenu)())
                    }
                }, [t]), C = (0, i.useCallback)(async () => {
                    d(!0);
                    const [e, n] = await Promise.all([a.e(4665).then(a.bind(a, 59248)), t()]);
                    e.Twitter.shareSnapshotInstantly(n.symbol, n.imageUrl), m.current && (d(!1), (0, Le.globalCloseMenu)())
                }, [t]);
                return i.createElement(i.Fragment, null, i.createElement(u.PopupMenuItem, {
                    "data-name": "save-chart-image",
                    label: (0, o.t)("Save chart image"),
                    icon: Ot,
                    onClick: g,
                    shortcut: (0, G.humanReadableHash)(G.Modifiers.Mod + G.Modifiers.Alt + 83),
                    theme: Kt
                }), i.createElement(u.PopupMenuItem, {
                    "data-name": "copy-chart-image",
                    label: (0, o.t)("Copy chart image"),
                    icon: Wt,
                    onClick: v,
                    shortcut: (0,
                        G.humanReadableHash)(G.Modifiers.Mod + G.Modifiers.Shift + 83),
                    theme: Kt
                }), i.createElement(u.PopupMenuItem, {
                    "data-name": "copy-link-to-the-chart-image",
                    label: i.createElement(Lt, {
                        isLoading: s
                    }, (0, o.t)("Copy link to the chart image")),
                    icon: Ut,
                    onClick: () => {
                        l(!0), S(!1)
                    },
                    dontClosePopup: !0,
                    isDisabled: s,
                    shortcut: (0, G.humanReadableHash)(G.Modifiers.Alt + 83),
                    className: p(s && Vt.loading),
                    theme: Kt
                }), i.createElement(u.PopupMenuItem, {
                    "data-name": "open-image-in-new-tab",
                    label: i.createElement(Lt, {
                        isLoading: r
                    }, (0, o.t)("Open image in new tab")),
                    icon: Bt,
                    onClick: () => {
                        h(!0), S(!0)
                    },
                    dontClosePopup: !0,
                    isDisabled: r,
                    className: p(r && Vt.loading),
                    theme: Kt
                }), i.createElement(u.PopupMenuItem, {
                    "data-name": "tweet-chart-image",
                    label: i.createElement(Lt, {
                        isLoading: c
                    }, (0, o.t)("Tweet chart image")),
                    icon: Pt,
                    onClick: C,
                    dontClosePopup: !0,
                    isDisabled: c,
                    className: p(c && Vt.loading),
                    theme: Kt
                }))
            }
            var qt = a(22900);

            function Xt(e) {
                const [t, a] = (0, i.useState)(!1), n = (0, Dt.useIsMounted)(), s = (0, i.useCallback)(async () => {
                    a(!0), await e.serverSnapshot(), n.current && a(!1)
                }, [e.serverSnapshot]);
                return i.createElement(S.ToolWidgetButton, {
                    id: e.id,
                    className: e.className,
                    isDisabled: t,
                    onClick: s,
                    title: e.tooltip,
                    icon: e.icon
                })
            }
            var Qt = a(78780);
            const Zt = (jt = function(e) {
                return (0, qt.isOnMobileAppPage)("any") ? i.createElement(Xt, { ...e,
                    icon: Qt
                }) : i.createElement(m.ToolWidgetMenu, {
                    content: i.createElement(S.ToolWidgetButton, {
                        id: e.id,
                        className: e.className,
                        title: e.tooltip,
                        icon: Qt
                    }),
                    drawerPosition: "Bottom",
                    drawerBreakpoint: k.DialogBreakpoints.TabletSmall,
                    arrow: !1,
                    onClick: function() {}
                }, i.createElement(Gt, { ...e
                }))
            }, (Jt = class extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._clientSnapshot = async () => {
                        const e = this.context.chartWidgetCollection.activeChartWidget.value().model().mainSeries().actualSymbol();
                        return {
                            canvas: await this.context.chartWidgetCollection.clientSnapshot(),
                            name: `${(0,Tt.shortName)(e)}_${xt.formatLocal(new Date)}`
                        }
                    }, this._serverSnapshot = async () => {
                        const e = this.context.chartWidgetCollection.activeChartWidget.value().model().mainSeries().actualSymbol(),
                            t = await this.context.chartWidgetCollection.takeScreenshot(),
                            a = n.enabled("charting_library_base") && void 0 !== this.context.snapshotUrl ? t : (0, Mt.convertImageNameToUrl)(t);
                        return {
                            symbol: (0, Tt.shortName)(e),
                            imageUrl: a
                        }
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired
                    })
                }
                render() {
                    const {
                        className: e,
                        id: t
                    } = this.props;
                    return i.createElement(jt, {
                        id: t,
                        className: e,
                        tooltip: It.takeSnapshot,
                        serverSnapshot: this._serverSnapshot,
                        clientSnapshot: this._clientSnapshot
                    })
                }
            }).contextType = At, Jt);
            var jt, Jt, $t = a(72454),
                Yt = a(79653),
                ea = a(40801);
            class ta {
                async show(e) {
                    if (null !== ta._provider) {
                        const e = await ta._provider.getSymbol();
                        return l.linking.symbol.setValue(e.symbol), e
                    }
                    if (ta._currentShowingInstance) throw new DOMException("SymbolSearchUI is already shown", "InvalidStateError");
                    try {
                        ta._currentShowingInstance = this, ta.preload();
                        const t = await ta._implementation;
                        return (0, $.assert)(null !== t), new Promise(a => {
                            t.showDefaultSearchDialog({ ...e,
                                onSearchComplete: e => {
                                    a({
                                        symbol: e
                                    })
                                }
                            })
                        })
                    } finally {
                        ta._currentShowingInstance = null
                    }
                }
                static setProvider(e) {
                    this._provider = e
                }
                static preload() {
                    null === this._provider && null === this._implementation && (this._implementation = (0, ea.loadNewSymbolSearch)())
                }
            }
            ta._currentShowingInstance = null, ta._provider = null, ta._implementation = null;
            var aa = a(44649),
                na = a(14552);
            const ia = (0, ht.mergeThemes)(S.DEFAULT_TOOL_WIDGET_BUTTON_THEME, aa);
            (0, ht.mergeThemes)(ia, na);
            class sa extends i.PureComponent {
                constructor(e) {
                    super(e), this._openSymbolSearchDialog = async e => {
                        if ((0, G.modifiersFromEvent)(e) !== G.Modifiers.Alt) try {
                            (0, D.trackEvent)("GUI", "SS", "main search"), await (new ta).show({
                                defaultValue: this._isSpread(this.state.symbol) ? this.state.symbol : this.state.shortName,
                                showSpreadActions: (0, $t.canShowSpreadActions)() && this.props.isActionsVisible,
                                source: "searchBar",
                                footer: Te.mobiletouch ? void 0 : i.createElement(Yt.SymbolSearchDialogFooter, null, (0, o.t)("Simply start typing while on the chart to pull up this search box"))
                            })
                        } catch (e) {} else navigator.clipboard.writeText(this.state.symbol)
                    }, this._isSpread = e => !1, this._onSymbolChanged = () => {
                        const e = l.linking.symbol.value();
                        this.setState({
                            symbol: e,
                            shortName: oa()
                        })
                    }, this._subscribeToLogo = e => {
                        0
                    }, this._unsubscribeToLogo = e => {
                        0
                    }, this._handleLogo = e => {}, this.state = {
                        symbol: l.linking.symbol.value(),
                        shortName: oa(),
                        logoUrls: []
                    }
                }
                componentDidMount() {
                    l.linking.symbol.subscribe(this._onSymbolChanged), l.linking.seriesShortSymbol.subscribe(this._onSymbolChanged), ta.preload()
                }
                componentWillUnmount() {
                    l.linking.symbol.unsubscribe(this._onSymbolChanged), l.linking.seriesShortSymbol.unsubscribe(this._onSymbolChanged)
                }
                render() {
                    const {
                        id: e,
                        className: t
                    } = this.props;
                    return i.createElement(S.ToolWidgetButton, {
                        id: e,
                        className: v()(t, n.enabled("uppercase_instrument_names") && aa.uppercase),
                        theme: ia,
                        icon: void 0,
                        text: this.state.shortName,
                        title: (0, o.t)("Symbol Search"),
                        onClick: this._openSymbolSearchDialog
                    })
                }
            }

            function oa() {
                return l.linking.seriesShortSymbol.value() || l.linking.symbol.value() || ""
            }
            var la = a(79236);
            class ra extends i.PureComponent {
                constructor() {
                    super(...arguments), this._handleClick = e => {
                        e.stopPropagation();
                        const {
                            onApply: t,
                            item: a
                        } = this.props;
                        t(a)
                    }
                }
                render() {
                    const {
                        className: e,
                        item: t
                    } = this.props;
                    return i.createElement("div", {
                        className: p(e, la.item, "apply-common-tooltip"),
                        onClick: this._handleClick,
                        title: t.name
                    }, i.createElement("div", {
                        className: la.round
                    }, t.name.length > 0 ? t.name[0].toUpperCase() : " "))
                }
            }
            var ha = a(33756),
                ca = a(53257);

            function da(e) {
                return i.createElement("div", {
                    className: p(ca.description, e.className)
                }, e.children)
            }
            var ua = a(11597);
            const ma = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    labelRow: ua.labelRow,
                    toolbox: ua.toolbox,
                    item: ua.titleItem
                }),
                pa = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    labelRow: ua.labelRow,
                    toolbox: ua.toolbox,
                    item: ua.titleItemTabletSmall
                }),
                va = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    item: ua.item
                }),
                ga = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, {
                    item: ua.itemTabletSmall
                });

            function ba(e) {
                const {
                    item: t,
                    onApply: a,
                    onRemove: n,
                    onFavor: s,
                    favorite: o,
                    isFavoritingAllowed: l,
                    isTabletSmall: r
                } = e, [h, d] = (0, Ee.useHover)(), m = t.meta_info, p = m ? (0, ha.descriptionString)(m.indicators) : void 0, g = r ? pa : ma, b = r ? ga : va, S = (0,
                    i.useCallback)(() => a(t), [a, t]), C = (0, i.useCallback)(() => n(t), [n, t]), _ = (0, i.useCallback)(() => {
                    s && s(t)
                }, [s, t]);
                return i.createElement("div", { ...d,
                    className: ua.wrap,
                    "data-name": t.name,
                    "data-id": t.id,
                    "data-is-default": Boolean(t.is_default)
                }, i.createElement(u.PopupMenuItem, {
                    theme: g,
                    label: t.name,
                    labelRowClassName: v()(r && ua.itemLabelTabletSmall),
                    isHovered: h,
                    showToolboxOnHover: !o && !h,
                    onClick: S,
                    toolbox: i.createElement(i.Fragment, null, !t.is_default && i.createElement(Me.RemoveButton, {
                        key: "remove",
                        hidden: !Te.touch && !h,
                        onClick: C
                    }), Boolean(s) && l && i.createElement(c.FavoriteButton, {
                        key: "favorite",
                        isFilled: Boolean(o),
                        onClick: _
                    }))
                }), p && i.createElement(u.PopupMenuItem, {
                    theme: b,
                    label: i.createElement(da, {
                        className: v()(ua.description, r && ua.descriptionTabletSmall)
                    }, p),
                    onClick: S,
                    isHovered: h
                }))
            }
            var Sa = a(72230),
                Ca = a(95247);
            const _a = (0, ht.mergeThemes)(u.DEFAULT_POPUP_MENU_ITEM_THEME, Ca),
                wa = {
                    text: (0, ut.appendEllipsis)((0, o.t)("Save Indicator template"))
                };

            function fa(e) {
                const {
                    onClick: t,
                    isTabletSmall: a
                } = e;
                return i.createElement(u.PopupMenuItem, {
                    theme: _a,
                    className: Ca.wrap,
                    label: i.createElement("div", {
                        className: Ca.titleWrap
                    }, i.createElement("div", {
                        className: v()(Ca.title, a && Ca.titleTabletSmall)
                    }, i.createElement(d.Icon, {
                        className: Ca.icon,
                        icon: Sa
                    }), i.createElement("div", {
                        className: Ca.text
                    }, wa.text))),
                    onClick: t
                })
            }
            var ya = a(77727),
                ka = a(97873);
            const Ma = i.createContext(null);
            var Ea = a(76755);

            function Ta(e) {
                const {
                    templates: t,
                    favorites: a,
                    onTemplateSave: n,
                    onTemplateRemove: s,
                    onTemplateSelect: o,
                    onTemplateFavorite: l,
                    isTabletSmall: r,
                    isLoading: h
                } = e, c = (0, i.useMemo)(() => t.filter(e => e.is_default), [t]), d = (0, i.useMemo)(() => t.filter(e => !e.is_default), [t]), u = (0, i.useMemo)(() => new Set(a.map(e => e.name)), [a]), m = (0, i.useContext)(Ma), p = (0, i.useContext)(ka.MenuContext), g = (0, ya.useForceUpdate)();
                (0, i.useEffect)(() => {
                    if (null !== m) {
                        const e = {};
                        return m.getOnChange().subscribe(e, () => {
                            g(), p && p.update()
                        }), () => m.getOnChange().unsubscribeAll(e)
                    }
                    return () => {}
                }, []);
                const b = e => i.createElement(ba, {
                    key: e.name,
                    item: e,
                    isFavoritingAllowed: Boolean(l),
                    favorite: u.has(e.name),
                    onApply: o,
                    onFavor: l,
                    onRemove: s,
                    isTabletSmall: r
                });
                return i.createElement("div", {
                    className: v()(Ea.menu, r && Ea.menuSmallTablet)
                }, i.createElement(fa, {
                    onClick: n,
                    isTabletSmall: r
                }), h && i.createElement(i.Fragment, null, i.createElement(f.PopupMenuSeparator, null), i.createElement(se, null)), !h && (r ? i.createElement(xa, {
                    defaults: c,
                    customs: d,
                    render: b
                }) : i.createElement(Ia, {
                    defaults: c,
                    customs: d,
                    render: b,
                    state: m
                })))
            }

            function xa(e) {
                const {
                    defaults: t,
                    customs: a,
                    render: n
                } = e;
                return i.createElement(i.Fragment, null, a.length > 0 && i.createElement(i.Fragment, null, i.createElement(f.PopupMenuSeparator, null), i.createElement(le, {
                    className: Ea.menuItemHeaderTabletSmall
                }, (0, o.t)("My templates")), a.map(n)), t.length > 0 && i.createElement(i.Fragment, null, i.createElement(f.PopupMenuSeparator, null), i.createElement(le, {
                    className: Ea.menuItemHeaderTabletSmall
                }, (0, o.t)("Default templates")), t.map(n)))
            }

            function Ia(e) {
                const {
                    defaults: t,
                    customs: a,
                    render: n,
                    state: s
                } = e
                ;
                return i.createElement(i.Fragment, null, a.length > 0 && i.createElement(i.Fragment, null, i.createElement(f.PopupMenuSeparator, null), i.createElement(le, {
                    className: Ea.menuItemHeader
                }, (0, o.t)("My templates")), a.map(n)), a.length > 0 && t.length > 0 && s && i.createElement(i.Fragment, null, i.createElement(f.PopupMenuSeparator, null), i.createElement(Re.CollapsibleSection, {
                    summary: (0, o.t)("Default templates"),
                    open: !s.get().defaultsCollapsed,
                    onStateChange: e => s.set({
                        defaultsCollapsed: !e
                    })
                }, t.map(n))), 0 === a.length && t.length > 0 && i.createElement(i.Fragment, null, i.createElement(f.PopupMenuSeparator, null), i.createElement(le, {
                    className: Ea.menuItemHeader
                }, (0, o.t)("Default templates")), t.map(n)))
            }
            var Aa = a(32856),
                Na = a.n(Aa);
            class Ra {
                constructor(e, t) {
                    var a, i;
                    this._isFavoriteEnabled = n.enabled("items_favoriting"), this.handleFavorTemplate = e => {
                        if (!this._isFavoriteEnabled) return;
                        const {
                            name: t
                        } = e;
                        this._isTemplateFavorite(t) ? this._removeFavoriteTemplate(t) : this._addFavoriteTemplate(t)
                    }, this.handleDropdownOpen = () => {
                        this._setState({
                            isLoading: !0
                        }), this._studyTemplates.invalidate(), this._studyTemplates.refreshStudyTemplateList(() => this._setState({
                            isLoading: !1
                        }))
                    }, this.handleApplyTemplate = e => {
                        this._studyTemplates.applyTemplate(e.name)
                    }, this.handleRemoveTemplate = e => {
                        this._studyTemplates.deleteStudyTemplate(e.name)
                    }, this.handleSaveTemplate = () => {
                        this._studyTemplates.showSaveAsDialog()
                    }, this._studyTemplates = e, this._favoriteStudyTemplatesService = t;
                    const s = (null === (a = this._favoriteStudyTemplatesService) || void 0 === a ? void 0 : a.get()) || [],
                        o = this._studyTemplates.list();
                    this._state = new(Na())({
                        isLoading: !1,
                        studyTemplatesList: o,
                        favorites: s
                    }), this._studyTemplates.getOnChange().subscribe(this, this._handleTemplatesChange), this._studyTemplates.refreshStudyTemplateList(), this._isFavoriteEnabled && (null === (i = this._favoriteStudyTemplatesService) || void 0 === i || i.getOnChange().subscribe(this, this._handleFavoritesChange))
                }
                destroy() {
                    var e;
                    this._studyTemplates.getOnChange().unsubscribe(this, this._handleTemplatesChange), this._isFavoriteEnabled && (null === (e = this._favoriteStudyTemplatesService) || void 0 === e || e.getOnChange().unsubscribe(this, this._handleFavoritesChange))
                }
                state() {
                    return this._state.readonly()
                }
                _setState(e) {
                    this._state.setValue({ ...this._state.value(),
                        ...e
                    })
                }
                _handleTemplatesChange() {
                    this._setState({
                        studyTemplatesList: this._studyTemplates.list()
                    })
                }
                _handleFavoritesChange(e) {
                    this._isFavoriteEnabled && this._setState({
                        favorites: e
                    })
                }
                _removeFavoriteTemplate(e) {
                    var t;
                    const {
                        favorites: a
                    } = this._state.value();
                    null === (t = this._favoriteStudyTemplatesService) || void 0 === t || t.set(a.filter(t => t !== e))
                }
                _addFavoriteTemplate(e) {
                    var t;
                    const {
                        favorites: a
                    } = this._state.value();
                    null === (t = this._favoriteStudyTemplatesService) || void 0 === t || t.set([...a, e])
                }
                _isTemplateFavorite(e) {
                    const {
                        favorites: t
                    } = this._state.value();
                    return t.includes(e)
                }
            }
            var Fa = a(24769),
                za = a(29377);
            const Ha = {
                    title: (0, o.t)("Templates"),
                    tooltip: (0, o.t)("Indicator Templates")
                },
                La = (0, E.registryContextType)();
            class Da extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._updateState = e => {
                            this.setState({ ...e,
                                isActive: this.state.isActive
                            })
                        },
                        this._handleApplyTemplate = e => {
                            this._handleClose(), this._model.handleApplyTemplate(e)
                        }, this._handleRemoveTemplate = e => {
                            this._handleClose(), this._model.handleRemoveTemplate(e)
                        }, this._handleClose = () => {
                            this._handleToggleDropdown(!1)
                        }, this._handleToggleDropdown = e => {
                            const {
                                isActive: t
                            } = this.state, a = "boolean" == typeof e ? e : !t;
                            this.setState({
                                isActive: a
                            })
                        }, (0, E.validateRegistry)(t, {
                            favoriteStudyTemplatesService: s.any,
                            studyTemplates: s.any.isRequired,
                            templatesMenuViewStateService: s.any
                        });
                    const {
                        favoriteStudyTemplatesService: a,
                        studyTemplates: n
                    } = t;
                    this._model = new Ra(n, a), this.state = { ...this._model.state().value(),
                        isActive: !1
                    }
                }
                componentDidMount() {
                    this._model.state().subscribe(this._updateState)
                }
                componentWillUnmount() {
                    this._model.state().unsubscribe(this._updateState), this._model.destroy()
                }
                render() {
                    const {
                        studyTemplatesList: e,
                        favorites: t
                    } = this.state, {
                        isShownQuicks: a,
                        className: n,
                        displayMode: s,
                        id: o
                    } = this.props;
                    return i.createElement(Ma.Provider, {
                        value: this.context.templatesMenuViewStateService || null
                    }, i.createElement(Pa, {
                        id: o,
                        className: n,
                        mode: s,
                        templates: e,
                        favorites: t,
                        onMenuOpen: this._model.handleDropdownOpen,
                        onTemplateFavorite: a ? this._model.handleFavorTemplate : void 0,
                        onTemplateSelect: this._handleApplyTemplate,
                        onTemplateRemove: this._handleRemoveTemplate,
                        onTemplateSave: this._model.handleSaveTemplate
                    }))
                }
            }

            function Pa(e) {
                const {
                    id: t,
                    className: a,
                    mode: n,
                    favorites: s,
                    templates: o,
                    isMenuOpen: l,
                    onTemplateSelect: r,
                    onTemplateSave: h,
                    onTemplateFavorite: c,
                    onTemplateRemove: d
                } = e, u = v()(a, za.wrap, {
                    [za.full]: "full" === n,
                    [za.medium]: "medium" === n
                }), p = o.filter(e => s.includes(e.name)), g = "small" !== n && c && p.length > 0;
                return i.createElement(b, {
                    id: t,
                    className: u
                }, i.createElement(y.MatchMedia, {
                    rule: k.DialogBreakpoints.TabletSmall
                }, t => i.createElement(m.ToolWidgetMenu, {
                    onOpen: e.onMenuOpen,
                    isDrawer: t,
                    drawerPosition: "Bottom",
                    arrow: !1,
                    content: i.createElement(L, {
                        className: v()(g && za.buttonWithFavorites),
                        displayMode: n,
                        isOpened: l,
                        icon: Fa,
                        text: P.hasNewHeaderToolbarStyles ? void 0 : Ha.title,
                        title: Ha.tooltip,
                        forceInteractive: !0,
                        collapseWhen: P.hasNewHeaderToolbarStyles ? ["full", "medium", "small"] : void 0
                    }),
                    onClick: S
                }, i.createElement(Ta, {
                    onTemplateSave: h,
                    onTemplateSelect: r,
                    onTemplateRemove: d,
                    onTemplateFavorite: c,
                    templates: o,
                    favorites: p,
                    isTabletSmall: t
                }))), g && i.createElement(Wa, {
                    favorites: p,
                    onTemplateSelect: function(e) {
                        r(e), S()
                    }
                }));

                function S() {
                    0
                }
            }

            function Wa(e) {
                return i.createElement(i.Fragment, null, e.favorites.map((t, a, n) => i.createElement(ra, {
                    key: t.name,
                    item: t,
                    onApply: e.onTemplateSelect,
                    className: v()({
                        [za.first]: 0 === a,
                        [za.last]: a === n.length - 1
                    })
                })))
            }
            Da.contextType = La;
            a(95068);
            var Oa = a(839),
                Ua = a(51463),
                Ba = a(31877),
                Va = a(58269),
                Ka = a(51897);
            const Ga = {
                    undoHint: (0, o.t)("Undo {hint}"),
                    redoHint: (0, o.t)("Redo {hint}")
                },
                qa = {
                    undoHotKey: (0, K.hotKeySerialize)({
                        keys: [(0, G.humanReadableModifiers)(G.Modifiers.Mod, !1), "Z"],
                        text: "{0} + {1}"
                    }),
                    redoHotKey: (0, K.hotKeySerialize)({
                        keys: [(0, G.humanReadableModifiers)(G.Modifiers.Mod, !1), "Y"],
                        text: "{0} + {1}"
                    })
                },
                Xa = (0, ht.weakComposeClasses)(Ba, Oa, {
                    buttonUndo: "button",
                    buttonRedo: "button"
                }),
                Qa = (0, ht.mergeThemes)(Ba, Ua),
                Za = { ...Ba,
                    button: Xa.buttonUndo
                },
                ja = { ...Ba,
                    button: Xa.buttonRedo
                },
                Ja = (0, E.registryContextType)();
            class $a extends i.PureComponent {
                constructor(e, t) {
                    super(e, t), this._batched = null, this._handleClickUndo = () => {
                        (0, D.trackEvent)("GUI", "Undo");
                        const {
                            chartWidgetCollection: e
                        } = this.context;
                        e.undoHistory.undo()
                    }, this._handleClickRedo = () => {
                        (0, D.trackEvent)("GUI", "Redo");
                        const {
                            chartWidgetCollection: e
                        } = this.context;
                        e.undoHistory.redo()
                    }, (0, E.validateRegistry)(t, {
                        chartWidgetCollection: s.any.isRequired
                    }), this.state = this._getStateFromUndoHistory()
                }
                componentDidMount() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    e.undoHistory.redoStack().onChange().subscribe(this, this._onChangeStack), e.undoHistory.undoStack().onChange().subscribe(this, this._onChangeStack)
                }
                componentWillUnmount() {
                    const {
                        chartWidgetCollection: e
                    } = this.context;
                    e.undoHistory.redoStack().onChange().unsubscribe(this, this._onChangeStack), e.undoHistory.undoStack().onChange().unsubscribe(this, this._onChangeStack), this._batched = null
                }
                render() {
                    const {
                        id: e
                    } = this.props, {
                        isEnabledRedo: t,
                        isEnabledUndo: a,
                        redoStack: n,
                        undoStack: s
                    } = this.state;
                    return i.createElement(b, {
                        id: e
                    }, i.createElement(S.ToolWidgetButton, {
                        icon: Va,
                        isDisabled: !a,
                        onClick: this._handleClickUndo,
                        title: a ? Ga.undoHint.format({
                            hint: s
                        }) : void 0,
                        "data-tooltip-hotkey": a ? qa.undoHotKey : void 0,
                        theme: P.hasNewHeaderToolbarStyles ? Qa : Za
                    }), i.createElement(S.ToolWidgetButton, {
                        icon: Ka,
                        isDisabled: !t,
                        onClick: this._handleClickRedo,
                        title: t ? Ga.redoHint.format({
                            hint: n
                        }) : void 0,
                        "data-tooltip-hotkey": t ? qa.redoHotKey : void 0,
                        theme: P.hasNewHeaderToolbarStyles ? Qa : ja
                    }))
                }
                _onChangeStack() {
                    null === this._batched && (this._batched = Promise.resolve().then(() => {
                        if (null === this._batched) return;
                        this._batched = null;
                        const e = this._getStateFromUndoHistory();
                        this.setState(e)
                    }))
                }
                _getStateFromUndoHistory() {
                    const {
                        chartWidgetCollection: e
                    } = this.context, t = e.undoHistory.undoStack(), a = e.undoHistory.redoStack(), n = a.head(), i = t.head();
                    return {
                        isEnabledRedo: !a.isEmpty(),
                        isEnabledUndo: !t.isEmpty(),
                        redoStack: n ? n.text().translatedText() : "",
                        undoStack: i ? i.text().translatedText() : ""
                    }
                }
            }
            $a.contextType = Ja;
            var Ya = a(73935),
                en = a(5383);
            class tn extends i.PureComponent {
                constructor() {
                    super(...arguments), this._ref = null, this._update = () => {
                        this.forceUpdate()
                    }, this._setRef = e => {
                        this._ref = e
                    }, this._handleMeasure = ({
                        width: e
                    }) => {
                        this.props.width.setValue(e)
                    }
                }
                componentDidMount() {
                    const {
                        element: e,
                        isFake: t,
                        width: a
                    } = this.props;
                    if (t) a.subscribe(this._update);
                    else {
                        const t = (0, $.ensureNotNull)(this._ref);
                        Ya.findDOMNode(t).appendChild(e)
                    }
                }
                componentWillUnmount() {
                    const {
                        width: e,
                        isFake: t
                    } = this.props;
                    t && e.unsubscribe(this._update)
                }
                render() {
                    const {
                        isFake: e = !1,
                        width: t
                    } = this.props;
                    return i.createElement(en, {
                        shouldMeasure: !e,
                        whitelist: ["width"],
                        onMeasure: this._handleMeasure
                    }, i.createElement(b, {
                        ref: this._setRef,
                        style: e ? {
                            width: t.value()
                        } : void 0,
                        "data-is-custom-header-element": !0
                    }))
                }
            }

            function an(e) {
                const {
                    displayMode: t,
                    params: a
                } = e;
                return i.createElement(m.ToolWidgetMenu, {
                    content: i.createElement(L, {
                        collapseWhen: void 0 !== a.icon ? void 0 : [],
                        displayMode: t,
                        icon: a.icon,
                        text: a.title,
                        title: a.tooltip,
                        "data-name": "dropdown",
                        "data-is-custom-header-element": !0
                    }),
                    drawerPosition: "Bottom",
                    drawerBreakpoint: k.DialogBreakpoints.TabletSmall,
                    arrow: !1
                }, a.items.map((e, t) => i.createElement(u.PopupMenuItem, {
                    key: t,
                    label: e.title,
                    onClick: () => e.onSelect(),
                    "data-name": "dropdown-item"
                })))
            }

            function nn() {
                return {
                    Bars: n.enabled("header_chart_type") ? F : void 0,
                    Compare: n.enabled("header_compare") ? B : void 0,
                    Custom: tn,
                    Fullscreen: n.enabled("header_fullscreen_button") ? J : void 0,
                    Indicators: n.enabled("header_indicators") ? pe : void 0,
                    Intervals: n.enabled("header_resolutions") ? Ke : void 0,
                    OpenPopup: Ze,
                    Properties: n.enabled("header_settings") && n.enabled("show_chart_property_page") ? Ye : void 0,
                    SaveLoad: n.enabled("header_saveload") ? kt : void 0,
                    Screenshot: n.enabled("header_screenshot") ? Zt : void 0,
                    SymbolSearch: n.enabled("header_symbol_search") ? sa : void 0,
                    Templates: n.enabled("study_templates") ? Da : void 0,
                    Dropdown: an,
                    UndoRedo: n.enabled("header_undo_redo") ? $a : void 0,
                    Layout: void 0
                }
            }
        },
        33756: (e, t, a) => {
            "use strict";
            a.d(t, {
                createStudyTemplateMetaInfo: () => i,
                descriptionString: () => s
            });
            var n = a(17e3);

            function i(e, t) {
                return {
                    indicators: e.orderedDataSources(!0).filter(e => (0, n.isStudy)(e) && !(0, n.isESDStudy)(e)).map(e => ({
                        id: e.metaInfo().id,
                        description: e.title(!0, void 0, !0)
                    })),
                    interval: t
                }
            }

            function s(e) {
                const t = new Map;
                return e.forEach(e => {
                    const [a, n] = t.get(e.id) || [e.description, 0];
                    t.set(e.id, [a, n + 1])
                }), Array.from(t.values()).map(([e, t]) => `${e}${t>1?" x "+t:""}`).join(", ")
            }
        },
        1495: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                SERIES_ICONS: () => d
            });
            var n = a(27292),
                i = a(82302),
                s = a(83153),
                o = a(156),
                l = a(63724),
                r = a(35564),
                h = a(24631),
                c = a(60554);
            const d = {
                3: n,
                0: i,
                1: s,
                8: o,
                9: l,
                2: r,
                10: h,
                12: c
            }
        },
        84629: (e, t, a) => {
            "use strict";
            a.d(t, {
                convertImageNameToUrl: () => s
            });
            var n = a(27490),
                i = a(42971);

            function s(e) {
                return n.enabled("charting_library_base") || (0, i.isProd)() ? "https://www.tradingview.com/x/" + e + "/" : window.location.protocol + "//" + window.location.host + "/x/" + e + "/"
            }
        },
        63526: (e, t, a) => {
            "use strict";

            function n(e, t) {
                const a = document.createElement("a");
                a.style.display = "none", a.href = t, a.download = e, a.click()
            }
            a.d(t, {
                downloadFile: () => n
            })
        },
        59726: (e, t, a) => {
            "use strict";

            function n(e, t, a, n, i) {
                function s(i) {
                    if (e > i.timeStamp) return;
                    const s = i.target;
                    void 0 !== a && null !== t && null !== s && s.ownerDocument === n && (t.contains(s) || a(i))
                }
                return i.click && n.addEventListener("click", s, !1), i.mouseDown && n.addEventListener("mousedown", s, !1), i.touchEnd && n.addEventListener("touchend", s, !1), i.touchStart && n.addEventListener("touchstart", s, !1), () => {
                    n.removeEventListener("click", s, !1), n.removeEventListener("mousedown", s, !1), n.removeEventListener("touchend", s, !1), n.removeEventListener("touchstart", s, !1)
                }
            }
            a.d(t, {
                addOutsideEventListener: () => n
            })
        },
        72923: (e, t, a) => {
            "use strict";
            a.d(t, {
                DialogBreakpoints: () => i
            });
            var n = a(32455);
            const i = {
                SmallHeight: n["small-height-breakpoint"],
                TabletSmall: n["tablet-small-breakpoint"],
                TabletNormal: n["tablet-normal-breakpoint"]
            }
        },
        79653: (e, t, a) => {
            "use strict";
            a.d(t, {
                SymbolSearchDialogFooter: () => l
            });
            var n = a(67294),
                i = a(94184),
                s = a.n(i),
                o = a(84856);

            function l(e) {
                const {
                    className: t,
                    children: a
                } = e;
                return n.createElement("div", {
                    className: s()(o.footer, t)
                }, a)
            }
        },
        65043: (e, t, a) => {
            "use strict";
            a.d(t, {
                FavoriteButton: () => d
            });
            var n = a(79881),
                i = a(67294),
                s = a(94184),
                o = a(49775),
                l = a(72579),
                r = a(23204),
                h = a(69560);
            const c = {
                add: (0, n.t)("Add to favorites"),
                remove: (0, n.t)("Remove from favorites")
            };

            function d(e) {
                const {
                    className: t,
                    isFilled: a,
                    isActive: n,
                    onClick: d,
                    ...u
                } = e;
                return i.createElement(o.Icon, { ...u,
                    className: s(h.favorite, "apply-common-tooltip", a && h.checked, n && h.active, t),
                    icon: a ? l : r,
                    onClick: d,
                    title: a ? c.remove : c.add
                })
            }
        },
        77727: (e, t, a) => {
            "use strict";
            a.d(t, {
                useForceUpdate: () => i
            });
            var n = a(67294);
            const i = () => {
                const [, e] = (0, n.useReducer)((e, t) => e + 1, 0);
                return e
            }
        },
        14303: (e, t, a) => {
            "use strict";
            a.d(t, {
                RemoveButton: () => c
            });
            var n = a(79881),
                i = a(67294),
                s = a(94184),
                o = a(49775),
                l = a(36535),
                r = a(15169);
            const h = {
                remove: (0, n.t)("Remove")
            };

            function c(e) {
                const {
                    className: t,
                    isActive: a,
                    onClick: n,
                    title: c,
                    hidden: d,
                    "data-name": u = "remove-button",
                    ...m
                } = e;
                return i.createElement(o.Icon, { ...m,
                    "data-name": u,
                    className: s(r.button, "apply-common-tooltip", a && r.active, d && r.hidden, t),
                    icon: l,
                    onClick: n,
                    title: c || h.remove
                })
            }
        },
        4598: (e, t, a) => {
            "use strict";

            function n(e, t, a = {}) {
                const n = Object.assign({}, t);
                for (const i of Object.keys(t)) {
                    const s = a[i] || i;
                    s in e && (n[i] = [e[s], t[i]].join(" "))
                }
                return n
            }

            function i(e, t, a = {}) {
                return Object.assign({}, e, n(e, t, a))
            }
            a.d(t, {
                weakComposeClasses: () => n,
                mergeThemes: () => i
            })
        },
        58448: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M8.5 6A2.5 2.5 0 0 0 6 8.5V11h1V8.5C7 7.67 7.67 7 8.5 7H11V6H8.5zM6 17v2.5A2.5 2.5 0 0 0 8.5 22H11v-1H8.5A1.5 1.5 0 0 1 7 19.5V17H6zM19.5 7H17V6h2.5A2.5 2.5 0 0 1 22 8.5V11h-1V8.5c0-.83-.67-1.5-1.5-1.5zM22 19.5V17h-1v2.5c0 .83-.67 1.5-1.5 1.5H17v1h2.5a2.5 2.5 0 0 0 2.5-2.5z"/></svg>'
        },
        51382: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M8.5 6A2.5 2.5 0 0 0 6 8.5v11A2.5 2.5 0 0 0 8.5 22h11a2.5 2.5 0 0 0 2.5-2.5v-3h-1v3c0 .83-.67 1.5-1.5 1.5h-11A1.5 1.5 0 0 1 7 19.5v-11C7 7.67 7.67 7 8.5 7h3V6h-3zm7 1h4.8l-7.49 7.48.71.7L21 7.72v4.79h1V6h-6.5v1z"/></svg>'
        },
        27292: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M12.5 17.207L18.707 11h2l3.647-3.646-.708-.708L20.293 10h-2L12.5 15.793l-3-3-4.854 4.853.708.708L9.5 14.207z"/><path d="M9 16h1v1H9zm1 1h1v1h-1zm-1 1h1v1H9zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1H9zm2 0h1v1h-1zm-3-3h1v1H8zm-1 1h1v1H7zm-1 1h1v1H6zm2 0h1v1H8zm-1 1h1v1H7zm-2 0h1v1H5zm17-9h1v1h-1zm1-1h1v1h-1zm0 2h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-5-7h1v1h-1zm2 0h1v1h-1zm1-1h1v1h-1zm-2 2h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-2-6h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-3-3h1v1h-1zm-1 1h1v1h-1zm-1 1h1v1h-1zm2 0h1v1h-1zm-1 1h1v1h-1z"/></svg>'
        },
        82302: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="none" stroke="currentColor" stroke-linecap="square"><path d="M10.5 7.5v15M7.5 20.5H10M13.5 11.5H11M19.5 6.5v15M16.5 9.5H19M22.5 16.5H20"/></g></svg>'
        },
        24631: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="none" stroke="currentColor"><path stroke-dasharray="1,1" d="M4 14.5h22"/><path stroke-linecap="round" stroke-linejoin="round" d="M7.5 12.5l2-4 1 2 2-4 3 6"/><path stroke-linecap="round" d="M5.5 16.5l-1 2"/><path stroke-linecap="round" stroke-linejoin="round" d="M17.5 16.5l2 4 2-4m2-4l1-2-1 2z"/></g></svg>'
        },
        83153: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M17 11v6h3v-6h-3zm-.5-1h4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5z"/><path d="M18 7h1v3.5h-1zm0 10.5h1V21h-1z"/><path d="M9 8v12h3V8H9zm-.5-1h4a.5.5 0 0 1 .5.5v13a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-13a.5.5 0 0 1 .5-.5z"/><path d="M10 4h1v3.5h-1zm0 16.5h1V24h-1z"/></svg>'
        },
        72230: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><g fill="none"><path stroke="currentColor" d="M11 20.5H7.5a5 5 0 1 1 .42-9.98 7.5 7.5 0 0 1 14.57 2.1 4 4 0 0 1-1 7.877H18"/><path stroke="currentColor" d="M14.5 24V12.5M11 16l3.5-3.5L18 16"/></g></svg>'
        },
        84022: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M13.5 6a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17zM4 14.5a9.5 9.5 0 1 1 19 0 9.5 9.5 0 0 1-19 0z"/><path fill="currentColor" d="M9 14h4v-4h1v4h4v1h-4v4h-1v-4H9v-1z"/></svg>'
        },
        72061: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor"><path d="M21 7v4h1V6h-5v1z"/><path d="M16.854 11.854l5-5-.708-.708-5 5zM7 7v4H6V6h5v1z"/><path d="M11.146 11.854l-5-5 .708-.708 5 5zM21 21v-4h1v5h-5v-1z"/><path d="M16.854 16.146l5 5-.708.708-5-5z"/><g><path d="M7 21v-4H6v5h5v-1z"/><path d="M11.146 16.146l-5 5 .708.708 5-5z"/></g></g></svg>'
        },
        156: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M9 8v12h3V8H9zm-1-.502C8 7.223 8.215 7 8.498 7h4.004c.275 0 .498.22.498.498v13.004a.493.493 0 0 1-.498.498H8.498A.496.496 0 0 1 8 20.502V7.498z"/><path d="M10 4h1v3.5h-1z"/><path d="M17 6v6h3V6h-3zm-1-.5c0-.276.215-.5.498-.5h4.004c.275 0 .498.23.498.5v7c0 .276-.215.5-.498.5h-4.004a.503.503 0 0 1-.498-.5v-7z"/><path d="M18 2h1v3.5h-1z"/></svg>'
        },
        60554: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" clip-rule="evenodd" d="M7.5 7H7v14h5V7H7.5zM8 20V8h3v12H8zm7.5-11H15v10h5V9h-4.5zm.5 9v-8h3v8h-3z"/></svg>'
        },
        63724: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="currentColor"><path d="M17 11v6h3v-6h-3zm-.5-1h4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5z"/><path d="M18 7h1v3.5h-1zm0 10.5h1V21h-1z"/><path d="M9 8v11h3V8H9zm-.5-1h4a.5.5 0 0 1 .5.5v12a.5.5 0 0 1-.5.5h-4a.5.5 0 0 1-.5-.5v-12a.5.5 0 0 1 .5-.5z"/><path d="M10 4h1v5h-1zm0 14h1v5h-1zM8.5 9H10v1H8.5zM11 9h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11zm-1 1h1v1h-1zm-1.5 1H10v1H8.5zm2.5 0h1.5v1H11z"/></svg>'
        },
        60226: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M20 17l-5 5M15 17l5 5M9 11.5h7M17.5 8a2.5 2.5 0 0 0-5 0v11a2.5 2.5 0 0 1-5 0"/></svg>'
        },
        35564: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M11.982 16.689L17.192 12h3.033l4.149-4.668-.748-.664L19.776 11h-2.968l-4.79 4.311L9 12.293l-4.354 4.353.708.708L9 13.707z"/></svg>'
        },
        19614: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 21" width="21" height="21"><g fill="none" stroke="currentColor"><path d="M18.5 11v5.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-13a2 2 0 0 1 2-2H9"/><path stroke-linecap="square" d="M18 2l-8.5 8.5m4-9h5v5"/></g></svg>'
        },
        84050: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><g fill="currentColor" fill-rule="evenodd"><path fill-rule="nonzero" d="M14 17a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm0-1a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/><path d="M5.005 16A1.003 1.003 0 0 1 4 14.992v-1.984A.998.998 0 0 1 5 12h1.252a7.87 7.87 0 0 1 .853-2.06l-.919-.925c-.356-.397-.348-1 .03-1.379l1.42-1.42a1 1 0 0 1 1.416.007l.889.882A7.96 7.96 0 0 1 12 6.253V5c0-.514.46-1 1-1h2c.557 0 1 .44 1 1v1.253a7.96 7.96 0 0 1 2.06.852l.888-.882a1 1 0 0 1 1.416-.006l1.42 1.42a.999.999 0 0 1 .029 1.377s-.4.406-.918.926a7.87 7.87 0 0 1 .853 2.06H23c.557 0 1 .447 1 1.008v1.984A.998.998 0 0 1 23 16h-1.252a7.87 7.87 0 0 1-.853 2.06l.882.888a1 1 0 0 1 .006 1.416l-1.42 1.42a1 1 0 0 1-1.415-.007l-.889-.882a7.96 7.96 0 0 1-2.059.852v1.248c0 .56-.45 1.005-1.008 1.005h-1.984A1.004 1.004 0 0 1 12 22.995v-1.248a7.96 7.96 0 0 1-2.06-.852l-.888.882a1 1 0 0 1-1.416.006l-1.42-1.42a1 1 0 0 1 .007-1.415l.882-.888A7.87 7.87 0 0 1 6.252 16H5.005zm3.378-6.193l-.227.34A6.884 6.884 0 0 0 7.14 12.6l-.082.4H5.005C5.002 13 5 13.664 5 14.992c0 .005.686.008 2.058.008l.082.4c.18.883.52 1.71 1.016 2.453l.227.34-1.45 1.46c-.004.003.466.477 1.41 1.422l1.464-1.458.34.227a6.959 6.959 0 0 0 2.454 1.016l.399.083v2.052c0 .003.664.005 1.992.005.005 0 .008-.686.008-2.057l.399-.083a6.959 6.959 0 0 0 2.454-1.016l.34-.227 1.46 1.45c.003.004.477-.466 1.422-1.41l-1.458-1.464.227-.34A6.884 6.884 0 0 0 20.86 15.4l.082-.4h2.053c.003 0 .005-.664.005-1.992 0-.005-.686-.008-2.058-.008l-.082-.4a6.884 6.884 0 0 0-1.016-2.453l-.227-.34 1.376-1.384.081-.082-1.416-1.416-1.465 1.458-.34-.227a6.959 6.959 0 0 0-2.454-1.016L15 7.057V5c0-.003-.664-.003-1.992 0-.005 0-.008.686-.008 2.057l-.399.083a6.959 6.959 0 0 0-2.454 1.016l-.34.227-1.46-1.45c-.003-.004-.477.466-1.421 1.408l1.457 1.466z"/></g></svg>'
        },
        51897: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M18.293 13l-2.647 2.646.707.708 3.854-3.854-3.854-3.854-.707.708L18.293 12H12.5A5.5 5.5 0 0 0 7 17.5V19h1v-1.5a4.5 4.5 0 0 1 4.5-4.5h5.793z"/></svg>'
        },
        78780: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.118 6a.5.5 0 0 0-.447.276L9.809 8H5.5A1.5 1.5 0 0 0 4 9.5v10A1.5 1.5 0 0 0 5.5 21h16a1.5 1.5 0 0 0 1.5-1.5v-10A1.5 1.5 0 0 0 21.5 8h-4.309l-.862-1.724A.5.5 0 0 0 15.882 6h-4.764zm-1.342-.17A1.5 1.5 0 0 1 11.118 5h4.764a1.5 1.5 0 0 1 1.342.83L17.809 7H21.5A2.5 2.5 0 0 1 24 9.5v10a2.5 2.5 0 0 1-2.5 2.5h-16A2.5 2.5 0 0 1 3 19.5v-10A2.5 2.5 0 0 1 5.5 7h3.691l.585-1.17z"/><path fill-rule="evenodd" clip-rule="evenodd" d="M13.5 18a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm0 1a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9z"/></svg>'
        },
        24769: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" fill-rule="evenodd" d="M8 7h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zM6 8c0-1.1.9-2 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V8zm11-1h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm-2 1c0-1.1.9-2 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2V8zm-4 8H8a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1zm-3-1a2 2 0 0 0-2 2v3c0 1.1.9 2 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H8zm9 1h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zm-2 1c0-1.1.9-2 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2v-3z"/></svg>'
        },
        58269: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="currentColor" d="M8.707 13l2.647 2.646-.707.708L6.792 12.5l3.853-3.854.708.708L8.707 12H14.5a5.5 5.5 0 0 1 5.5 5.5V19h-1v-1.5a4.5 4.5 0 0 0-4.5-4.5H8.707z"/></svg>'
        },
        36535: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"><path fill="currentColor" d="M9.707 9l4.647-4.646-.707-.708L9 8.293 4.354 3.646l-.708.708L8.293 9l-4.647 4.646.708.708L9 9.707l4.646 4.647.708-.707L9.707 9z"/></svg>'
        },
        6577: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M8 9.5H6.5a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V20m-8-1.5h11a1 1 0 0 0 1-1v-11a1 1 0 0 0-1-1h-11a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1z"/></svg>'
        },
        66146: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"><path stroke="currentColor" d="M6.5 16v4.5a1 1 0 001 1h14a1 1 0 001-1V16M14.5 5V17m-4-3.5l4 4l4-4"/></svg>'
        },
        72579: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path fill="currentColor" d="M9 1l2.35 4.76 5.26.77-3.8 3.7.9 5.24L9 13l-4.7 2.47.9-5.23-3.8-3.71 5.25-.77L9 1z"/></svg>'
        },
        23204: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18 18" width="18" height="18" fill="none"><path stroke="currentColor" d="M9 2.13l1.903 3.855.116.236.26.038 4.255.618-3.079 3.001-.188.184.044.259.727 4.237-3.805-2L9 12.434l-.233.122-3.805 2.001.727-4.237.044-.26-.188-.183-3.079-3.001 4.255-.618.26-.038.116-.236L9 2.13z"/></svg>'
        },
        18679: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28" fill="none"><path stroke="currentColor" d="M19 15l2.5-2.5c1-1 1.5-3.5-.5-5.5s-4.5-1.5-5.5-.5L13 9M10 12l-2.5 2.5c-1 1-1.5 3.5.5 5.5s4.5 1.5 5.5.5L16 18M17 11l-5 5"/></svg>'
        },
        15155: e => {
            e.exports = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28" width="28" height="28"><path fill="#1DA1F2" d="M10.28 22.26c7.55 0 11.68-6.26 11.68-11.67v-.53c.8-.58 1.49-1.3 2.04-2.13-.74.33-1.53.54-2.36.65.85-.5 1.5-1.32 1.8-2.28-.78.48-1.66.81-2.6 1a4.1 4.1 0 00-7 3.74c-3.4-.17-6.43-1.8-8.46-4.29a4.1 4.1 0 001.28 5.48c-.68-.02-1.3-.2-1.86-.5v.05a4.11 4.11 0 003.29 4.02 4 4 0 01-1.85.08 4.1 4.1 0 003.83 2.85A8.23 8.23 0 014 20.43a11.67 11.67 0 006.28 1.83z"/></svg>'
        }
    }
]);