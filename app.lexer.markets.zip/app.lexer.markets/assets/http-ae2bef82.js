import {
    p as B,
    a as Te,
    c as x,
    e as le,
    b as Ae
} from "./index-95ae70b2.js";
var K = globalThis && globalThis.__spreadArray || function(t, e, r) {
        if (r || arguments.length === 2)
            for (var i = 0, s = e.length, o; i < s; i++)(o || !(i in e)) && (o || (o = Array.prototype.slice.call(e, 0, i)), o[i] = e[i]);
        return t.concat(o || Array.prototype.slice.call(e))
    },
    Pe = function() {
        function t(e, r, i) {
            this.name = e, this.version = r, this.os = i, this.type = "browser"
        }
        return t
    }(),
    xe = function() {
        function t(e) {
            this.version = e, this.type = "node", this.name = "node", this.os = B.platform
        }
        return t
    }(),
    Be = function() {
        function t(e, r, i, s) {
            this.name = e, this.version = r, this.os = i, this.bot = s, this.type = "bot-device"
        }
        return t
    }(),
    Ce = function() {
        function t() {
            this.type = "bot", this.bot = !0, this.name = "bot", this.version = null, this.os = null
        }
        return t
    }(),
    De = function() {
        function t() {
            this.type = "react-native", this.name = "react-native", this.version = null, this.os = null
        }
        return t
    }(),
    Ie = /alexa|bot|crawl(er|ing)|facebookexternalhit|feedburner|google web preview|nagios|postrank|pingdom|slurp|spider|yahoo!|yandex/,
    Me = /(nuhk|curl|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask\ Jeeves\/Teoma|ia_archiver)/,
    Q = 3,
    Le = [
        ["aol", /AOLShield\/([0-9\._]+)/],
        ["edge", /Edge\/([0-9\._]+)/],
        ["edge-ios", /EdgiOS\/([0-9\._]+)/],
        ["yandexbrowser", /YaBrowser\/([0-9\._]+)/],
        ["kakaotalk", /KAKAOTALK\s([0-9\.]+)/],
        ["samsung", /SamsungBrowser\/([0-9\.]+)/],
        ["silk", /\bSilk\/([0-9._-]+)\b/],
        ["miui", /MiuiBrowser\/([0-9\.]+)$/],
        ["beaker", /BeakerBrowser\/([0-9\.]+)/],
        ["edge-chromium", /EdgA?\/([0-9\.]+)/],
        ["chromium-webview", /(?!Chrom.*OPR)wv\).*Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
        ["chrome", /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
        ["phantomjs", /PhantomJS\/([0-9\.]+)(:?\s|$)/],
        ["crios", /CriOS\/([0-9\.]+)(:?\s|$)/],
        ["firefox", /Firefox\/([0-9\.]+)(?:\s|$)/],
        ["fxios", /FxiOS\/([0-9\.]+)/],
        ["opera-mini", /Opera Mini.*Version\/([0-9\.]+)/],
        ["opera", /Opera\/([0-9\.]+)(?:\s|$)/],
        ["opera", /OPR\/([0-9\.]+)(:?\s|$)/],
        ["pie", /^Microsoft Pocket Internet Explorer\/(\d+\.\d+)$/],
        ["pie", /^Mozilla\/\d\.\d+\s\(compatible;\s(?:MSP?IE|MSInternet Explorer) (\d+\.\d+);.*Windows CE.*\)$/],
        ["netfront", /^Mozilla\/\d\.\d+.*NetFront\/(\d.\d)/],
        ["ie", /Trident\/7\.0.*rv\:([0-9\.]+).*\).*Gecko$/],
        ["ie", /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
        ["ie", /MSIE\s(7\.0)/],
        ["bb10", /BB10;\sTouch.*Version\/([0-9\.]+)/],
        ["android", /Android\s([0-9\.]+)/],
        ["ios", /Version\/([0-9\._]+).*Mobile.*Safari.*/],
        ["safari", /Version\/([0-9\._]+).*Safari/],
        ["facebook", /FB[AS]V\/([0-9\.]+)/],
        ["instagram", /Instagram\s([0-9\.]+)/],
        ["ios-webview", /AppleWebKit\/([0-9\.]+).*Mobile/],
        ["ios-webview", /AppleWebKit\/([0-9\.]+).*Gecko\)$/],
        ["curl", /^curl\/([0-9\.]+)$/],
        ["searchbot", Ie]
    ],
    Y = [
        ["iOS", /iP(hone|od|ad)/],
        ["Android OS", /Android/],
        ["BlackBerry OS", /BlackBerry|BB10/],
        ["Windows Mobile", /IEMobile/],
        ["Amazon OS", /Kindle/],
        ["Windows 3.11", /Win16/],
        ["Windows 95", /(Windows 95)|(Win95)|(Windows_95)/],
        ["Windows 98", /(Windows 98)|(Win98)/],
        ["Windows 2000", /(Windows NT 5.0)|(Windows 2000)/],
        ["Windows XP", /(Windows NT 5.1)|(Windows XP)/],
        ["Windows Server 2003", /(Windows NT 5.2)/],
        ["Windows Vista", /(Windows NT 6.0)/],
        ["Windows 7", /(Windows NT 6.1)/],
        ["Windows 8", /(Windows NT 6.2)/],
        ["Windows 8.1", /(Windows NT 6.3)/],
        ["Windows 10", /(Windows NT 10.0)/],
        ["Windows ME", /Windows ME/],
        ["Windows CE", /Windows CE|WinCE|Microsoft Pocket Internet Explorer/],
        ["Open BSD", /OpenBSD/],
        ["Sun OS", /SunOS/],
        ["Chrome OS", /CrOS/],
        ["Linux", /(Linux)|(X11)/],
        ["Mac OS", /(Mac_PowerPC)|(Macintosh)/],
        ["QNX", /QNX/],
        ["BeOS", /BeOS/],
        ["OS/2", /OS\/2/]
    ];

function cr(t) {
    return t ? Z(t) : typeof document > "u" && typeof navigator < "u" && navigator.product === "ReactNative" ? new De : typeof navigator < "u" ? Z(navigator.userAgent) : Fe()
}

function je(t) {
    return t !== "" && Le.reduce(function(e, r) {
        var i = r[0],
            s = r[1];
        if (e) return e;
        var o = s.exec(t);
        return !!o && [i, o]
    }, !1)
}

function Z(t) {
    var e = je(t);
    if (!e) return null;
    var r = e[0],
        i = e[1];
    if (r === "searchbot") return new Ce;
    var s = i[1] && i[1].split(".").join("_").split("_").slice(0, 3);
    s ? s.length < Q && (s = K(K([], s, !0), We(Q - s.length), !0)) : s = [];
    var o = s.join("."),
        c = Ne(t),
        u = Me.exec(t);
    return u && u[1] ? new Be(r, o, c, u[1]) : new Pe(r, o, c)
}

function Ne(t) {
    for (var e = 0, r = Y.length; e < r; e++) {
        var i = Y[e],
            s = i[0],
            o = i[1],
            c = o.exec(t);
        if (c) return s
    }
    return null
}

function Fe() {
    var t = typeof B < "u" && B.version;
    return t ? new xe(B.version.slice(1)) : null
}

function We(t) {
    for (var e = [], r = 0; r < t; r++) e.push("0");
    return e
}
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var $ = function(t, e) {
    return $ = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(r, i) {
        r.__proto__ = i
    } || function(r, i) {
        for (var s in i) i.hasOwnProperty(s) && (r[s] = i[s])
    }, $(t, e)
};

function Ue(t, e) {
    $(t, e);

    function r() {
        this.constructor = t
    }
    t.prototype = e === null ? Object.create(e) : (r.prototype = e.prototype, new r)
}
var H = function() {
    return H = Object.assign || function(e) {
        for (var r, i = 1, s = arguments.length; i < s; i++) {
            r = arguments[i];
            for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o])
        }
        return e
    }, H.apply(this, arguments)
};

function $e(t, e) {
    var r = {};
    for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && e.indexOf(i) < 0 && (r[i] = t[i]);
    if (t != null && typeof Object.getOwnPropertySymbols == "function")
        for (var s = 0, i = Object.getOwnPropertySymbols(t); s < i.length; s++) e.indexOf(i[s]) < 0 && Object.prototype.propertyIsEnumerable.call(t, i[s]) && (r[i[s]] = t[i[s]]);
    return r
}

function He(t, e, r, i) {
    var s = arguments.length,
        o = s < 3 ? e : i === null ? i = Object.getOwnPropertyDescriptor(e, r) : i,
        c;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") o = Reflect.decorate(t, e, r, i);
    else
        for (var u = t.length - 1; u >= 0; u--)(c = t[u]) && (o = (s < 3 ? c(o) : s > 3 ? c(e, r, o) : c(e, r)) || o);
    return s > 3 && o && Object.defineProperty(e, r, o), o
}

function ke(t, e) {
    return function(r, i) {
        e(r, i, t)
    }
}

function Ve(t, e) {
    if (typeof Reflect == "object" && typeof Reflect.metadata == "function") return Reflect.metadata(t, e)
}

function qe(t, e, r, i) {
    function s(o) {
        return o instanceof r ? o : new r(function(c) {
            c(o)
        })
    }
    return new(r || (r = Promise))(function(o, c) {
        function u(b) {
            try {
                f(i.next(b))
            } catch (g) {
                c(g)
            }
        }

        function E(b) {
            try {
                f(i.throw(b))
            } catch (g) {
                c(g)
            }
        }

        function f(b) {
            b.done ? o(b.value) : s(b.value).then(u, E)
        }
        f((i = i.apply(t, e || [])).next())
    })
}

function Je(t, e) {
    var r = {
            label: 0,
            sent: function() {
                if (o[0] & 1) throw o[1];
                return o[1]
            },
            trys: [],
            ops: []
        },
        i, s, o, c;
    return c = {
        next: u(0),
        throw: u(1),
        return: u(2)
    }, typeof Symbol == "function" && (c[Symbol.iterator] = function() {
        return this
    }), c;

    function u(f) {
        return function(b) {
            return E([f, b])
        }
    }

    function E(f) {
        if (i) throw new TypeError("Generator is already executing.");
        for (; r;) try {
            if (i = 1, s && (o = f[0] & 2 ? s.return : f[0] ? s.throw || ((o = s.return) && o.call(s), 0) : s.next) && !(o = o.call(s, f[1])).done) return o;
            switch (s = 0, o && (f = [f[0] & 2, o.value]), f[0]) {
                case 0:
                case 1:
                    o = f;
                    break;
                case 4:
                    return r.label++, {
                        value: f[1],
                        done: !1
                    };
                case 5:
                    r.label++, s = f[1], f = [0];
                    continue;
                case 7:
                    f = r.ops.pop(), r.trys.pop();
                    continue;
                default:
                    if (o = r.trys, !(o = o.length > 0 && o[o.length - 1]) && (f[0] === 6 || f[0] === 2)) {
                        r = 0;
                        continue
                    }
                    if (f[0] === 3 && (!o || f[1] > o[0] && f[1] < o[3])) {
                        r.label = f[1];
                        break
                    }
                    if (f[0] === 6 && r.label < o[1]) {
                        r.label = o[1], o = f;
                        break
                    }
                    if (o && r.label < o[2]) {
                        r.label = o[2], r.ops.push(f);
                        break
                    }
                    o[2] && r.ops.pop(), r.trys.pop();
                    continue
            }
            f = e.call(t, r)
        } catch (b) {
            f = [6, b], s = 0
        } finally {
            i = o = 0
        }
        if (f[0] & 5) throw f[1];
        return {
            value: f[0] ? f[1] : void 0,
            done: !0
        }
    }
}

function Ge(t, e, r, i) {
    i === void 0 && (i = r), t[i] = e[r]
}

function Xe(t, e) {
    for (var r in t) r !== "default" && !e.hasOwnProperty(r) && (e[r] = t[r])
}

function k(t) {
    var e = typeof Symbol == "function" && Symbol.iterator,
        r = e && t[e],
        i = 0;
    if (r) return r.call(t);
    if (t && typeof t.length == "number") return {
        next: function() {
            return t && i >= t.length && (t = void 0), {
                value: t && t[i++],
                done: !t
            }
        }
    };
    throw new TypeError(e ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function he(t, e) {
    var r = typeof Symbol == "function" && t[Symbol.iterator];
    if (!r) return t;
    var i = r.call(t),
        s, o = [],
        c;
    try {
        for (;
            (e === void 0 || e-- > 0) && !(s = i.next()).done;) o.push(s.value)
    } catch (u) {
        c = {
            error: u
        }
    } finally {
        try {
            s && !s.done && (r = i.return) && r.call(i)
        } finally {
            if (c) throw c.error
        }
    }
    return o
}

function ze() {
    for (var t = [], e = 0; e < arguments.length; e++) t = t.concat(he(arguments[e]));
    return t
}

function Ke() {
    for (var t = 0, e = 0, r = arguments.length; e < r; e++) t += arguments[e].length;
    for (var i = Array(t), s = 0, e = 0; e < r; e++)
        for (var o = arguments[e], c = 0, u = o.length; c < u; c++, s++) i[s] = o[c];
    return i
}

function L(t) {
    return this instanceof L ? (this.v = t, this) : new L(t)
}

function Qe(t, e, r) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var i = r.apply(t, e || []),
        s, o = [];
    return s = {}, c("next"), c("throw"), c("return"), s[Symbol.asyncIterator] = function() {
        return this
    }, s;

    function c(d) {
        i[d] && (s[d] = function(w) {
            return new Promise(function(h, O) {
                o.push([d, w, h, O]) > 1 || u(d, w)
            })
        })
    }

    function u(d, w) {
        try {
            E(i[d](w))
        } catch (h) {
            g(o[0][3], h)
        }
    }

    function E(d) {
        d.value instanceof L ? Promise.resolve(d.value.v).then(f, b) : g(o[0][2], d)
    }

    function f(d) {
        u("next", d)
    }

    function b(d) {
        u("throw", d)
    }

    function g(d, w) {
        d(w), o.shift(), o.length && u(o[0][0], o[0][1])
    }
}

function Ye(t) {
    var e, r;
    return e = {}, i("next"), i("throw", function(s) {
        throw s
    }), i("return"), e[Symbol.iterator] = function() {
        return this
    }, e;

    function i(s, o) {
        e[s] = t[s] ? function(c) {
            return (r = !r) ? {
                value: L(t[s](c)),
                done: s === "return"
            } : o ? o(c) : c
        } : o
    }
}

function Ze(t) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var e = t[Symbol.asyncIterator],
        r;
    return e ? e.call(t) : (t = typeof k == "function" ? k(t) : t[Symbol.iterator](), r = {}, i("next"), i("throw"), i("return"), r[Symbol.asyncIterator] = function() {
        return this
    }, r);

    function i(o) {
        r[o] = t[o] && function(c) {
            return new Promise(function(u, E) {
                c = t[o](c), s(u, E, c.done, c.value)
            })
        }
    }

    function s(o, c, u, E) {
        Promise.resolve(E).then(function(f) {
            o({
                value: f,
                done: u
            })
        }, c)
    }
}

function et(t, e) {
    return Object.defineProperty ? Object.defineProperty(t, "raw", {
        value: e
    }) : t.raw = e, t
}

function tt(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (t != null)
        for (var r in t) Object.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e
}

function rt(t) {
    return t && t.__esModule ? t : {
        default: t
    }
}

function nt(t, e) {
    if (!e.has(t)) throw new TypeError("attempted to get private field on non-instance");
    return e.get(t)
}

function ot(t, e, r) {
    if (!e.has(t)) throw new TypeError("attempted to set private field on non-instance");
    return e.set(t, r), r
}
const it = Object.freeze(Object.defineProperty({
        __proto__: null,
        get __assign() {
            return H
        },
        __asyncDelegator: Ye,
        __asyncGenerator: Qe,
        __asyncValues: Ze,
        __await: L,
        __awaiter: qe,
        __classPrivateFieldGet: nt,
        __classPrivateFieldSet: ot,
        __createBinding: Ge,
        __decorate: He,
        __exportStar: Xe,
        __extends: Ue,
        __generator: Je,
        __importDefault: rt,
        __importStar: tt,
        __makeTemplateObject: et,
        __metadata: Ve,
        __param: ke,
        __read: he,
        __rest: $e,
        __spread: ze,
        __spreadArrays: Ke,
        __values: k
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    st = Te(it);
var y = {};
Object.defineProperty(y, "__esModule", {
    value: !0
});
var at = y.getLocalStorage = At = y.getLocalStorageOrThrow = St = y.getCrypto = Ot = y.getCryptoOrThrow = _t = y.getLocation = mt = y.getLocationOrThrow = vt = y.getNavigator = yt = y.getNavigatorOrThrow = dt = y.getDocument = lt = y.getDocumentOrThrow = ut = y.getFromWindowOrThrow = ct = y.getFromWindow = void 0;

function C(t) {
    let e;
    return typeof window < "u" && typeof window[t] < "u" && (e = window[t]), e
}
var ct = y.getFromWindow = C;

function D(t) {
    const e = C(t);
    if (!e) throw new Error(`${t} is not defined in Window`);
    return e
}
var ut = y.getFromWindowOrThrow = D;

function ft() {
    return D("document")
}
var lt = y.getDocumentOrThrow = ft;

function ht() {
    return C("document")
}
var dt = y.getDocument = ht;

function pt() {
    return D("navigator")
}
var yt = y.getNavigatorOrThrow = pt;

function gt() {
    return C("navigator")
}
var vt = y.getNavigator = gt;

function wt() {
    return D("location")
}
var mt = y.getLocationOrThrow = wt;

function bt() {
    return C("location")
}
var _t = y.getLocation = bt;

function Et() {
    return D("crypto")
}
var Ot = y.getCryptoOrThrow = Et;

function Rt() {
    return C("crypto")
}
var St = y.getCrypto = Rt;

function Tt() {
    return D("localStorage")
}
var At = y.getLocalStorageOrThrow = Tt;

function Pt() {
    return C("localStorage")
}
at = y.getLocalStorage = Pt;
var J = {};
Object.defineProperty(J, "__esModule", {
    value: !0
});
var xt = J.getWindowMetadata = void 0;
const ee = y;

function Bt() {
    let t, e;
    try {
        t = ee.getDocumentOrThrow(), e = ee.getLocationOrThrow()
    } catch {
        return null
    }

    function r() {
        const g = t.getElementsByTagName("link"),
            d = [];
        for (let w = 0; w < g.length; w++) {
            const h = g[w],
                O = h.getAttribute("rel");
            if (O && O.toLowerCase().indexOf("icon") > -1) {
                const v = h.getAttribute("href");
                if (v)
                    if (v.toLowerCase().indexOf("https:") === -1 && v.toLowerCase().indexOf("http:") === -1 && v.indexOf("//") !== 0) {
                        let A = e.protocol + "//" + e.host;
                        if (v.indexOf("/") === 0) A += v;
                        else {
                            const j = e.pathname.split("/");
                            j.pop();
                            const F = j.join("/");
                            A += F + "/" + v
                        }
                        d.push(A)
                    } else if (v.indexOf("//") === 0) {
                    const A = e.protocol + v;
                    d.push(A)
                } else d.push(v)
            }
        }
        return d
    }

    function i(...g) {
        const d = t.getElementsByTagName("meta");
        for (let w = 0; w < d.length; w++) {
            const h = d[w],
                O = ["itemprop", "property", "name"].map(v => h.getAttribute(v)).filter(v => v ? g.includes(v) : !1);
            if (O.length && O) {
                const v = h.getAttribute("content");
                if (v) return v
            }
        }
        return ""
    }

    function s() {
        let g = i("name", "og:site_name", "og:title", "twitter:title");
        return g || (g = t.title), g
    }

    function o() {
        return i("description", "og:description", "twitter:description", "keywords")
    }
    const c = s(),
        u = o(),
        E = e.origin,
        f = r();
    return {
        description: u,
        url: E,
        icons: f,
        name: c
    }
}
xt = J.getWindowMetadata = Bt;
var ur = t => encodeURIComponent(t).replace(/[!'()*]/g, e => `%${e.charCodeAt(0).toString(16).toUpperCase()}`),
    de = "%[a-f0-9]{2}",
    te = new RegExp("(" + de + ")|([^%]+?)", "gi"),
    re = new RegExp("(" + de + ")+", "gi");

function V(t, e) {
    try {
        return [decodeURIComponent(t.join(""))]
    } catch {}
    if (t.length === 1) return t;
    e = e || 1;
    var r = t.slice(0, e),
        i = t.slice(e);
    return Array.prototype.concat.call([], V(r), V(i))
}

function Ct(t) {
    try {
        return decodeURIComponent(t)
    } catch {
        for (var e = t.match(te) || [], r = 1; r < e.length; r++) t = V(e, r).join(""), e = t.match(te) || [];
        return t
    }
}

function Dt(t) {
    for (var e = {
            "%FE%FF": "��",
            "%FF%FE": "��"
        }, r = re.exec(t); r;) {
        try {
            e[r[0]] = decodeURIComponent(r[0])
        } catch {
            var i = Ct(r[0]);
            i !== r[0] && (e[r[0]] = i)
        }
        r = re.exec(t)
    }
    e["%C2"] = "�";
    for (var s = Object.keys(e), o = 0; o < s.length; o++) {
        var c = s[o];
        t = t.replace(new RegExp(c, "g"), e[c])
    }
    return t
}
var fr = function(t) {
        if (typeof t != "string") throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof t + "`");
        try {
            return t = t.replace(/\+/g, " "), decodeURIComponent(t)
        } catch {
            return Dt(t)
        }
    },
    lr = (t, e) => {
        if (!(typeof t == "string" && typeof e == "string")) throw new TypeError("Expected the arguments to be of type `string`");
        if (e === "") return [t];
        const r = t.indexOf(e);
        return r === -1 ? [t] : [t.slice(0, r), t.slice(r + e.length)]
    };
const It = t => JSON.stringify(t, (e, r) => typeof r == "bigint" ? r.toString() + "n" : r),
    Mt = t => {
        const e = /([\[:])?(\d{17,}|(?:[9](?:[1-9]07199254740991|0[1-9]7199254740991|00[8-9]199254740991|007[2-9]99254740991|007199[3-9]54740991|0071992[6-9]4740991|00719925[5-9]740991|007199254[8-9]40991|0071992547[5-9]0991|00719925474[1-9]991|00719925474099[2-9])))([,\}\]])/g,
            r = t.replace(e, '$1"$2n"$3');
        return JSON.parse(r, (i, s) => typeof s == "string" && s.match(/^\d+n$/) ? BigInt(s.substring(0, s.length - 1)) : s)
    };

function Lt(t) {
    if (typeof t != "string") throw new Error(`Cannot safe json parse value of type ${typeof t}`);
    try {
        return Mt(t)
    } catch {
        return t
    }
}

function ne(t) {
    return typeof t == "string" ? t : It(t) || ""
}
const jt = "PARSE_ERROR",
    Nt = "INVALID_REQUEST",
    Ft = "METHOD_NOT_FOUND",
    Wt = "INVALID_PARAMS",
    pe = "INTERNAL_ERROR",
    G = "SERVER_ERROR",
    Ut = [-32700, -32600, -32601, -32602, -32603],
    M = {
        [jt]: {
            code: -32700,
            message: "Parse error"
        },
        [Nt]: {
            code: -32600,
            message: "Invalid Request"
        },
        [Ft]: {
            code: -32601,
            message: "Method not found"
        },
        [Wt]: {
            code: -32602,
            message: "Invalid params"
        },
        [pe]: {
            code: -32603,
            message: "Internal error"
        },
        [G]: {
            code: -32e3,
            message: "Server error"
        }
    },
    ye = G;

function $t(t) {
    return Ut.includes(t)
}

function oe(t) {
    return Object.keys(M).includes(t) ? M[t] : M[ye]
}

function Ht(t) {
    const e = Object.values(M).find(r => r.code === t);
    return e || M[ye]
}

function kt(t, e, r) {
    return t.message.includes("getaddrinfo ENOTFOUND") || t.message.includes("connect ECONNREFUSED") ? new Error(`Unavailable ${r} RPC url at ${e}`) : t
}
var Vt = {},
    S = {},
    ie;

function qt() {
    if (ie) return S;
    ie = 1, Object.defineProperty(S, "__esModule", {
        value: !0
    }), S.isBrowserCryptoAvailable = S.getSubtleCrypto = S.getBrowerCrypto = void 0;

    function t() {
        return (x === null || x === void 0 ? void 0 : x.crypto) || (x === null || x === void 0 ? void 0 : x.msCrypto) || {}
    }
    S.getBrowerCrypto = t;

    function e() {
        const i = t();
        return i.subtle || i.webkitSubtle
    }
    S.getSubtleCrypto = e;

    function r() {
        return !!t() && !!e()
    }
    return S.isBrowserCryptoAvailable = r, S
}
var T = {},
    se;

function Jt() {
    if (se) return T;
    se = 1, Object.defineProperty(T, "__esModule", {
        value: !0
    }), T.isBrowser = T.isNode = T.isReactNative = void 0;

    function t() {
        return typeof document > "u" && typeof navigator < "u" && navigator.product === "ReactNative"
    }
    T.isReactNative = t;

    function e() {
        return typeof B < "u" && typeof B.versions < "u" && typeof B.versions.node < "u"
    }
    T.isNode = e;

    function r() {
        return !t() && !e()
    }
    return T.isBrowser = r, T
}(function(t) {
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    const e = st;
    e.__exportStar(qt(), t), e.__exportStar(Jt(), t)
})(Vt);

function ge(t = 3) {
    const e = Date.now() * Math.pow(10, t),
        r = Math.floor(Math.random() * Math.pow(10, t));
    return e + r
}

function Gt(t = 6) {
    return BigInt(ge(t))
}

function Xt(t, e, r) {
    return {
        id: r || ge(),
        jsonrpc: "2.0",
        method: t,
        params: e
    }
}

function hr(t, e) {
    return {
        id: t,
        jsonrpc: "2.0",
        result: e
    }
}

function zt(t, e, r) {
    return {
        id: t,
        jsonrpc: "2.0",
        error: Kt(e, r)
    }
}

function Kt(t, e) {
    return typeof t > "u" ? oe(pe) : (typeof t == "string" && (t = Object.assign(Object.assign({}, oe(G)), {
        message: t
    })), typeof e < "u" && (t.data = e), $t(t.code) && (t = Ht(t.code)), t)
}
class ve {}
class dr extends ve {
    constructor(e) {
        super()
    }
}
class Qt extends ve {
    constructor() {
        super()
    }
}
class Yt extends Qt {
    constructor(e) {
        super()
    }
}
const Zt = "^https?:",
    er = "^wss?:";

function tr(t) {
    const e = t.match(new RegExp(/^\w+:/, "gi"));
    if (!(!e || !e.length)) return e[0]
}

function we(t, e) {
    const r = tr(t);
    return typeof r > "u" ? !1 : new RegExp(e).test(r)
}

function ae(t) {
    return we(t, Zt)
}

function pr(t) {
    return we(t, er)
}

function yr(t) {
    return new RegExp("wss?://localhost(:d{2,5})?").test(t)
}

function me(t) {
    return typeof t == "object" && "id" in t && "jsonrpc" in t && t.jsonrpc === "2.0"
}

function gr(t) {
    return me(t) && "method" in t
}

function rr(t) {
    return me(t) && (nr(t) || be(t))
}

function nr(t) {
    return "result" in t
}

function be(t) {
    return "error" in t
}
class vr extends Yt {
    constructor(e) {
        super(e), this.events = new le.EventEmitter, this.hasRegisteredEventListeners = !1, this.connection = this.setConnection(e), this.connection.connected && this.registerEventListeners()
    }
    async connect(e = this.connection) {
        await this.open(e)
    }
    async disconnect() {
        await this.close()
    }
    on(e, r) {
        this.events.on(e, r)
    }
    once(e, r) {
        this.events.once(e, r)
    }
    off(e, r) {
        this.events.off(e, r)
    }
    removeListener(e, r) {
        this.events.removeListener(e, r)
    }
    async request(e, r) {
        return this.requestStrict(Xt(e.method, e.params || [], e.id || Gt().toString()), r)
    }
    async requestStrict(e, r) {
        return new Promise(async (i, s) => {
            if (!this.connection.connected) try {
                await this.open()
            } catch (o) {
                s(o)
            }
            this.events.on(`${e.id}`, o => {
                be(o) ? s(o.error) : i(o.result)
            });
            try {
                await this.connection.send(e, r)
            } catch (o) {
                s(o)
            }
        })
    }
    setConnection(e = this.connection) {
        return e
    }
    onPayload(e) {
        this.events.emit("payload", e), rr(e) ? this.events.emit(`${e.id}`, e) : this.events.emit("message", {
            type: e.method,
            data: e.params
        })
    }
    onClose(e) {
        e && e.code === 3e3 && this.events.emit("error", new Error(`WebSocket connection closed abnormally with code: ${e.code} ${e.reason?`(${e.reason})`:""}`)), this.events.emit("disconnect")
    }
    async open(e = this.connection) {
        this.connection === e && this.connection.connected || (this.connection.connected && this.close(), typeof e == "string" && (await this.connection.open(e), e = this.connection), this.connection = this.setConnection(e), await this.connection.open(), this.registerEventListeners(), this.events.emit("connect"))
    }
    async close() {
        await this.connection.close()
    }
    registerEventListeners() {
        this.hasRegisteredEventListeners || (this.connection.on("payload", e => this.onPayload(e)), this.connection.on("close", e => this.onClose(e)), this.connection.on("error", e => this.events.emit("error", e)), this.connection.on("register_error", e => this.onClose()), this.hasRegisteredEventListeners = !0)
    }
}
var q = {
    exports: {}
};
(function(t, e) {
    var r = typeof self < "u" ? self : x,
        i = function() {
            function o() {
                this.fetch = !1, this.DOMException = r.DOMException
            }
            return o.prototype = r, new o
        }();
    (function(o) {
        (function(c) {
            var u = {
                searchParams: "URLSearchParams" in o,
                iterable: "Symbol" in o && "iterator" in Symbol,
                blob: "FileReader" in o && "Blob" in o && function() {
                    try {
                        return new Blob, !0
                    } catch {
                        return !1
                    }
                }(),
                formData: "FormData" in o,
                arrayBuffer: "ArrayBuffer" in o
            };

            function E(n) {
                return n && DataView.prototype.isPrototypeOf(n)
            }
            if (u.arrayBuffer) var f = ["[object Int8Array]", "[object Uint8Array]", "[object Uint8ClampedArray]", "[object Int16Array]", "[object Uint16Array]", "[object Int32Array]", "[object Uint32Array]", "[object Float32Array]", "[object Float64Array]"],
                b = ArrayBuffer.isView || function(n) {
                    return n && f.indexOf(Object.prototype.toString.call(n)) > -1
                };

            function g(n) {
                if (typeof n != "string" && (n = String(n)), /[^a-z0-9\-#$%&'*+.^_`|~]/i.test(n)) throw new TypeError("Invalid character in header field name");
                return n.toLowerCase()
            }

            function d(n) {
                return typeof n != "string" && (n = String(n)), n
            }

            function w(n) {
                var a = {
                    next: function() {
                        var l = n.shift();
                        return {
                            done: l === void 0,
                            value: l
                        }
                    }
                };
                return u.iterable && (a[Symbol.iterator] = function() {
                    return a
                }), a
            }

            function h(n) {
                this.map = {}, n instanceof h ? n.forEach(function(a, l) {
                    this.append(l, a)
                }, this) : Array.isArray(n) ? n.forEach(function(a) {
                    this.append(a[0], a[1])
                }, this) : n && Object.getOwnPropertyNames(n).forEach(function(a) {
                    this.append(a, n[a])
                }, this)
            }
            h.prototype.append = function(n, a) {
                n = g(n), a = d(a);
                var l = this.map[n];
                this.map[n] = l ? l + ", " + a : a
            }, h.prototype.delete = function(n) {
                delete this.map[g(n)]
            }, h.prototype.get = function(n) {
                return n = g(n), this.has(n) ? this.map[n] : null
            }, h.prototype.has = function(n) {
                return this.map.hasOwnProperty(g(n))
            }, h.prototype.set = function(n, a) {
                this.map[g(n)] = d(a)
            }, h.prototype.forEach = function(n, a) {
                for (var l in this.map) this.map.hasOwnProperty(l) && n.call(a, this.map[l], l, this)
            }, h.prototype.keys = function() {
                var n = [];
                return this.forEach(function(a, l) {
                    n.push(l)
                }), w(n)
            }, h.prototype.values = function() {
                var n = [];
                return this.forEach(function(a) {
                    n.push(a)
                }), w(n)
            }, h.prototype.entries = function() {
                var n = [];
                return this.forEach(function(a, l) {
                    n.push([l, a])
                }), w(n)
            }, u.iterable && (h.prototype[Symbol.iterator] = h.prototype.entries);

            function O(n) {
                if (n.bodyUsed) return Promise.reject(new TypeError("Already read"));
                n.bodyUsed = !0
            }

            function v(n) {
                return new Promise(function(a, l) {
                    n.onload = function() {
                        a(n.result)
                    }, n.onerror = function() {
                        l(n.error)
                    }
                })
            }

            function A(n) {
                var a = new FileReader,
                    l = v(a);
                return a.readAsArrayBuffer(n), l
            }

            function j(n) {
                var a = new FileReader,
                    l = v(a);
                return a.readAsText(n), l
            }

            function F(n) {
                for (var a = new Uint8Array(n), l = new Array(a.length), _ = 0; _ < a.length; _++) l[_] = String.fromCharCode(a[_]);
                return l.join("")
            }

            function X(n) {
                if (n.slice) return n.slice(0);
                var a = new Uint8Array(n.byteLength);
                return a.set(new Uint8Array(n)), a.buffer
            }

            function z() {
                return this.bodyUsed = !1, this._initBody = function(n) {
                    this._bodyInit = n, n ? typeof n == "string" ? this._bodyText = n : u.blob && Blob.prototype.isPrototypeOf(n) ? this._bodyBlob = n : u.formData && FormData.prototype.isPrototypeOf(n) ? this._bodyFormData = n : u.searchParams && URLSearchParams.prototype.isPrototypeOf(n) ? this._bodyText = n.toString() : u.arrayBuffer && u.blob && E(n) ? (this._bodyArrayBuffer = X(n.buffer), this._bodyInit = new Blob([this._bodyArrayBuffer])) : u.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(n) || b(n)) ? this._bodyArrayBuffer = X(n) : this._bodyText = n = Object.prototype.toString.call(n) : this._bodyText = "", this.headers.get("content-type") || (typeof n == "string" ? this.headers.set("content-type", "text/plain;charset=UTF-8") : this._bodyBlob && this._bodyBlob.type ? this.headers.set("content-type", this._bodyBlob.type) : u.searchParams && URLSearchParams.prototype.isPrototypeOf(n) && this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"))
                }, u.blob && (this.blob = function() {
                    var n = O(this);
                    if (n) return n;
                    if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
                    if (this._bodyArrayBuffer) return Promise.resolve(new Blob([this._bodyArrayBuffer]));
                    if (this._bodyFormData) throw new Error("could not read FormData body as blob");
                    return Promise.resolve(new Blob([this._bodyText]))
                }, this.arrayBuffer = function() {
                    return this._bodyArrayBuffer ? O(this) || Promise.resolve(this._bodyArrayBuffer) : this.blob().then(A)
                }), this.text = function() {
                    var n = O(this);
                    if (n) return n;
                    if (this._bodyBlob) return j(this._bodyBlob);
                    if (this._bodyArrayBuffer) return Promise.resolve(F(this._bodyArrayBuffer));
                    if (this._bodyFormData) throw new Error("could not read FormData body as text");
                    return Promise.resolve(this._bodyText)
                }, u.formData && (this.formData = function() {
                    return this.text().then(Oe)
                }), this.json = function() {
                    return this.text().then(JSON.parse)
                }, this
            }
            var _e = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];

            function Ee(n) {
                var a = n.toUpperCase();
                return _e.indexOf(a) > -1 ? a : n
            }

            function P(n, a) {
                a = a || {};
                var l = a.body;
                if (n instanceof P) {
                    if (n.bodyUsed) throw new TypeError("Already read");
                    this.url = n.url, this.credentials = n.credentials, a.headers || (this.headers = new h(n.headers)), this.method = n.method, this.mode = n.mode, this.signal = n.signal, !l && n._bodyInit != null && (l = n._bodyInit, n.bodyUsed = !0)
                } else this.url = String(n);
                if (this.credentials = a.credentials || this.credentials || "same-origin", (a.headers || !this.headers) && (this.headers = new h(a.headers)), this.method = Ee(a.method || this.method || "GET"), this.mode = a.mode || this.mode || null, this.signal = a.signal || this.signal, this.referrer = null, (this.method === "GET" || this.method === "HEAD") && l) throw new TypeError("Body not allowed for GET or HEAD requests");
                this._initBody(l)
            }
            P.prototype.clone = function() {
                return new P(this, {
                    body: this._bodyInit
                })
            };

            function Oe(n) {
                var a = new FormData;
                return n.trim().split("&").forEach(function(l) {
                    if (l) {
                        var _ = l.split("="),
                            m = _.shift().replace(/\+/g, " "),
                            p = _.join("=").replace(/\+/g, " ");
                        a.append(decodeURIComponent(m), decodeURIComponent(p))
                    }
                }), a
            }

            function Re(n) {
                var a = new h,
                    l = n.replace(/\r?\n[\t ]+/g, " ");
                return l.split(/\r?\n/).forEach(function(_) {
                    var m = _.split(":"),
                        p = m.shift().trim();
                    if (p) {
                        var N = m.join(":").trim();
                        a.append(p, N)
                    }
                }), a
            }
            z.call(P.prototype);

            function R(n, a) {
                a || (a = {}), this.type = "default", this.status = a.status === void 0 ? 200 : a.status, this.ok = this.status >= 200 && this.status < 300, this.statusText = "statusText" in a ? a.statusText : "OK", this.headers = new h(a.headers), this.url = a.url || "", this._initBody(n)
            }
            z.call(R.prototype), R.prototype.clone = function() {
                return new R(this._bodyInit, {
                    status: this.status,
                    statusText: this.statusText,
                    headers: new h(this.headers),
                    url: this.url
                })
            }, R.error = function() {
                var n = new R(null, {
                    status: 0,
                    statusText: ""
                });
                return n.type = "error", n
            };
            var Se = [301, 302, 303, 307, 308];
            R.redirect = function(n, a) {
                if (Se.indexOf(a) === -1) throw new RangeError("Invalid status code");
                return new R(null, {
                    status: a,
                    headers: {
                        location: n
                    }
                })
            }, c.DOMException = o.DOMException;
            try {
                new c.DOMException
            } catch {
                c.DOMException = function(a, l) {
                    this.message = a, this.name = l;
                    var _ = Error(a);
                    this.stack = _.stack
                }, c.DOMException.prototype = Object.create(Error.prototype), c.DOMException.prototype.constructor = c.DOMException
            }

            function W(n, a) {
                return new Promise(function(l, _) {
                    var m = new P(n, a);
                    if (m.signal && m.signal.aborted) return _(new c.DOMException("Aborted", "AbortError"));
                    var p = new XMLHttpRequest;

                    function N() {
                        p.abort()
                    }
                    p.onload = function() {
                        var I = {
                            status: p.status,
                            statusText: p.statusText,
                            headers: Re(p.getAllResponseHeaders() || "")
                        };
                        I.url = "responseURL" in p ? p.responseURL : I.headers.get("X-Request-URL");
                        var U = "response" in p ? p.response : p.responseText;
                        l(new R(U, I))
                    }, p.onerror = function() {
                        _(new TypeError("Network request failed"))
                    }, p.ontimeout = function() {
                        _(new TypeError("Network request failed"))
                    }, p.onabort = function() {
                        _(new c.DOMException("Aborted", "AbortError"))
                    }, p.open(m.method, m.url, !0), m.credentials === "include" ? p.withCredentials = !0 : m.credentials === "omit" && (p.withCredentials = !1), "responseType" in p && u.blob && (p.responseType = "blob"), m.headers.forEach(function(I, U) {
                        p.setRequestHeader(U, I)
                    }), m.signal && (m.signal.addEventListener("abort", N), p.onreadystatechange = function() {
                        p.readyState === 4 && m.signal.removeEventListener("abort", N)
                    }), p.send(typeof m._bodyInit > "u" ? null : m._bodyInit)
                })
            }
            return W.polyfill = !0, o.fetch || (o.fetch = W, o.Headers = h, o.Request = P, o.Response = R), c.Headers = h, c.Request = P, c.Response = R, c.fetch = W, Object.defineProperty(c, "__esModule", {
                value: !0
            }), c
        })({})
    })(i), i.fetch.ponyfill = !0, delete i.fetch.polyfill;
    var s = i;
    e = s.fetch, e.default = s.fetch, e.fetch = s.fetch, e.Headers = s.Headers, e.Request = s.Request, e.Response = s.Response, t.exports = e
})(q, q.exports);
var or = q.exports;
const ce = Ae(or),
    ir = {
        Accept: "application/json",
        "Content-Type": "application/json"
    },
    sr = "POST",
    ue = {
        headers: ir,
        method: sr
    },
    fe = 10;
class wr {
    constructor(e, r = !1) {
        if (this.url = e, this.disableProviderPing = r, this.events = new le.EventEmitter, this.isAvailable = !1, this.registering = !1, !ae(e)) throw new Error(`Provided URL is not compatible with HTTP connection: ${e}`);
        this.url = e, this.disableProviderPing = r
    }
    get connected() {
        return this.isAvailable
    }
    get connecting() {
        return this.registering
    }
    on(e, r) {
        this.events.on(e, r)
    }
    once(e, r) {
        this.events.once(e, r)
    }
    off(e, r) {
        this.events.off(e, r)
    }
    removeListener(e, r) {
        this.events.removeListener(e, r)
    }
    async open(e = this.url) {
        await this.register(e)
    }
    async close() {
        if (!this.isAvailable) throw new Error("Connection already closed");
        this.onClose()
    }
    async send(e, r) {
        this.isAvailable || await this.register();
        try {
            const i = ne(e),
                o = await (await ce(this.url, Object.assign(Object.assign({}, ue), {
                    body: i
                }))).json();
            this.onPayload({
                data: o
            })
        } catch (i) {
            this.onError(e.id, i)
        }
    }
    async register(e = this.url) {
        if (!ae(e)) throw new Error(`Provided URL is not compatible with HTTP connection: ${e}`);
        if (this.registering) {
            const r = this.events.getMaxListeners();
            return (this.events.listenerCount("register_error") >= r || this.events.listenerCount("open") >= r) && this.events.setMaxListeners(r + 1), new Promise((i, s) => {
                this.events.once("register_error", o => {
                    this.resetMaxListeners(), s(o)
                }), this.events.once("open", () => {
                    if (this.resetMaxListeners(), typeof this.isAvailable > "u") return s(new Error("HTTP connection is missing or invalid"));
                    i()
                })
            })
        }
        this.url = e, this.registering = !0;
        try {
            if (!this.disableProviderPing) {
                const r = ne({
                    id: 1,
                    jsonrpc: "2.0",
                    method: "test",
                    params: []
                });
                await ce(e, Object.assign(Object.assign({}, ue), {
                    body: r
                }))
            }
            this.onOpen()
        } catch (r) {
            const i = this.parseError(r);
            throw this.events.emit("register_error", i), this.onClose(), i
        }
    }
    onOpen() {
        this.isAvailable = !0, this.registering = !1, this.events.emit("open")
    }
    onClose() {
        this.isAvailable = !1, this.registering = !1, this.events.emit("close")
    }
    onPayload(e) {
        if (typeof e.data > "u") return;
        const r = typeof e.data == "string" ? Lt(e.data) : e.data;
        this.events.emit("payload", r)
    }
    onError(e, r) {
        const i = this.parseError(r),
            s = i.message || i.toString(),
            o = zt(e, s);
        this.events.emit("payload", o)
    }
    parseError(e, r = this.url) {
        return kt(e, r, "HTTP")
    }
    resetMaxListeners() {
        this.events.getMaxListeners() > fe && this.events.setMaxListeners(fe)
    }
}
export {
    lt as A, yt as B, mt as C, Ot as D, St as E, At as F, ge as G, wr as H, dr as I, vr as J, ur as a, vt as b, dt as c, fr as d, cr as e, _t as f, xt as g, ne as h, Lt as i, pr as j, Vt as k, yr as l, zt as m, gr as n, rr as o, kt as p, hr as q, st as r, lr as s, nr as t, be as u, Xt as v, Gt as w, at as x, ct as y, ut as z
};