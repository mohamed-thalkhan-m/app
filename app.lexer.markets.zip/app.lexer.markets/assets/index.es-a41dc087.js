import {
    r as O_,
    g as _r,
    p as yc,
    a as A_,
    e as ri,
    c as _a,
    b as P_,
    E as ru,
    _ as N_
} from "./index-95ae70b2.js";
import {
    r as vi,
    s as T_,
    a as R_,
    d as F_,
    g as U_,
    b as kf,
    c as $_,
    e as L_,
    f as M_,
    h as cs,
    i as La,
    j as Il,
    k as j_,
    l as z_,
    m as iu,
    p as q_,
    J as Ti,
    n as nu,
    o as su,
    q as au,
    t as Oi,
    u as gi,
    v as ou,
    w as Vf,
    H as en
} from "./http-ae2bef82.js";
var cu = {},
    Ma = {},
    $e = {},
    Gf = {};
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });

    function t(f, v) {
        var g = f >>> 16 & 65535,
            b = f & 65535,
            S = v >>> 16 & 65535,
            O = v & 65535;
        return b * O + (g * O + b * S << 16 >>> 0) | 0
    }
    n.mul = Math.imul || t;

    function r(f, v) {
        return f + v | 0
    }
    n.add = r;

    function s(f, v) {
        return f - v | 0
    }
    n.sub = s;

    function o(f, v) {
        return f << v | f >>> 32 - v
    }
    n.rotl = o;

    function l(f, v) {
        return f << 32 - v | f >>> v
    }
    n.rotr = l;

    function d(f) {
        return typeof f == "number" && isFinite(f) && Math.floor(f) === f
    }
    n.isInteger = Number.isInteger || d, n.MAX_SAFE_INTEGER = 9007199254740991, n.isSafeInteger = function(f) {
        return n.isInteger(f) && f >= -n.MAX_SAFE_INTEGER && f <= n.MAX_SAFE_INTEGER
    }
})(Gf);
Object.defineProperty($e, "__esModule", {
    value: !0
});
var Wf = Gf;

function H_(n, t) {
    return t === void 0 && (t = 0), (n[t + 0] << 8 | n[t + 1]) << 16 >> 16
}
$e.readInt16BE = H_;

function B_(n, t) {
    return t === void 0 && (t = 0), (n[t + 0] << 8 | n[t + 1]) >>> 0
}
$e.readUint16BE = B_;

function K_(n, t) {
    return t === void 0 && (t = 0), (n[t + 1] << 8 | n[t]) << 16 >> 16
}
$e.readInt16LE = K_;

function k_(n, t) {
    return t === void 0 && (t = 0), (n[t + 1] << 8 | n[t]) >>> 0
}
$e.readUint16LE = k_;

function Yf(n, t, r) {
    return t === void 0 && (t = new Uint8Array(2)), r === void 0 && (r = 0), t[r + 0] = n >>> 8, t[r + 1] = n >>> 0, t
}
$e.writeUint16BE = Yf;
$e.writeInt16BE = Yf;

function Jf(n, t, r) {
    return t === void 0 && (t = new Uint8Array(2)), r === void 0 && (r = 0), t[r + 0] = n >>> 0, t[r + 1] = n >>> 8, t
}
$e.writeUint16LE = Jf;
$e.writeInt16LE = Jf;

function jc(n, t) {
    return t === void 0 && (t = 0), n[t] << 24 | n[t + 1] << 16 | n[t + 2] << 8 | n[t + 3]
}
$e.readInt32BE = jc;

function zc(n, t) {
    return t === void 0 && (t = 0), (n[t] << 24 | n[t + 1] << 16 | n[t + 2] << 8 | n[t + 3]) >>> 0
}
$e.readUint32BE = zc;

function qc(n, t) {
    return t === void 0 && (t = 0), n[t + 3] << 24 | n[t + 2] << 16 | n[t + 1] << 8 | n[t]
}
$e.readInt32LE = qc;

function Hc(n, t) {
    return t === void 0 && (t = 0), (n[t + 3] << 24 | n[t + 2] << 16 | n[t + 1] << 8 | n[t]) >>> 0
}
$e.readUint32LE = Hc;

function Aa(n, t, r) {
    return t === void 0 && (t = new Uint8Array(4)), r === void 0 && (r = 0), t[r + 0] = n >>> 24, t[r + 1] = n >>> 16, t[r + 2] = n >>> 8, t[r + 3] = n >>> 0, t
}
$e.writeUint32BE = Aa;
$e.writeInt32BE = Aa;

function Pa(n, t, r) {
    return t === void 0 && (t = new Uint8Array(4)), r === void 0 && (r = 0), t[r + 0] = n >>> 0, t[r + 1] = n >>> 8, t[r + 2] = n >>> 16, t[r + 3] = n >>> 24, t
}
$e.writeUint32LE = Pa;
$e.writeInt32LE = Pa;

function V_(n, t) {
    t === void 0 && (t = 0);
    var r = jc(n, t),
        s = jc(n, t + 4);
    return r * 4294967296 + s - (s >> 31) * 4294967296
}
$e.readInt64BE = V_;

function G_(n, t) {
    t === void 0 && (t = 0);
    var r = zc(n, t),
        s = zc(n, t + 4);
    return r * 4294967296 + s
}
$e.readUint64BE = G_;

function W_(n, t) {
    t === void 0 && (t = 0);
    var r = qc(n, t),
        s = qc(n, t + 4);
    return s * 4294967296 + r - (r >> 31) * 4294967296
}
$e.readInt64LE = W_;

function Y_(n, t) {
    t === void 0 && (t = 0);
    var r = Hc(n, t),
        s = Hc(n, t + 4);
    return s * 4294967296 + r
}
$e.readUint64LE = Y_;

function Xf(n, t, r) {
    return t === void 0 && (t = new Uint8Array(8)), r === void 0 && (r = 0), Aa(n / 4294967296 >>> 0, t, r), Aa(n >>> 0, t, r + 4), t
}
$e.writeUint64BE = Xf;
$e.writeInt64BE = Xf;

function Zf(n, t, r) {
    return t === void 0 && (t = new Uint8Array(8)), r === void 0 && (r = 0), Pa(n >>> 0, t, r), Pa(n / 4294967296 >>> 0, t, r + 4), t
}
$e.writeUint64LE = Zf;
$e.writeInt64LE = Zf;

function J_(n, t, r) {
    if (r === void 0 && (r = 0), n % 8 !== 0) throw new Error("readUintBE supports only bitLengths divisible by 8");
    if (n / 8 > t.length - r) throw new Error("readUintBE: array is too short for the given bitLength");
    for (var s = 0, o = 1, l = n / 8 + r - 1; l >= r; l--) s += t[l] * o, o *= 256;
    return s
}
$e.readUintBE = J_;

function X_(n, t, r) {
    if (r === void 0 && (r = 0), n % 8 !== 0) throw new Error("readUintLE supports only bitLengths divisible by 8");
    if (n / 8 > t.length - r) throw new Error("readUintLE: array is too short for the given bitLength");
    for (var s = 0, o = 1, l = r; l < r + n / 8; l++) s += t[l] * o, o *= 256;
    return s
}
$e.readUintLE = X_;

function Z_(n, t, r, s) {
    if (r === void 0 && (r = new Uint8Array(n / 8)), s === void 0 && (s = 0), n % 8 !== 0) throw new Error("writeUintBE supports only bitLengths divisible by 8");
    if (!Wf.isSafeInteger(t)) throw new Error("writeUintBE value must be an integer");
    for (var o = 1, l = n / 8 + s - 1; l >= s; l--) r[l] = t / o & 255, o *= 256;
    return r
}
$e.writeUintBE = Z_;

function Q_(n, t, r, s) {
    if (r === void 0 && (r = new Uint8Array(n / 8)), s === void 0 && (s = 0), n % 8 !== 0) throw new Error("writeUintLE supports only bitLengths divisible by 8");
    if (!Wf.isSafeInteger(t)) throw new Error("writeUintLE value must be an integer");
    for (var o = 1, l = s; l < s + n / 8; l++) r[l] = t / o & 255, o *= 256;
    return r
}
$e.writeUintLE = Q_;

function em(n, t) {
    t === void 0 && (t = 0);
    var r = new DataView(n.buffer, n.byteOffset, n.byteLength);
    return r.getFloat32(t)
}
$e.readFloat32BE = em;

function tm(n, t) {
    t === void 0 && (t = 0);
    var r = new DataView(n.buffer, n.byteOffset, n.byteLength);
    return r.getFloat32(t, !0)
}
$e.readFloat32LE = tm;

function rm(n, t) {
    t === void 0 && (t = 0);
    var r = new DataView(n.buffer, n.byteOffset, n.byteLength);
    return r.getFloat64(t)
}
$e.readFloat64BE = rm;

function im(n, t) {
    t === void 0 && (t = 0);
    var r = new DataView(n.buffer, n.byteOffset, n.byteLength);
    return r.getFloat64(t, !0)
}
$e.readFloat64LE = im;

function nm(n, t, r) {
    t === void 0 && (t = new Uint8Array(4)), r === void 0 && (r = 0);
    var s = new DataView(t.buffer, t.byteOffset, t.byteLength);
    return s.setFloat32(r, n), t
}
$e.writeFloat32BE = nm;

function sm(n, t, r) {
    t === void 0 && (t = new Uint8Array(4)), r === void 0 && (r = 0);
    var s = new DataView(t.buffer, t.byteOffset, t.byteLength);
    return s.setFloat32(r, n, !0), t
}
$e.writeFloat32LE = sm;

function am(n, t, r) {
    t === void 0 && (t = new Uint8Array(8)), r === void 0 && (r = 0);
    var s = new DataView(t.buffer, t.byteOffset, t.byteLength);
    return s.setFloat64(r, n), t
}
$e.writeFloat64BE = am;

function om(n, t, r) {
    t === void 0 && (t = new Uint8Array(8)), r === void 0 && (r = 0);
    var s = new DataView(t.buffer, t.byteOffset, t.byteLength);
    return s.setFloat64(r, n, !0), t
}
$e.writeFloat64LE = om;
var xr = {};
Object.defineProperty(xr, "__esModule", {
    value: !0
});

function cm(n) {
    for (var t = 0; t < n.length; t++) n[t] = 0;
    return n
}
xr.wipe = cm;
Object.defineProperty(Ma, "__esModule", {
    value: !0
});
var Qt = $e,
    Bc = xr,
    um = 20;

function hm(n, t, r) {
    for (var s = 1634760805, o = 857760878, l = 2036477234, d = 1797285236, f = r[3] << 24 | r[2] << 16 | r[1] << 8 | r[0], v = r[7] << 24 | r[6] << 16 | r[5] << 8 | r[4], g = r[11] << 24 | r[10] << 16 | r[9] << 8 | r[8], b = r[15] << 24 | r[14] << 16 | r[13] << 8 | r[12], S = r[19] << 24 | r[18] << 16 | r[17] << 8 | r[16], O = r[23] << 24 | r[22] << 16 | r[21] << 8 | r[20], P = r[27] << 24 | r[26] << 16 | r[25] << 8 | r[24], N = r[31] << 24 | r[30] << 16 | r[29] << 8 | r[28], H = t[3] << 24 | t[2] << 16 | t[1] << 8 | t[0], G = t[7] << 24 | t[6] << 16 | t[5] << 8 | t[4], ie = t[11] << 24 | t[10] << 16 | t[9] << 8 | t[8], T = t[15] << 24 | t[14] << 16 | t[13] << 8 | t[12], L = s, I = o, C = l, w = d, c = f, m = v, K = g, V = b, ae = S, ce = O, ge = P, F = N, q = H, le = G, te = ie, W = T, ee = 0; ee < um; ee += 2) L = L + c | 0, q ^= L, q = q >>> 32 - 16 | q << 16, ae = ae + q | 0, c ^= ae, c = c >>> 32 - 12 | c << 12, I = I + m | 0, le ^= I, le = le >>> 32 - 16 | le << 16, ce = ce + le | 0, m ^= ce, m = m >>> 32 - 12 | m << 12, C = C + K | 0, te ^= C, te = te >>> 32 - 16 | te << 16, ge = ge + te | 0, K ^= ge, K = K >>> 32 - 12 | K << 12, w = w + V | 0, W ^= w, W = W >>> 32 - 16 | W << 16, F = F + W | 0, V ^= F, V = V >>> 32 - 12 | V << 12, C = C + K | 0, te ^= C, te = te >>> 32 - 8 | te << 8, ge = ge + te | 0, K ^= ge, K = K >>> 32 - 7 | K << 7, w = w + V | 0, W ^= w, W = W >>> 32 - 8 | W << 8, F = F + W | 0, V ^= F, V = V >>> 32 - 7 | V << 7, I = I + m | 0, le ^= I, le = le >>> 32 - 8 | le << 8, ce = ce + le | 0, m ^= ce, m = m >>> 32 - 7 | m << 7, L = L + c | 0, q ^= L, q = q >>> 32 - 8 | q << 8, ae = ae + q | 0, c ^= ae, c = c >>> 32 - 7 | c << 7, L = L + m | 0, W ^= L, W = W >>> 32 - 16 | W << 16, ge = ge + W | 0, m ^= ge, m = m >>> 32 - 12 | m << 12, I = I + K | 0, q ^= I, q = q >>> 32 - 16 | q << 16, F = F + q | 0, K ^= F, K = K >>> 32 - 12 | K << 12, C = C + V | 0, le ^= C, le = le >>> 32 - 16 | le << 16, ae = ae + le | 0, V ^= ae, V = V >>> 32 - 12 | V << 12, w = w + c | 0, te ^= w, te = te >>> 32 - 16 | te << 16, ce = ce + te | 0, c ^= ce, c = c >>> 32 - 12 | c << 12, C = C + V | 0, le ^= C, le = le >>> 32 - 8 | le << 8, ae = ae + le | 0, V ^= ae, V = V >>> 32 - 7 | V << 7, w = w + c | 0, te ^= w, te = te >>> 32 - 8 | te << 8, ce = ce + te | 0, c ^= ce, c = c >>> 32 - 7 | c << 7, I = I + K | 0, q ^= I, q = q >>> 32 - 8 | q << 8, F = F + q | 0, K ^= F, K = K >>> 32 - 7 | K << 7, L = L + m | 0, W ^= L, W = W >>> 32 - 8 | W << 8, ge = ge + W | 0, m ^= ge, m = m >>> 32 - 7 | m << 7;
    Qt.writeUint32LE(L + s | 0, n, 0), Qt.writeUint32LE(I + o | 0, n, 4), Qt.writeUint32LE(C + l | 0, n, 8), Qt.writeUint32LE(w + d | 0, n, 12), Qt.writeUint32LE(c + f | 0, n, 16), Qt.writeUint32LE(m + v | 0, n, 20), Qt.writeUint32LE(K + g | 0, n, 24), Qt.writeUint32LE(V + b | 0, n, 28), Qt.writeUint32LE(ae + S | 0, n, 32), Qt.writeUint32LE(ce + O | 0, n, 36), Qt.writeUint32LE(ge + P | 0, n, 40), Qt.writeUint32LE(F + N | 0, n, 44), Qt.writeUint32LE(q + H | 0, n, 48), Qt.writeUint32LE(le + G | 0, n, 52), Qt.writeUint32LE(te + ie | 0, n, 56), Qt.writeUint32LE(W + T | 0, n, 60)
}

function Qf(n, t, r, s, o) {
    if (o === void 0 && (o = 0), n.length !== 32) throw new Error("ChaCha: key size must be 32 bytes");
    if (s.length < r.length) throw new Error("ChaCha: destination is shorter than source");
    var l, d;
    if (o === 0) {
        if (t.length !== 8 && t.length !== 12) throw new Error("ChaCha nonce must be 8 or 12 bytes");
        l = new Uint8Array(16), d = l.length - t.length, l.set(t, d)
    } else {
        if (t.length !== 16) throw new Error("ChaCha nonce with counter must be 16 bytes");
        l = t, d = o
    }
    for (var f = new Uint8Array(64), v = 0; v < r.length; v += 64) {
        hm(f, l, n);
        for (var g = v; g < v + 64 && g < r.length; g++) s[g] = r[g] ^ f[g - v];
        fm(l, 0, d)
    }
    return Bc.wipe(f), o === 0 && Bc.wipe(l), s
}
Ma.streamXOR = Qf;

function lm(n, t, r, s) {
    return s === void 0 && (s = 0), Bc.wipe(r), Qf(n, t, r, r, s)
}
Ma.stream = lm;

function fm(n, t, r) {
    for (var s = 1; r--;) s = s + (n[t] & 255) | 0, n[t] = s & 255, s >>>= 8, t++;
    if (s > 0) throw new Error("ChaCha: counter overflow")
}
var ep = {},
    Ri = {};
Object.defineProperty(Ri, "__esModule", {
    value: !0
});

function pm(n, t, r) {
    return ~(n - 1) & t | n - 1 & r
}
Ri.select = pm;

function dm(n, t) {
    return (n | 0) - (t | 0) - 1 >>> 31 & 1
}
Ri.lessOrEqual = dm;

function tp(n, t) {
    if (n.length !== t.length) return 0;
    for (var r = 0, s = 0; s < n.length; s++) r |= n[s] ^ t[s];
    return 1 & r - 1 >>> 8
}
Ri.compare = tp;

function gm(n, t) {
    return n.length === 0 || t.length === 0 ? !1 : tp(n, t) !== 0
}
Ri.equal = gm;
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var t = Ri,
        r = xr;
    n.DIGEST_LENGTH = 16;
    var s = function() {
        function d(f) {
            this.digestLength = n.DIGEST_LENGTH, this._buffer = new Uint8Array(16), this._r = new Uint16Array(10), this._h = new Uint16Array(10), this._pad = new Uint16Array(8), this._leftover = 0, this._fin = 0, this._finished = !1;
            var v = f[0] | f[1] << 8;
            this._r[0] = v & 8191;
            var g = f[2] | f[3] << 8;
            this._r[1] = (v >>> 13 | g << 3) & 8191;
            var b = f[4] | f[5] << 8;
            this._r[2] = (g >>> 10 | b << 6) & 7939;
            var S = f[6] | f[7] << 8;
            this._r[3] = (b >>> 7 | S << 9) & 8191;
            var O = f[8] | f[9] << 8;
            this._r[4] = (S >>> 4 | O << 12) & 255, this._r[5] = O >>> 1 & 8190;
            var P = f[10] | f[11] << 8;
            this._r[6] = (O >>> 14 | P << 2) & 8191;
            var N = f[12] | f[13] << 8;
            this._r[7] = (P >>> 11 | N << 5) & 8065;
            var H = f[14] | f[15] << 8;
            this._r[8] = (N >>> 8 | H << 8) & 8191, this._r[9] = H >>> 5 & 127, this._pad[0] = f[16] | f[17] << 8, this._pad[1] = f[18] | f[19] << 8, this._pad[2] = f[20] | f[21] << 8, this._pad[3] = f[22] | f[23] << 8, this._pad[4] = f[24] | f[25] << 8, this._pad[5] = f[26] | f[27] << 8, this._pad[6] = f[28] | f[29] << 8, this._pad[7] = f[30] | f[31] << 8
        }
        return d.prototype._blocks = function(f, v, g) {
            for (var b = this._fin ? 0 : 2048, S = this._h[0], O = this._h[1], P = this._h[2], N = this._h[3], H = this._h[4], G = this._h[5], ie = this._h[6], T = this._h[7], L = this._h[8], I = this._h[9], C = this._r[0], w = this._r[1], c = this._r[2], m = this._r[3], K = this._r[4], V = this._r[5], ae = this._r[6], ce = this._r[7], ge = this._r[8], F = this._r[9]; g >= 16;) {
                var q = f[v + 0] | f[v + 1] << 8;
                S += q & 8191;
                var le = f[v + 2] | f[v + 3] << 8;
                O += (q >>> 13 | le << 3) & 8191;
                var te = f[v + 4] | f[v + 5] << 8;
                P += (le >>> 10 | te << 6) & 8191;
                var W = f[v + 6] | f[v + 7] << 8;
                N += (te >>> 7 | W << 9) & 8191;
                var ee = f[v + 8] | f[v + 9] << 8;
                H += (W >>> 4 | ee << 12) & 8191, G += ee >>> 1 & 8191;
                var Y = f[v + 10] | f[v + 11] << 8;
                ie += (ee >>> 14 | Y << 2) & 8191;
                var re = f[v + 12] | f[v + 13] << 8;
                T += (Y >>> 11 | re << 5) & 8191;
                var xe = f[v + 14] | f[v + 15] << 8;
                L += (re >>> 8 | xe << 8) & 8191, I += xe >>> 5 | b;
                var ne = 0,
                    be = ne;
                be += S * C, be += O * (5 * F), be += P * (5 * ge), be += N * (5 * ce), be += H * (5 * ae), ne = be >>> 13, be &= 8191, be += G * (5 * V), be += ie * (5 * K), be += T * (5 * m), be += L * (5 * c), be += I * (5 * w), ne += be >>> 13, be &= 8191;
                var he = ne;
                he += S * w, he += O * C, he += P * (5 * F), he += N * (5 * ge), he += H * (5 * ce), ne = he >>> 13, he &= 8191, he += G * (5 * ae), he += ie * (5 * V), he += T * (5 * K), he += L * (5 * m), he += I * (5 * c), ne += he >>> 13, he &= 8191;
                var _e = ne;
                _e += S * c, _e += O * w, _e += P * C, _e += N * (5 * F), _e += H * (5 * ge), ne = _e >>> 13, _e &= 8191, _e += G * (5 * ce), _e += ie * (5 * ae), _e += T * (5 * V), _e += L * (5 * K), _e += I * (5 * m), ne += _e >>> 13, _e &= 8191;
                var z = ne;
                z += S * m, z += O * c, z += P * w, z += N * C, z += H * (5 * F), ne = z >>> 13, z &= 8191, z += G * (5 * ge), z += ie * (5 * ce), z += T * (5 * ae), z += L * (5 * V), z += I * (5 * K), ne += z >>> 13, z &= 8191;
                var j = ne;
                j += S * K, j += O * m, j += P * c, j += N * w, j += H * C, ne = j >>> 13, j &= 8191, j += G * (5 * F), j += ie * (5 * ge), j += T * (5 * ce), j += L * (5 * ae), j += I * (5 * V), ne += j >>> 13, j &= 8191;
                var R = ne;
                R += S * V, R += O * K, R += P * m, R += N * c, R += H * w, ne = R >>> 13, R &= 8191, R += G * C, R += ie * (5 * F), R += T * (5 * ge), R += L * (5 * ce), R += I * (5 * ae), ne += R >>> 13, R &= 8191;
                var h = ne;
                h += S * ae, h += O * V, h += P * K, h += N * m, h += H * c, ne = h >>> 13, h &= 8191, h += G * w, h += ie * C, h += T * (5 * F), h += L * (5 * ge), h += I * (5 * ce), ne += h >>> 13, h &= 8191;
                var x = ne;
                x += S * ce, x += O * ae, x += P * V, x += N * K, x += H * m, ne = x >>> 13, x &= 8191, x += G * c, x += ie * w, x += T * C, x += L * (5 * F), x += I * (5 * ge), ne += x >>> 13, x &= 8191;
                var se = ne;
                se += S * ge, se += O * ce, se += P * ae, se += N * V, se += H * K, ne = se >>> 13, se &= 8191, se += G * m, se += ie * c, se += T * w, se += L * C, se += I * (5 * F), ne += se >>> 13, se &= 8191;
                var fe = ne;
                fe += S * F, fe += O * ge, fe += P * ce, fe += N * ae, fe += H * V, ne = fe >>> 13, fe &= 8191, fe += G * K, fe += ie * m, fe += T * c, fe += L * w, fe += I * C, ne += fe >>> 13, fe &= 8191, ne = (ne << 2) + ne | 0, ne = ne + be | 0, be = ne & 8191, ne = ne >>> 13, he += ne, S = be, O = he, P = _e, N = z, H = j, G = R, ie = h, T = x, L = se, I = fe, v += 16, g -= 16
            }
            this._h[0] = S, this._h[1] = O, this._h[2] = P, this._h[3] = N, this._h[4] = H, this._h[5] = G, this._h[6] = ie, this._h[7] = T, this._h[8] = L, this._h[9] = I
        }, d.prototype.finish = function(f, v) {
            v === void 0 && (v = 0);
            var g = new Uint16Array(10),
                b, S, O, P;
            if (this._leftover) {
                for (P = this._leftover, this._buffer[P++] = 1; P < 16; P++) this._buffer[P] = 0;
                this._fin = 1, this._blocks(this._buffer, 0, 16)
            }
            for (b = this._h[1] >>> 13, this._h[1] &= 8191, P = 2; P < 10; P++) this._h[P] += b, b = this._h[P] >>> 13, this._h[P] &= 8191;
            for (this._h[0] += b * 5, b = this._h[0] >>> 13, this._h[0] &= 8191, this._h[1] += b, b = this._h[1] >>> 13, this._h[1] &= 8191, this._h[2] += b, g[0] = this._h[0] + 5, b = g[0] >>> 13, g[0] &= 8191, P = 1; P < 10; P++) g[P] = this._h[P] + b, b = g[P] >>> 13, g[P] &= 8191;
            for (g[9] -= 8192, S = (b ^ 1) - 1, P = 0; P < 10; P++) g[P] &= S;
            for (S = ~S, P = 0; P < 10; P++) this._h[P] = this._h[P] & S | g[P];
            for (this._h[0] = (this._h[0] | this._h[1] << 13) & 65535, this._h[1] = (this._h[1] >>> 3 | this._h[2] << 10) & 65535, this._h[2] = (this._h[2] >>> 6 | this._h[3] << 7) & 65535, this._h[3] = (this._h[3] >>> 9 | this._h[4] << 4) & 65535, this._h[4] = (this._h[4] >>> 12 | this._h[5] << 1 | this._h[6] << 14) & 65535, this._h[5] = (this._h[6] >>> 2 | this._h[7] << 11) & 65535, this._h[6] = (this._h[7] >>> 5 | this._h[8] << 8) & 65535, this._h[7] = (this._h[8] >>> 8 | this._h[9] << 5) & 65535, O = this._h[0] + this._pad[0], this._h[0] = O & 65535, P = 1; P < 8; P++) O = (this._h[P] + this._pad[P] | 0) + (O >>> 16) | 0, this._h[P] = O & 65535;
            return f[v + 0] = this._h[0] >>> 0, f[v + 1] = this._h[0] >>> 8, f[v + 2] = this._h[1] >>> 0, f[v + 3] = this._h[1] >>> 8, f[v + 4] = this._h[2] >>> 0, f[v + 5] = this._h[2] >>> 8, f[v + 6] = this._h[3] >>> 0, f[v + 7] = this._h[3] >>> 8, f[v + 8] = this._h[4] >>> 0, f[v + 9] = this._h[4] >>> 8, f[v + 10] = this._h[5] >>> 0, f[v + 11] = this._h[5] >>> 8, f[v + 12] = this._h[6] >>> 0, f[v + 13] = this._h[6] >>> 8, f[v + 14] = this._h[7] >>> 0, f[v + 15] = this._h[7] >>> 8, this._finished = !0, this
        }, d.prototype.update = function(f) {
            var v = 0,
                g = f.length,
                b;
            if (this._leftover) {
                b = 16 - this._leftover, b > g && (b = g);
                for (var S = 0; S < b; S++) this._buffer[this._leftover + S] = f[v + S];
                if (g -= b, v += b, this._leftover += b, this._leftover < 16) return this;
                this._blocks(this._buffer, 0, 16), this._leftover = 0
            }
            if (g >= 16 && (b = g - g % 16, this._blocks(f, v, b), v += b, g -= b), g) {
                for (var S = 0; S < g; S++) this._buffer[this._leftover + S] = f[v + S];
                this._leftover += g
            }
            return this
        }, d.prototype.digest = function() {
            if (this._finished) throw new Error("Poly1305 was finished");
            var f = new Uint8Array(16);
            return this.finish(f), f
        }, d.prototype.clean = function() {
            return r.wipe(this._buffer), r.wipe(this._r), r.wipe(this._h), r.wipe(this._pad), this._leftover = 0, this._fin = 0, this._finished = !0, this
        }, d
    }();
    n.Poly1305 = s;

    function o(d, f) {
        var v = new s(d);
        v.update(f);
        var g = v.digest();
        return v.clean(), g
    }
    n.oneTimeAuth = o;

    function l(d, f) {
        return d.length !== n.DIGEST_LENGTH || f.length !== n.DIGEST_LENGTH ? !1 : t.equal(d, f)
    }
    n.equal = l
})(ep);
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var t = Ma,
        r = ep,
        s = xr,
        o = $e,
        l = Ri;
    n.KEY_LENGTH = 32, n.NONCE_LENGTH = 12, n.TAG_LENGTH = 16;
    var d = new Uint8Array(16),
        f = function() {
            function v(g) {
                if (this.nonceLength = n.NONCE_LENGTH, this.tagLength = n.TAG_LENGTH, g.length !== n.KEY_LENGTH) throw new Error("ChaCha20Poly1305 needs 32-byte key");
                this._key = new Uint8Array(g)
            }
            return v.prototype.seal = function(g, b, S, O) {
                if (g.length > 16) throw new Error("ChaCha20Poly1305: incorrect nonce length");
                var P = new Uint8Array(16);
                P.set(g, P.length - g.length);
                var N = new Uint8Array(32);
                t.stream(this._key, P, N, 4);
                var H = b.length + this.tagLength,
                    G;
                if (O) {
                    if (O.length !== H) throw new Error("ChaCha20Poly1305: incorrect destination length");
                    G = O
                } else G = new Uint8Array(H);
                return t.streamXOR(this._key, P, b, G, 4), this._authenticate(G.subarray(G.length - this.tagLength, G.length), N, G.subarray(0, G.length - this.tagLength), S), s.wipe(P), G
            }, v.prototype.open = function(g, b, S, O) {
                if (g.length > 16) throw new Error("ChaCha20Poly1305: incorrect nonce length");
                if (b.length < this.tagLength) return null;
                var P = new Uint8Array(16);
                P.set(g, P.length - g.length);
                var N = new Uint8Array(32);
                t.stream(this._key, P, N, 4);
                var H = new Uint8Array(this.tagLength);
                if (this._authenticate(H, N, b.subarray(0, b.length - this.tagLength), S), !l.equal(H, b.subarray(b.length - this.tagLength, b.length))) return null;
                var G = b.length - this.tagLength,
                    ie;
                if (O) {
                    if (O.length !== G) throw new Error("ChaCha20Poly1305: incorrect destination length");
                    ie = O
                } else ie = new Uint8Array(G);
                return t.streamXOR(this._key, P, b.subarray(0, b.length - this.tagLength), ie, 4), s.wipe(P), ie
            }, v.prototype.clean = function() {
                return s.wipe(this._key), this
            }, v.prototype._authenticate = function(g, b, S, O) {
                var P = new r.Poly1305(b);
                O && (P.update(O), O.length % 16 > 0 && P.update(d.subarray(O.length % 16))), P.update(S), S.length % 16 > 0 && P.update(d.subarray(S.length % 16));
                var N = new Uint8Array(8);
                O && o.writeUint64LE(O.length, N), P.update(N), o.writeUint64LE(S.length, N), P.update(N);
                for (var H = P.digest(), G = 0; G < H.length; G++) g[G] = H[G];
                P.clean(), s.wipe(H), s.wipe(N)
            }, v
        }();
    n.ChaCha20Poly1305 = f
})(cu);
var rp = {},
    us = {},
    uu = {};
Object.defineProperty(uu, "__esModule", {
    value: !0
});

function vm(n) {
    return typeof n.saveState < "u" && typeof n.restoreState < "u" && typeof n.cleanSavedState < "u"
}
uu.isSerializableHash = vm;
Object.defineProperty(us, "__esModule", {
    value: !0
});
var Zr = uu,
    ym = Ri,
    _m = xr,
    ip = function() {
        function n(t, r) {
            this._finished = !1, this._inner = new t, this._outer = new t, this.blockSize = this._outer.blockSize, this.digestLength = this._outer.digestLength;
            var s = new Uint8Array(this.blockSize);
            r.length > this.blockSize ? this._inner.update(r).finish(s).clean() : s.set(r);
            for (var o = 0; o < s.length; o++) s[o] ^= 54;
            this._inner.update(s);
            for (var o = 0; o < s.length; o++) s[o] ^= 106;
            this._outer.update(s), Zr.isSerializableHash(this._inner) && Zr.isSerializableHash(this._outer) && (this._innerKeyedState = this._inner.saveState(), this._outerKeyedState = this._outer.saveState()), _m.wipe(s)
        }
        return n.prototype.reset = function() {
            if (!Zr.isSerializableHash(this._inner) || !Zr.isSerializableHash(this._outer)) throw new Error("hmac: can't reset() because hash doesn't implement restoreState()");
            return this._inner.restoreState(this._innerKeyedState), this._outer.restoreState(this._outerKeyedState), this._finished = !1, this
        }, n.prototype.clean = function() {
            Zr.isSerializableHash(this._inner) && this._inner.cleanSavedState(this._innerKeyedState), Zr.isSerializableHash(this._outer) && this._outer.cleanSavedState(this._outerKeyedState), this._inner.clean(), this._outer.clean()
        }, n.prototype.update = function(t) {
            return this._inner.update(t), this
        }, n.prototype.finish = function(t) {
            return this._finished ? (this._outer.finish(t), this) : (this._inner.finish(t), this._outer.update(t.subarray(0, this.digestLength)).finish(t), this._finished = !0, this)
        }, n.prototype.digest = function() {
            var t = new Uint8Array(this.digestLength);
            return this.finish(t), t
        }, n.prototype.saveState = function() {
            if (!Zr.isSerializableHash(this._inner)) throw new Error("hmac: can't saveState() because hash doesn't implement it");
            return this._inner.saveState()
        }, n.prototype.restoreState = function(t) {
            if (!Zr.isSerializableHash(this._inner) || !Zr.isSerializableHash(this._outer)) throw new Error("hmac: can't restoreState() because hash doesn't implement it");
            return this._inner.restoreState(t), this._outer.restoreState(this._outerKeyedState), this._finished = !1, this
        }, n.prototype.cleanSavedState = function(t) {
            if (!Zr.isSerializableHash(this._inner)) throw new Error("hmac: can't cleanSavedState() because hash doesn't implement it");
            this._inner.cleanSavedState(t)
        }, n
    }();
us.HMAC = ip;

function mm(n, t, r) {
    var s = new ip(n, t);
    s.update(r);
    var o = s.digest();
    return s.clean(), o
}
us.hmac = mm;
us.equal = ym.equal;
Object.defineProperty(rp, "__esModule", {
    value: !0
});
var Sl = us,
    xl = xr,
    bm = function() {
        function n(t, r, s, o) {
            s === void 0 && (s = new Uint8Array(0)), this._counter = new Uint8Array(1), this._hash = t, this._info = o;
            var l = Sl.hmac(this._hash, s, r);
            this._hmac = new Sl.HMAC(t, l), this._buffer = new Uint8Array(this._hmac.digestLength), this._bufpos = this._buffer.length
        }
        return n.prototype._fillBuffer = function() {
            this._counter[0]++;
            var t = this._counter[0];
            if (t === 0) throw new Error("hkdf: cannot expand more");
            this._hmac.reset(), t > 1 && this._hmac.update(this._buffer), this._info && this._hmac.update(this._info), this._hmac.update(this._counter), this._hmac.finish(this._buffer), this._bufpos = 0
        }, n.prototype.expand = function(t) {
            for (var r = new Uint8Array(t), s = 0; s < r.length; s++) this._bufpos === this._buffer.length && this._fillBuffer(), r[s] = this._buffer[this._bufpos++];
            return r
        }, n.prototype.clean = function() {
            this._hmac.clean(), xl.wipe(this._buffer), xl.wipe(this._counter), this._bufpos = 0
        }, n
    }(),
    wm = rp.HKDF = bm,
    An = {},
    ja = {},
    za = {};
Object.defineProperty(za, "__esModule", {
    value: !0
});
za.BrowserRandomSource = void 0;
const Cl = 65536;
class Em {
    constructor() {
        this.isAvailable = !1, this.isInstantiated = !1;
        const t = typeof self < "u" ? self.crypto || self.msCrypto : null;
        t && t.getRandomValues !== void 0 && (this._crypto = t, this.isAvailable = !0, this.isInstantiated = !0)
    }
    randomBytes(t) {
        if (!this.isAvailable || !this._crypto) throw new Error("Browser random byte generator is not available.");
        const r = new Uint8Array(t);
        for (let s = 0; s < r.length; s += Cl) this._crypto.getRandomValues(r.subarray(s, s + Math.min(r.length - s, Cl)));
        return r
    }
}
za.BrowserRandomSource = Em;

function Dm(n) {
    throw new Error('Could not dynamically require "' + n + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')
}
var qa = {};
Object.defineProperty(qa, "__esModule", {
    value: !0
});
qa.NodeRandomSource = void 0;
const Im = xr;
class Sm {
    constructor() {
        if (this.isAvailable = !1, this.isInstantiated = !1, typeof Dm < "u") {
            const t = O_;
            t && t.randomBytes && (this._crypto = t, this.isAvailable = !0, this.isInstantiated = !0)
        }
    }
    randomBytes(t) {
        if (!this.isAvailable || !this._crypto) throw new Error("Node.js random byte generator is not available.");
        let r = this._crypto.randomBytes(t);
        if (r.length !== t) throw new Error("NodeRandomSource: got fewer bytes than requested");
        const s = new Uint8Array(t);
        for (let o = 0; o < s.length; o++) s[o] = r[o];
        return (0, Im.wipe)(r), s
    }
}
qa.NodeRandomSource = Sm;
Object.defineProperty(ja, "__esModule", {
    value: !0
});
ja.SystemRandomSource = void 0;
const xm = za,
    Cm = qa;
class Om {
    constructor() {
        if (this.isAvailable = !1, this.name = "", this._source = new xm.BrowserRandomSource, this._source.isAvailable) {
            this.isAvailable = !0, this.name = "Browser";
            return
        }
        if (this._source = new Cm.NodeRandomSource, this._source.isAvailable) {
            this.isAvailable = !0, this.name = "Node";
            return
        }
    }
    randomBytes(t) {
        if (!this.isAvailable) throw new Error("System random byte generator is not available.");
        return this._source.randomBytes(t)
    }
}
ja.SystemRandomSource = Om;
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.randomStringForEntropy = n.randomString = n.randomUint32 = n.randomBytes = n.defaultRandomSource = void 0;
    const t = ja,
        r = $e,
        s = xr;
    n.defaultRandomSource = new t.SystemRandomSource;

    function o(g, b = n.defaultRandomSource) {
        return b.randomBytes(g)
    }
    n.randomBytes = o;

    function l(g = n.defaultRandomSource) {
        const b = o(4, g),
            S = (0, r.readUint32LE)(b);
        return (0, s.wipe)(b), S
    }
    n.randomUint32 = l;
    const d = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    function f(g, b = d, S = n.defaultRandomSource) {
        if (b.length < 2) throw new Error("randomString charset is too short");
        if (b.length > 256) throw new Error("randomString charset is too long");
        let O = "";
        const P = b.length,
            N = 256 - 256 % P;
        for (; g > 0;) {
            const H = o(Math.ceil(g * 256 / N), S);
            for (let G = 0; G < H.length && g > 0; G++) {
                const ie = H[G];
                ie < N && (O += b.charAt(ie % P), g--)
            }(0, s.wipe)(H)
        }
        return O
    }
    n.randomString = f;

    function v(g, b = d, S = n.defaultRandomSource) {
        const O = Math.ceil(g / (Math.log(b.length) / Math.LN2));
        return f(O, b, S)
    }
    n.randomStringForEntropy = v
})(An);
var Ha = {};
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var t = $e,
        r = xr;
    n.DIGEST_LENGTH = 32, n.BLOCK_SIZE = 64;
    var s = function() {
        function f() {
            this.digestLength = n.DIGEST_LENGTH, this.blockSize = n.BLOCK_SIZE, this._state = new Int32Array(8), this._temp = new Int32Array(64), this._buffer = new Uint8Array(128), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this.reset()
        }
        return f.prototype._initState = function() {
            this._state[0] = 1779033703, this._state[1] = 3144134277, this._state[2] = 1013904242, this._state[3] = 2773480762, this._state[4] = 1359893119, this._state[5] = 2600822924, this._state[6] = 528734635, this._state[7] = 1541459225
        }, f.prototype.reset = function() {
            return this._initState(), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this
        }, f.prototype.clean = function() {
            r.wipe(this._buffer), r.wipe(this._temp), this.reset()
        }, f.prototype.update = function(v, g) {
            if (g === void 0 && (g = v.length), this._finished) throw new Error("SHA256: can't update because hash was finished.");
            var b = 0;
            if (this._bytesHashed += g, this._bufferLength > 0) {
                for (; this._bufferLength < this.blockSize && g > 0;) this._buffer[this._bufferLength++] = v[b++], g--;
                this._bufferLength === this.blockSize && (l(this._temp, this._state, this._buffer, 0, this.blockSize), this._bufferLength = 0)
            }
            for (g >= this.blockSize && (b = l(this._temp, this._state, v, b, g), g %= this.blockSize); g > 0;) this._buffer[this._bufferLength++] = v[b++], g--;
            return this
        }, f.prototype.finish = function(v) {
            if (!this._finished) {
                var g = this._bytesHashed,
                    b = this._bufferLength,
                    S = g / 536870912 | 0,
                    O = g << 3,
                    P = g % 64 < 56 ? 64 : 128;
                this._buffer[b] = 128;
                for (var N = b + 1; N < P - 8; N++) this._buffer[N] = 0;
                t.writeUint32BE(S, this._buffer, P - 8), t.writeUint32BE(O, this._buffer, P - 4), l(this._temp, this._state, this._buffer, 0, P), this._finished = !0
            }
            for (var N = 0; N < this.digestLength / 4; N++) t.writeUint32BE(this._state[N], v, N * 4);
            return this
        }, f.prototype.digest = function() {
            var v = new Uint8Array(this.digestLength);
            return this.finish(v), v
        }, f.prototype.saveState = function() {
            if (this._finished) throw new Error("SHA256: cannot save finished state");
            return {
                state: new Int32Array(this._state),
                buffer: this._bufferLength > 0 ? new Uint8Array(this._buffer) : void 0,
                bufferLength: this._bufferLength,
                bytesHashed: this._bytesHashed
            }
        }, f.prototype.restoreState = function(v) {
            return this._state.set(v.state), this._bufferLength = v.bufferLength, v.buffer && this._buffer.set(v.buffer), this._bytesHashed = v.bytesHashed, this._finished = !1, this
        }, f.prototype.cleanSavedState = function(v) {
            r.wipe(v.state), v.buffer && r.wipe(v.buffer), v.bufferLength = 0, v.bytesHashed = 0
        }, f
    }();
    n.SHA256 = s;
    var o = new Int32Array([1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]);

    function l(f, v, g, b, S) {
        for (; S >= 64;) {
            for (var O = v[0], P = v[1], N = v[2], H = v[3], G = v[4], ie = v[5], T = v[6], L = v[7], I = 0; I < 16; I++) {
                var C = b + I * 4;
                f[I] = t.readUint32BE(g, C)
            }
            for (var I = 16; I < 64; I++) {
                var w = f[I - 2],
                    c = (w >>> 17 | w << 32 - 17) ^ (w >>> 19 | w << 32 - 19) ^ w >>> 10;
                w = f[I - 15];
                var m = (w >>> 7 | w << 32 - 7) ^ (w >>> 18 | w << 32 - 18) ^ w >>> 3;
                f[I] = (c + f[I - 7] | 0) + (m + f[I - 16] | 0)
            }
            for (var I = 0; I < 64; I++) {
                var c = (((G >>> 6 | G << 26) ^ (G >>> 11 | G << 21) ^ (G >>> 25 | G << 7)) + (G & ie ^ ~G & T) | 0) + (L + (o[I] + f[I] | 0) | 0) | 0,
                    m = ((O >>> 2 | O << 32 - 2) ^ (O >>> 13 | O << 32 - 13) ^ (O >>> 22 | O << 32 - 22)) + (O & P ^ O & N ^ P & N) | 0;
                L = T, T = ie, ie = G, G = H + c | 0, H = N, N = P, P = O, O = c + m | 0
            }
            v[0] += O, v[1] += P, v[2] += N, v[3] += H, v[4] += G, v[5] += ie, v[6] += T, v[7] += L, b += 64, S -= 64
        }
        return b
    }

    function d(f) {
        var v = new s;
        v.update(f);
        var g = v.digest();
        return v.clean(), g
    }
    n.hash = d
})(Ha);
var hu = {};
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.sharedKey = n.generateKeyPair = n.generateKeyPairFromSeed = n.scalarMultBase = n.scalarMult = n.SHARED_KEY_LENGTH = n.SECRET_KEY_LENGTH = n.PUBLIC_KEY_LENGTH = void 0;
    const t = An,
        r = xr;
    n.PUBLIC_KEY_LENGTH = 32, n.SECRET_KEY_LENGTH = 32, n.SHARED_KEY_LENGTH = 32;

    function s(I) {
        const C = new Float64Array(16);
        if (I)
            for (let w = 0; w < I.length; w++) C[w] = I[w];
        return C
    }
    const o = new Uint8Array(32);
    o[0] = 9;
    const l = s([56129, 1]);

    function d(I) {
        let C = 1;
        for (let w = 0; w < 16; w++) {
            let c = I[w] + C + 65535;
            C = Math.floor(c / 65536), I[w] = c - C * 65536
        }
        I[0] += C - 1 + 37 * (C - 1)
    }

    function f(I, C, w) {
        const c = ~(w - 1);
        for (let m = 0; m < 16; m++) {
            const K = c & (I[m] ^ C[m]);
            I[m] ^= K, C[m] ^= K
        }
    }

    function v(I, C) {
        const w = s(),
            c = s();
        for (let m = 0; m < 16; m++) c[m] = C[m];
        d(c), d(c), d(c);
        for (let m = 0; m < 2; m++) {
            w[0] = c[0] - 65517;
            for (let V = 1; V < 15; V++) w[V] = c[V] - 65535 - (w[V - 1] >> 16 & 1), w[V - 1] &= 65535;
            w[15] = c[15] - 32767 - (w[14] >> 16 & 1);
            const K = w[15] >> 16 & 1;
            w[14] &= 65535, f(c, w, 1 - K)
        }
        for (let m = 0; m < 16; m++) I[2 * m] = c[m] & 255, I[2 * m + 1] = c[m] >> 8
    }

    function g(I, C) {
        for (let w = 0; w < 16; w++) I[w] = C[2 * w] + (C[2 * w + 1] << 8);
        I[15] &= 32767
    }

    function b(I, C, w) {
        for (let c = 0; c < 16; c++) I[c] = C[c] + w[c]
    }

    function S(I, C, w) {
        for (let c = 0; c < 16; c++) I[c] = C[c] - w[c]
    }

    function O(I, C, w) {
        let c, m, K = 0,
            V = 0,
            ae = 0,
            ce = 0,
            ge = 0,
            F = 0,
            q = 0,
            le = 0,
            te = 0,
            W = 0,
            ee = 0,
            Y = 0,
            re = 0,
            xe = 0,
            ne = 0,
            be = 0,
            he = 0,
            _e = 0,
            z = 0,
            j = 0,
            R = 0,
            h = 0,
            x = 0,
            se = 0,
            fe = 0,
            Ie = 0,
            He = 0,
            ke = 0,
            Le = 0,
            pt = 0,
            dt = 0,
            je = w[0],
            Se = w[1],
            Re = w[2],
            Fe = w[3],
            ze = w[4],
            Oe = w[5],
            Ue = w[6],
            De = w[7],
            Ae = w[8],
            Be = w[9],
            Ce = w[10],
            Ve = w[11],
            We = w[12],
            et = w[13],
            tt = w[14],
            Je = w[15];
        c = C[0], K += c * je, V += c * Se, ae += c * Re, ce += c * Fe, ge += c * ze, F += c * Oe, q += c * Ue, le += c * De, te += c * Ae, W += c * Be, ee += c * Ce, Y += c * Ve, re += c * We, xe += c * et, ne += c * tt, be += c * Je, c = C[1], V += c * je, ae += c * Se, ce += c * Re, ge += c * Fe, F += c * ze, q += c * Oe, le += c * Ue, te += c * De, W += c * Ae, ee += c * Be, Y += c * Ce, re += c * Ve, xe += c * We, ne += c * et, be += c * tt, he += c * Je, c = C[2], ae += c * je, ce += c * Se, ge += c * Re, F += c * Fe, q += c * ze, le += c * Oe, te += c * Ue, W += c * De, ee += c * Ae, Y += c * Be, re += c * Ce, xe += c * Ve, ne += c * We, be += c * et, he += c * tt, _e += c * Je, c = C[3], ce += c * je, ge += c * Se, F += c * Re, q += c * Fe, le += c * ze, te += c * Oe, W += c * Ue, ee += c * De, Y += c * Ae, re += c * Be, xe += c * Ce, ne += c * Ve, be += c * We, he += c * et, _e += c * tt, z += c * Je, c = C[4], ge += c * je, F += c * Se, q += c * Re, le += c * Fe, te += c * ze, W += c * Oe, ee += c * Ue, Y += c * De, re += c * Ae, xe += c * Be, ne += c * Ce, be += c * Ve, he += c * We, _e += c * et, z += c * tt, j += c * Je, c = C[5], F += c * je, q += c * Se, le += c * Re, te += c * Fe, W += c * ze, ee += c * Oe, Y += c * Ue, re += c * De, xe += c * Ae, ne += c * Be, be += c * Ce, he += c * Ve, _e += c * We, z += c * et, j += c * tt, R += c * Je, c = C[6], q += c * je, le += c * Se, te += c * Re, W += c * Fe, ee += c * ze, Y += c * Oe, re += c * Ue, xe += c * De, ne += c * Ae, be += c * Be, he += c * Ce, _e += c * Ve, z += c * We, j += c * et, R += c * tt, h += c * Je, c = C[7], le += c * je, te += c * Se, W += c * Re, ee += c * Fe, Y += c * ze, re += c * Oe, xe += c * Ue, ne += c * De, be += c * Ae, he += c * Be, _e += c * Ce, z += c * Ve, j += c * We, R += c * et, h += c * tt, x += c * Je, c = C[8], te += c * je, W += c * Se, ee += c * Re, Y += c * Fe, re += c * ze, xe += c * Oe, ne += c * Ue, be += c * De, he += c * Ae, _e += c * Be, z += c * Ce, j += c * Ve, R += c * We, h += c * et, x += c * tt, se += c * Je, c = C[9], W += c * je, ee += c * Se, Y += c * Re, re += c * Fe, xe += c * ze, ne += c * Oe, be += c * Ue, he += c * De, _e += c * Ae, z += c * Be, j += c * Ce, R += c * Ve, h += c * We, x += c * et, se += c * tt, fe += c * Je, c = C[10], ee += c * je, Y += c * Se, re += c * Re, xe += c * Fe, ne += c * ze, be += c * Oe, he += c * Ue, _e += c * De, z += c * Ae, j += c * Be, R += c * Ce, h += c * Ve, x += c * We, se += c * et, fe += c * tt, Ie += c * Je, c = C[11], Y += c * je, re += c * Se, xe += c * Re, ne += c * Fe, be += c * ze, he += c * Oe, _e += c * Ue, z += c * De, j += c * Ae, R += c * Be, h += c * Ce, x += c * Ve, se += c * We, fe += c * et, Ie += c * tt, He += c * Je, c = C[12], re += c * je, xe += c * Se, ne += c * Re, be += c * Fe, he += c * ze, _e += c * Oe, z += c * Ue, j += c * De, R += c * Ae, h += c * Be, x += c * Ce, se += c * Ve, fe += c * We, Ie += c * et, He += c * tt, ke += c * Je, c = C[13], xe += c * je, ne += c * Se, be += c * Re, he += c * Fe, _e += c * ze, z += c * Oe, j += c * Ue, R += c * De, h += c * Ae, x += c * Be, se += c * Ce, fe += c * Ve, Ie += c * We, He += c * et, ke += c * tt, Le += c * Je, c = C[14], ne += c * je, be += c * Se, he += c * Re, _e += c * Fe, z += c * ze, j += c * Oe, R += c * Ue, h += c * De, x += c * Ae, se += c * Be, fe += c * Ce, Ie += c * Ve, He += c * We, ke += c * et, Le += c * tt, pt += c * Je, c = C[15], be += c * je, he += c * Se, _e += c * Re, z += c * Fe, j += c * ze, R += c * Oe, h += c * Ue, x += c * De, se += c * Ae, fe += c * Be, Ie += c * Ce, He += c * Ve, ke += c * We, Le += c * et, pt += c * tt, dt += c * Je, K += 38 * he, V += 38 * _e, ae += 38 * z, ce += 38 * j, ge += 38 * R, F += 38 * h, q += 38 * x, le += 38 * se, te += 38 * fe, W += 38 * Ie, ee += 38 * He, Y += 38 * ke, re += 38 * Le, xe += 38 * pt, ne += 38 * dt, m = 1, c = K + m + 65535, m = Math.floor(c / 65536), K = c - m * 65536, c = V + m + 65535, m = Math.floor(c / 65536), V = c - m * 65536, c = ae + m + 65535, m = Math.floor(c / 65536), ae = c - m * 65536, c = ce + m + 65535, m = Math.floor(c / 65536), ce = c - m * 65536, c = ge + m + 65535, m = Math.floor(c / 65536), ge = c - m * 65536, c = F + m + 65535, m = Math.floor(c / 65536), F = c - m * 65536, c = q + m + 65535, m = Math.floor(c / 65536), q = c - m * 65536, c = le + m + 65535, m = Math.floor(c / 65536), le = c - m * 65536, c = te + m + 65535, m = Math.floor(c / 65536), te = c - m * 65536, c = W + m + 65535, m = Math.floor(c / 65536), W = c - m * 65536, c = ee + m + 65535, m = Math.floor(c / 65536), ee = c - m * 65536, c = Y + m + 65535, m = Math.floor(c / 65536), Y = c - m * 65536, c = re + m + 65535, m = Math.floor(c / 65536), re = c - m * 65536, c = xe + m + 65535, m = Math.floor(c / 65536), xe = c - m * 65536, c = ne + m + 65535, m = Math.floor(c / 65536), ne = c - m * 65536, c = be + m + 65535, m = Math.floor(c / 65536), be = c - m * 65536, K += m - 1 + 37 * (m - 1), m = 1, c = K + m + 65535, m = Math.floor(c / 65536), K = c - m * 65536, c = V + m + 65535, m = Math.floor(c / 65536), V = c - m * 65536, c = ae + m + 65535, m = Math.floor(c / 65536), ae = c - m * 65536, c = ce + m + 65535, m = Math.floor(c / 65536), ce = c - m * 65536, c = ge + m + 65535, m = Math.floor(c / 65536), ge = c - m * 65536, c = F + m + 65535, m = Math.floor(c / 65536), F = c - m * 65536, c = q + m + 65535, m = Math.floor(c / 65536), q = c - m * 65536, c = le + m + 65535, m = Math.floor(c / 65536), le = c - m * 65536, c = te + m + 65535, m = Math.floor(c / 65536), te = c - m * 65536, c = W + m + 65535, m = Math.floor(c / 65536), W = c - m * 65536, c = ee + m + 65535, m = Math.floor(c / 65536), ee = c - m * 65536, c = Y + m + 65535, m = Math.floor(c / 65536), Y = c - m * 65536, c = re + m + 65535, m = Math.floor(c / 65536), re = c - m * 65536, c = xe + m + 65535, m = Math.floor(c / 65536), xe = c - m * 65536, c = ne + m + 65535, m = Math.floor(c / 65536), ne = c - m * 65536, c = be + m + 65535, m = Math.floor(c / 65536), be = c - m * 65536, K += m - 1 + 37 * (m - 1), I[0] = K, I[1] = V, I[2] = ae, I[3] = ce, I[4] = ge, I[5] = F, I[6] = q, I[7] = le, I[8] = te, I[9] = W, I[10] = ee, I[11] = Y, I[12] = re, I[13] = xe, I[14] = ne, I[15] = be
    }

    function P(I, C) {
        O(I, C, C)
    }

    function N(I, C) {
        const w = s();
        for (let c = 0; c < 16; c++) w[c] = C[c];
        for (let c = 253; c >= 0; c--) P(w, w), c !== 2 && c !== 4 && O(w, w, C);
        for (let c = 0; c < 16; c++) I[c] = w[c]
    }

    function H(I, C) {
        const w = new Uint8Array(32),
            c = new Float64Array(80),
            m = s(),
            K = s(),
            V = s(),
            ae = s(),
            ce = s(),
            ge = s();
        for (let te = 0; te < 31; te++) w[te] = I[te];
        w[31] = I[31] & 127 | 64, w[0] &= 248, g(c, C);
        for (let te = 0; te < 16; te++) K[te] = c[te];
        m[0] = ae[0] = 1;
        for (let te = 254; te >= 0; --te) {
            const W = w[te >>> 3] >>> (te & 7) & 1;
            f(m, K, W), f(V, ae, W), b(ce, m, V), S(m, m, V), b(V, K, ae), S(K, K, ae), P(ae, ce), P(ge, m), O(m, V, m), O(V, K, ce), b(ce, m, V), S(m, m, V), P(K, m), S(V, ae, ge), O(m, V, l), b(m, m, ae), O(V, V, m), O(m, ae, ge), O(ae, K, c), P(K, ce), f(m, K, W), f(V, ae, W)
        }
        for (let te = 0; te < 16; te++) c[te + 16] = m[te], c[te + 32] = V[te], c[te + 48] = K[te], c[te + 64] = ae[te];
        const F = c.subarray(32),
            q = c.subarray(16);
        N(F, F), O(q, q, F);
        const le = new Uint8Array(32);
        return v(le, q), le
    }
    n.scalarMult = H;

    function G(I) {
        return H(I, o)
    }
    n.scalarMultBase = G;

    function ie(I) {
        if (I.length !== n.SECRET_KEY_LENGTH) throw new Error(`x25519: seed must be ${n.SECRET_KEY_LENGTH} bytes`);
        const C = new Uint8Array(I);
        return {
            publicKey: G(C),
            secretKey: C
        }
    }
    n.generateKeyPairFromSeed = ie;

    function T(I) {
        const C = (0, t.randomBytes)(32, I),
            w = ie(C);
        return (0, r.wipe)(C), w
    }
    n.generateKeyPair = T;

    function L(I, C, w = !1) {
        if (I.length !== n.PUBLIC_KEY_LENGTH) throw new Error("X25519: incorrect secret key length");
        if (C.length !== n.PUBLIC_KEY_LENGTH) throw new Error("X25519: incorrect public key length");
        const c = H(I, C);
        if (w) {
            let m = 0;
            for (let K = 0; K < c.length; K++) m |= c[K];
            if (m === 0) throw new Error("X25519: invalid shared key")
        }
        return c
    }
    n.sharedKey = L
})(hu);

function lu(n) {
    return globalThis.Buffer != null ? new Uint8Array(n.buffer, n.byteOffset, n.byteLength) : n
}

function np(n = 0) {
    return globalThis.Buffer != null && globalThis.Buffer.allocUnsafe != null ? lu(globalThis.Buffer.allocUnsafe(n)) : new Uint8Array(n)
}

function Kc(n, t) {
    t || (t = n.reduce((o, l) => o + l.length, 0));
    const r = np(t);
    let s = 0;
    for (const o of n) r.set(o, s), s += o.length;
    return lu(r)
}

function Am(n, t) {
    if (n.length >= 255) throw new TypeError("Alphabet too long");
    for (var r = new Uint8Array(256), s = 0; s < r.length; s++) r[s] = 255;
    for (var o = 0; o < n.length; o++) {
        var l = n.charAt(o),
            d = l.charCodeAt(0);
        if (r[d] !== 255) throw new TypeError(l + " is ambiguous");
        r[d] = o
    }
    var f = n.length,
        v = n.charAt(0),
        g = Math.log(f) / Math.log(256),
        b = Math.log(256) / Math.log(f);

    function S(N) {
        if (N instanceof Uint8Array || (ArrayBuffer.isView(N) ? N = new Uint8Array(N.buffer, N.byteOffset, N.byteLength) : Array.isArray(N) && (N = Uint8Array.from(N))), !(N instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
        if (N.length === 0) return "";
        for (var H = 0, G = 0, ie = 0, T = N.length; ie !== T && N[ie] === 0;) ie++, H++;
        for (var L = (T - ie) * b + 1 >>> 0, I = new Uint8Array(L); ie !== T;) {
            for (var C = N[ie], w = 0, c = L - 1;
                (C !== 0 || w < G) && c !== -1; c--, w++) C += 256 * I[c] >>> 0, I[c] = C % f >>> 0, C = C / f >>> 0;
            if (C !== 0) throw new Error("Non-zero carry");
            G = w, ie++
        }
        for (var m = L - G; m !== L && I[m] === 0;) m++;
        for (var K = v.repeat(H); m < L; ++m) K += n.charAt(I[m]);
        return K
    }

    function O(N) {
        if (typeof N != "string") throw new TypeError("Expected String");
        if (N.length === 0) return new Uint8Array;
        var H = 0;
        if (N[H] !== " ") {
            for (var G = 0, ie = 0; N[H] === v;) G++, H++;
            for (var T = (N.length - H) * g + 1 >>> 0, L = new Uint8Array(T); N[H];) {
                var I = r[N.charCodeAt(H)];
                if (I === 255) return;
                for (var C = 0, w = T - 1;
                    (I !== 0 || C < ie) && w !== -1; w--, C++) I += f * L[w] >>> 0, L[w] = I % 256 >>> 0, I = I / 256 >>> 0;
                if (I !== 0) throw new Error("Non-zero carry");
                ie = C, H++
            }
            if (N[H] !== " ") {
                for (var c = T - ie; c !== T && L[c] === 0;) c++;
                for (var m = new Uint8Array(G + (T - c)), K = G; c !== T;) m[K++] = L[c++];
                return m
            }
        }
    }

    function P(N) {
        var H = O(N);
        if (H) return H;
        throw new Error(`Non-${t} character`)
    }
    return {
        encode: S,
        decodeUnsafe: O,
        decode: P
    }
}
var Pm = Am,
    Nm = Pm;
const Tm = n => {
        if (n instanceof Uint8Array && n.constructor.name === "Uint8Array") return n;
        if (n instanceof ArrayBuffer) return new Uint8Array(n);
        if (ArrayBuffer.isView(n)) return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        throw new Error("Unknown type, must be binary type")
    },
    Rm = n => new TextEncoder().encode(n),
    Fm = n => new TextDecoder().decode(n);
class Um {
    constructor(t, r, s) {
        this.name = t, this.prefix = r, this.baseEncode = s
    }
    encode(t) {
        if (t instanceof Uint8Array) return `${this.prefix}${this.baseEncode(t)}`;
        throw Error("Unknown type, must be binary type")
    }
}
class $m {
    constructor(t, r, s) {
        if (this.name = t, this.prefix = r, r.codePointAt(0) === void 0) throw new Error("Invalid prefix character");
        this.prefixCodePoint = r.codePointAt(0), this.baseDecode = s
    }
    decode(t) {
        if (typeof t == "string") {
            if (t.codePointAt(0) !== this.prefixCodePoint) throw Error(`Unable to decode multibase string ${JSON.stringify(t)}, ${this.name} decoder only supports inputs prefixed with ${this.prefix}`);
            return this.baseDecode(t.slice(this.prefix.length))
        } else throw Error("Can only multibase decode strings")
    }
    or(t) {
        return sp(this, t)
    }
}
class Lm {
    constructor(t) {
        this.decoders = t
    }
    or(t) {
        return sp(this, t)
    }
    decode(t) {
        const r = t[0],
            s = this.decoders[r];
        if (s) return s.decode(t);
        throw RangeError(`Unable to decode multibase string ${JSON.stringify(t)}, only inputs prefixed with ${Object.keys(this.decoders)} are supported`)
    }
}
const sp = (n, t) => new Lm({ ...n.decoders || {
        [n.prefix]: n
    },
    ...t.decoders || {
        [t.prefix]: t
    }
});
class Mm {
    constructor(t, r, s, o) {
        this.name = t, this.prefix = r, this.baseEncode = s, this.baseDecode = o, this.encoder = new Um(t, r, s), this.decoder = new $m(t, r, o)
    }
    encode(t) {
        return this.encoder.encode(t)
    }
    decode(t) {
        return this.decoder.decode(t)
    }
}
const Ba = ({
        name: n,
        prefix: t,
        encode: r,
        decode: s
    }) => new Mm(n, t, r, s),
    hs = ({
        prefix: n,
        name: t,
        alphabet: r
    }) => {
        const {
            encode: s,
            decode: o
        } = Nm(r, t);
        return Ba({
            prefix: n,
            name: t,
            encode: s,
            decode: l => Tm(o(l))
        })
    },
    jm = (n, t, r, s) => {
        const o = {};
        for (let b = 0; b < t.length; ++b) o[t[b]] = b;
        let l = n.length;
        for (; n[l - 1] === "=";) --l;
        const d = new Uint8Array(l * r / 8 | 0);
        let f = 0,
            v = 0,
            g = 0;
        for (let b = 0; b < l; ++b) {
            const S = o[n[b]];
            if (S === void 0) throw new SyntaxError(`Non-${s} character`);
            v = v << r | S, f += r, f >= 8 && (f -= 8, d[g++] = 255 & v >> f)
        }
        if (f >= r || 255 & v << 8 - f) throw new SyntaxError("Unexpected end of data");
        return d
    },
    zm = (n, t, r) => {
        const s = t[t.length - 1] === "=",
            o = (1 << r) - 1;
        let l = "",
            d = 0,
            f = 0;
        for (let v = 0; v < n.length; ++v)
            for (f = f << 8 | n[v], d += 8; d > r;) d -= r, l += t[o & f >> d];
        if (d && (l += t[o & f << r - d]), s)
            for (; l.length * r & 7;) l += "=";
        return l
    },
    Yt = ({
        name: n,
        prefix: t,
        bitsPerChar: r,
        alphabet: s
    }) => Ba({
        prefix: t,
        name: n,
        encode(o) {
            return zm(o, s, r)
        },
        decode(o) {
            return jm(o, s, r, n)
        }
    }),
    qm = Ba({
        prefix: "\0",
        name: "identity",
        encode: n => Fm(n),
        decode: n => Rm(n)
    }),
    Hm = Object.freeze(Object.defineProperty({
        __proto__: null,
        identity: qm
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Bm = Yt({
        prefix: "0",
        name: "base2",
        alphabet: "01",
        bitsPerChar: 1
    }),
    Km = Object.freeze(Object.defineProperty({
        __proto__: null,
        base2: Bm
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    km = Yt({
        prefix: "7",
        name: "base8",
        alphabet: "01234567",
        bitsPerChar: 3
    }),
    Vm = Object.freeze(Object.defineProperty({
        __proto__: null,
        base8: km
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Gm = hs({
        prefix: "9",
        name: "base10",
        alphabet: "0123456789"
    }),
    Wm = Object.freeze(Object.defineProperty({
        __proto__: null,
        base10: Gm
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Ym = Yt({
        prefix: "f",
        name: "base16",
        alphabet: "0123456789abcdef",
        bitsPerChar: 4
    }),
    Jm = Yt({
        prefix: "F",
        name: "base16upper",
        alphabet: "0123456789ABCDEF",
        bitsPerChar: 4
    }),
    Xm = Object.freeze(Object.defineProperty({
        __proto__: null,
        base16: Ym,
        base16upper: Jm
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Zm = Yt({
        prefix: "b",
        name: "base32",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567",
        bitsPerChar: 5
    }),
    Qm = Yt({
        prefix: "B",
        name: "base32upper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
        bitsPerChar: 5
    }),
    eb = Yt({
        prefix: "c",
        name: "base32pad",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567=",
        bitsPerChar: 5
    }),
    tb = Yt({
        prefix: "C",
        name: "base32padupper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567=",
        bitsPerChar: 5
    }),
    rb = Yt({
        prefix: "v",
        name: "base32hex",
        alphabet: "0123456789abcdefghijklmnopqrstuv",
        bitsPerChar: 5
    }),
    ib = Yt({
        prefix: "V",
        name: "base32hexupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV",
        bitsPerChar: 5
    }),
    nb = Yt({
        prefix: "t",
        name: "base32hexpad",
        alphabet: "0123456789abcdefghijklmnopqrstuv=",
        bitsPerChar: 5
    }),
    sb = Yt({
        prefix: "T",
        name: "base32hexpadupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV=",
        bitsPerChar: 5
    }),
    ab = Yt({
        prefix: "h",
        name: "base32z",
        alphabet: "ybndrfg8ejkmcpqxot1uwisza345h769",
        bitsPerChar: 5
    }),
    ob = Object.freeze(Object.defineProperty({
        __proto__: null,
        base32: Zm,
        base32hex: rb,
        base32hexpad: nb,
        base32hexpadupper: sb,
        base32hexupper: ib,
        base32pad: eb,
        base32padupper: tb,
        base32upper: Qm,
        base32z: ab
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    cb = hs({
        prefix: "k",
        name: "base36",
        alphabet: "0123456789abcdefghijklmnopqrstuvwxyz"
    }),
    ub = hs({
        prefix: "K",
        name: "base36upper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    }),
    hb = Object.freeze(Object.defineProperty({
        __proto__: null,
        base36: cb,
        base36upper: ub
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    lb = hs({
        name: "base58btc",
        prefix: "z",
        alphabet: "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    }),
    fb = hs({
        name: "base58flickr",
        prefix: "Z",
        alphabet: "123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ"
    }),
    pb = Object.freeze(Object.defineProperty({
        __proto__: null,
        base58btc: lb,
        base58flickr: fb
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    db = Yt({
        prefix: "m",
        name: "base64",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        bitsPerChar: 6
    }),
    gb = Yt({
        prefix: "M",
        name: "base64pad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        bitsPerChar: 6
    }),
    vb = Yt({
        prefix: "u",
        name: "base64url",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
        bitsPerChar: 6
    }),
    yb = Yt({
        prefix: "U",
        name: "base64urlpad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=",
        bitsPerChar: 6
    }),
    _b = Object.freeze(Object.defineProperty({
        __proto__: null,
        base64: db,
        base64pad: gb,
        base64url: vb,
        base64urlpad: yb
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ap = Array.from("🚀🪐☄🛰🌌🌑🌒🌓🌔🌕🌖🌗🌘🌍🌏🌎🐉☀💻🖥💾💿😂❤😍🤣😊🙏💕😭😘👍😅👏😁🔥🥰💔💖💙😢🤔😆🙄💪😉☺👌🤗💜😔😎😇🌹🤦🎉💞✌✨🤷😱😌🌸🙌😋💗💚😏💛🙂💓🤩😄😀🖤😃💯🙈👇🎶😒🤭❣😜💋👀😪😑💥🙋😞😩😡🤪👊🥳😥🤤👉💃😳✋😚😝😴🌟😬🙃🍀🌷😻😓⭐✅🥺🌈😈🤘💦✔😣🏃💐☹🎊💘😠☝😕🌺🎂🌻😐🖕💝🙊😹🗣💫💀👑🎵🤞😛🔴😤🌼😫⚽🤙☕🏆🤫👈😮🙆🍻🍃🐶💁😲🌿🧡🎁⚡🌞🎈❌✊👋😰🤨😶🤝🚶💰🍓💢🤟🙁🚨💨🤬✈🎀🍺🤓😙💟🌱😖👶🥴▶➡❓💎💸⬇😨🌚🦋😷🕺⚠🙅😟😵👎🤲🤠🤧📌🔵💅🧐🐾🍒😗🤑🌊🤯🐷☎💧😯💆👆🎤🙇🍑❄🌴💣🐸💌📍🥀🤢👅💡💩👐📸👻🤐🤮🎼🥵🚩🍎🍊👼💍📣🥂"),
    mb = ap.reduce((n, t, r) => (n[r] = t, n), []),
    bb = ap.reduce((n, t, r) => (n[t.codePointAt(0)] = r, n), []);

function wb(n) {
    return n.reduce((t, r) => (t += mb[r], t), "")
}

function Eb(n) {
    const t = [];
    for (const r of n) {
        const s = bb[r.codePointAt(0)];
        if (s === void 0) throw new Error(`Non-base256emoji character: ${r}`);
        t.push(s)
    }
    return new Uint8Array(t)
}
const Db = Ba({
        prefix: "🚀",
        name: "base256emoji",
        encode: wb,
        decode: Eb
    }),
    Ib = Object.freeze(Object.defineProperty({
        __proto__: null,
        base256emoji: Db
    }, Symbol.toStringTag, {
        value: "Module"
    }));
new TextEncoder;
new TextDecoder;
const Ol = { ...Hm,
    ...Km,
    ...Vm,
    ...Wm,
    ...Xm,
    ...ob,
    ...hb,
    ...pb,
    ..._b,
    ...Ib
};

function op(n, t, r, s) {
    return {
        name: n,
        prefix: t,
        encoder: {
            name: n,
            prefix: t,
            encode: r
        },
        decoder: {
            decode: s
        }
    }
}
const Al = op("utf8", "u", n => "u" + new TextDecoder("utf8").decode(n), n => new TextEncoder().encode(n.substring(1))),
    _c = op("ascii", "a", n => {
        let t = "a";
        for (let r = 0; r < n.length; r++) t += String.fromCharCode(n[r]);
        return t
    }, n => {
        n = n.substring(1);
        const t = np(n.length);
        for (let r = 0; r < n.length; r++) t[r] = n.charCodeAt(r);
        return t
    }),
    cp = {
        utf8: Al,
        "utf-8": Al,
        hex: Ol.base16,
        latin1: _c,
        ascii: _c,
        binary: _c,
        ...Ol
    };

function mr(n, t = "utf8") {
    const r = cp[t];
    if (!r) throw new Error(`Unsupported encoding "${t}"`);
    return (t === "utf8" || t === "utf-8") && globalThis.Buffer != null && globalThis.Buffer.from != null ? lu(globalThis.Buffer.from(n, "utf-8")) : r.decoder.decode(`${r.prefix}${n}`)
}

function ur(n, t = "utf8") {
    const r = cp[t];
    if (!r) throw new Error(`Unsupported encoding "${t}"`);
    return (t === "utf8" || t === "utf-8") && globalThis.Buffer != null && globalThis.Buffer.from != null ? globalThis.Buffer.from(n.buffer, n.byteOffset, n.byteLength).toString("utf8") : r.encoder.encode(n).substring(1)
}
var ye = {},
    mc = {},
    Xn = {},
    Pl;

function Sb() {
    if (Pl) return Xn;
    Pl = 1, Object.defineProperty(Xn, "__esModule", {
        value: !0
    }), Xn.delay = void 0;

    function n(t) {
        return new Promise(r => {
            setTimeout(() => {
                r(!0)
            }, t)
        })
    }
    return Xn.delay = n, Xn
}
var Yi = {},
    bc = {},
    Ji = {},
    Nl;

function xb() {
    return Nl || (Nl = 1, Object.defineProperty(Ji, "__esModule", {
        value: !0
    }), Ji.ONE_THOUSAND = Ji.ONE_HUNDRED = void 0, Ji.ONE_HUNDRED = 100, Ji.ONE_THOUSAND = 1e3), Ji
}
var wc = {},
    Tl;

function Cb() {
    return Tl || (Tl = 1, function(n) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.ONE_YEAR = n.FOUR_WEEKS = n.THREE_WEEKS = n.TWO_WEEKS = n.ONE_WEEK = n.THIRTY_DAYS = n.SEVEN_DAYS = n.FIVE_DAYS = n.THREE_DAYS = n.ONE_DAY = n.TWENTY_FOUR_HOURS = n.TWELVE_HOURS = n.SIX_HOURS = n.THREE_HOURS = n.ONE_HOUR = n.SIXTY_MINUTES = n.THIRTY_MINUTES = n.TEN_MINUTES = n.FIVE_MINUTES = n.ONE_MINUTE = n.SIXTY_SECONDS = n.THIRTY_SECONDS = n.TEN_SECONDS = n.FIVE_SECONDS = n.ONE_SECOND = void 0, n.ONE_SECOND = 1, n.FIVE_SECONDS = 5, n.TEN_SECONDS = 10, n.THIRTY_SECONDS = 30, n.SIXTY_SECONDS = 60, n.ONE_MINUTE = n.SIXTY_SECONDS, n.FIVE_MINUTES = n.ONE_MINUTE * 5, n.TEN_MINUTES = n.ONE_MINUTE * 10, n.THIRTY_MINUTES = n.ONE_MINUTE * 30, n.SIXTY_MINUTES = n.ONE_MINUTE * 60, n.ONE_HOUR = n.SIXTY_MINUTES, n.THREE_HOURS = n.ONE_HOUR * 3, n.SIX_HOURS = n.ONE_HOUR * 6, n.TWELVE_HOURS = n.ONE_HOUR * 12, n.TWENTY_FOUR_HOURS = n.ONE_HOUR * 24, n.ONE_DAY = n.TWENTY_FOUR_HOURS, n.THREE_DAYS = n.ONE_DAY * 3, n.FIVE_DAYS = n.ONE_DAY * 5, n.SEVEN_DAYS = n.ONE_DAY * 7, n.THIRTY_DAYS = n.ONE_DAY * 30, n.ONE_WEEK = n.SEVEN_DAYS, n.TWO_WEEKS = n.ONE_WEEK * 2, n.THREE_WEEKS = n.ONE_WEEK * 3, n.FOUR_WEEKS = n.ONE_WEEK * 4, n.ONE_YEAR = n.ONE_DAY * 365
    }(wc)), wc
}
var Rl;

function up() {
    return Rl || (Rl = 1, function(n) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        const t = vi;
        t.__exportStar(xb(), n), t.__exportStar(Cb(), n)
    }(bc)), bc
}
var Fl;

function Ob() {
    if (Fl) return Yi;
    Fl = 1, Object.defineProperty(Yi, "__esModule", {
        value: !0
    }), Yi.fromMiliseconds = Yi.toMiliseconds = void 0;
    const n = up();

    function t(s) {
        return s * n.ONE_THOUSAND
    }
    Yi.toMiliseconds = t;

    function r(s) {
        return Math.floor(s / n.ONE_THOUSAND)
    }
    return Yi.fromMiliseconds = r, Yi
}
var Ul;

function Ab() {
    return Ul || (Ul = 1, function(n) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        const t = vi;
        t.__exportStar(Sb(), n), t.__exportStar(Ob(), n)
    }(mc)), mc
}
var Sn = {},
    $l;

function Pb() {
    if ($l) return Sn;
    $l = 1, Object.defineProperty(Sn, "__esModule", {
        value: !0
    }), Sn.Watch = void 0;
    class n {
        constructor() {
            this.timestamps = new Map
        }
        start(r) {
            if (this.timestamps.has(r)) throw new Error(`Watch already started for label: ${r}`);
            this.timestamps.set(r, {
                started: Date.now()
            })
        }
        stop(r) {
            const s = this.get(r);
            if (typeof s.elapsed < "u") throw new Error(`Watch already stopped for label: ${r}`);
            const o = Date.now() - s.started;
            this.timestamps.set(r, {
                started: s.started,
                elapsed: o
            })
        }
        get(r) {
            const s = this.timestamps.get(r);
            if (typeof s > "u") throw new Error(`No timestamp found for label: ${r}`);
            return s
        }
        elapsed(r) {
            const s = this.get(r);
            return s.elapsed || Date.now() - s.started
        }
    }
    return Sn.Watch = n, Sn.default = n, Sn
}
var Ec = {},
    Zn = {},
    Ll;

function Nb() {
    if (Ll) return Zn;
    Ll = 1, Object.defineProperty(Zn, "__esModule", {
        value: !0
    }), Zn.IWatch = void 0;
    class n {}
    return Zn.IWatch = n, Zn
}
var Ml;

function Tb() {
    return Ml || (Ml = 1, function(n) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), vi.__exportStar(Nb(), n)
    }(Ec)), Ec
}(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    const t = vi;
    t.__exportStar(Ab(), n), t.__exportStar(Pb(), n), t.__exportStar(Tb(), n), t.__exportStar(up(), n)
})(ye);
var os = {},
    Rb = function(n, t) {
        for (var r = {}, s = Object.keys(n), o = Array.isArray(t), l = 0; l < s.length; l++) {
            var d = s[l],
                f = n[d];
            (o ? t.indexOf(d) !== -1 : t(d, f, n)) && (r[d] = f)
        }
        return r
    };
(function(n) {
    const t = R_,
        r = F_,
        s = T_,
        o = Rb,
        l = T => T == null,
        d = Symbol("encodeFragmentIdentifier");

    function f(T) {
        switch (T.arrayFormat) {
            case "index":
                return L => (I, C) => {
                    const w = I.length;
                    return C === void 0 || T.skipNull && C === null || T.skipEmptyString && C === "" ? I : C === null ? [...I, [b(L, T), "[", w, "]"].join("")] : [...I, [b(L, T), "[", b(w, T), "]=", b(C, T)].join("")]
                };
            case "bracket":
                return L => (I, C) => C === void 0 || T.skipNull && C === null || T.skipEmptyString && C === "" ? I : C === null ? [...I, [b(L, T), "[]"].join("")] : [...I, [b(L, T), "[]=", b(C, T)].join("")];
            case "colon-list-separator":
                return L => (I, C) => C === void 0 || T.skipNull && C === null || T.skipEmptyString && C === "" ? I : C === null ? [...I, [b(L, T), ":list="].join("")] : [...I, [b(L, T), ":list=", b(C, T)].join("")];
            case "comma":
            case "separator":
            case "bracket-separator":
                {
                    const L = T.arrayFormat === "bracket-separator" ? "[]=" : "=";
                    return I => (C, w) => w === void 0 || T.skipNull && w === null || T.skipEmptyString && w === "" ? C : (w = w === null ? "" : w, C.length === 0 ? [
                        [b(I, T), L, b(w, T)].join("")
                    ] : [
                        [C, b(w, T)].join(T.arrayFormatSeparator)
                    ])
                }
            default:
                return L => (I, C) => C === void 0 || T.skipNull && C === null || T.skipEmptyString && C === "" ? I : C === null ? [...I, b(L, T)] : [...I, [b(L, T), "=", b(C, T)].join("")]
        }
    }

    function v(T) {
        let L;
        switch (T.arrayFormat) {
            case "index":
                return (I, C, w) => {
                    if (L = /\[(\d*)\]$/.exec(I), I = I.replace(/\[\d*\]$/, ""), !L) {
                        w[I] = C;
                        return
                    }
                    w[I] === void 0 && (w[I] = {}), w[I][L[1]] = C
                };
            case "bracket":
                return (I, C, w) => {
                    if (L = /(\[\])$/.exec(I), I = I.replace(/\[\]$/, ""), !L) {
                        w[I] = C;
                        return
                    }
                    if (w[I] === void 0) {
                        w[I] = [C];
                        return
                    }
                    w[I] = [].concat(w[I], C)
                };
            case "colon-list-separator":
                return (I, C, w) => {
                    if (L = /(:list)$/.exec(I), I = I.replace(/:list$/, ""), !L) {
                        w[I] = C;
                        return
                    }
                    if (w[I] === void 0) {
                        w[I] = [C];
                        return
                    }
                    w[I] = [].concat(w[I], C)
                };
            case "comma":
            case "separator":
                return (I, C, w) => {
                    const c = typeof C == "string" && C.includes(T.arrayFormatSeparator),
                        m = typeof C == "string" && !c && S(C, T).includes(T.arrayFormatSeparator);
                    C = m ? S(C, T) : C;
                    const K = c || m ? C.split(T.arrayFormatSeparator).map(V => S(V, T)) : C === null ? C : S(C, T);
                    w[I] = K
                };
            case "bracket-separator":
                return (I, C, w) => {
                    const c = /(\[\])$/.test(I);
                    if (I = I.replace(/\[\]$/, ""), !c) {
                        w[I] = C && S(C, T);
                        return
                    }
                    const m = C === null ? [] : C.split(T.arrayFormatSeparator).map(K => S(K, T));
                    if (w[I] === void 0) {
                        w[I] = m;
                        return
                    }
                    w[I] = [].concat(w[I], m)
                };
            default:
                return (I, C, w) => {
                    if (w[I] === void 0) {
                        w[I] = C;
                        return
                    }
                    w[I] = [].concat(w[I], C)
                }
        }
    }

    function g(T) {
        if (typeof T != "string" || T.length !== 1) throw new TypeError("arrayFormatSeparator must be single character string")
    }

    function b(T, L) {
        return L.encode ? L.strict ? t(T) : encodeURIComponent(T) : T
    }

    function S(T, L) {
        return L.decode ? r(T) : T
    }

    function O(T) {
        return Array.isArray(T) ? T.sort() : typeof T == "object" ? O(Object.keys(T)).sort((L, I) => Number(L) - Number(I)).map(L => T[L]) : T
    }

    function P(T) {
        const L = T.indexOf("#");
        return L !== -1 && (T = T.slice(0, L)), T
    }

    function N(T) {
        let L = "";
        const I = T.indexOf("#");
        return I !== -1 && (L = T.slice(I)), L
    }

    function H(T) {
        T = P(T);
        const L = T.indexOf("?");
        return L === -1 ? "" : T.slice(L + 1)
    }

    function G(T, L) {
        return L.parseNumbers && !Number.isNaN(Number(T)) && typeof T == "string" && T.trim() !== "" ? T = Number(T) : L.parseBooleans && T !== null && (T.toLowerCase() === "true" || T.toLowerCase() === "false") && (T = T.toLowerCase() === "true"), T
    }

    function ie(T, L) {
        L = Object.assign({
            decode: !0,
            sort: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ",",
            parseNumbers: !1,
            parseBooleans: !1
        }, L), g(L.arrayFormatSeparator);
        const I = v(L),
            C = Object.create(null);
        if (typeof T != "string" || (T = T.trim().replace(/^[?#&]/, ""), !T)) return C;
        for (const w of T.split("&")) {
            if (w === "") continue;
            let [c, m] = s(L.decode ? w.replace(/\+/g, " ") : w, "=");
            m = m === void 0 ? null : ["comma", "separator", "bracket-separator"].includes(L.arrayFormat) ? m : S(m, L), I(S(c, L), m, C)
        }
        for (const w of Object.keys(C)) {
            const c = C[w];
            if (typeof c == "object" && c !== null)
                for (const m of Object.keys(c)) c[m] = G(c[m], L);
            else C[w] = G(c, L)
        }
        return L.sort === !1 ? C : (L.sort === !0 ? Object.keys(C).sort() : Object.keys(C).sort(L.sort)).reduce((w, c) => {
            const m = C[c];
            return m && typeof m == "object" && !Array.isArray(m) ? w[c] = O(m) : w[c] = m, w
        }, Object.create(null))
    }
    n.extract = H, n.parse = ie, n.stringify = (T, L) => {
        if (!T) return "";
        L = Object.assign({
            encode: !0,
            strict: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ","
        }, L), g(L.arrayFormatSeparator);
        const I = m => L.skipNull && l(T[m]) || L.skipEmptyString && T[m] === "",
            C = f(L),
            w = {};
        for (const m of Object.keys(T)) I(m) || (w[m] = T[m]);
        const c = Object.keys(w);
        return L.sort !== !1 && c.sort(L.sort), c.map(m => {
            const K = T[m];
            return K === void 0 ? "" : K === null ? b(m, L) : Array.isArray(K) ? K.length === 0 && L.arrayFormat === "bracket-separator" ? b(m, L) + "[]" : K.reduce(C(m), []).join("&") : b(m, L) + "=" + b(K, L)
        }).filter(m => m.length > 0).join("&")
    }, n.parseUrl = (T, L) => {
        L = Object.assign({
            decode: !0
        }, L);
        const [I, C] = s(T, "#");
        return Object.assign({
            url: I.split("?")[0] || "",
            query: ie(H(T), L)
        }, L && L.parseFragmentIdentifier && C ? {
            fragmentIdentifier: S(C, L)
        } : {})
    }, n.stringifyUrl = (T, L) => {
        L = Object.assign({
            encode: !0,
            strict: !0,
            [d]: !0
        }, L);
        const I = P(T.url).split("?")[0] || "",
            C = n.extract(T.url),
            w = n.parse(C, {
                sort: !1
            }),
            c = Object.assign(w, T.query);
        let m = n.stringify(c, L);
        m && (m = `?${m}`);
        let K = N(T.url);
        return T.fragmentIdentifier && (K = `#${L[d]?b(T.fragmentIdentifier,L):T.fragmentIdentifier}`), `${I}${m}${K}`
    }, n.pick = (T, L, I) => {
        I = Object.assign({
            parseFragmentIdentifier: !0,
            [d]: !1
        }, I);
        const {
            url: C,
            query: w,
            fragmentIdentifier: c
        } = n.parseUrl(T, I);
        return n.stringifyUrl({
            url: C,
            query: o(w, L),
            fragmentIdentifier: c
        }, I)
    }, n.exclude = (T, L, I) => {
        const C = Array.isArray(L) ? w => !L.includes(w) : (w, c) => !L(w, c);
        return n.pick(T, C, I)
    }
})(os);
const Fb = {
    waku: {
        publish: "waku_publish",
        batchPublish: "waku_batchPublish",
        subscribe: "waku_subscribe",
        batchSubscribe: "waku_batchSubscribe",
        subscription: "waku_subscription",
        unsubscribe: "waku_unsubscribe",
        batchUnsubscribe: "waku_batchUnsubscribe"
    },
    irn: {
        publish: "irn_publish",
        batchPublish: "irn_batchPublish",
        subscribe: "irn_subscribe",
        batchSubscribe: "irn_batchSubscribe",
        subscription: "irn_subscription",
        unsubscribe: "irn_unsubscribe",
        batchUnsubscribe: "irn_batchUnsubscribe"
    },
    iridium: {
        publish: "iridium_publish",
        batchPublish: "iridium_batchPublish",
        subscribe: "iridium_subscribe",
        batchSubscribe: "iridium_batchSubscribe",
        subscription: "iridium_subscription",
        unsubscribe: "iridium_unsubscribe",
        batchUnsubscribe: "iridium_batchUnsubscribe"
    }
};

function Ub(n, t = []) {
    const r = [];
    return Object.keys(n).forEach(s => {
        if (t.length && !t.includes(s)) return;
        const o = n[s];
        r.push(...o.accounts)
    }), r
}

function hp(n, t) {
    return n.includes(":") ? [n] : t.chains || []
}
const lp = "base10",
    cr = "base16",
    kc = "base64pad",
    fu = "utf8",
    fp = 0,
    tn = 1,
    $b = 0,
    jl = 1,
    Vc = 12,
    pu = 32;

function Lb() {
    const n = hu.generateKeyPair();
    return {
        privateKey: ur(n.secretKey, cr),
        publicKey: ur(n.publicKey, cr)
    }
}

function Gc() {
    const n = An.randomBytes(pu);
    return ur(n, cr)
}

function Mb(n, t) {
    const r = hu.sharedKey(mr(n, cr), mr(t, cr)),
        s = new wm(Ha.SHA256, r).expand(pu);
    return ur(s, cr)
}

function jb(n) {
    const t = Ha.hash(mr(n, cr));
    return ur(t, cr)
}

function Cn(n) {
    const t = Ha.hash(mr(n, fu));
    return ur(t, cr)
}

function zb(n) {
    return mr(`${n}`, lp)
}

function ls(n) {
    return Number(ur(n, lp))
}

function qb(n) {
    const t = zb(typeof n.type < "u" ? n.type : fp);
    if (ls(t) === tn && typeof n.senderPublicKey > "u") throw new Error("Missing sender public key for type 1 envelope");
    const r = typeof n.senderPublicKey < "u" ? mr(n.senderPublicKey, cr) : void 0,
        s = typeof n.iv < "u" ? mr(n.iv, cr) : An.randomBytes(Vc),
        o = new cu.ChaCha20Poly1305(mr(n.symKey, cr)).seal(s, mr(n.message, fu));
    return Bb({
        type: t,
        sealed: o,
        iv: s,
        senderPublicKey: r
    })
}

function Hb(n) {
    const t = new cu.ChaCha20Poly1305(mr(n.symKey, cr)),
        {
            sealed: r,
            iv: s
        } = Na(n.encoded),
        o = t.open(s, r);
    if (o === null) throw new Error("Failed to decrypt");
    return ur(o, fu)
}

function Bb(n) {
    if (ls(n.type) === tn) {
        if (typeof n.senderPublicKey > "u") throw new Error("Missing sender public key for type 1 envelope");
        return ur(Kc([n.type, n.senderPublicKey, n.iv, n.sealed]), kc)
    }
    return ur(Kc([n.type, n.iv, n.sealed]), kc)
}

function Na(n) {
    const t = mr(n, kc),
        r = t.slice($b, jl),
        s = jl;
    if (ls(r) === tn) {
        const f = s + pu,
            v = f + Vc,
            g = t.slice(s, f),
            b = t.slice(f, v),
            S = t.slice(v);
        return {
            type: r,
            sealed: S,
            iv: b,
            senderPublicKey: g
        }
    }
    const o = s + Vc,
        l = t.slice(s, o),
        d = t.slice(o);
    return {
        type: r,
        sealed: d,
        iv: l
    }
}

function Kb(n, t) {
    const r = Na(n);
    return pp({
        type: ls(r.type),
        senderPublicKey: typeof r.senderPublicKey < "u" ? ur(r.senderPublicKey, cr) : void 0,
        receiverPublicKey: t == null ? void 0 : t.receiverPublicKey
    })
}

function pp(n) {
    const t = (n == null ? void 0 : n.type) || fp;
    if (t === tn) {
        if (typeof(n == null ? void 0 : n.senderPublicKey) > "u") throw new Error("missing sender public key");
        if (typeof(n == null ? void 0 : n.receiverPublicKey) > "u") throw new Error("missing receiver public key")
    }
    return {
        type: t,
        senderPublicKey: n == null ? void 0 : n.senderPublicKey,
        receiverPublicKey: n == null ? void 0 : n.receiverPublicKey
    }
}

function zl(n) {
    return n.type === tn && typeof n.senderPublicKey == "string" && typeof n.receiverPublicKey == "string"
}
var kb = Object.defineProperty,
    ql = Object.getOwnPropertySymbols,
    Vb = Object.prototype.hasOwnProperty,
    Gb = Object.prototype.propertyIsEnumerable,
    Hl = (n, t, r) => t in n ? kb(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    Bl = (n, t) => {
        for (var r in t || (t = {})) Vb.call(t, r) && Hl(n, r, t[r]);
        if (ql)
            for (var r of ql(t)) Gb.call(t, r) && Hl(n, r, t[r]);
        return n
    };
const Wb = "ReactNative",
    Pi = {
        reactNative: "react-native",
        node: "node",
        browser: "browser",
        unknown: "unknown"
    },
    Yb = "js";

function du() {
    return typeof yc < "u" && typeof yc.versions < "u" && typeof yc.versions.node < "u"
}

function dp() {
    return !$_() && !!kf() && navigator.product === Wb
}

function gu() {
    return !du() && !!kf()
}

function vu() {
    return dp() ? Pi.reactNative : du() ? Pi.node : gu() ? Pi.browser : Pi.unknown
}

function Jb(n, t) {
    let r = os.parse(n);
    return r = Bl(Bl({}, r), t), n = os.stringify(r), n
}

function Xb() {
    return U_() || {
        name: "",
        description: "",
        url: "",
        icons: [""]
    }
}

function Zb() {
    if (vu() === Pi.reactNative && typeof _r < "u" && typeof(_r == null ? void 0 : _r.Platform) < "u") {
        const {
            OS: r,
            Version: s
        } = _r.Platform;
        return [r, s].join("-")
    }
    const n = L_();
    if (n === null) return "unknown";
    const t = n.os ? n.os.replace(" ", "").toLowerCase() : "unknown";
    return n.type === "browser" ? [t, n.name, n.version].join("-") : [t, n.version].join("-")
}

function Qb() {
    var n;
    const t = vu();
    return t === Pi.browser ? [t, ((n = M_()) == null ? void 0 : n.host) || "unknown"].join(":") : t
}

function ew(n, t, r) {
    const s = Zb(),
        o = Qb();
    return [
        [n, t].join("-"), [Yb, r].join("-"), s, o
    ].join("/")
}

function tw({
    protocol: n,
    version: t,
    relayUrl: r,
    sdkVersion: s,
    auth: o,
    projectId: l,
    useOnCloseEvent: d
}) {
    const f = r.split("?"),
        v = ew(n, t, s),
        g = {
            auth: o,
            ua: v,
            projectId: l,
            useOnCloseEvent: d || void 0
        },
        b = Jb(f[1] || "", g);
    return f[0] + "?" + b
}

function Qi(n, t) {
    return n.filter(r => t.includes(r)).length === n.length
}

function gp(n) {
    return Object.fromEntries(n.entries())
}

function vp(n) {
    return new Map(Object.entries(n))
}

function xn(n = ye.FIVE_MINUTES, t) {
    const r = ye.toMiliseconds(n || ye.FIVE_MINUTES);
    let s, o, l;
    return {
        resolve: d => {
            l && s && (clearTimeout(l), s(d))
        },
        reject: d => {
            l && o && (clearTimeout(l), o(d))
        },
        done: () => new Promise((d, f) => {
            l = setTimeout(() => {
                f(new Error(t))
            }, r), s = d, o = f
        })
    }
}

function Ta(n, t, r) {
    return new Promise(async (s, o) => {
        const l = setTimeout(() => o(new Error(r)), t);
        try {
            const d = await n;
            s(d)
        } catch (d) {
            o(d)
        }
        clearTimeout(l)
    })
}

function yp(n, t) {
    if (typeof t == "string" && t.startsWith(`${n}:`)) return t;
    if (n.toLowerCase() === "topic") {
        if (typeof t != "string") throw new Error('Value must be "string" for expirer target type: topic');
        return `topic:${t}`
    } else if (n.toLowerCase() === "id") {
        if (typeof t != "number") throw new Error('Value must be "number" for expirer target type: id');
        return `id:${t}`
    }
    throw new Error(`Unknown expirer target type: ${n}`)
}

function rw(n) {
    return yp("topic", n)
}

function iw(n) {
    return yp("id", n)
}

function _p(n) {
    const [t, r] = n.split(":"), s = {
        id: void 0,
        topic: void 0
    };
    if (t === "topic" && typeof r == "string") s.topic = r;
    else if (t === "id" && Number.isInteger(Number(r))) s.id = Number(r);
    else throw new Error(`Invalid target, expected id:number or topic:string, got ${t}:${r}`);
    return s
}

function kr(n, t) {
    return ye.fromMiliseconds((t || Date.now()) + ye.toMiliseconds(n))
}

function Ai(n) {
    return Date.now() >= ye.toMiliseconds(n)
}

function qt(n, t) {
    return `${n}${t?`:${t}`:""}`
}

function Dc(n = [], t = []) {
    return [...new Set([...n, ...t])]
}
async function nw({
    id: n,
    topic: t,
    wcDeepLink: r
}) {
    try {
        if (!r) return;
        const s = typeof r == "string" ? JSON.parse(r) : r;
        let o = s == null ? void 0 : s.href;
        if (typeof o != "string") return;
        o.endsWith("/") && (o = o.slice(0, -1));
        const l = `${o}/wc?requestId=${n}&sessionTopic=${t}`,
            d = vu();
        d === Pi.browser ? l.startsWith("https://") ? window.open(l, "_blank", "noreferrer noopener") : window.open(l, "_self", "noreferrer noopener") : d === Pi.reactNative && typeof(_r == null ? void 0 : _r.Linking) < "u" && await _r.Linking.openURL(l)
    } catch (s) {
        console.error(s)
    }
}
const sw = "irn";

function Wc(n) {
    return (n == null ? void 0 : n.relay) || {
        protocol: sw
    }
}

function Ia(n) {
    const t = Fb[n];
    if (typeof t > "u") throw new Error(`Relay Protocol not supported: ${n}`);
    return t
}
var aw = Object.defineProperty,
    Kl = Object.getOwnPropertySymbols,
    ow = Object.prototype.hasOwnProperty,
    cw = Object.prototype.propertyIsEnumerable,
    kl = (n, t, r) => t in n ? aw(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    uw = (n, t) => {
        for (var r in t || (t = {})) ow.call(t, r) && kl(n, r, t[r]);
        if (Kl)
            for (var r of Kl(t)) cw.call(t, r) && kl(n, r, t[r]);
        return n
    };

function hw(n, t = "-") {
    const r = {},
        s = "relay" + t;
    return Object.keys(n).forEach(o => {
        if (o.startsWith(s)) {
            const l = o.replace(s, ""),
                d = n[o];
            r[l] = d
        }
    }), r
}

function lw(n) {
    const t = n.indexOf(":"),
        r = n.indexOf("?") !== -1 ? n.indexOf("?") : void 0,
        s = n.substring(0, t),
        o = n.substring(t + 1, r).split("@"),
        l = typeof r < "u" ? n.substring(r) : "",
        d = os.parse(l);
    return {
        protocol: s,
        topic: fw(o[0]),
        version: parseInt(o[1], 10),
        symKey: d.symKey,
        relay: hw(d)
    }
}

function fw(n) {
    return n.startsWith("//") ? n.substring(2) : n
}

function pw(n, t = "-") {
    const r = "relay",
        s = {};
    return Object.keys(n).forEach(o => {
        const l = r + t + o;
        n[o] && (s[l] = n[o])
    }), s
}

function dw(n) {
    return `${n.protocol}:${n.topic}@${n.version}?` + os.stringify(uw({
        symKey: n.symKey
    }, pw(n.relay)))
}

function Pn(n) {
    const t = [];
    return n.forEach(r => {
        const [s, o] = r.split(":");
        t.push(`${s}:${o}`)
    }), t
}

function gw(n) {
    const t = [];
    return Object.values(n).forEach(r => {
        t.push(...Pn(r.accounts))
    }), t
}

function vw(n, t) {
    const r = [];
    return Object.values(n).forEach(s => {
        Pn(s.accounts).includes(t) && r.push(...s.methods)
    }), r
}

function yw(n, t) {
    const r = [];
    return Object.values(n).forEach(s => {
        Pn(s.accounts).includes(t) && r.push(...s.events)
    }), r
}

function _w(n, t) {
    const r = xa(n, t);
    if (r) throw new Error(r.message);
    const s = {};
    for (const [o, l] of Object.entries(n)) s[o] = {
        methods: l.methods,
        events: l.events,
        chains: l.accounts.map(d => `${d.split(":")[0]}:${d.split(":")[1]}`)
    };
    return s
}

function yu(n) {
    return n.includes(":")
}

function Sa(n) {
    return yu(n) ? n.split(":")[0] : n
}
const mw = {
        INVALID_METHOD: {
            message: "Invalid method.",
            code: 1001
        },
        INVALID_EVENT: {
            message: "Invalid event.",
            code: 1002
        },
        INVALID_UPDATE_REQUEST: {
            message: "Invalid update request.",
            code: 1003
        },
        INVALID_EXTEND_REQUEST: {
            message: "Invalid extend request.",
            code: 1004
        },
        INVALID_SESSION_SETTLE_REQUEST: {
            message: "Invalid session settle request.",
            code: 1005
        },
        UNAUTHORIZED_METHOD: {
            message: "Unauthorized method.",
            code: 3001
        },
        UNAUTHORIZED_EVENT: {
            message: "Unauthorized event.",
            code: 3002
        },
        UNAUTHORIZED_UPDATE_REQUEST: {
            message: "Unauthorized update request.",
            code: 3003
        },
        UNAUTHORIZED_EXTEND_REQUEST: {
            message: "Unauthorized extend request.",
            code: 3004
        },
        USER_REJECTED: {
            message: "User rejected.",
            code: 5e3
        },
        USER_REJECTED_CHAINS: {
            message: "User rejected chains.",
            code: 5001
        },
        USER_REJECTED_METHODS: {
            message: "User rejected methods.",
            code: 5002
        },
        USER_REJECTED_EVENTS: {
            message: "User rejected events.",
            code: 5003
        },
        UNSUPPORTED_CHAINS: {
            message: "Unsupported chains.",
            code: 5100
        },
        UNSUPPORTED_METHODS: {
            message: "Unsupported methods.",
            code: 5101
        },
        UNSUPPORTED_EVENTS: {
            message: "Unsupported events.",
            code: 5102
        },
        UNSUPPORTED_ACCOUNTS: {
            message: "Unsupported accounts.",
            code: 5103
        },
        UNSUPPORTED_NAMESPACE_KEY: {
            message: "Unsupported namespace key.",
            code: 5104
        },
        USER_DISCONNECTED: {
            message: "User disconnected.",
            code: 6e3
        },
        SESSION_SETTLEMENT_FAILED: {
            message: "Session settlement failed.",
            code: 7e3
        },
        WC_METHOD_UNSUPPORTED: {
            message: "Unsupported wc_ method.",
            code: 10001
        }
    },
    bw = {
        NOT_INITIALIZED: {
            message: "Not initialized.",
            code: 1
        },
        NO_MATCHING_KEY: {
            message: "No matching key.",
            code: 2
        },
        RESTORE_WILL_OVERRIDE: {
            message: "Restore will override.",
            code: 3
        },
        RESUBSCRIBED: {
            message: "Resubscribed.",
            code: 4
        },
        MISSING_OR_INVALID: {
            message: "Missing or invalid.",
            code: 5
        },
        EXPIRED: {
            message: "Expired.",
            code: 6
        },
        UNKNOWN_TYPE: {
            message: "Unknown type.",
            code: 7
        },
        MISMATCHED_TOPIC: {
            message: "Mismatched topic.",
            code: 8
        },
        NON_CONFORMING_NAMESPACES: {
            message: "Non conforming namespaces.",
            code: 9
        }
    };

function ue(n, t) {
    const {
        message: r,
        code: s
    } = bw[n];
    return {
        message: t ? `${r} ${t}` : r,
        code: s
    }
}

function Tt(n, t) {
    const {
        message: r,
        code: s
    } = mw[n];
    return {
        message: t ? `${r} ${t}` : r,
        code: s
    }
}

function ti(n, t) {
    return Array.isArray(n) ? typeof t < "u" && n.length ? n.every(t) : !0 : !1
}

function On(n) {
    return Object.getPrototypeOf(n) === Object.prototype && Object.keys(n).length
}

function or(n) {
    return typeof n > "u"
}

function Gt(n, t) {
    return t && or(n) ? !0 : typeof n == "string" && !!n.trim().length
}

function _u(n, t) {
    return t && or(n) ? !0 : typeof n == "number" && !isNaN(n)
}

function ww(n, t) {
    const {
        requiredNamespaces: r
    } = t, s = Object.keys(n.namespaces), o = Object.keys(r);
    let l = !0;
    return Qi(o, s) ? (s.forEach(d => {
        const {
            accounts: f,
            methods: v,
            events: g
        } = n.namespaces[d], b = Pn(f), S = r[d];
        (!Qi(hp(d, S), b) || !Qi(S.methods, v) || !Qi(S.events, g)) && (l = !1)
    }), l) : !1
}

function Ra(n) {
    return Gt(n, !1) && n.includes(":") ? n.split(":").length === 2 : !1
}

function Ew(n) {
    if (Gt(n, !1) && n.includes(":")) {
        const t = n.split(":");
        if (t.length === 3) {
            const r = t[0] + ":" + t[1];
            return !!t[2] && Ra(r)
        }
    }
    return !1
}

function Dw(n) {
    if (Gt(n, !1)) try {
        return typeof new URL(n) < "u"
    } catch {
        return !1
    }
    return !1
}

function Iw(n) {
    var t;
    return (t = n == null ? void 0 : n.proposer) == null ? void 0 : t.publicKey
}

function Sw(n) {
    return n == null ? void 0 : n.topic
}

function xw(n, t) {
    let r = null;
    return Gt(n == null ? void 0 : n.publicKey, !1) || (r = ue("MISSING_OR_INVALID", `${t} controller public key should be a string`)), r
}

function Vl(n) {
    let t = !0;
    return ti(n) ? n.length && (t = n.every(r => Gt(r, !1))) : t = !1, t
}

function Cw(n, t, r) {
    let s = null;
    return ti(t) && t.length ? t.forEach(o => {
        s || Ra(o) || (s = Tt("UNSUPPORTED_CHAINS", `${r}, chain ${o} should be a string and conform to "namespace:chainId" format`))
    }) : Ra(n) || (s = Tt("UNSUPPORTED_CHAINS", `${r}, chains must be defined as "namespace:chainId" e.g. "eip155:1": {...} in the namespace key OR as an array of CAIP-2 chainIds e.g. eip155: { chains: ["eip155:1", "eip155:5"] }`)), s
}

function Ow(n, t, r) {
    let s = null;
    return Object.entries(n).forEach(([o, l]) => {
        if (s) return;
        const d = Cw(o, hp(o, l), `${t} ${r}`);
        d && (s = d)
    }), s
}

function Aw(n, t) {
    let r = null;
    return ti(n) ? n.forEach(s => {
        r || Ew(s) || (r = Tt("UNSUPPORTED_ACCOUNTS", `${t}, account ${s} should be a string and conform to "namespace:chainId:address" format`))
    }) : r = Tt("UNSUPPORTED_ACCOUNTS", `${t}, accounts should be an array of strings conforming to "namespace:chainId:address" format`), r
}

function Pw(n, t) {
    let r = null;
    return Object.values(n).forEach(s => {
        if (r) return;
        const o = Aw(s == null ? void 0 : s.accounts, `${t} namespace`);
        o && (r = o)
    }), r
}

function Nw(n, t) {
    let r = null;
    return Vl(n == null ? void 0 : n.methods) ? Vl(n == null ? void 0 : n.events) || (r = Tt("UNSUPPORTED_EVENTS", `${t}, events should be an array of strings or empty array for no events`)) : r = Tt("UNSUPPORTED_METHODS", `${t}, methods should be an array of strings or empty array for no methods`), r
}

function mp(n, t) {
    let r = null;
    return Object.values(n).forEach(s => {
        if (r) return;
        const o = Nw(s, `${t}, namespace`);
        o && (r = o)
    }), r
}

function Tw(n, t, r) {
    let s = null;
    if (n && On(n)) {
        const o = mp(n, t);
        o && (s = o);
        const l = Ow(n, t, r);
        l && (s = l)
    } else s = ue("MISSING_OR_INVALID", `${t}, ${r} should be an object with data`);
    return s
}

function xa(n, t) {
    let r = null;
    if (n && On(n)) {
        const s = mp(n, t);
        s && (r = s);
        const o = Pw(n, t);
        o && (r = o)
    } else r = ue("MISSING_OR_INVALID", `${t}, namespaces should be an object with data`);
    return r
}

function bp(n) {
    return Gt(n.protocol, !0)
}

function Rw(n, t) {
    let r = !1;
    return t && !n ? r = !0 : n && ti(n) && n.length && n.forEach(s => {
        r = bp(s)
    }), r
}

function Fw(n) {
    return typeof n == "number"
}

function yr(n) {
    return typeof n < "u" && typeof n !== null
}

function Uw(n) {
    return !(!n || typeof n != "object" || !n.code || !_u(n.code, !1) || !n.message || !Gt(n.message, !1))
}

function $w(n) {
    return !(or(n) || !Gt(n.method, !1))
}

function Lw(n) {
    return !(or(n) || or(n.result) && or(n.error) || !_u(n.id, !1) || !Gt(n.jsonrpc, !1))
}

function Mw(n) {
    return !(or(n) || !Gt(n.name, !1))
}

function Gl(n, t) {
    return !(!Ra(t) || !gw(n).includes(t))
}

function jw(n, t, r) {
    return Gt(r, !1) ? vw(n, t).includes(r) : !1
}

function zw(n, t, r) {
    return Gt(r, !1) ? yw(n, t).includes(r) : !1
}

function Wl(n, t, r) {
    let s = null;
    const o = qw(n),
        l = Hw(t),
        d = Object.keys(o),
        f = Object.keys(l),
        v = Yl(Object.keys(n)),
        g = Yl(Object.keys(t)),
        b = v.filter(S => !g.includes(S));
    return b.length && (s = ue("NON_CONFORMING_NAMESPACES", `${r} namespaces keys don't satisfy requiredNamespaces.
      Required: ${b.toString()}
      Received: ${Object.keys(t).toString()}`)), Qi(d, f) || (s = ue("NON_CONFORMING_NAMESPACES", `${r} namespaces chains don't satisfy required namespaces.
      Required: ${d.toString()}
      Approved: ${f.toString()}`)), Object.keys(t).forEach(S => {
        if (!S.includes(":") || s) return;
        const O = Pn(t[S].accounts);
        O.includes(S) || (s = ue("NON_CONFORMING_NAMESPACES", `${r} namespaces accounts don't satisfy namespace accounts for ${S}
        Required: ${S}
        Approved: ${O.toString()}`))
    }), d.forEach(S => {
        s || (Qi(o[S].methods, l[S].methods) ? Qi(o[S].events, l[S].events) || (s = ue("NON_CONFORMING_NAMESPACES", `${r} namespaces events don't satisfy namespace events for ${S}`)) : s = ue("NON_CONFORMING_NAMESPACES", `${r} namespaces methods don't satisfy namespace methods for ${S}`))
    }), s
}

function qw(n) {
    const t = {};
    return Object.keys(n).forEach(r => {
        var s;
        r.includes(":") ? t[r] = n[r] : (s = n[r].chains) == null || s.forEach(o => {
            t[o] = {
                methods: n[r].methods,
                events: n[r].events
            }
        })
    }), t
}

function Yl(n) {
    return [...new Set(n.map(t => t.includes(":") ? t.split(":")[0] : t))]
}

function Hw(n) {
    const t = {};
    return Object.keys(n).forEach(r => {
        if (r.includes(":")) t[r] = n[r];
        else {
            const s = Pn(n[r].accounts);
            s == null || s.forEach(o => {
                t[o] = {
                    accounts: n[r].accounts.filter(l => l.includes(`${o}:`)),
                    methods: n[r].methods,
                    events: n[r].events
                }
            })
        }
    }), t
}

function Bw(n, t) {
    return _u(n, !1) && n <= t.max && n >= t.min
}
const Kw = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/,
    kw = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/,
    Vw = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;

function Gw(n, t) {
    if (n === "__proto__" || n === "constructor" && t && typeof t == "object" && "prototype" in t) {
        Ww(n);
        return
    }
    return t
}

function Ww(n) {
    console.warn(`[destr] Dropping "${n}" key to prevent prototype pollution.`)
}

function ma(n, t = {}) {
    if (typeof n != "string") return n;
    const r = n.trim();
    if (n[0] === '"' && n.at(-1) === '"' && !n.includes("\\")) return r.slice(1, -1);
    if (r.length <= 9) {
        const s = r.toLowerCase();
        if (s === "true") return !0;
        if (s === "false") return !1;
        if (s === "undefined") return;
        if (s === "null") return null;
        if (s === "nan") return Number.NaN;
        if (s === "infinity") return Number.POSITIVE_INFINITY;
        if (s === "-infinity") return Number.NEGATIVE_INFINITY
    }
    if (!Vw.test(n)) {
        if (t.strict) throw new SyntaxError("[destr] Invalid JSON");
        return n
    }
    try {
        if (Kw.test(n) || kw.test(n)) {
            if (t.strict) throw new Error("[destr] Possible prototype pollution");
            return JSON.parse(n, Gw)
        }
        return JSON.parse(n)
    } catch (s) {
        if (t.strict) throw s;
        return n
    }
}

function Yw(n) {
    return !n || typeof n.then != "function" ? Promise.resolve(n) : n
}

function Vt(n, ...t) {
    try {
        return Yw(n(...t))
    } catch (r) {
        return Promise.reject(r)
    }
}

function Jw(n) {
    const t = typeof n;
    return n === null || t !== "object" && t !== "function"
}

function Xw(n) {
    const t = Object.getPrototypeOf(n);
    return !t || t.isPrototypeOf(Object)
}

function Ca(n) {
    if (Jw(n)) return String(n);
    if (Xw(n) || Array.isArray(n)) return JSON.stringify(n);
    if (typeof n.toJSON == "function") return Ca(n.toJSON());
    throw new Error("[unstorage] Cannot stringify value!")
}

function wp() {
    if (typeof Buffer === void 0) throw new TypeError("[unstorage] Buffer is not supported!")
}
const Yc = "base64:";

function Zw(n) {
    if (typeof n == "string") return n;
    wp();
    const t = Buffer.from(n).toString("base64");
    return Yc + t
}

function Qw(n) {
    return typeof n != "string" || !n.startsWith(Yc) ? n : (wp(), Buffer.from(n.slice(Yc.length), "base64"))
}

function vr(n) {
    return n ? n.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") : ""
}

function eE(...n) {
    return vr(n.join(":"))
}

function ba(n) {
    return n = vr(n), n ? n + ":" : ""
}
const tE = "memory",
    rE = () => {
        const n = new Map;
        return {
            name: tE,
            options: {},
            hasItem(t) {
                return n.has(t)
            },
            getItem(t) {
                return n.get(t) ? ? null
            },
            getItemRaw(t) {
                return n.get(t) ? ? null
            },
            setItem(t, r) {
                n.set(t, r)
            },
            setItemRaw(t, r) {
                n.set(t, r)
            },
            removeItem(t) {
                n.delete(t)
            },
            getKeys() {
                return Array.from(n.keys())
            },
            clear() {
                n.clear()
            },
            dispose() {
                n.clear()
            }
        }
    };

function iE(n = {}) {
    const t = {
            mounts: {
                "": n.driver || rE()
            },
            mountpoints: [""],
            watching: !1,
            watchListeners: [],
            unwatch: {}
        },
        r = g => {
            for (const b of t.mountpoints)
                if (g.startsWith(b)) return {
                    base: b,
                    relativeKey: g.slice(b.length),
                    driver: t.mounts[b]
                };
            return {
                base: "",
                relativeKey: g,
                driver: t.mounts[""]
            }
        },
        s = (g, b) => t.mountpoints.filter(S => S.startsWith(g) || b && g.startsWith(S)).map(S => ({
            relativeBase: g.length > S.length ? g.slice(S.length) : void 0,
            mountpoint: S,
            driver: t.mounts[S]
        })),
        o = (g, b) => {
            if (t.watching) {
                b = vr(b);
                for (const S of t.watchListeners) S(g, b)
            }
        },
        l = async () => {
            if (!t.watching) {
                t.watching = !0;
                for (const g in t.mounts) t.unwatch[g] = await Jl(t.mounts[g], o, g)
            }
        },
        d = async () => {
            if (t.watching) {
                for (const g in t.unwatch) await t.unwatch[g]();
                t.unwatch = {}, t.watching = !1
            }
        },
        f = (g, b, S) => {
            const O = new Map,
                P = N => {
                    let H = O.get(N.base);
                    return H || (H = {
                        driver: N.driver,
                        base: N.base,
                        items: []
                    }, O.set(N.base, H)), H
                };
            for (const N of g) {
                const H = typeof N == "string",
                    G = vr(H ? N : N.key),
                    ie = H ? void 0 : N.value,
                    T = H || !N.options ? b : { ...b,
                        ...N.options
                    },
                    L = r(G);
                P(L).items.push({
                    key: G,
                    value: ie,
                    relativeKey: L.relativeKey,
                    options: T
                })
            }
            return Promise.all([...O.values()].map(N => S(N))).then(N => N.flat())
        },
        v = {
            hasItem(g, b = {}) {
                g = vr(g);
                const {
                    relativeKey: S,
                    driver: O
                } = r(g);
                return Vt(O.hasItem, S, b)
            },
            getItem(g, b = {}) {
                g = vr(g);
                const {
                    relativeKey: S,
                    driver: O
                } = r(g);
                return Vt(O.getItem, S, b).then(P => ma(P))
            },
            getItems(g, b) {
                return f(g, b, S => S.driver.getItems ? Vt(S.driver.getItems, S.items.map(O => ({
                    key: O.relativeKey,
                    options: O.options
                })), b).then(O => O.map(P => ({
                    key: eE(S.base, P.key),
                    value: ma(P.value)
                }))) : Promise.all(S.items.map(O => Vt(S.driver.getItem, O.relativeKey, O.options).then(P => ({
                    key: O.key,
                    value: ma(P)
                })))))
            },
            getItemRaw(g, b = {}) {
                g = vr(g);
                const {
                    relativeKey: S,
                    driver: O
                } = r(g);
                return O.getItemRaw ? Vt(O.getItemRaw, S, b) : Vt(O.getItem, S, b).then(P => Qw(P))
            },
            async setItem(g, b, S = {}) {
                if (b === void 0) return v.removeItem(g);
                g = vr(g);
                const {
                    relativeKey: O,
                    driver: P
                } = r(g);
                P.setItem && (await Vt(P.setItem, O, Ca(b), S), P.watch || o("update", g))
            },
            async setItems(g, b) {
                await f(g, b, async S => {
                    S.driver.setItems && await Vt(S.driver.setItems, S.items.map(O => ({
                        key: O.relativeKey,
                        value: Ca(O.value),
                        options: O.options
                    })), b), S.driver.setItem && await Promise.all(S.items.map(O => Vt(S.driver.setItem, O.relativeKey, Ca(O.value), O.options)))
                })
            },
            async setItemRaw(g, b, S = {}) {
                if (b === void 0) return v.removeItem(g, S);
                g = vr(g);
                const {
                    relativeKey: O,
                    driver: P
                } = r(g);
                if (P.setItemRaw) await Vt(P.setItemRaw, O, b, S);
                else if (P.setItem) await Vt(P.setItem, O, Zw(b), S);
                else return;
                P.watch || o("update", g)
            },
            async removeItem(g, b = {}) {
                typeof b == "boolean" && (b = {
                    removeMeta: b
                }), g = vr(g);
                const {
                    relativeKey: S,
                    driver: O
                } = r(g);
                O.removeItem && (await Vt(O.removeItem, S, b), (b.removeMeta || b.removeMata) && await Vt(O.removeItem, S + "$", b), O.watch || o("remove", g))
            },
            async getMeta(g, b = {}) {
                typeof b == "boolean" && (b = {
                    nativeOnly: b
                }), g = vr(g);
                const {
                    relativeKey: S,
                    driver: O
                } = r(g), P = Object.create(null);
                if (O.getMeta && Object.assign(P, await Vt(O.getMeta, S, b)), !b.nativeOnly) {
                    const N = await Vt(O.getItem, S + "$", b).then(H => ma(H));
                    N && typeof N == "object" && (typeof N.atime == "string" && (N.atime = new Date(N.atime)), typeof N.mtime == "string" && (N.mtime = new Date(N.mtime)), Object.assign(P, N))
                }
                return P
            },
            setMeta(g, b, S = {}) {
                return this.setItem(g + "$", b, S)
            },
            removeMeta(g, b = {}) {
                return this.removeItem(g + "$", b)
            },
            async getKeys(g, b = {}) {
                g = ba(g);
                const S = s(g, !0);
                let O = [];
                const P = [];
                for (const N of S) {
                    const G = (await Vt(N.driver.getKeys, N.relativeBase, b)).map(ie => N.mountpoint + vr(ie)).filter(ie => !O.some(T => ie.startsWith(T)));
                    P.push(...G), O = [N.mountpoint, ...O.filter(ie => !ie.startsWith(N.mountpoint))]
                }
                return g ? P.filter(N => N.startsWith(g) && !N.endsWith("$")) : P.filter(N => !N.endsWith("$"))
            },
            async clear(g, b = {}) {
                g = ba(g), await Promise.all(s(g, !1).map(async S => {
                    if (S.driver.clear) return Vt(S.driver.clear, S.relativeBase, b);
                    if (S.driver.removeItem) {
                        const O = await S.driver.getKeys(S.relativeBase || "", b);
                        return Promise.all(O.map(P => S.driver.removeItem(P, b)))
                    }
                }))
            },
            async dispose() {
                await Promise.all(Object.values(t.mounts).map(g => Xl(g)))
            },
            async watch(g) {
                return await l(), t.watchListeners.push(g), async () => {
                    t.watchListeners = t.watchListeners.filter(b => b !== g), t.watchListeners.length === 0 && await d()
                }
            },
            async unwatch() {
                t.watchListeners = [], await d()
            },
            mount(g, b) {
                if (g = ba(g), g && t.mounts[g]) throw new Error(`already mounted at ${g}`);
                return g && (t.mountpoints.push(g), t.mountpoints.sort((S, O) => O.length - S.length)), t.mounts[g] = b, t.watching && Promise.resolve(Jl(b, o, g)).then(S => {
                    t.unwatch[g] = S
                }).catch(console.error), v
            },
            async unmount(g, b = !0) {
                g = ba(g), !(!g || !t.mounts[g]) && (t.watching && g in t.unwatch && (t.unwatch[g](), delete t.unwatch[g]), b && await Xl(t.mounts[g]), t.mountpoints = t.mountpoints.filter(S => S !== g), delete t.mounts[g])
            },
            getMount(g = "") {
                g = vr(g) + ":";
                const b = r(g);
                return {
                    driver: b.driver,
                    base: b.base
                }
            },
            getMounts(g = "", b = {}) {
                return g = vr(g), s(g, b.parents).map(O => ({
                    driver: O.driver,
                    base: O.mountpoint
                }))
            }
        };
    return v
}

function Jl(n, t, r) {
    return n.watch ? n.watch((s, o) => t(s, r + o)) : () => {}
}
async function Xl(n) {
    typeof n.dispose == "function" && await Vt(n.dispose)
}

function rn(n) {
    return new Promise((t, r) => {
        n.oncomplete = n.onsuccess = () => t(n.result), n.onabort = n.onerror = () => r(n.error)
    })
}

function Ep(n, t) {
    const r = indexedDB.open(n);
    r.onupgradeneeded = () => r.result.createObjectStore(t);
    const s = rn(r);
    return (o, l) => s.then(d => l(d.transaction(t, o).objectStore(t)))
}
let Ic;

function fs() {
    return Ic || (Ic = Ep("keyval-store", "keyval")), Ic
}

function Zl(n, t = fs()) {
    return t("readonly", r => rn(r.get(n)))
}

function nE(n, t, r = fs()) {
    return r("readwrite", s => (s.put(t, n), rn(s.transaction)))
}

function sE(n, t = fs()) {
    return t("readwrite", r => (r.delete(n), rn(r.transaction)))
}

function aE(n = fs()) {
    return n("readwrite", t => (t.clear(), rn(t.transaction)))
}

function oE(n, t) {
    return n.openCursor().onsuccess = function() {
        this.result && (t(this.result), this.result.continue())
    }, rn(n.transaction)
}

function cE(n = fs()) {
    return n("readonly", t => {
        if (t.getAllKeys) return rn(t.getAllKeys());
        const r = [];
        return oE(t, s => r.push(s.key)).then(() => r)
    })
}
const uE = "idb-keyval";
var hE = (n = {}) => {
    const t = n.base && n.base.length > 0 ? `${n.base}:` : "",
        r = o => t + o;
    let s;
    return n.dbName && n.storeName && (s = Ep(n.dbName, n.storeName)), {
        name: uE,
        options: n,
        async hasItem(o) {
            return !(typeof await Zl(r(o), s) > "u")
        },
        async getItem(o) {
            return await Zl(r(o), s) ? ? null
        },
        setItem(o, l) {
            return nE(r(o), l, s)
        },
        removeItem(o) {
            return sE(r(o), s)
        },
        getKeys() {
            return cE(s)
        },
        clear() {
            return aE(s)
        }
    }
};
const lE = "WALLET_CONNECT_V2_INDEXED_DB",
    fE = "keyvaluestorage";
let pE = class {
    constructor() {
        this.indexedDb = iE({
            driver: hE({
                dbName: lE,
                storeName: fE
            })
        })
    }
    async getKeys() {
        return this.indexedDb.getKeys()
    }
    async getEntries() {
        return (await this.indexedDb.getItems(await this.indexedDb.getKeys())).map(t => [t.key, t.value])
    }
    async getItem(t) {
        const r = await this.indexedDb.getItem(t);
        if (r !== null) return r
    }
    async setItem(t, r) {
        await this.indexedDb.setItem(t, cs(r))
    }
    async removeItem(t) {
        await this.indexedDb.removeItem(t)
    }
};
var Sc = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof _r < "u" ? _r : typeof self < "u" ? self : {},
    Oa = {
        exports: {}
    };
(function() {
    let n;

    function t() {}
    n = t, n.prototype.getItem = function(r) {
        return this.hasOwnProperty(r) ? String(this[r]) : null
    }, n.prototype.setItem = function(r, s) {
        this[r] = String(s)
    }, n.prototype.removeItem = function(r) {
        delete this[r]
    }, n.prototype.clear = function() {
        const r = this;
        Object.keys(r).forEach(function(s) {
            r[s] = void 0, delete r[s]
        })
    }, n.prototype.key = function(r) {
        return r = r || 0, Object.keys(this)[r]
    }, n.prototype.__defineGetter__("length", function() {
        return Object.keys(this).length
    }), typeof Sc < "u" && Sc.localStorage ? Oa.exports = Sc.localStorage : typeof window < "u" && window.localStorage ? Oa.exports = window.localStorage : Oa.exports = new t
})();

function dE(n) {
    var t;
    return [n[0], La((t = n[1]) != null ? t : "")]
}
let gE = class {
    constructor() {
        this.localStorage = Oa.exports
    }
    async getKeys() {
        return Object.keys(this.localStorage)
    }
    async getEntries() {
        return Object.entries(this.localStorage).map(dE)
    }
    async getItem(t) {
        const r = this.localStorage.getItem(t);
        if (r !== null) return La(r)
    }
    async setItem(t, r) {
        this.localStorage.setItem(t, cs(r))
    }
    async removeItem(t) {
        this.localStorage.removeItem(t)
    }
};
const vE = "wc_storage_version",
    Ql = 1,
    yE = async (n, t, r) => {
        const s = vE,
            o = await t.getItem(s);
        if (o && o >= Ql) {
            r(t);
            return
        }
        const l = await n.getKeys();
        if (!l.length) {
            r(t);
            return
        }
        const d = [];
        for (; l.length;) {
            const f = l.shift();
            if (!f) continue;
            const v = f.toLowerCase();
            if (v.includes("wc@") || v.includes("walletconnect") || v.includes("wc_") || v.includes("wallet_connect")) {
                const g = await n.getItem(f);
                await t.setItem(f, g), d.push(f)
            }
        }
        await t.setItem(s, Ql), r(t), _E(n, d)
    },
    _E = async (n, t) => {
        t.length && t.forEach(async r => {
            await n.removeItem(r)
        })
    };
let mE = class {
    constructor() {
        this.initialized = !1, this.setInitialized = r => {
            this.storage = r, this.initialized = !0
        };
        const t = new gE;
        this.storage = t;
        try {
            const r = new pE;
            yE(t, r, this.setInitialized)
        } catch {
            this.initialized = !0
        }
    }
    async getKeys() {
        return await this.initialize(), this.storage.getKeys()
    }
    async getEntries() {
        return await this.initialize(), this.storage.getEntries()
    }
    async getItem(t) {
        return await this.initialize(), this.storage.getItem(t)
    }
    async setItem(t, r) {
        return await this.initialize(), this.storage.setItem(t, r)
    }
    async removeItem(t) {
        return await this.initialize(), this.storage.removeItem(t)
    }
    async initialize() {
        this.initialized || await new Promise(t => {
            const r = setInterval(() => {
                this.initialized && (clearInterval(r), t())
            }, 20)
        })
    }
};
var Nn = {},
    Qn = {},
    xc = {},
    es = {};
class nn {}
const bE = Object.freeze(Object.defineProperty({
        __proto__: null,
        IEvents: nn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    wE = A_(bE);
var ef;

function EE() {
    if (ef) return es;
    ef = 1, Object.defineProperty(es, "__esModule", {
        value: !0
    }), es.IHeartBeat = void 0;
    const n = wE;
    class t extends n.IEvents {
        constructor(s) {
            super()
        }
    }
    return es.IHeartBeat = t, es
}
var tf;

function Dp() {
    return tf || (tf = 1, function(n) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), vi.__exportStar(EE(), n)
    }(xc)), xc
}
var Cc = {},
    Xi = {},
    rf;

function DE() {
    if (rf) return Xi;
    rf = 1, Object.defineProperty(Xi, "__esModule", {
        value: !0
    }), Xi.HEARTBEAT_EVENTS = Xi.HEARTBEAT_INTERVAL = void 0;
    const n = ye;
    return Xi.HEARTBEAT_INTERVAL = n.FIVE_SECONDS, Xi.HEARTBEAT_EVENTS = {
        pulse: "heartbeat_pulse"
    }, Xi
}
var nf;

function Ip() {
    return nf || (nf = 1, function(n) {
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), vi.__exportStar(DE(), n)
    }(Cc)), Cc
}
var sf;

function IE() {
    if (sf) return Qn;
    sf = 1, Object.defineProperty(Qn, "__esModule", {
        value: !0
    }), Qn.HeartBeat = void 0;
    const n = vi,
        t = ri,
        r = ye,
        s = Dp(),
        o = Ip();
    class l extends s.IHeartBeat {
        constructor(f) {
            super(f), this.events = new t.EventEmitter, this.interval = o.HEARTBEAT_INTERVAL, this.interval = (f == null ? void 0 : f.interval) || o.HEARTBEAT_INTERVAL
        }
        static init(f) {
            return n.__awaiter(this, void 0, void 0, function*() {
                const v = new l(f);
                return yield v.init(), v
            })
        }
        init() {
            return n.__awaiter(this, void 0, void 0, function*() {
                yield this.initialize()
            })
        }
        stop() {
            clearInterval(this.intervalRef)
        }
        on(f, v) {
            this.events.on(f, v)
        }
        once(f, v) {
            this.events.once(f, v)
        }
        off(f, v) {
            this.events.off(f, v)
        }
        removeListener(f, v) {
            this.events.removeListener(f, v)
        }
        initialize() {
            return n.__awaiter(this, void 0, void 0, function*() {
                this.intervalRef = setInterval(() => this.pulse(), r.toMiliseconds(this.interval))
            })
        }
        pulse() {
            this.events.emit(o.HEARTBEAT_EVENTS.pulse)
        }
    }
    return Qn.HeartBeat = l, Qn
}(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    const t = vi;
    t.__exportStar(IE(), n), t.__exportStar(Dp(), n), t.__exportStar(Ip(), n)
})(Nn);
var Qe = {},
    Oc, af;

function SE() {
    if (af) return Oc;
    af = 1;

    function n(r) {
        try {
            return JSON.stringify(r)
        } catch {
            return '"[Circular]"'
        }
    }
    Oc = t;

    function t(r, s, o) {
        var l = o && o.stringify || n,
            d = 1;
        if (typeof r == "object" && r !== null) {
            var f = s.length + d;
            if (f === 1) return r;
            var v = new Array(f);
            v[0] = l(r);
            for (var g = 1; g < f; g++) v[g] = l(s[g]);
            return v.join(" ")
        }
        if (typeof r != "string") return r;
        var b = s.length;
        if (b === 0) return r;
        for (var S = "", O = 1 - d, P = -1, N = r && r.length || 0, H = 0; H < N;) {
            if (r.charCodeAt(H) === 37 && H + 1 < N) {
                switch (P = P > -1 ? P : 0, r.charCodeAt(H + 1)) {
                    case 100:
                    case 102:
                        if (O >= b || s[O] == null) break;
                        P < H && (S += r.slice(P, H)), S += Number(s[O]), P = H + 2, H++;
                        break;
                    case 105:
                        if (O >= b || s[O] == null) break;
                        P < H && (S += r.slice(P, H)), S += Math.floor(Number(s[O])), P = H + 2, H++;
                        break;
                    case 79:
                    case 111:
                    case 106:
                        if (O >= b || s[O] === void 0) break;
                        P < H && (S += r.slice(P, H));
                        var G = typeof s[O];
                        if (G === "string") {
                            S += "'" + s[O] + "'", P = H + 2, H++;
                            break
                        }
                        if (G === "function") {
                            S += s[O].name || "<anonymous>", P = H + 2, H++;
                            break
                        }
                        S += l(s[O]), P = H + 2, H++;
                        break;
                    case 115:
                        if (O >= b) break;
                        P < H && (S += r.slice(P, H)), S += String(s[O]), P = H + 2, H++;
                        break;
                    case 37:
                        P < H && (S += r.slice(P, H)), S += "%", P = H + 2, H++, O--;
                        break
                }++O
            }++H
        }
        return P === -1 ? r : (P < N && (S += r.slice(P)), S)
    }
    return Oc
}
var Ac, of ;

function xE() {
    if ( of ) return Ac; of = 1;
    const n = SE();
    Ac = o;
    const t = C().console || {},
        r = {
            mapHttpRequest: N,
            mapHttpResponse: N,
            wrapRequestSerializer: H,
            wrapResponseSerializer: H,
            wrapErrorSerializer: H,
            req: N,
            res: N,
            err: O
        };

    function s(w, c) {
        return Array.isArray(w) ? w.filter(function(K) {
            return K !== "!stdSerializers.err"
        }) : w === !0 ? Object.keys(c) : !1
    }

    function o(w) {
        w = w || {}, w.browser = w.browser || {};
        const c = w.browser.transmit;
        if (c && typeof c.send != "function") throw Error("pino: transmit option must have a send function");
        const m = w.browser.write || t;
        w.browser.write && (w.browser.asObject = !0);
        const K = w.serializers || {},
            V = s(w.browser.serialize, K);
        let ae = w.browser.serialize;
        Array.isArray(w.browser.serialize) && w.browser.serialize.indexOf("!stdSerializers.err") > -1 && (ae = !1);
        const ce = ["error", "fatal", "warn", "info", "debug", "trace"];
        typeof m == "function" && (m.error = m.fatal = m.warn = m.info = m.debug = m.trace = m), w.enabled === !1 && (w.level = "silent");
        const ge = w.level || "info",
            F = Object.create(m);
        F.log || (F.log = G), Object.defineProperty(F, "levelVal", {
            get: le
        }), Object.defineProperty(F, "level", {
            get: te,
            set: W
        });
        const q = {
            transmit: c,
            serialize: V,
            asObject: w.browser.asObject,
            levels: ce,
            timestamp: P(w)
        };
        F.levels = o.levels, F.level = ge, F.setMaxListeners = F.getMaxListeners = F.emit = F.addListener = F.on = F.prependListener = F.once = F.prependOnceListener = F.removeListener = F.removeAllListeners = F.listeners = F.listenerCount = F.eventNames = F.write = F.flush = G, F.serializers = K, F._serialize = V, F._stdErrSerialize = ae, F.child = ee, c && (F._logEvent = S());

        function le() {
            return this.level === "silent" ? 1 / 0 : this.levels.values[this.level]
        }

        function te() {
            return this._level
        }

        function W(Y) {
            if (Y !== "silent" && !this.levels.values[Y]) throw Error("unknown level " + Y);
            this._level = Y, l(q, F, "error", "log"), l(q, F, "fatal", "error"), l(q, F, "warn", "error"), l(q, F, "info", "log"), l(q, F, "debug", "log"), l(q, F, "trace", "log")
        }

        function ee(Y, re) {
            if (!Y) throw new Error("missing bindings for child Pino");
            re = re || {}, V && Y.serializers && (re.serializers = Y.serializers);
            const xe = re.serializers;
            if (V && xe) {
                var ne = Object.assign({}, K, xe),
                    be = w.browser.serialize === !0 ? Object.keys(ne) : V;
                delete Y.serializers, v([Y], be, ne, this._stdErrSerialize)
            }

            function he(_e) {
                this._childLevel = (_e._childLevel | 0) + 1, this.error = g(_e, Y, "error"), this.fatal = g(_e, Y, "fatal"), this.warn = g(_e, Y, "warn"), this.info = g(_e, Y, "info"), this.debug = g(_e, Y, "debug"), this.trace = g(_e, Y, "trace"), ne && (this.serializers = ne, this._serialize = be), c && (this._logEvent = S([].concat(_e._logEvent.bindings, Y)))
            }
            return he.prototype = this, new he(this)
        }
        return F
    }
    o.levels = {
        values: {
            fatal: 60,
            error: 50,
            warn: 40,
            info: 30,
            debug: 20,
            trace: 10
        },
        labels: {
            10: "trace",
            20: "debug",
            30: "info",
            40: "warn",
            50: "error",
            60: "fatal"
        }
    }, o.stdSerializers = r, o.stdTimeFunctions = Object.assign({}, {
        nullTime: ie,
        epochTime: T,
        unixTime: L,
        isoTime: I
    });

    function l(w, c, m, K) {
        const V = Object.getPrototypeOf(c);
        c[m] = c.levelVal > c.levels.values[m] ? G : V[m] ? V[m] : t[m] || t[K] || G, d(w, c, m)
    }

    function d(w, c, m) {
        !w.transmit && c[m] === G || (c[m] = function(K) {
            return function() {
                const ae = w.timestamp(),
                    ce = new Array(arguments.length),
                    ge = Object.getPrototypeOf && Object.getPrototypeOf(this) === t ? t : this;
                for (var F = 0; F < ce.length; F++) ce[F] = arguments[F];
                if (w.serialize && !w.asObject && v(ce, this._serialize, this.serializers, this._stdErrSerialize), w.asObject ? K.call(ge, f(this, m, ce, ae)) : K.apply(ge, ce), w.transmit) {
                    const q = w.transmit.level || c.level,
                        le = o.levels.values[q],
                        te = o.levels.values[m];
                    if (te < le) return;
                    b(this, {
                        ts: ae,
                        methodLevel: m,
                        methodValue: te,
                        transmitLevel: q,
                        transmitValue: o.levels.values[w.transmit.level || c.level],
                        send: w.transmit.send,
                        val: c.levelVal
                    }, ce)
                }
            }
        }(c[m]))
    }

    function f(w, c, m, K) {
        w._serialize && v(m, w._serialize, w.serializers, w._stdErrSerialize);
        const V = m.slice();
        let ae = V[0];
        const ce = {};
        K && (ce.time = K), ce.level = o.levels.values[c];
        let ge = (w._childLevel | 0) + 1;
        if (ge < 1 && (ge = 1), ae !== null && typeof ae == "object") {
            for (; ge-- && typeof V[0] == "object";) Object.assign(ce, V.shift());
            ae = V.length ? n(V.shift(), V) : void 0
        } else typeof ae == "string" && (ae = n(V.shift(), V));
        return ae !== void 0 && (ce.msg = ae), ce
    }

    function v(w, c, m, K) {
        for (const V in w)
            if (K && w[V] instanceof Error) w[V] = o.stdSerializers.err(w[V]);
            else if (typeof w[V] == "object" && !Array.isArray(w[V]))
            for (const ae in w[V]) c && c.indexOf(ae) > -1 && ae in m && (w[V][ae] = m[ae](w[V][ae]))
    }

    function g(w, c, m) {
        return function() {
            const K = new Array(1 + arguments.length);
            K[0] = c;
            for (var V = 1; V < K.length; V++) K[V] = arguments[V - 1];
            return w[m].apply(this, K)
        }
    }

    function b(w, c, m) {
        const K = c.send,
            V = c.ts,
            ae = c.methodLevel,
            ce = c.methodValue,
            ge = c.val,
            F = w._logEvent.bindings;
        v(m, w._serialize || Object.keys(w.serializers), w.serializers, w._stdErrSerialize === void 0 ? !0 : w._stdErrSerialize), w._logEvent.ts = V, w._logEvent.messages = m.filter(function(q) {
            return F.indexOf(q) === -1
        }), w._logEvent.level.label = ae, w._logEvent.level.value = ce, K(ae, w._logEvent, ge), w._logEvent = S(F)
    }

    function S(w) {
        return {
            ts: 0,
            messages: [],
            bindings: w || [],
            level: {
                label: "",
                value: 0
            }
        }
    }

    function O(w) {
        const c = {
            type: w.constructor.name,
            msg: w.message,
            stack: w.stack
        };
        for (const m in w) c[m] === void 0 && (c[m] = w[m]);
        return c
    }

    function P(w) {
        return typeof w.timestamp == "function" ? w.timestamp : w.timestamp === !1 ? ie : T
    }

    function N() {
        return {}
    }

    function H(w) {
        return w
    }

    function G() {}

    function ie() {
        return !1
    }

    function T() {
        return Date.now()
    }

    function L() {
        return Math.round(Date.now() / 1e3)
    }

    function I() {
        return new Date(Date.now()).toISOString()
    }

    function C() {
        function w(c) {
            return typeof c < "u" && c
        }
        try {
            return typeof globalThis < "u" || Object.defineProperty(Object.prototype, "globalThis", {
                get: function() {
                    return delete Object.prototype.globalThis, this.globalThis = this
                },
                configurable: !0
            }), globalThis
        } catch {
            return w(self) || w(window) || w(this) || {}
        }
    }
    return Ac
}
var Zi = {},
    cf;

function Sp() {
    return cf || (cf = 1, Object.defineProperty(Zi, "__esModule", {
        value: !0
    }), Zi.PINO_CUSTOM_CONTEXT_KEY = Zi.PINO_LOGGER_DEFAULTS = void 0, Zi.PINO_LOGGER_DEFAULTS = {
        level: "info"
    }, Zi.PINO_CUSTOM_CONTEXT_KEY = "custom_context"), Zi
}
var ar = {},
    uf;

function CE() {
    if (uf) return ar;
    uf = 1, Object.defineProperty(ar, "__esModule", {
        value: !0
    }), ar.generateChildLogger = ar.formatChildLoggerContext = ar.getLoggerContext = ar.setBrowserLoggerContext = ar.getBrowserLoggerContext = ar.getDefaultLoggerOptions = void 0;
    const n = Sp();

    function t(f) {
        return Object.assign(Object.assign({}, f), {
            level: (f == null ? void 0 : f.level) || n.PINO_LOGGER_DEFAULTS.level
        })
    }
    ar.getDefaultLoggerOptions = t;

    function r(f, v = n.PINO_CUSTOM_CONTEXT_KEY) {
        return f[v] || ""
    }
    ar.getBrowserLoggerContext = r;

    function s(f, v, g = n.PINO_CUSTOM_CONTEXT_KEY) {
        return f[g] = v, f
    }
    ar.setBrowserLoggerContext = s;

    function o(f, v = n.PINO_CUSTOM_CONTEXT_KEY) {
        let g = "";
        return typeof f.bindings > "u" ? g = r(f, v) : g = f.bindings().context || "", g
    }
    ar.getLoggerContext = o;

    function l(f, v, g = n.PINO_CUSTOM_CONTEXT_KEY) {
        const b = o(f, g);
        return b.trim() ? `${b}/${v}` : v
    }
    ar.formatChildLoggerContext = l;

    function d(f, v, g = n.PINO_CUSTOM_CONTEXT_KEY) {
        const b = l(f, v, g),
            S = f.child({
                context: b
            });
        return s(S, b, g)
    }
    return ar.generateChildLogger = d, ar
}(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.pino = void 0;
    const t = vi,
        r = t.__importDefault(xE());
    Object.defineProperty(n, "pino", {
        enumerable: !0,
        get: function() {
            return r.default
        }
    }), t.__exportStar(Sp(), n), t.__exportStar(CE(), n)
})(Qe);
class OE extends nn {
    constructor(t) {
        super(), this.opts = t, this.protocol = "wc", this.version = 2
    }
}
class AE extends nn {
    constructor(t, r) {
        super(), this.core = t, this.logger = r, this.records = new Map
    }
}
class PE {
    constructor(t, r) {
        this.logger = t, this.core = r
    }
}
let NE = class extends nn {
        constructor(t, r) {
            super(), this.relayer = t, this.logger = r
        }
    },
    TE = class extends nn {
        constructor(t) {
            super()
        }
    },
    RE = class {
        constructor(t, r, s, o) {
            this.core = t, this.logger = r, this.name = s
        }
    };
class FE extends nn {
    constructor(t, r) {
        super(), this.relayer = t, this.logger = r
    }
}
let UE = class extends nn {
        constructor(t, r) {
            super(), this.core = t, this.logger = r
        }
    },
    $E = class {
        constructor(t, r) {
            this.projectId = t, this.logger = r
        }
    },
    LE = class {
        constructor(t) {
            this.opts = t, this.protocol = "wc", this.version = 2
        }
    },
    ME = class {
        constructor(t) {
            this.client = t
        }
    };
var mu = {},
    xp = {};
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    });
    var t = $e,
        r = xr;
    n.DIGEST_LENGTH = 64, n.BLOCK_SIZE = 128;
    var s = function() {
        function f() {
            this.digestLength = n.DIGEST_LENGTH, this.blockSize = n.BLOCK_SIZE, this._stateHi = new Int32Array(8), this._stateLo = new Int32Array(8), this._tempHi = new Int32Array(16), this._tempLo = new Int32Array(16), this._buffer = new Uint8Array(256), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this.reset()
        }
        return f.prototype._initState = function() {
            this._stateHi[0] = 1779033703, this._stateHi[1] = 3144134277, this._stateHi[2] = 1013904242, this._stateHi[3] = 2773480762, this._stateHi[4] = 1359893119, this._stateHi[5] = 2600822924, this._stateHi[6] = 528734635, this._stateHi[7] = 1541459225, this._stateLo[0] = 4089235720, this._stateLo[1] = 2227873595, this._stateLo[2] = 4271175723, this._stateLo[3] = 1595750129, this._stateLo[4] = 2917565137, this._stateLo[5] = 725511199, this._stateLo[6] = 4215389547, this._stateLo[7] = 327033209
        }, f.prototype.reset = function() {
            return this._initState(), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this
        }, f.prototype.clean = function() {
            r.wipe(this._buffer), r.wipe(this._tempHi), r.wipe(this._tempLo), this.reset()
        }, f.prototype.update = function(v, g) {
            if (g === void 0 && (g = v.length), this._finished) throw new Error("SHA512: can't update because hash was finished.");
            var b = 0;
            if (this._bytesHashed += g, this._bufferLength > 0) {
                for (; this._bufferLength < n.BLOCK_SIZE && g > 0;) this._buffer[this._bufferLength++] = v[b++], g--;
                this._bufferLength === this.blockSize && (l(this._tempHi, this._tempLo, this._stateHi, this._stateLo, this._buffer, 0, this.blockSize), this._bufferLength = 0)
            }
            for (g >= this.blockSize && (b = l(this._tempHi, this._tempLo, this._stateHi, this._stateLo, v, b, g), g %= this.blockSize); g > 0;) this._buffer[this._bufferLength++] = v[b++], g--;
            return this
        }, f.prototype.finish = function(v) {
            if (!this._finished) {
                var g = this._bytesHashed,
                    b = this._bufferLength,
                    S = g / 536870912 | 0,
                    O = g << 3,
                    P = g % 128 < 112 ? 128 : 256;
                this._buffer[b] = 128;
                for (var N = b + 1; N < P - 8; N++) this._buffer[N] = 0;
                t.writeUint32BE(S, this._buffer, P - 8), t.writeUint32BE(O, this._buffer, P - 4), l(this._tempHi, this._tempLo, this._stateHi, this._stateLo, this._buffer, 0, P), this._finished = !0
            }
            for (var N = 0; N < this.digestLength / 8; N++) t.writeUint32BE(this._stateHi[N], v, N * 8), t.writeUint32BE(this._stateLo[N], v, N * 8 + 4);
            return this
        }, f.prototype.digest = function() {
            var v = new Uint8Array(this.digestLength);
            return this.finish(v), v
        }, f.prototype.saveState = function() {
            if (this._finished) throw new Error("SHA256: cannot save finished state");
            return {
                stateHi: new Int32Array(this._stateHi),
                stateLo: new Int32Array(this._stateLo),
                buffer: this._bufferLength > 0 ? new Uint8Array(this._buffer) : void 0,
                bufferLength: this._bufferLength,
                bytesHashed: this._bytesHashed
            }
        }, f.prototype.restoreState = function(v) {
            return this._stateHi.set(v.stateHi), this._stateLo.set(v.stateLo), this._bufferLength = v.bufferLength, v.buffer && this._buffer.set(v.buffer), this._bytesHashed = v.bytesHashed, this._finished = !1, this
        }, f.prototype.cleanSavedState = function(v) {
            r.wipe(v.stateHi), r.wipe(v.stateLo), v.buffer && r.wipe(v.buffer), v.bufferLength = 0, v.bytesHashed = 0
        }, f
    }();
    n.SHA512 = s;
    var o = new Int32Array([1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591]);

    function l(f, v, g, b, S, O, P) {
        for (var N = g[0], H = g[1], G = g[2], ie = g[3], T = g[4], L = g[5], I = g[6], C = g[7], w = b[0], c = b[1], m = b[2], K = b[3], V = b[4], ae = b[5], ce = b[6], ge = b[7], F, q, le, te, W, ee, Y, re; P >= 128;) {
            for (var xe = 0; xe < 16; xe++) {
                var ne = 8 * xe + O;
                f[xe] = t.readUint32BE(S, ne), v[xe] = t.readUint32BE(S, ne + 4)
            }
            for (var xe = 0; xe < 80; xe++) {
                var be = N,
                    he = H,
                    _e = G,
                    z = ie,
                    j = T,
                    R = L,
                    h = I,
                    x = C,
                    se = w,
                    fe = c,
                    Ie = m,
                    He = K,
                    ke = V,
                    Le = ae,
                    pt = ce,
                    dt = ge;
                if (F = C, q = ge, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = (T >>> 14 | V << 32 - 14) ^ (T >>> 18 | V << 32 - 18) ^ (V >>> 41 - 32 | T << 32 - (41 - 32)), q = (V >>> 14 | T << 32 - 14) ^ (V >>> 18 | T << 32 - 18) ^ (T >>> 41 - 32 | V << 32 - (41 - 32)), W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, F = T & L ^ ~T & I, q = V & ae ^ ~V & ce, W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, F = o[xe * 2], q = o[xe * 2 + 1], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, F = f[xe % 16], q = v[xe % 16], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, le = Y & 65535 | re << 16, te = W & 65535 | ee << 16, F = le, q = te, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = (N >>> 28 | w << 32 - 28) ^ (w >>> 34 - 32 | N << 32 - (34 - 32)) ^ (w >>> 39 - 32 | N << 32 - (39 - 32)), q = (w >>> 28 | N << 32 - 28) ^ (N >>> 34 - 32 | w << 32 - (34 - 32)) ^ (N >>> 39 - 32 | w << 32 - (39 - 32)), W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, F = N & H ^ N & G ^ H & G, q = w & c ^ w & m ^ c & m, W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, x = Y & 65535 | re << 16, dt = W & 65535 | ee << 16, F = z, q = He, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = le, q = te, W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, z = Y & 65535 | re << 16, He = W & 65535 | ee << 16, H = be, G = he, ie = _e, T = z, L = j, I = R, C = h, N = x, c = se, m = fe, K = Ie, V = He, ae = ke, ce = Le, ge = pt, w = dt, xe % 16 === 15)
                    for (var ne = 0; ne < 16; ne++) F = f[ne], q = v[ne], W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = f[(ne + 9) % 16], q = v[(ne + 9) % 16], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, le = f[(ne + 1) % 16], te = v[(ne + 1) % 16], F = (le >>> 1 | te << 32 - 1) ^ (le >>> 8 | te << 32 - 8) ^ le >>> 7, q = (te >>> 1 | le << 32 - 1) ^ (te >>> 8 | le << 32 - 8) ^ (te >>> 7 | le << 32 - 7), W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, le = f[(ne + 14) % 16], te = v[(ne + 14) % 16], F = (le >>> 19 | te << 32 - 19) ^ (te >>> 61 - 32 | le << 32 - (61 - 32)) ^ le >>> 6, q = (te >>> 19 | le << 32 - 19) ^ (le >>> 61 - 32 | te << 32 - (61 - 32)) ^ (te >>> 6 | le << 32 - 6), W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, f[ne] = Y & 65535 | re << 16, v[ne] = W & 65535 | ee << 16
            }
            F = N, q = w, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[0], q = b[0], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[0] = N = Y & 65535 | re << 16, b[0] = w = W & 65535 | ee << 16, F = H, q = c, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[1], q = b[1], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[1] = H = Y & 65535 | re << 16, b[1] = c = W & 65535 | ee << 16, F = G, q = m, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[2], q = b[2], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[2] = G = Y & 65535 | re << 16, b[2] = m = W & 65535 | ee << 16, F = ie, q = K, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[3], q = b[3], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[3] = ie = Y & 65535 | re << 16, b[3] = K = W & 65535 | ee << 16, F = T, q = V, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[4], q = b[4], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[4] = T = Y & 65535 | re << 16, b[4] = V = W & 65535 | ee << 16, F = L, q = ae, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[5], q = b[5], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[5] = L = Y & 65535 | re << 16, b[5] = ae = W & 65535 | ee << 16, F = I, q = ce, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[6], q = b[6], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[6] = I = Y & 65535 | re << 16, b[6] = ce = W & 65535 | ee << 16, F = C, q = ge, W = q & 65535, ee = q >>> 16, Y = F & 65535, re = F >>> 16, F = g[7], q = b[7], W += q & 65535, ee += q >>> 16, Y += F & 65535, re += F >>> 16, ee += W >>> 16, Y += ee >>> 16, re += Y >>> 16, g[7] = C = Y & 65535 | re << 16, b[7] = ge = W & 65535 | ee << 16, O += 128, P -= 128
        }
        return O
    }

    function d(f) {
        var v = new s;
        v.update(f);
        var g = v.digest();
        return v.clean(), g
    }
    n.hash = d
})(xp);
(function(n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.convertSecretKeyToX25519 = n.convertPublicKeyToX25519 = n.verify = n.sign = n.extractPublicKeyFromSecretKey = n.generateKeyPair = n.generateKeyPairFromSeed = n.SEED_LENGTH = n.SECRET_KEY_LENGTH = n.PUBLIC_KEY_LENGTH = n.SIGNATURE_LENGTH = void 0;
    const t = An,
        r = xp,
        s = xr;
    n.SIGNATURE_LENGTH = 64, n.PUBLIC_KEY_LENGTH = 32, n.SECRET_KEY_LENGTH = 64, n.SEED_LENGTH = 32;

    function o(z) {
        const j = new Float64Array(16);
        if (z)
            for (let R = 0; R < z.length; R++) j[R] = z[R];
        return j
    }
    const l = new Uint8Array(32);
    l[0] = 9;
    const d = o(),
        f = o([1]),
        v = o([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]),
        g = o([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]),
        b = o([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]),
        S = o([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]),
        O = o([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);

    function P(z, j) {
        for (let R = 0; R < 16; R++) z[R] = j[R] | 0
    }

    function N(z) {
        let j = 1;
        for (let R = 0; R < 16; R++) {
            let h = z[R] + j + 65535;
            j = Math.floor(h / 65536), z[R] = h - j * 65536
        }
        z[0] += j - 1 + 37 * (j - 1)
    }

    function H(z, j, R) {
        const h = ~(R - 1);
        for (let x = 0; x < 16; x++) {
            const se = h & (z[x] ^ j[x]);
            z[x] ^= se, j[x] ^= se
        }
    }

    function G(z, j) {
        const R = o(),
            h = o();
        for (let x = 0; x < 16; x++) h[x] = j[x];
        N(h), N(h), N(h);
        for (let x = 0; x < 2; x++) {
            R[0] = h[0] - 65517;
            for (let fe = 1; fe < 15; fe++) R[fe] = h[fe] - 65535 - (R[fe - 1] >> 16 & 1), R[fe - 1] &= 65535;
            R[15] = h[15] - 32767 - (R[14] >> 16 & 1);
            const se = R[15] >> 16 & 1;
            R[14] &= 65535, H(h, R, 1 - se)
        }
        for (let x = 0; x < 16; x++) z[2 * x] = h[x] & 255, z[2 * x + 1] = h[x] >> 8
    }

    function ie(z, j) {
        let R = 0;
        for (let h = 0; h < 32; h++) R |= z[h] ^ j[h];
        return (1 & R - 1 >>> 8) - 1
    }

    function T(z, j) {
        const R = new Uint8Array(32),
            h = new Uint8Array(32);
        return G(R, z), G(h, j), ie(R, h)
    }

    function L(z) {
        const j = new Uint8Array(32);
        return G(j, z), j[0] & 1
    }

    function I(z, j) {
        for (let R = 0; R < 16; R++) z[R] = j[2 * R] + (j[2 * R + 1] << 8);
        z[15] &= 32767
    }

    function C(z, j, R) {
        for (let h = 0; h < 16; h++) z[h] = j[h] + R[h]
    }

    function w(z, j, R) {
        for (let h = 0; h < 16; h++) z[h] = j[h] - R[h]
    }

    function c(z, j, R) {
        let h, x, se = 0,
            fe = 0,
            Ie = 0,
            He = 0,
            ke = 0,
            Le = 0,
            pt = 0,
            dt = 0,
            je = 0,
            Se = 0,
            Re = 0,
            Fe = 0,
            ze = 0,
            Oe = 0,
            Ue = 0,
            De = 0,
            Ae = 0,
            Be = 0,
            Ce = 0,
            Ve = 0,
            We = 0,
            et = 0,
            tt = 0,
            Je = 0,
            er = 0,
            hr = 0,
            Vr = 0,
            tr = 0,
            ii = 0,
            yi = 0,
            Ui = 0,
            bt = R[0],
            gt = R[1],
            wt = R[2],
            Et = R[3],
            _t = R[4],
            vt = R[5],
            Ft = R[6],
            Ut = R[7],
            Dt = R[8],
            $t = R[9],
            It = R[10],
            Ot = R[11],
            St = R[12],
            ht = R[13],
            Lt = R[14],
            Mt = R[15];
        h = j[0], se += h * bt, fe += h * gt, Ie += h * wt, He += h * Et, ke += h * _t, Le += h * vt, pt += h * Ft, dt += h * Ut, je += h * Dt, Se += h * $t, Re += h * It, Fe += h * Ot, ze += h * St, Oe += h * ht, Ue += h * Lt, De += h * Mt, h = j[1], fe += h * bt, Ie += h * gt, He += h * wt, ke += h * Et, Le += h * _t, pt += h * vt, dt += h * Ft, je += h * Ut, Se += h * Dt, Re += h * $t, Fe += h * It, ze += h * Ot, Oe += h * St, Ue += h * ht, De += h * Lt, Ae += h * Mt, h = j[2], Ie += h * bt, He += h * gt, ke += h * wt, Le += h * Et, pt += h * _t, dt += h * vt, je += h * Ft, Se += h * Ut, Re += h * Dt, Fe += h * $t, ze += h * It, Oe += h * Ot, Ue += h * St, De += h * ht, Ae += h * Lt, Be += h * Mt, h = j[3], He += h * bt, ke += h * gt, Le += h * wt, pt += h * Et, dt += h * _t, je += h * vt, Se += h * Ft, Re += h * Ut, Fe += h * Dt, ze += h * $t, Oe += h * It, Ue += h * Ot, De += h * St, Ae += h * ht, Be += h * Lt, Ce += h * Mt, h = j[4], ke += h * bt, Le += h * gt, pt += h * wt, dt += h * Et, je += h * _t, Se += h * vt, Re += h * Ft, Fe += h * Ut, ze += h * Dt, Oe += h * $t, Ue += h * It, De += h * Ot, Ae += h * St, Be += h * ht, Ce += h * Lt, Ve += h * Mt, h = j[5], Le += h * bt, pt += h * gt, dt += h * wt, je += h * Et, Se += h * _t, Re += h * vt, Fe += h * Ft, ze += h * Ut, Oe += h * Dt, Ue += h * $t, De += h * It, Ae += h * Ot, Be += h * St, Ce += h * ht, Ve += h * Lt, We += h * Mt, h = j[6], pt += h * bt, dt += h * gt, je += h * wt, Se += h * Et, Re += h * _t, Fe += h * vt, ze += h * Ft, Oe += h * Ut, Ue += h * Dt, De += h * $t, Ae += h * It, Be += h * Ot, Ce += h * St, Ve += h * ht, We += h * Lt, et += h * Mt, h = j[7], dt += h * bt, je += h * gt, Se += h * wt, Re += h * Et, Fe += h * _t, ze += h * vt, Oe += h * Ft, Ue += h * Ut, De += h * Dt, Ae += h * $t, Be += h * It, Ce += h * Ot, Ve += h * St, We += h * ht, et += h * Lt, tt += h * Mt, h = j[8], je += h * bt, Se += h * gt, Re += h * wt, Fe += h * Et, ze += h * _t, Oe += h * vt, Ue += h * Ft, De += h * Ut, Ae += h * Dt, Be += h * $t, Ce += h * It, Ve += h * Ot, We += h * St, et += h * ht, tt += h * Lt, Je += h * Mt, h = j[9], Se += h * bt, Re += h * gt, Fe += h * wt, ze += h * Et, Oe += h * _t, Ue += h * vt, De += h * Ft, Ae += h * Ut, Be += h * Dt, Ce += h * $t, Ve += h * It, We += h * Ot, et += h * St, tt += h * ht, Je += h * Lt, er += h * Mt, h = j[10], Re += h * bt, Fe += h * gt, ze += h * wt, Oe += h * Et, Ue += h * _t, De += h * vt, Ae += h * Ft, Be += h * Ut, Ce += h * Dt, Ve += h * $t, We += h * It, et += h * Ot, tt += h * St, Je += h * ht, er += h * Lt, hr += h * Mt, h = j[11], Fe += h * bt, ze += h * gt, Oe += h * wt, Ue += h * Et, De += h * _t, Ae += h * vt, Be += h * Ft, Ce += h * Ut, Ve += h * Dt, We += h * $t, et += h * It, tt += h * Ot, Je += h * St, er += h * ht, hr += h * Lt, Vr += h * Mt, h = j[12], ze += h * bt, Oe += h * gt, Ue += h * wt, De += h * Et, Ae += h * _t, Be += h * vt, Ce += h * Ft, Ve += h * Ut, We += h * Dt, et += h * $t, tt += h * It, Je += h * Ot, er += h * St, hr += h * ht, Vr += h * Lt, tr += h * Mt, h = j[13], Oe += h * bt, Ue += h * gt, De += h * wt, Ae += h * Et, Be += h * _t, Ce += h * vt, Ve += h * Ft, We += h * Ut, et += h * Dt, tt += h * $t, Je += h * It, er += h * Ot, hr += h * St, Vr += h * ht, tr += h * Lt, ii += h * Mt, h = j[14], Ue += h * bt, De += h * gt, Ae += h * wt, Be += h * Et, Ce += h * _t, Ve += h * vt, We += h * Ft, et += h * Ut, tt += h * Dt, Je += h * $t, er += h * It, hr += h * Ot, Vr += h * St, tr += h * ht, ii += h * Lt, yi += h * Mt, h = j[15], De += h * bt, Ae += h * gt, Be += h * wt, Ce += h * Et, Ve += h * _t, We += h * vt, et += h * Ft, tt += h * Ut, Je += h * Dt, er += h * $t, hr += h * It, Vr += h * Ot, tr += h * St, ii += h * ht, yi += h * Lt, Ui += h * Mt, se += 38 * Ae, fe += 38 * Be, Ie += 38 * Ce, He += 38 * Ve, ke += 38 * We, Le += 38 * et, pt += 38 * tt, dt += 38 * Je, je += 38 * er, Se += 38 * hr, Re += 38 * Vr, Fe += 38 * tr, ze += 38 * ii, Oe += 38 * yi, Ue += 38 * Ui, x = 1, h = se + x + 65535, x = Math.floor(h / 65536), se = h - x * 65536, h = fe + x + 65535, x = Math.floor(h / 65536), fe = h - x * 65536, h = Ie + x + 65535, x = Math.floor(h / 65536), Ie = h - x * 65536, h = He + x + 65535, x = Math.floor(h / 65536), He = h - x * 65536, h = ke + x + 65535, x = Math.floor(h / 65536), ke = h - x * 65536, h = Le + x + 65535, x = Math.floor(h / 65536), Le = h - x * 65536, h = pt + x + 65535, x = Math.floor(h / 65536), pt = h - x * 65536, h = dt + x + 65535, x = Math.floor(h / 65536), dt = h - x * 65536, h = je + x + 65535, x = Math.floor(h / 65536), je = h - x * 65536, h = Se + x + 65535, x = Math.floor(h / 65536), Se = h - x * 65536, h = Re + x + 65535, x = Math.floor(h / 65536), Re = h - x * 65536, h = Fe + x + 65535, x = Math.floor(h / 65536), Fe = h - x * 65536, h = ze + x + 65535, x = Math.floor(h / 65536), ze = h - x * 65536, h = Oe + x + 65535, x = Math.floor(h / 65536), Oe = h - x * 65536, h = Ue + x + 65535, x = Math.floor(h / 65536), Ue = h - x * 65536, h = De + x + 65535, x = Math.floor(h / 65536), De = h - x * 65536, se += x - 1 + 37 * (x - 1), x = 1, h = se + x + 65535, x = Math.floor(h / 65536), se = h - x * 65536, h = fe + x + 65535, x = Math.floor(h / 65536), fe = h - x * 65536, h = Ie + x + 65535, x = Math.floor(h / 65536), Ie = h - x * 65536, h = He + x + 65535, x = Math.floor(h / 65536), He = h - x * 65536, h = ke + x + 65535, x = Math.floor(h / 65536), ke = h - x * 65536, h = Le + x + 65535, x = Math.floor(h / 65536), Le = h - x * 65536, h = pt + x + 65535, x = Math.floor(h / 65536), pt = h - x * 65536, h = dt + x + 65535, x = Math.floor(h / 65536), dt = h - x * 65536, h = je + x + 65535, x = Math.floor(h / 65536), je = h - x * 65536, h = Se + x + 65535, x = Math.floor(h / 65536), Se = h - x * 65536, h = Re + x + 65535, x = Math.floor(h / 65536), Re = h - x * 65536, h = Fe + x + 65535, x = Math.floor(h / 65536), Fe = h - x * 65536, h = ze + x + 65535, x = Math.floor(h / 65536), ze = h - x * 65536, h = Oe + x + 65535, x = Math.floor(h / 65536), Oe = h - x * 65536, h = Ue + x + 65535, x = Math.floor(h / 65536), Ue = h - x * 65536, h = De + x + 65535, x = Math.floor(h / 65536), De = h - x * 65536, se += x - 1 + 37 * (x - 1), z[0] = se, z[1] = fe, z[2] = Ie, z[3] = He, z[4] = ke, z[5] = Le, z[6] = pt, z[7] = dt, z[8] = je, z[9] = Se, z[10] = Re, z[11] = Fe, z[12] = ze, z[13] = Oe, z[14] = Ue, z[15] = De
    }

    function m(z, j) {
        c(z, j, j)
    }

    function K(z, j) {
        const R = o();
        let h;
        for (h = 0; h < 16; h++) R[h] = j[h];
        for (h = 253; h >= 0; h--) m(R, R), h !== 2 && h !== 4 && c(R, R, j);
        for (h = 0; h < 16; h++) z[h] = R[h]
    }

    function V(z, j) {
        const R = o();
        let h;
        for (h = 0; h < 16; h++) R[h] = j[h];
        for (h = 250; h >= 0; h--) m(R, R), h !== 1 && c(R, R, j);
        for (h = 0; h < 16; h++) z[h] = R[h]
    }

    function ae(z, j) {
        const R = o(),
            h = o(),
            x = o(),
            se = o(),
            fe = o(),
            Ie = o(),
            He = o(),
            ke = o(),
            Le = o();
        w(R, z[1], z[0]), w(Le, j[1], j[0]), c(R, R, Le), C(h, z[0], z[1]), C(Le, j[0], j[1]), c(h, h, Le), c(x, z[3], j[3]), c(x, x, g), c(se, z[2], j[2]), C(se, se, se), w(fe, h, R), w(Ie, se, x), C(He, se, x), C(ke, h, R), c(z[0], fe, Ie), c(z[1], ke, He), c(z[2], He, Ie), c(z[3], fe, ke)
    }

    function ce(z, j, R) {
        for (let h = 0; h < 4; h++) H(z[h], j[h], R)
    }

    function ge(z, j) {
        const R = o(),
            h = o(),
            x = o();
        K(x, j[2]), c(R, j[0], x), c(h, j[1], x), G(z, h), z[31] ^= L(R) << 7
    }

    function F(z, j, R) {
        P(z[0], d), P(z[1], f), P(z[2], f), P(z[3], d);
        for (let h = 255; h >= 0; --h) {
            const x = R[h / 8 | 0] >> (h & 7) & 1;
            ce(z, j, x), ae(j, z), ae(z, z), ce(z, j, x)
        }
    }

    function q(z, j) {
        const R = [o(), o(), o(), o()];
        P(R[0], b), P(R[1], S), P(R[2], f), c(R[3], b, S), F(z, R, j)
    }

    function le(z) {
        if (z.length !== n.SEED_LENGTH) throw new Error(`ed25519: seed must be ${n.SEED_LENGTH} bytes`);
        const j = (0, r.hash)(z);
        j[0] &= 248, j[31] &= 127, j[31] |= 64;
        const R = new Uint8Array(32),
            h = [o(), o(), o(), o()];
        q(h, j), ge(R, h);
        const x = new Uint8Array(64);
        return x.set(z), x.set(R, 32), {
            publicKey: R,
            secretKey: x
        }
    }
    n.generateKeyPairFromSeed = le;

    function te(z) {
        const j = (0, t.randomBytes)(32, z),
            R = le(j);
        return (0, s.wipe)(j), R
    }
    n.generateKeyPair = te;

    function W(z) {
        if (z.length !== n.SECRET_KEY_LENGTH) throw new Error(`ed25519: secret key must be ${n.SECRET_KEY_LENGTH} bytes`);
        return new Uint8Array(z.subarray(32))
    }
    n.extractPublicKeyFromSecretKey = W;
    const ee = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);

    function Y(z, j) {
        let R, h, x, se;
        for (h = 63; h >= 32; --h) {
            for (R = 0, x = h - 32, se = h - 12; x < se; ++x) j[x] += R - 16 * j[h] * ee[x - (h - 32)], R = Math.floor((j[x] + 128) / 256), j[x] -= R * 256;
            j[x] += R, j[h] = 0
        }
        for (R = 0, x = 0; x < 32; x++) j[x] += R - (j[31] >> 4) * ee[x], R = j[x] >> 8, j[x] &= 255;
        for (x = 0; x < 32; x++) j[x] -= R * ee[x];
        for (h = 0; h < 32; h++) j[h + 1] += j[h] >> 8, z[h] = j[h] & 255
    }

    function re(z) {
        const j = new Float64Array(64);
        for (let R = 0; R < 64; R++) j[R] = z[R];
        for (let R = 0; R < 64; R++) z[R] = 0;
        Y(z, j)
    }

    function xe(z, j) {
        const R = new Float64Array(64),
            h = [o(), o(), o(), o()],
            x = (0, r.hash)(z.subarray(0, 32));
        x[0] &= 248, x[31] &= 127, x[31] |= 64;
        const se = new Uint8Array(64);
        se.set(x.subarray(32), 32);
        const fe = new r.SHA512;
        fe.update(se.subarray(32)), fe.update(j);
        const Ie = fe.digest();
        fe.clean(), re(Ie), q(h, Ie), ge(se, h), fe.reset(), fe.update(se.subarray(0, 32)), fe.update(z.subarray(32)), fe.update(j);
        const He = fe.digest();
        re(He);
        for (let ke = 0; ke < 32; ke++) R[ke] = Ie[ke];
        for (let ke = 0; ke < 32; ke++)
            for (let Le = 0; Le < 32; Le++) R[ke + Le] += He[ke] * x[Le];
        return Y(se.subarray(32), R), se
    }
    n.sign = xe;

    function ne(z, j) {
        const R = o(),
            h = o(),
            x = o(),
            se = o(),
            fe = o(),
            Ie = o(),
            He = o();
        return P(z[2], f), I(z[1], j), m(x, z[1]), c(se, x, v), w(x, x, z[2]), C(se, z[2], se), m(fe, se), m(Ie, fe), c(He, Ie, fe), c(R, He, x), c(R, R, se), V(R, R), c(R, R, x), c(R, R, se), c(R, R, se), c(z[0], R, se), m(h, z[0]), c(h, h, se), T(h, x) && c(z[0], z[0], O), m(h, z[0]), c(h, h, se), T(h, x) ? -1 : (L(z[0]) === j[31] >> 7 && w(z[0], d, z[0]), c(z[3], z[0], z[1]), 0)
    }

    function be(z, j, R) {
        const h = new Uint8Array(32),
            x = [o(), o(), o(), o()],
            se = [o(), o(), o(), o()];
        if (R.length !== n.SIGNATURE_LENGTH) throw new Error(`ed25519: signature must be ${n.SIGNATURE_LENGTH} bytes`);
        if (ne(se, z)) return !1;
        const fe = new r.SHA512;
        fe.update(R.subarray(0, 32)), fe.update(z), fe.update(j);
        const Ie = fe.digest();
        return re(Ie), F(x, se, Ie), q(se, R.subarray(32)), ae(x, se), ge(h, x), !ie(R, h)
    }
    n.verify = be;

    function he(z) {
        let j = [o(), o(), o(), o()];
        if (ne(j, z)) throw new Error("Ed25519: invalid public key");
        let R = o(),
            h = o(),
            x = j[1];
        C(R, f, x), w(h, f, x), K(h, h), c(R, R, h);
        let se = new Uint8Array(32);
        return G(se, R), se
    }
    n.convertPublicKeyToX25519 = he;

    function _e(z) {
        const j = (0, r.hash)(z.subarray(0, 32));
        j[0] &= 248, j[31] &= 127, j[31] |= 64;
        const R = new Uint8Array(j.subarray(0, 32));
        return (0, s.wipe)(j), R
    }
    n.convertSecretKeyToX25519 = _e
})(mu);
const jE = "EdDSA",
    zE = "JWT",
    Cp = ".",
    Op = "base64url",
    qE = "utf8",
    HE = "utf8",
    BE = ":",
    KE = "did",
    kE = "key",
    hf = "base58btc",
    VE = "z",
    GE = "K36",
    WE = 32;

function Fa(n) {
    return ur(mr(cs(n), qE), Op)
}

function Ap(n) {
    const t = mr(GE, hf),
        r = VE + ur(Kc([t, n]), hf);
    return [KE, kE, r].join(BE)
}

function YE(n) {
    return ur(n, Op)
}

function JE(n) {
    return mr([Fa(n.header), Fa(n.payload)].join(Cp), HE)
}

function XE(n) {
    return [Fa(n.header), Fa(n.payload), YE(n.signature)].join(Cp)
}

function lf(n = An.randomBytes(WE)) {
    return mu.generateKeyPairFromSeed(n)
}
async function ZE(n, t, r, s, o = ye.fromMiliseconds(Date.now())) {
    const l = {
            alg: jE,
            typ: zE
        },
        d = Ap(s.publicKey),
        f = o + r,
        v = {
            iss: d,
            sub: n,
            aud: t,
            iat: o,
            exp: f
        },
        g = JE({
            header: l,
            payload: v
        }),
        b = mu.sign(s.secretKey, g);
    return XE({
        header: l,
        payload: v,
        signature: b
    })
}
const QE = () => typeof _r < "u" && typeof _r.WebSocket < "u" ? _r.WebSocket : typeof window < "u" && typeof window.WebSocket < "u" ? window.WebSocket : require("ws"),
    e3 = () => typeof window < "u",
    ff = n => n.split("?")[0],
    pf = 10,
    t3 = QE();
class r3 {
    constructor(t) {
        if (this.url = t, this.events = new ri.EventEmitter, this.registering = !1, !Il(t)) throw new Error(`Provided URL is not compatible with WebSocket connection: ${t}`);
        this.url = t
    }
    get connected() {
        return typeof this.socket < "u"
    }
    get connecting() {
        return this.registering
    }
    on(t, r) {
        this.events.on(t, r)
    }
    once(t, r) {
        this.events.once(t, r)
    }
    off(t, r) {
        this.events.off(t, r)
    }
    removeListener(t, r) {
        this.events.removeListener(t, r)
    }
    async open(t = this.url) {
        await this.register(t)
    }
    async close() {
        return new Promise((t, r) => {
            if (typeof this.socket > "u") {
                r(new Error("Connection already closed"));
                return
            }
            this.socket.onclose = s => {
                this.onClose(s), t()
            }, this.socket.close()
        })
    }
    async send(t, r) {
        typeof this.socket > "u" && (this.socket = await this.register());
        try {
            this.socket.send(cs(t))
        } catch (s) {
            this.onError(t.id, s)
        }
    }
    register(t = this.url) {
        if (!Il(t)) throw new Error(`Provided URL is not compatible with WebSocket connection: ${t}`);
        if (this.registering) {
            const r = this.events.getMaxListeners();
            return (this.events.listenerCount("register_error") >= r || this.events.listenerCount("open") >= r) && this.events.setMaxListeners(r + 1), new Promise((s, o) => {
                this.events.once("register_error", l => {
                    this.resetMaxListeners(), o(l)
                }), this.events.once("open", () => {
                    if (this.resetMaxListeners(), typeof this.socket > "u") return o(new Error("WebSocket connection is missing or invalid"));
                    s(this.socket)
                })
            })
        }
        return this.url = t, this.registering = !0, new Promise((r, s) => {
            const o = j_.isReactNative() ? void 0 : {
                    rejectUnauthorized: !z_(t)
                },
                l = new t3(t, [], o);
            e3() ? l.onerror = d => {
                const f = d;
                s(this.emitError(f.error))
            } : l.on("error", d => {
                s(this.emitError(d))
            }), l.onopen = () => {
                this.onOpen(l), r(l)
            }
        })
    }
    onOpen(t) {
        t.onmessage = r => this.onPayload(r), t.onclose = r => this.onClose(r), this.socket = t, this.registering = !1, this.events.emit("open")
    }
    onClose(t) {
        this.socket = void 0, this.registering = !1, this.events.emit("close", t)
    }
    onPayload(t) {
        if (typeof t.data > "u") return;
        const r = typeof t.data == "string" ? La(t.data) : t.data;
        this.events.emit("payload", r)
    }
    onError(t, r) {
        const s = this.parseError(r),
            o = s.message || s.toString(),
            l = iu(t, o);
        this.events.emit("payload", l)
    }
    parseError(t, r = this.url) {
        return q_(t, ff(r), "WS")
    }
    resetMaxListeners() {
        this.events.getMaxListeners() > pf && this.events.setMaxListeners(pf)
    }
    emitError(t) {
        const r = this.parseError(new Error((t == null ? void 0 : t.message) || `WebSocket connection failed for host: ${ff(this.url)}`));
        return this.events.emit("register_error", r), r
    }
}
var Ua = {
    exports: {}
};
Ua.exports;
(function(n, t) {
    var r = 200,
        s = "__lodash_hash_undefined__",
        o = 1,
        l = 2,
        d = 9007199254740991,
        f = "[object Arguments]",
        v = "[object Array]",
        g = "[object AsyncFunction]",
        b = "[object Boolean]",
        S = "[object Date]",
        O = "[object Error]",
        P = "[object Function]",
        N = "[object GeneratorFunction]",
        H = "[object Map]",
        G = "[object Number]",
        ie = "[object Null]",
        T = "[object Object]",
        L = "[object Promise]",
        I = "[object Proxy]",
        C = "[object RegExp]",
        w = "[object Set]",
        c = "[object String]",
        m = "[object Symbol]",
        K = "[object Undefined]",
        V = "[object WeakMap]",
        ae = "[object ArrayBuffer]",
        ce = "[object DataView]",
        ge = "[object Float32Array]",
        F = "[object Float64Array]",
        q = "[object Int8Array]",
        le = "[object Int16Array]",
        te = "[object Int32Array]",
        W = "[object Uint8Array]",
        ee = "[object Uint8ClampedArray]",
        Y = "[object Uint16Array]",
        re = "[object Uint32Array]",
        xe = /[\\^$.*+?()[\]{}|]/g,
        ne = /^\[object .+?Constructor\]$/,
        be = /^(?:0|[1-9]\d*)$/,
        he = {};
    he[ge] = he[F] = he[q] = he[le] = he[te] = he[W] = he[ee] = he[Y] = he[re] = !0, he[f] = he[v] = he[ae] = he[b] = he[ce] = he[S] = he[O] = he[P] = he[H] = he[G] = he[T] = he[C] = he[w] = he[c] = he[V] = !1;
    var _e = typeof _a == "object" && _a && _a.Object === Object && _a,
        z = typeof self == "object" && self && self.Object === Object && self,
        j = _e || z || Function("return this")(),
        R = t && !t.nodeType && t,
        h = R && !0 && n && !n.nodeType && n,
        x = h && h.exports === R,
        se = x && _e.process,
        fe = function() {
            try {
                return se && se.binding && se.binding("util")
            } catch {}
        }(),
        Ie = fe && fe.isTypedArray;

    function He(E, U) {
        for (var Z = -1, pe = E == null ? 0 : E.length, ot = 0, Ne = []; ++Z < pe;) {
            var lt = E[Z];
            U(lt, Z, E) && (Ne[ot++] = lt)
        }
        return Ne
    }

    function ke(E, U) {
        for (var Z = -1, pe = U.length, ot = E.length; ++Z < pe;) E[ot + Z] = U[Z];
        return E
    }

    function Le(E, U) {
        for (var Z = -1, pe = E == null ? 0 : E.length; ++Z < pe;)
            if (U(E[Z], Z, E)) return !0;
        return !1
    }

    function pt(E, U) {
        for (var Z = -1, pe = Array(E); ++Z < E;) pe[Z] = U(Z);
        return pe
    }

    function dt(E) {
        return function(U) {
            return E(U)
        }
    }

    function je(E, U) {
        return E.has(U)
    }

    function Se(E, U) {
        return E == null ? void 0 : E[U]
    }

    function Re(E) {
        var U = -1,
            Z = Array(E.size);
        return E.forEach(function(pe, ot) {
            Z[++U] = [ot, pe]
        }), Z
    }

    function Fe(E, U) {
        return function(Z) {
            return E(U(Z))
        }
    }

    function ze(E) {
        var U = -1,
            Z = Array(E.size);
        return E.forEach(function(pe) {
            Z[++U] = pe
        }), Z
    }
    var Oe = Array.prototype,
        Ue = Function.prototype,
        De = Object.prototype,
        Ae = j["__core-js_shared__"],
        Be = Ue.toString,
        Ce = De.hasOwnProperty,
        Ve = function() {
            var E = /[^.]+$/.exec(Ae && Ae.keys && Ae.keys.IE_PROTO || "");
            return E ? "Symbol(src)_1." + E : ""
        }(),
        We = De.toString,
        et = RegExp("^" + Be.call(Ce).replace(xe, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
        tt = x ? j.Buffer : void 0,
        Je = j.Symbol,
        er = j.Uint8Array,
        hr = De.propertyIsEnumerable,
        Vr = Oe.splice,
        tr = Je ? Je.toStringTag : void 0,
        ii = Object.getOwnPropertySymbols,
        yi = tt ? tt.isBuffer : void 0,
        Ui = Fe(Object.keys, Object),
        bt = br(j, "DataView"),
        gt = br(j, "Map"),
        wt = br(j, "Promise"),
        Et = br(j, "Set"),
        _t = br(j, "WeakMap"),
        vt = br(Object, "create"),
        Ft = si(bt),
        Ut = si(gt),
        Dt = si(wt),
        $t = si(Et),
        It = si(_t),
        Ot = Je ? Je.prototype : void 0,
        St = Ot ? Ot.valueOf : void 0;

    function ht(E) {
        var U = -1,
            Z = E == null ? 0 : E.length;
        for (this.clear(); ++U < Z;) {
            var pe = E[U];
            this.set(pe[0], pe[1])
        }
    }

    function Lt() {
        this.__data__ = vt ? vt(null) : {}, this.size = 0
    }

    function Mt(E) {
        var U = this.has(E) && delete this.__data__[E];
        return this.size -= U ? 1 : 0, U
    }

    function Va(E) {
        var U = this.__data__;
        if (vt) {
            var Z = U[E];
            return Z === s ? void 0 : Z
        }
        return Ce.call(U, E) ? U[E] : void 0
    }

    function Ga(E) {
        var U = this.__data__;
        return vt ? U[E] !== void 0 : Ce.call(U, E)
    }

    function Wa(E, U) {
        var Z = this.__data__;
        return this.size += this.has(E) ? 0 : 1, Z[E] = vt && U === void 0 ? s : U, this
    }
    ht.prototype.clear = Lt, ht.prototype.delete = Mt, ht.prototype.get = Va, ht.prototype.has = Ga, ht.prototype.set = Wa;

    function Cr(E) {
        var U = -1,
            Z = E == null ? 0 : E.length;
        for (this.clear(); ++U < Z;) {
            var pe = E[U];
            this.set(pe[0], pe[1])
        }
    }

    function Ya() {
        this.__data__ = [], this.size = 0
    }

    function Ja(E) {
        var U = this.__data__,
            Z = $i(U, E);
        if (Z < 0) return !1;
        var pe = U.length - 1;
        return Z == pe ? U.pop() : Vr.call(U, Z, 1), --this.size, !0
    }

    function Xa(E) {
        var U = this.__data__,
            Z = $i(U, E);
        return Z < 0 ? void 0 : U[Z][1]
    }

    function Za(E) {
        return $i(this.__data__, E) > -1
    }

    function Qa(E, U) {
        var Z = this.__data__,
            pe = $i(Z, E);
        return pe < 0 ? (++this.size, Z.push([E, U])) : Z[pe][1] = U, this
    }
    Cr.prototype.clear = Ya, Cr.prototype.delete = Ja, Cr.prototype.get = Xa, Cr.prototype.has = Za, Cr.prototype.set = Qa;

    function ni(E) {
        var U = -1,
            Z = E == null ? 0 : E.length;
        for (this.clear(); ++U < Z;) {
            var pe = E[U];
            this.set(pe[0], pe[1])
        }
    }

    function sn() {
        this.size = 0, this.__data__ = {
            hash: new ht,
            map: new(gt || Cr),
            string: new ht
        }
    }

    function eo(E) {
        var U = _i(this, E).delete(E);
        return this.size -= U ? 1 : 0, U
    }

    function an(E) {
        return _i(this, E).get(E)
    }

    function to(E) {
        return _i(this, E).has(E)
    }

    function ro(E, U) {
        var Z = _i(this, E),
            pe = Z.size;
        return Z.set(E, U), this.size += Z.size == pe ? 0 : 1, this
    }
    ni.prototype.clear = sn, ni.prototype.delete = eo, ni.prototype.get = an, ni.prototype.has = to, ni.prototype.set = ro;

    function on(E) {
        var U = -1,
            Z = E == null ? 0 : E.length;
        for (this.__data__ = new ni; ++U < Z;) this.add(E[U])
    }

    function ds(E) {
        return this.__data__.set(E, s), this
    }

    function gs(E) {
        return this.__data__.has(E)
    }
    on.prototype.add = on.prototype.push = ds, on.prototype.has = gs;

    function jr(E) {
        var U = this.__data__ = new Cr(E);
        this.size = U.size
    }

    function io() {
        this.__data__ = new Cr, this.size = 0
    }

    function no(E) {
        var U = this.__data__,
            Z = U.delete(E);
        return this.size = U.size, Z
    }

    function so(E) {
        return this.__data__.get(E)
    }

    function ao(E) {
        return this.__data__.has(E)
    }

    function vs(E, U) {
        var Z = this.__data__;
        if (Z instanceof Cr) {
            var pe = Z.__data__;
            if (!gt || pe.length < r - 1) return pe.push([E, U]), this.size = ++Z.size, this;
            Z = this.__data__ = new ni(pe)
        }
        return Z.set(E, U), this.size = Z.size, this
    }
    jr.prototype.clear = io, jr.prototype.delete = no, jr.prototype.get = so, jr.prototype.has = ao, jr.prototype.set = vs;

    function ys(E, U) {
        var Z = hn(E),
            pe = !Z && As(E),
            ot = !Z && !pe && Fn(E),
            Ne = !Z && !pe && !ot && Ts(E),
            lt = Z || pe || ot || Ne,
            jt = lt ? pt(E.length, String) : [],
            Xe = jt.length;
        for (var ct in E)(U || Ce.call(E, ct)) && !(lt && (ct == "length" || ot && (ct == "offset" || ct == "parent") || Ne && (ct == "buffer" || ct == "byteLength" || ct == "byteOffset") || Is(ct, Xe))) && jt.push(ct);
        return jt
    }

    function $i(E, U) {
        for (var Z = E.length; Z--;)
            if (Os(E[Z][0], U)) return Z;
        return -1
    }

    function Tn(E, U, Z) {
        var pe = U(E);
        return hn(E) ? pe : ke(pe, Z(E))
    }

    function Li(E) {
        return E == null ? E === void 0 ? K : ie : tr && tr in Object(E) ? Es(E) : uo(E)
    }

    function Rn(E) {
        return ji(E) && Li(E) == f
    }

    function Mi(E, U, Z, pe, ot) {
        return E === U ? !0 : E == null || U == null || !ji(E) && !ji(U) ? E !== E && U !== U : _s(E, U, Z, pe, Mi, ot)
    }

    function _s(E, U, Z, pe, ot, Ne) {
        var lt = hn(E),
            jt = hn(U),
            Xe = lt ? v : Gr(E),
            ct = jt ? v : Gr(U);
        Xe = Xe == f ? T : Xe, ct = ct == f ? T : ct;
        var At = Xe == T,
            lr = ct == T,
            zt = Xe == ct;
        if (zt && Fn(E)) {
            if (!Fn(U)) return !1;
            lt = !0, At = !1
        }
        if (zt && !At) return Ne || (Ne = new jr), lt || Ts(E) ? cn(E, U, Z, pe, ot, Ne) : co(E, U, Xe, Z, pe, ot, Ne);
        if (!(Z & o)) {
            var ft = At && Ce.call(E, "__wrapped__"),
                rr = lr && Ce.call(U, "__wrapped__");
            if (ft || rr) {
                var zr = ft ? E.value() : E,
                    Or = rr ? U.value() : U;
                return Ne || (Ne = new jr), ot(zr, Or, Z, pe, Ne)
            }
        }
        return zt ? (Ne || (Ne = new jr), ws(E, U, Z, pe, ot, Ne)) : !1
    }

    function oo(E) {
        if (!Ns(E) || xs(E)) return !1;
        var U = ln(E) ? et : ne;
        return U.test(si(E))
    }

    function ms(E) {
        return ji(E) && Ps(E.length) && !!he[Li(E)]
    }

    function bs(E) {
        if (!Cs(E)) return Ui(E);
        var U = [];
        for (var Z in Object(E)) Ce.call(E, Z) && Z != "constructor" && U.push(Z);
        return U
    }

    function cn(E, U, Z, pe, ot, Ne) {
        var lt = Z & o,
            jt = E.length,
            Xe = U.length;
        if (jt != Xe && !(lt && Xe > jt)) return !1;
        var ct = Ne.get(E);
        if (ct && Ne.get(U)) return ct == U;
        var At = -1,
            lr = !0,
            zt = Z & l ? new on : void 0;
        for (Ne.set(E, U), Ne.set(U, E); ++At < jt;) {
            var ft = E[At],
                rr = U[At];
            if (pe) var zr = lt ? pe(rr, ft, At, U, E, Ne) : pe(ft, rr, At, E, U, Ne);
            if (zr !== void 0) {
                if (zr) continue;
                lr = !1;
                break
            }
            if (zt) {
                if (!Le(U, function(Or, Wr) {
                        if (!je(zt, Wr) && (ft === Or || ot(ft, Or, Z, pe, Ne))) return zt.push(Wr)
                    })) {
                    lr = !1;
                    break
                }
            } else if (!(ft === rr || ot(ft, rr, Z, pe, Ne))) {
                lr = !1;
                break
            }
        }
        return Ne.delete(E), Ne.delete(U), lr
    }

    function co(E, U, Z, pe, ot, Ne, lt) {
        switch (Z) {
            case ce:
                if (E.byteLength != U.byteLength || E.byteOffset != U.byteOffset) return !1;
                E = E.buffer, U = U.buffer;
            case ae:
                return !(E.byteLength != U.byteLength || !Ne(new er(E), new er(U)));
            case b:
            case S:
            case G:
                return Os(+E, +U);
            case O:
                return E.name == U.name && E.message == U.message;
            case C:
            case c:
                return E == U + "";
            case H:
                var jt = Re;
            case w:
                var Xe = pe & o;
                if (jt || (jt = ze), E.size != U.size && !Xe) return !1;
                var ct = lt.get(E);
                if (ct) return ct == U;
                pe |= l, lt.set(E, U);
                var At = cn(jt(E), jt(U), pe, ot, Ne, lt);
                return lt.delete(E), At;
            case m:
                if (St) return St.call(E) == St.call(U)
        }
        return !1
    }

    function ws(E, U, Z, pe, ot, Ne) {
        var lt = Z & o,
            jt = un(E),
            Xe = jt.length,
            ct = un(U),
            At = ct.length;
        if (Xe != At && !lt) return !1;
        for (var lr = Xe; lr--;) {
            var zt = jt[lr];
            if (!(lt ? zt in U : Ce.call(U, zt))) return !1
        }
        var ft = Ne.get(E);
        if (ft && Ne.get(U)) return ft == U;
        var rr = !0;
        Ne.set(E, U), Ne.set(U, E);
        for (var zr = lt; ++lr < Xe;) {
            zt = jt[lr];
            var Or = E[zt],
                Wr = U[zt];
            if (pe) var Un = lt ? pe(Wr, Or, zt, U, E, Ne) : pe(Or, Wr, zt, E, U, Ne);
            if (!(Un === void 0 ? Or === Wr || ot(Or, Wr, Z, pe, Ne) : Un)) {
                rr = !1;
                break
            }
            zr || (zr = zt == "constructor")
        }
        if (rr && !zr) {
            var zi = E.constructor,
                Kt = U.constructor;
            zi != Kt && "constructor" in E && "constructor" in U && !(typeof zi == "function" && zi instanceof zi && typeof Kt == "function" && Kt instanceof Kt) && (rr = !1)
        }
        return Ne.delete(E), Ne.delete(U), rr
    }

    function un(E) {
        return Tn(E, fo, Ds)
    }

    function _i(E, U) {
        var Z = E.__data__;
        return Ss(U) ? Z[typeof U == "string" ? "string" : "hash"] : Z.map
    }

    function br(E, U) {
        var Z = Se(E, U);
        return oo(Z) ? Z : void 0
    }

    function Es(E) {
        var U = Ce.call(E, tr),
            Z = E[tr];
        try {
            E[tr] = void 0;
            var pe = !0
        } catch {}
        var ot = We.call(E);
        return pe && (U ? E[tr] = Z : delete E[tr]), ot
    }
    var Ds = ii ? function(E) {
            return E == null ? [] : (E = Object(E), He(ii(E), function(U) {
                return hr.call(E, U)
            }))
        } : at,
        Gr = Li;
    (bt && Gr(new bt(new ArrayBuffer(1))) != ce || gt && Gr(new gt) != H || wt && Gr(wt.resolve()) != L || Et && Gr(new Et) != w || _t && Gr(new _t) != V) && (Gr = function(E) {
        var U = Li(E),
            Z = U == T ? E.constructor : void 0,
            pe = Z ? si(Z) : "";
        if (pe) switch (pe) {
            case Ft:
                return ce;
            case Ut:
                return H;
            case Dt:
                return L;
            case $t:
                return w;
            case It:
                return V
        }
        return U
    });

    function Is(E, U) {
        return U = U ? ? d, !!U && (typeof E == "number" || be.test(E)) && E > -1 && E % 1 == 0 && E < U
    }

    function Ss(E) {
        var U = typeof E;
        return U == "string" || U == "number" || U == "symbol" || U == "boolean" ? E !== "__proto__" : E === null
    }

    function xs(E) {
        return !!Ve && Ve in E
    }

    function Cs(E) {
        var U = E && E.constructor,
            Z = typeof U == "function" && U.prototype || De;
        return E === Z
    }

    function uo(E) {
        return We.call(E)
    }

    function si(E) {
        if (E != null) {
            try {
                return Be.call(E)
            } catch {}
            try {
                return E + ""
            } catch {}
        }
        return ""
    }

    function Os(E, U) {
        return E === U || E !== E && U !== U
    }
    var As = Rn(function() {
            return arguments
        }()) ? Rn : function(E) {
            return ji(E) && Ce.call(E, "callee") && !hr.call(E, "callee")
        },
        hn = Array.isArray;

    function ho(E) {
        return E != null && Ps(E.length) && !ln(E)
    }
    var Fn = yi || st;

    function lo(E, U) {
        return Mi(E, U)
    }

    function ln(E) {
        if (!Ns(E)) return !1;
        var U = Li(E);
        return U == P || U == N || U == g || U == I
    }

    function Ps(E) {
        return typeof E == "number" && E > -1 && E % 1 == 0 && E <= d
    }

    function Ns(E) {
        var U = typeof E;
        return E != null && (U == "object" || U == "function")
    }

    function ji(E) {
        return E != null && typeof E == "object"
    }
    var Ts = Ie ? dt(Ie) : ms;

    function fo(E) {
        return ho(E) ? ys(E) : bs(E)
    }

    function at() {
        return []
    }

    function st() {
        return !1
    }
    n.exports = lo
})(Ua, Ua.exports);
var i3 = Ua.exports;
const n3 = P_(i3);

function s3(n, t) {
    if (n.length >= 255) throw new TypeError("Alphabet too long");
    for (var r = new Uint8Array(256), s = 0; s < r.length; s++) r[s] = 255;
    for (var o = 0; o < n.length; o++) {
        var l = n.charAt(o),
            d = l.charCodeAt(0);
        if (r[d] !== 255) throw new TypeError(l + " is ambiguous");
        r[d] = o
    }
    var f = n.length,
        v = n.charAt(0),
        g = Math.log(f) / Math.log(256),
        b = Math.log(256) / Math.log(f);

    function S(N) {
        if (N instanceof Uint8Array || (ArrayBuffer.isView(N) ? N = new Uint8Array(N.buffer, N.byteOffset, N.byteLength) : Array.isArray(N) && (N = Uint8Array.from(N))), !(N instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
        if (N.length === 0) return "";
        for (var H = 0, G = 0, ie = 0, T = N.length; ie !== T && N[ie] === 0;) ie++, H++;
        for (var L = (T - ie) * b + 1 >>> 0, I = new Uint8Array(L); ie !== T;) {
            for (var C = N[ie], w = 0, c = L - 1;
                (C !== 0 || w < G) && c !== -1; c--, w++) C += 256 * I[c] >>> 0, I[c] = C % f >>> 0, C = C / f >>> 0;
            if (C !== 0) throw new Error("Non-zero carry");
            G = w, ie++
        }
        for (var m = L - G; m !== L && I[m] === 0;) m++;
        for (var K = v.repeat(H); m < L; ++m) K += n.charAt(I[m]);
        return K
    }

    function O(N) {
        if (typeof N != "string") throw new TypeError("Expected String");
        if (N.length === 0) return new Uint8Array;
        var H = 0;
        if (N[H] !== " ") {
            for (var G = 0, ie = 0; N[H] === v;) G++, H++;
            for (var T = (N.length - H) * g + 1 >>> 0, L = new Uint8Array(T); N[H];) {
                var I = r[N.charCodeAt(H)];
                if (I === 255) return;
                for (var C = 0, w = T - 1;
                    (I !== 0 || C < ie) && w !== -1; w--, C++) I += f * L[w] >>> 0, L[w] = I % 256 >>> 0, I = I / 256 >>> 0;
                if (I !== 0) throw new Error("Non-zero carry");
                ie = C, H++
            }
            if (N[H] !== " ") {
                for (var c = T - ie; c !== T && L[c] === 0;) c++;
                for (var m = new Uint8Array(G + (T - c)), K = G; c !== T;) m[K++] = L[c++];
                return m
            }
        }
    }

    function P(N) {
        var H = O(N);
        if (H) return H;
        throw new Error(`Non-${t} character`)
    }
    return {
        encode: S,
        decodeUnsafe: O,
        decode: P
    }
}
var a3 = s3,
    o3 = a3;
const Pp = n => {
        if (n instanceof Uint8Array && n.constructor.name === "Uint8Array") return n;
        if (n instanceof ArrayBuffer) return new Uint8Array(n);
        if (ArrayBuffer.isView(n)) return new Uint8Array(n.buffer, n.byteOffset, n.byteLength);
        throw new Error("Unknown type, must be binary type")
    },
    c3 = n => new TextEncoder().encode(n),
    u3 = n => new TextDecoder().decode(n);
class h3 {
    constructor(t, r, s) {
        this.name = t, this.prefix = r, this.baseEncode = s
    }
    encode(t) {
        if (t instanceof Uint8Array) return `${this.prefix}${this.baseEncode(t)}`;
        throw Error("Unknown type, must be binary type")
    }
}
class l3 {
    constructor(t, r, s) {
        if (this.name = t, this.prefix = r, r.codePointAt(0) === void 0) throw new Error("Invalid prefix character");
        this.prefixCodePoint = r.codePointAt(0), this.baseDecode = s
    }
    decode(t) {
        if (typeof t == "string") {
            if (t.codePointAt(0) !== this.prefixCodePoint) throw Error(`Unable to decode multibase string ${JSON.stringify(t)}, ${this.name} decoder only supports inputs prefixed with ${this.prefix}`);
            return this.baseDecode(t.slice(this.prefix.length))
        } else throw Error("Can only multibase decode strings")
    }
    or(t) {
        return Np(this, t)
    }
}
class f3 {
    constructor(t) {
        this.decoders = t
    }
    or(t) {
        return Np(this, t)
    }
    decode(t) {
        const r = t[0],
            s = this.decoders[r];
        if (s) return s.decode(t);
        throw RangeError(`Unable to decode multibase string ${JSON.stringify(t)}, only inputs prefixed with ${Object.keys(this.decoders)} are supported`)
    }
}
const Np = (n, t) => new f3({ ...n.decoders || {
        [n.prefix]: n
    },
    ...t.decoders || {
        [t.prefix]: t
    }
});
class p3 {
    constructor(t, r, s, o) {
        this.name = t, this.prefix = r, this.baseEncode = s, this.baseDecode = o, this.encoder = new h3(t, r, s), this.decoder = new l3(t, r, o)
    }
    encode(t) {
        return this.encoder.encode(t)
    }
    decode(t) {
        return this.decoder.decode(t)
    }
}
const Ka = ({
        name: n,
        prefix: t,
        encode: r,
        decode: s
    }) => new p3(n, t, r, s),
    ps = ({
        prefix: n,
        name: t,
        alphabet: r
    }) => {
        const {
            encode: s,
            decode: o
        } = o3(r, t);
        return Ka({
            prefix: n,
            name: t,
            encode: s,
            decode: l => Pp(o(l))
        })
    },
    d3 = (n, t, r, s) => {
        const o = {};
        for (let b = 0; b < t.length; ++b) o[t[b]] = b;
        let l = n.length;
        for (; n[l - 1] === "=";) --l;
        const d = new Uint8Array(l * r / 8 | 0);
        let f = 0,
            v = 0,
            g = 0;
        for (let b = 0; b < l; ++b) {
            const S = o[n[b]];
            if (S === void 0) throw new SyntaxError(`Non-${s} character`);
            v = v << r | S, f += r, f >= 8 && (f -= 8, d[g++] = 255 & v >> f)
        }
        if (f >= r || 255 & v << 8 - f) throw new SyntaxError("Unexpected end of data");
        return d
    },
    g3 = (n, t, r) => {
        const s = t[t.length - 1] === "=",
            o = (1 << r) - 1;
        let l = "",
            d = 0,
            f = 0;
        for (let v = 0; v < n.length; ++v)
            for (f = f << 8 | n[v], d += 8; d > r;) d -= r, l += t[o & f >> d];
        if (d && (l += t[o & f << r - d]), s)
            for (; l.length * r & 7;) l += "=";
        return l
    },
    Jt = ({
        name: n,
        prefix: t,
        bitsPerChar: r,
        alphabet: s
    }) => Ka({
        prefix: t,
        name: n,
        encode(o) {
            return g3(o, s, r)
        },
        decode(o) {
            return d3(o, s, r, n)
        }
    }),
    v3 = Ka({
        prefix: "\0",
        name: "identity",
        encode: n => u3(n),
        decode: n => c3(n)
    });
var y3 = Object.freeze({
    __proto__: null,
    identity: v3
});
const _3 = Jt({
    prefix: "0",
    name: "base2",
    alphabet: "01",
    bitsPerChar: 1
});
var m3 = Object.freeze({
    __proto__: null,
    base2: _3
});
const b3 = Jt({
    prefix: "7",
    name: "base8",
    alphabet: "01234567",
    bitsPerChar: 3
});
var w3 = Object.freeze({
    __proto__: null,
    base8: b3
});
const E3 = ps({
    prefix: "9",
    name: "base10",
    alphabet: "0123456789"
});
var D3 = Object.freeze({
    __proto__: null,
    base10: E3
});
const I3 = Jt({
        prefix: "f",
        name: "base16",
        alphabet: "0123456789abcdef",
        bitsPerChar: 4
    }),
    S3 = Jt({
        prefix: "F",
        name: "base16upper",
        alphabet: "0123456789ABCDEF",
        bitsPerChar: 4
    });
var x3 = Object.freeze({
    __proto__: null,
    base16: I3,
    base16upper: S3
});
const C3 = Jt({
        prefix: "b",
        name: "base32",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567",
        bitsPerChar: 5
    }),
    O3 = Jt({
        prefix: "B",
        name: "base32upper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
        bitsPerChar: 5
    }),
    A3 = Jt({
        prefix: "c",
        name: "base32pad",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567=",
        bitsPerChar: 5
    }),
    P3 = Jt({
        prefix: "C",
        name: "base32padupper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567=",
        bitsPerChar: 5
    }),
    N3 = Jt({
        prefix: "v",
        name: "base32hex",
        alphabet: "0123456789abcdefghijklmnopqrstuv",
        bitsPerChar: 5
    }),
    T3 = Jt({
        prefix: "V",
        name: "base32hexupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV",
        bitsPerChar: 5
    }),
    R3 = Jt({
        prefix: "t",
        name: "base32hexpad",
        alphabet: "0123456789abcdefghijklmnopqrstuv=",
        bitsPerChar: 5
    }),
    F3 = Jt({
        prefix: "T",
        name: "base32hexpadupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV=",
        bitsPerChar: 5
    }),
    U3 = Jt({
        prefix: "h",
        name: "base32z",
        alphabet: "ybndrfg8ejkmcpqxot1uwisza345h769",
        bitsPerChar: 5
    });
var $3 = Object.freeze({
    __proto__: null,
    base32: C3,
    base32upper: O3,
    base32pad: A3,
    base32padupper: P3,
    base32hex: N3,
    base32hexupper: T3,
    base32hexpad: R3,
    base32hexpadupper: F3,
    base32z: U3
});
const L3 = ps({
        prefix: "k",
        name: "base36",
        alphabet: "0123456789abcdefghijklmnopqrstuvwxyz"
    }),
    M3 = ps({
        prefix: "K",
        name: "base36upper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    });
var j3 = Object.freeze({
    __proto__: null,
    base36: L3,
    base36upper: M3
});
const z3 = ps({
        name: "base58btc",
        prefix: "z",
        alphabet: "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    }),
    q3 = ps({
        name: "base58flickr",
        prefix: "Z",
        alphabet: "123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ"
    });
var H3 = Object.freeze({
    __proto__: null,
    base58btc: z3,
    base58flickr: q3
});
const B3 = Jt({
        prefix: "m",
        name: "base64",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        bitsPerChar: 6
    }),
    K3 = Jt({
        prefix: "M",
        name: "base64pad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        bitsPerChar: 6
    }),
    k3 = Jt({
        prefix: "u",
        name: "base64url",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
        bitsPerChar: 6
    }),
    V3 = Jt({
        prefix: "U",
        name: "base64urlpad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=",
        bitsPerChar: 6
    });
var G3 = Object.freeze({
    __proto__: null,
    base64: B3,
    base64pad: K3,
    base64url: k3,
    base64urlpad: V3
});
const Tp = Array.from("🚀🪐☄🛰🌌🌑🌒🌓🌔🌕🌖🌗🌘🌍🌏🌎🐉☀💻🖥💾💿😂❤😍🤣😊🙏💕😭😘👍😅👏😁🔥🥰💔💖💙😢🤔😆🙄💪😉☺👌🤗💜😔😎😇🌹🤦🎉💞✌✨🤷😱😌🌸🙌😋💗💚😏💛🙂💓🤩😄😀🖤😃💯🙈👇🎶😒🤭❣😜💋👀😪😑💥🙋😞😩😡🤪👊🥳😥🤤👉💃😳✋😚😝😴🌟😬🙃🍀🌷😻😓⭐✅🥺🌈😈🤘💦✔😣🏃💐☹🎊💘😠☝😕🌺🎂🌻😐🖕💝🙊😹🗣💫💀👑🎵🤞😛🔴😤🌼😫⚽🤙☕🏆🤫👈😮🙆🍻🍃🐶💁😲🌿🧡🎁⚡🌞🎈❌✊👋😰🤨😶🤝🚶💰🍓💢🤟🙁🚨💨🤬✈🎀🍺🤓😙💟🌱😖👶🥴▶➡❓💎💸⬇😨🌚🦋😷🕺⚠🙅😟😵👎🤲🤠🤧📌🔵💅🧐🐾🍒😗🤑🌊🤯🐷☎💧😯💆👆🎤🙇🍑❄🌴💣🐸💌📍🥀🤢👅💡💩👐📸👻🤐🤮🎼🥵🚩🍎🍊👼💍📣🥂"),
    W3 = Tp.reduce((n, t, r) => (n[r] = t, n), []),
    Y3 = Tp.reduce((n, t, r) => (n[t.codePointAt(0)] = r, n), []);

function J3(n) {
    return n.reduce((t, r) => (t += W3[r], t), "")
}

function X3(n) {
    const t = [];
    for (const r of n) {
        const s = Y3[r.codePointAt(0)];
        if (s === void 0) throw new Error(`Non-base256emoji character: ${r}`);
        t.push(s)
    }
    return new Uint8Array(t)
}
const Z3 = Ka({
    prefix: "🚀",
    name: "base256emoji",
    encode: J3,
    decode: X3
});
var Q3 = Object.freeze({
        __proto__: null,
        base256emoji: Z3
    }),
    e6 = Rp,
    df = 128,
    t6 = 127,
    r6 = ~t6,
    i6 = Math.pow(2, 31);

function Rp(n, t, r) {
    t = t || [], r = r || 0;
    for (var s = r; n >= i6;) t[r++] = n & 255 | df, n /= 128;
    for (; n & r6;) t[r++] = n & 255 | df, n >>>= 7;
    return t[r] = n | 0, Rp.bytes = r - s + 1, t
}
var n6 = Jc,
    s6 = 128,
    gf = 127;

function Jc(n, s) {
    var r = 0,
        s = s || 0,
        o = 0,
        l = s,
        d, f = n.length;
    do {
        if (l >= f) throw Jc.bytes = 0, new RangeError("Could not decode varint");
        d = n[l++], r += o < 28 ? (d & gf) << o : (d & gf) * Math.pow(2, o), o += 7
    } while (d >= s6);
    return Jc.bytes = l - s, r
}
var a6 = Math.pow(2, 7),
    o6 = Math.pow(2, 14),
    c6 = Math.pow(2, 21),
    u6 = Math.pow(2, 28),
    h6 = Math.pow(2, 35),
    l6 = Math.pow(2, 42),
    f6 = Math.pow(2, 49),
    p6 = Math.pow(2, 56),
    d6 = Math.pow(2, 63),
    g6 = function(n) {
        return n < a6 ? 1 : n < o6 ? 2 : n < c6 ? 3 : n < u6 ? 4 : n < h6 ? 5 : n < l6 ? 6 : n < f6 ? 7 : n < p6 ? 8 : n < d6 ? 9 : 10
    },
    v6 = {
        encode: e6,
        decode: n6,
        encodingLength: g6
    },
    Fp = v6;
const vf = (n, t, r = 0) => (Fp.encode(n, t, r), t),
    yf = n => Fp.encodingLength(n),
    Xc = (n, t) => {
        const r = t.byteLength,
            s = yf(n),
            o = s + yf(r),
            l = new Uint8Array(o + r);
        return vf(n, l, 0), vf(r, l, s), l.set(t, o), new y6(n, r, t, l)
    };
class y6 {
    constructor(t, r, s, o) {
        this.code = t, this.size = r, this.digest = s, this.bytes = o
    }
}
const Up = ({
    name: n,
    code: t,
    encode: r
}) => new _6(n, t, r);
class _6 {
    constructor(t, r, s) {
        this.name = t, this.code = r, this.encode = s
    }
    digest(t) {
        if (t instanceof Uint8Array) {
            const r = this.encode(t);
            return r instanceof Uint8Array ? Xc(this.code, r) : r.then(s => Xc(this.code, s))
        } else throw Error("Unknown type, must be binary type")
    }
}
const $p = n => async t => new Uint8Array(await crypto.subtle.digest(n, t)),
    m6 = Up({
        name: "sha2-256",
        code: 18,
        encode: $p("SHA-256")
    }),
    b6 = Up({
        name: "sha2-512",
        code: 19,
        encode: $p("SHA-512")
    });
var w6 = Object.freeze({
    __proto__: null,
    sha256: m6,
    sha512: b6
});
const Lp = 0,
    E6 = "identity",
    Mp = Pp,
    D6 = n => Xc(Lp, Mp(n)),
    I6 = {
        code: Lp,
        name: E6,
        encode: Mp,
        digest: D6
    };
var S6 = Object.freeze({
    __proto__: null,
    identity: I6
});
new TextEncoder, new TextDecoder;
const _f = { ...y3,
    ...m3,
    ...w3,
    ...D3,
    ...x3,
    ...$3,
    ...j3,
    ...H3,
    ...G3,
    ...Q3
};
({ ...w6,
    ...S6
});

function jp(n) {
    return globalThis.Buffer != null ? new Uint8Array(n.buffer, n.byteOffset, n.byteLength) : n
}

function x6(n = 0) {
    return globalThis.Buffer != null && globalThis.Buffer.allocUnsafe != null ? jp(globalThis.Buffer.allocUnsafe(n)) : new Uint8Array(n)
}

function zp(n, t, r, s) {
    return {
        name: n,
        prefix: t,
        encoder: {
            name: n,
            prefix: t,
            encode: r
        },
        decoder: {
            decode: s
        }
    }
}
const mf = zp("utf8", "u", n => "u" + new TextDecoder("utf8").decode(n), n => new TextEncoder().encode(n.substring(1))),
    Pc = zp("ascii", "a", n => {
        let t = "a";
        for (let r = 0; r < n.length; r++) t += String.fromCharCode(n[r]);
        return t
    }, n => {
        n = n.substring(1);
        const t = x6(n.length);
        for (let r = 0; r < n.length; r++) t[r] = n.charCodeAt(r);
        return t
    }),
    C6 = {
        utf8: mf,
        "utf-8": mf,
        hex: _f.base16,
        latin1: Pc,
        ascii: Pc,
        binary: Pc,
        ..._f
    };

function O6(n, t = "utf8") {
    const r = C6[t];
    if (!r) throw new Error(`Unsupported encoding "${t}"`);
    return (t === "utf8" || t === "utf-8") && globalThis.Buffer != null && globalThis.Buffer.from != null ? jp(globalThis.Buffer.from(n, "utf-8")) : r.decoder.decode(`${r.prefix}${n}`)
}
const qp = "wc",
    A6 = 2,
    bu = "core",
    Ni = `${qp}@2:${bu}:`,
    P6 = {
        name: bu,
        logger: "error"
    },
    N6 = {
        database: ":memory:"
    },
    T6 = "crypto",
    bf = "client_ed25519_seed",
    R6 = ye.ONE_DAY,
    F6 = "keychain",
    U6 = "0.3",
    $6 = "messages",
    L6 = "0.3",
    M6 = ye.SIX_HOURS,
    j6 = "publisher",
    Hp = "irn",
    z6 = "error",
    Bp = "wss://relay.walletconnect.com",
    wf = "wss://relay.walletconnect.org",
    q6 = "relayer",
    Ct = {
        message: "relayer_message",
        message_ack: "relayer_message_ack",
        connect: "relayer_connect",
        disconnect: "relayer_disconnect",
        error: "relayer_error",
        connection_stalled: "relayer_connection_stalled",
        transport_closed: "relayer_transport_closed",
        publish: "relayer_publish"
    },
    H6 = "_subscription",
    ts = {
        payload: "payload",
        connect: "connect",
        disconnect: "disconnect",
        error: "error"
    },
    B6 = ye.ONE_SECOND / 2,
    K6 = "2.9.0",
    k6 = 1e4,
    V6 = "0.3",
    G6 = "WALLETCONNECT_CLIENT_ID",
    ei = {
        created: "subscription_created",
        deleted: "subscription_deleted",
        expired: "subscription_expired",
        disabled: "subscription_disabled",
        sync: "subscription_sync",
        resubscribed: "subscription_resubscribed"
    },
    W6 = "subscription",
    Y6 = "0.3",
    J6 = ye.FIVE_SECONDS * 1e3,
    X6 = "pairing",
    Z6 = "0.3",
    rs = {
        wc_pairingDelete: {
            req: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1e3
            },
            res: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1001
            }
        },
        wc_pairingPing: {
            req: {
                ttl: ye.THIRTY_SECONDS,
                prompt: !1,
                tag: 1002
            },
            res: {
                ttl: ye.THIRTY_SECONDS,
                prompt: !1,
                tag: 1003
            }
        },
        unregistered_method: {
            req: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 0
            },
            res: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 0
            }
        }
    },
    Qr = {
        created: "history_created",
        updated: "history_updated",
        deleted: "history_deleted",
        sync: "history_sync"
    },
    Q6 = "history",
    eD = "0.3",
    tD = "expirer",
    Lr = {
        created: "expirer_created",
        deleted: "expirer_deleted",
        expired: "expirer_expired",
        sync: "expirer_sync"
    },
    rD = "0.3",
    Nc = "verify-api",
    Ef = "https://verify.walletconnect.com";
class iD {
    constructor(t, r) {
        this.core = t, this.logger = r, this.keychain = new Map, this.name = F6, this.version = U6, this.initialized = !1, this.storagePrefix = Ni, this.init = async () => {
            if (!this.initialized) {
                const s = await this.getKeyChain();
                typeof s < "u" && (this.keychain = s), this.initialized = !0
            }
        }, this.has = s => (this.isInitialized(), this.keychain.has(s)), this.set = async (s, o) => {
            this.isInitialized(), this.keychain.set(s, o), await this.persist()
        }, this.get = s => {
            this.isInitialized();
            const o = this.keychain.get(s);
            if (typeof o > "u") {
                const {
                    message: l
                } = ue("NO_MATCHING_KEY", `${this.name}: ${s}`);
                throw new Error(l)
            }
            return o
        }, this.del = async s => {
            this.isInitialized(), this.keychain.delete(s), await this.persist()
        }, this.core = t, this.logger = Qe.generateChildLogger(r, this.name)
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + "//" + this.name
    }
    async setKeyChain(t) {
        await this.core.storage.setItem(this.storageKey, gp(t))
    }
    async getKeyChain() {
        const t = await this.core.storage.getItem(this.storageKey);
        return typeof t < "u" ? vp(t) : void 0
    }
    async persist() {
        await this.setKeyChain(this.keychain)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class nD {
    constructor(t, r, s) {
        this.core = t, this.logger = r, this.name = T6, this.initialized = !1, this.init = async () => {
            this.initialized || (await this.keychain.init(), this.initialized = !0)
        }, this.hasKeys = o => (this.isInitialized(), this.keychain.has(o)), this.getClientId = async () => {
            this.isInitialized();
            const o = await this.getClientSeed(),
                l = lf(o);
            return Ap(l.publicKey)
        }, this.generateKeyPair = () => {
            this.isInitialized();
            const o = Lb();
            return this.setPrivateKey(o.publicKey, o.privateKey)
        }, this.signJWT = async o => {
            this.isInitialized();
            const l = await this.getClientSeed(),
                d = lf(l),
                f = Gc();
            return await ZE(f, o, R6, d)
        }, this.generateSharedKey = (o, l, d) => {
            this.isInitialized();
            const f = this.getPrivateKey(o),
                v = Mb(f, l);
            return this.setSymKey(v, d)
        }, this.setSymKey = async (o, l) => {
            this.isInitialized();
            const d = l || jb(o);
            return await this.keychain.set(d, o), d
        }, this.deleteKeyPair = async o => {
            this.isInitialized(), await this.keychain.del(o)
        }, this.deleteSymKey = async o => {
            this.isInitialized(), await this.keychain.del(o)
        }, this.encode = async (o, l, d) => {
            this.isInitialized();
            const f = pp(d),
                v = cs(l);
            if (zl(f)) {
                const O = f.senderPublicKey,
                    P = f.receiverPublicKey;
                o = await this.generateSharedKey(O, P)
            }
            const g = this.getSymKey(o),
                {
                    type: b,
                    senderPublicKey: S
                } = f;
            return qb({
                type: b,
                symKey: g,
                message: v,
                senderPublicKey: S
            })
        }, this.decode = async (o, l, d) => {
            this.isInitialized();
            const f = Kb(l, d);
            if (zl(f)) {
                const b = f.receiverPublicKey,
                    S = f.senderPublicKey;
                o = await this.generateSharedKey(b, S)
            }
            const v = this.getSymKey(o),
                g = Hb({
                    symKey: v,
                    encoded: l
                });
            return La(g)
        }, this.getPayloadType = o => {
            const l = Na(o);
            return ls(l.type)
        }, this.getPayloadSenderPublicKey = o => {
            const l = Na(o);
            return l.senderPublicKey ? ur(l.senderPublicKey, cr) : void 0
        }, this.core = t, this.logger = Qe.generateChildLogger(r, this.name), this.keychain = s || new iD(this.core, this.logger)
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    async setPrivateKey(t, r) {
        return await this.keychain.set(t, r), t
    }
    getPrivateKey(t) {
        return this.keychain.get(t)
    }
    async getClientSeed() {
        let t = "";
        try {
            t = this.keychain.get(bf)
        } catch {
            t = Gc(), await this.keychain.set(bf, t)
        }
        return O6(t, "base16")
    }
    getSymKey(t) {
        return this.keychain.get(t)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class sD extends PE {
    constructor(t, r) {
        super(t, r), this.logger = t, this.core = r, this.messages = new Map, this.name = $6, this.version = L6, this.initialized = !1, this.storagePrefix = Ni, this.init = async () => {
            if (!this.initialized) {
                this.logger.trace("Initialized");
                try {
                    const s = await this.getRelayerMessages();
                    typeof s < "u" && (this.messages = s), this.logger.debug(`Successfully Restored records for ${this.name}`), this.logger.trace({
                        type: "method",
                        method: "restore",
                        size: this.messages.size
                    })
                } catch (s) {
                    this.logger.debug(`Failed to Restore records for ${this.name}`), this.logger.error(s)
                } finally {
                    this.initialized = !0
                }
            }
        }, this.set = async (s, o) => {
            this.isInitialized();
            const l = Cn(o);
            let d = this.messages.get(s);
            return typeof d > "u" && (d = {}), typeof d[l] < "u" || (d[l] = o, this.messages.set(s, d), await this.persist()), l
        }, this.get = s => {
            this.isInitialized();
            let o = this.messages.get(s);
            return typeof o > "u" && (o = {}), o
        }, this.has = (s, o) => {
            this.isInitialized();
            const l = this.get(s),
                d = Cn(o);
            return typeof l[d] < "u"
        }, this.del = async s => {
            this.isInitialized(), this.messages.delete(s), await this.persist()
        }, this.logger = Qe.generateChildLogger(t, this.name), this.core = r
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + "//" + this.name
    }
    async setRelayerMessages(t) {
        await this.core.storage.setItem(this.storageKey, gp(t))
    }
    async getRelayerMessages() {
        const t = await this.core.storage.getItem(this.storageKey);
        return typeof t < "u" ? vp(t) : void 0
    }
    async persist() {
        await this.setRelayerMessages(this.messages)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class aD extends NE {
    constructor(t, r) {
        super(t, r), this.relayer = t, this.logger = r, this.events = new ri.EventEmitter, this.name = j6, this.queue = new Map, this.publishTimeout = ye.toMiliseconds(ye.TEN_SECONDS), this.queueTimeout = ye.toMiliseconds(ye.FIVE_SECONDS), this.needsTransportRestart = !1, this.publish = async (s, o, l) => {
            this.logger.debug("Publishing Payload"), this.logger.trace({
                type: "method",
                method: "publish",
                params: {
                    topic: s,
                    message: o,
                    opts: l
                }
            });
            try {
                const d = (l == null ? void 0 : l.ttl) || M6,
                    f = Wc(l),
                    v = (l == null ? void 0 : l.prompt) || !1,
                    g = (l == null ? void 0 : l.tag) || 0,
                    b = (l == null ? void 0 : l.id) || Vf().toString(),
                    S = {
                        topic: s,
                        message: o,
                        opts: {
                            ttl: d,
                            relay: f,
                            prompt: v,
                            tag: g,
                            id: b
                        }
                    },
                    O = setTimeout(() => this.queue.set(b, S), this.queueTimeout);
                try {
                    await await Ta(this.rpcPublish(s, o, d, f, v, g, b), this.publishTimeout), clearTimeout(O), this.relayer.events.emit(Ct.publish, S)
                } catch {
                    this.logger.debug("Publishing Payload stalled"), this.needsTransportRestart = !0;
                    return
                }
                this.logger.debug("Successfully Published Payload"), this.logger.trace({
                    type: "method",
                    method: "publish",
                    params: {
                        topic: s,
                        message: o,
                        opts: l
                    }
                })
            } catch (d) {
                throw this.logger.debug("Failed to Publish Payload"), this.logger.error(d), d
            }
        }, this.on = (s, o) => {
            this.events.on(s, o)
        }, this.once = (s, o) => {
            this.events.once(s, o)
        }, this.off = (s, o) => {
            this.events.off(s, o)
        }, this.removeListener = (s, o) => {
            this.events.removeListener(s, o)
        }, this.relayer = t, this.logger = Qe.generateChildLogger(r, this.name), this.registerEventListeners()
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    rpcPublish(t, r, s, o, l, d, f) {
        var v, g, b, S;
        const O = {
            method: Ia(o.protocol).publish,
            params: {
                topic: t,
                message: r,
                ttl: s,
                prompt: l,
                tag: d
            },
            id: f
        };
        return or((v = O.params) == null ? void 0 : v.prompt) && ((g = O.params) == null || delete g.prompt), or((b = O.params) == null ? void 0 : b.tag) && ((S = O.params) == null || delete S.tag), this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "message",
            direction: "outgoing",
            request: O
        }), this.relayer.request(O)
    }
    onPublish(t) {
        this.queue.delete(t)
    }
    checkQueue() {
        this.queue.forEach(async t => {
            const {
                topic: r,
                message: s,
                opts: o
            } = t;
            await this.publish(r, s, o)
        })
    }
    registerEventListeners() {
        this.relayer.core.heartbeat.on(Nn.HEARTBEAT_EVENTS.pulse, () => {
            if (this.needsTransportRestart) {
                this.needsTransportRestart = !1, this.relayer.events.emit(Ct.connection_stalled);
                return
            }
            this.checkQueue()
        }), this.relayer.on(Ct.message_ack, t => {
            this.onPublish(t.id.toString())
        })
    }
}
class oD {
    constructor() {
        this.map = new Map, this.set = (t, r) => {
            const s = this.get(t);
            this.exists(t, r) || this.map.set(t, [...s, r])
        }, this.get = t => this.map.get(t) || [], this.exists = (t, r) => this.get(t).includes(r), this.delete = (t, r) => {
            if (typeof r > "u") {
                this.map.delete(t);
                return
            }
            if (!this.map.has(t)) return;
            const s = this.get(t);
            if (!this.exists(t, r)) return;
            const o = s.filter(l => l !== r);
            if (!o.length) {
                this.map.delete(t);
                return
            }
            this.map.set(t, o)
        }, this.clear = () => {
            this.map.clear()
        }
    }
    get topics() {
        return Array.from(this.map.keys())
    }
}
var cD = Object.defineProperty,
    uD = Object.defineProperties,
    hD = Object.getOwnPropertyDescriptors,
    Df = Object.getOwnPropertySymbols,
    lD = Object.prototype.hasOwnProperty,
    fD = Object.prototype.propertyIsEnumerable,
    If = (n, t, r) => t in n ? cD(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    is = (n, t) => {
        for (var r in t || (t = {})) lD.call(t, r) && If(n, r, t[r]);
        if (Df)
            for (var r of Df(t)) fD.call(t, r) && If(n, r, t[r]);
        return n
    },
    Tc = (n, t) => uD(n, hD(t));
class pD extends FE {
    constructor(t, r) {
        super(t, r), this.relayer = t, this.logger = r, this.subscriptions = new Map, this.topicMap = new oD, this.events = new ri.EventEmitter, this.name = W6, this.version = Y6, this.pending = new Map, this.cached = [], this.initialized = !1, this.pendingSubscriptionWatchLabel = "pending_sub_watch_label", this.pollingInterval = 20, this.storagePrefix = Ni, this.subscribeTimeout = 1e4, this.restartInProgress = !1, this.batchSubscribeTopicsLimit = 500, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restart(), this.registerEventListeners(), this.onEnable(), this.clientId = await this.relayer.core.crypto.getClientId())
        }, this.subscribe = async (s, o) => {
            await this.restartToComplete(), this.isInitialized(), this.logger.debug("Subscribing Topic"), this.logger.trace({
                type: "method",
                method: "subscribe",
                params: {
                    topic: s,
                    opts: o
                }
            });
            try {
                const l = Wc(o),
                    d = {
                        topic: s,
                        relay: l
                    };
                this.pending.set(s, d);
                const f = await this.rpcSubscribe(s, l);
                return this.onSubscribe(f, d), this.logger.debug("Successfully Subscribed Topic"), this.logger.trace({
                    type: "method",
                    method: "subscribe",
                    params: {
                        topic: s,
                        opts: o
                    }
                }), f
            } catch (l) {
                throw this.logger.debug("Failed to Subscribe Topic"), this.logger.error(l), l
            }
        }, this.unsubscribe = async (s, o) => {
            await this.restartToComplete(), this.isInitialized(), typeof(o == null ? void 0 : o.id) < "u" ? await this.unsubscribeById(s, o.id, o) : await this.unsubscribeByTopic(s, o)
        }, this.isSubscribed = async s => this.topics.includes(s) ? !0 : await new Promise((o, l) => {
            const d = new ye.Watch;
            d.start(this.pendingSubscriptionWatchLabel);
            const f = setInterval(() => {
                !this.pending.has(s) && this.topics.includes(s) && (clearInterval(f), d.stop(this.pendingSubscriptionWatchLabel), o(!0)), d.elapsed(this.pendingSubscriptionWatchLabel) >= J6 && (clearInterval(f), d.stop(this.pendingSubscriptionWatchLabel), l(new Error("Subscription resolution timeout")))
            }, this.pollingInterval)
        }).catch(() => !1), this.on = (s, o) => {
            this.events.on(s, o)
        }, this.once = (s, o) => {
            this.events.once(s, o)
        }, this.off = (s, o) => {
            this.events.off(s, o)
        }, this.removeListener = (s, o) => {
            this.events.removeListener(s, o)
        }, this.restart = async () => {
            this.restartInProgress = !0, await this.restore(), await this.reset(), this.restartInProgress = !1
        }, this.relayer = t, this.logger = Qe.generateChildLogger(r, this.name), this.clientId = ""
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + "//" + this.name
    }
    get length() {
        return this.subscriptions.size
    }
    get ids() {
        return Array.from(this.subscriptions.keys())
    }
    get values() {
        return Array.from(this.subscriptions.values())
    }
    get topics() {
        return this.topicMap.topics
    }
    hasSubscription(t, r) {
        let s = !1;
        try {
            s = this.getSubscription(t).topic === r
        } catch {}
        return s
    }
    onEnable() {
        this.cached = [], this.initialized = !0
    }
    onDisable() {
        this.cached = this.values, this.subscriptions.clear(), this.topicMap.clear()
    }
    async unsubscribeByTopic(t, r) {
        const s = this.topicMap.get(t);
        await Promise.all(s.map(async o => await this.unsubscribeById(t, o, r)))
    }
    async unsubscribeById(t, r, s) {
        this.logger.debug("Unsubscribing Topic"), this.logger.trace({
            type: "method",
            method: "unsubscribe",
            params: {
                topic: t,
                id: r,
                opts: s
            }
        });
        try {
            const o = Wc(s);
            await this.rpcUnsubscribe(t, r, o);
            const l = Tt("USER_DISCONNECTED", `${this.name}, ${t}`);
            await this.onUnsubscribe(t, r, l), this.logger.debug("Successfully Unsubscribed Topic"), this.logger.trace({
                type: "method",
                method: "unsubscribe",
                params: {
                    topic: t,
                    id: r,
                    opts: s
                }
            })
        } catch (o) {
            throw this.logger.debug("Failed to Unsubscribe Topic"), this.logger.error(o), o
        }
    }
    async rpcSubscribe(t, r) {
        const s = {
            method: Ia(r.protocol).subscribe,
            params: {
                topic: t
            }
        };
        this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: s
        });
        try {
            await await Ta(this.relayer.request(s), this.subscribeTimeout)
        } catch {
            this.logger.debug("Outgoing Relay Subscribe Payload stalled"), this.relayer.events.emit(Ct.connection_stalled)
        }
        return Cn(t + this.clientId)
    }
    async rpcBatchSubscribe(t) {
        if (!t.length) return;
        const r = t[0].relay,
            s = {
                method: Ia(r.protocol).batchSubscribe,
                params: {
                    topics: t.map(o => o.topic)
                }
            };
        this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: s
        });
        try {
            return await await Ta(this.relayer.request(s), this.subscribeTimeout)
        } catch {
            this.logger.debug("Outgoing Relay Payload stalled"), this.relayer.events.emit(Ct.connection_stalled)
        }
    }
    rpcUnsubscribe(t, r, s) {
        const o = {
            method: Ia(s.protocol).unsubscribe,
            params: {
                topic: t,
                id: r
            }
        };
        return this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: o
        }), this.relayer.request(o)
    }
    onSubscribe(t, r) {
        this.setSubscription(t, Tc(is({}, r), {
            id: t
        })), this.pending.delete(r.topic)
    }
    onBatchSubscribe(t) {
        t.length && t.forEach(r => {
            this.setSubscription(r.id, is({}, r)), this.pending.delete(r.topic)
        })
    }
    async onUnsubscribe(t, r, s) {
        this.events.removeAllListeners(r), this.hasSubscription(r, t) && this.deleteSubscription(r, s), await this.relayer.messages.del(t)
    }
    async setRelayerSubscriptions(t) {
        await this.relayer.core.storage.setItem(this.storageKey, t)
    }
    async getRelayerSubscriptions() {
        return await this.relayer.core.storage.getItem(this.storageKey)
    }
    setSubscription(t, r) {
        this.subscriptions.has(t) || (this.logger.debug("Setting subscription"), this.logger.trace({
            type: "method",
            method: "setSubscription",
            id: t,
            subscription: r
        }), this.addSubscription(t, r))
    }
    addSubscription(t, r) {
        this.subscriptions.set(t, is({}, r)), this.topicMap.set(r.topic, t), this.events.emit(ei.created, r)
    }
    getSubscription(t) {
        this.logger.debug("Getting subscription"), this.logger.trace({
            type: "method",
            method: "getSubscription",
            id: t
        });
        const r = this.subscriptions.get(t);
        if (!r) {
            const {
                message: s
            } = ue("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw new Error(s)
        }
        return r
    }
    deleteSubscription(t, r) {
        this.logger.debug("Deleting subscription"), this.logger.trace({
            type: "method",
            method: "deleteSubscription",
            id: t,
            reason: r
        });
        const s = this.getSubscription(t);
        this.subscriptions.delete(t), this.topicMap.delete(s.topic, t), this.events.emit(ei.deleted, Tc(is({}, s), {
            reason: r
        }))
    }
    async persist() {
        await this.setRelayerSubscriptions(this.values), this.events.emit(ei.sync)
    }
    async reset() {
        if (this.cached.length) {
            const t = Math.ceil(this.cached.length / this.batchSubscribeTopicsLimit);
            for (let r = 0; r < t; r++) {
                const s = this.cached.splice(0, this.batchSubscribeTopicsLimit);
                await this.batchSubscribe(s)
            }
        }
        this.events.emit(ei.resubscribed)
    }
    async restore() {
        try {
            const t = await this.getRelayerSubscriptions();
            if (typeof t > "u" || !t.length) return;
            if (this.subscriptions.size) {
                const {
                    message: r
                } = ue("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(r), this.logger.error(`${this.name}: ${JSON.stringify(this.values)}`), new Error(r)
            }
            this.cached = t, this.logger.debug(`Successfully Restored subscriptions for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                subscriptions: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore subscriptions for ${this.name}`), this.logger.error(t)
        }
    }
    async batchSubscribe(t) {
        if (!t.length) return;
        const r = await this.rpcBatchSubscribe(t);
        ti(r) && this.onBatchSubscribe(r.map((s, o) => Tc(is({}, t[o]), {
            id: s
        })))
    }
    async onConnect() {
        this.restartInProgress || (await this.restart(), this.onEnable())
    }
    onDisconnect() {
        this.onDisable()
    }
    async checkPending() {
        if (this.relayer.transportExplicitlyClosed) return;
        const t = [];
        this.pending.forEach(r => {
            t.push(r)
        }), await this.batchSubscribe(t)
    }
    registerEventListeners() {
        this.relayer.core.heartbeat.on(Nn.HEARTBEAT_EVENTS.pulse, async () => {
            await this.checkPending()
        }), this.relayer.on(Ct.connect, async () => {
            await this.onConnect()
        }), this.relayer.on(Ct.disconnect, () => {
            this.onDisconnect()
        }), this.events.on(ei.created, async t => {
            const r = ei.created;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                data: t
            }), await this.persist()
        }), this.events.on(ei.deleted, async t => {
            const r = ei.deleted;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                data: t
            }), await this.persist()
        })
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    async restartToComplete() {
        this.restartInProgress && await new Promise(t => {
            const r = setInterval(() => {
                this.restartInProgress || (clearInterval(r), t())
            }, this.pollingInterval)
        })
    }
}
var dD = Object.defineProperty,
    Sf = Object.getOwnPropertySymbols,
    gD = Object.prototype.hasOwnProperty,
    vD = Object.prototype.propertyIsEnumerable,
    xf = (n, t, r) => t in n ? dD(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    yD = (n, t) => {
        for (var r in t || (t = {})) gD.call(t, r) && xf(n, r, t[r]);
        if (Sf)
            for (var r of Sf(t)) vD.call(t, r) && xf(n, r, t[r]);
        return n
    };
class _D extends TE {
    constructor(t) {
        super(t), this.protocol = "wc", this.version = 2, this.events = new ri.EventEmitter, this.name = q6, this.transportExplicitlyClosed = !1, this.initialized = !1, this.reconnecting = !1, this.connectionStatusPollingInterval = 20, this.staleConnectionErrors = ["socket hang up", "socket stalled"], this.request = async r => {
            this.logger.debug("Publishing Request Payload");
            try {
                return await this.toEstablishConnection(), await this.provider.request(r)
            } catch (s) {
                throw this.logger.debug("Failed to Publish Request"), this.logger.error(s), s
            }
        }, this.core = t.core, this.logger = typeof t.logger < "u" && typeof t.logger != "string" ? Qe.generateChildLogger(t.logger, this.name) : Qe.pino(Qe.getDefaultLoggerOptions({
            level: t.logger || z6
        })), this.messages = new sD(this.logger, t.core), this.subscriber = new pD(this, this.logger), this.publisher = new aD(this, this.logger), this.relayUrl = (t == null ? void 0 : t.relayUrl) || Bp, this.projectId = t.projectId, this.provider = {}
    }
    async init() {
        this.logger.trace("Initialized"), await this.createProvider(), await Promise.all([this.messages.init(), this.subscriber.init()]);
        try {
            await this.transportOpen()
        } catch {
            this.logger.warn(`Connection via ${this.relayUrl} failed, attempting to connect via failover domain ${wf}...`), await this.restartTransport(wf)
        }
        this.registerEventListeners(), this.initialized = !0, setTimeout(async () => {
            this.subscriber.topics.length === 0 && (this.logger.info("No topics subscribed to after init, closing transport"), await this.transportClose(), this.transportExplicitlyClosed = !1)
        }, k6)
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get connected() {
        return this.provider.connection.connected
    }
    get connecting() {
        return this.provider.connection.connecting
    }
    async publish(t, r, s) {
        this.isInitialized(), await this.publisher.publish(t, r, s), await this.recordMessageEvent({
            topic: t,
            message: r,
            publishedAt: Date.now()
        })
    }
    async subscribe(t, r) {
        var s;
        this.isInitialized();
        let o = ((s = this.subscriber.topicMap.get(t)) == null ? void 0 : s[0]) || "";
        return o || (await Promise.all([new Promise(l => {
            this.subscriber.once(ei.created, d => {
                d.topic === t && l()
            })
        }), new Promise(async l => {
            o = await this.subscriber.subscribe(t, r), l()
        })]), o)
    }
    async unsubscribe(t, r) {
        this.isInitialized(), await this.subscriber.unsubscribe(t, r)
    }
    on(t, r) {
        this.events.on(t, r)
    }
    once(t, r) {
        this.events.once(t, r)
    }
    off(t, r) {
        this.events.off(t, r)
    }
    removeListener(t, r) {
        this.events.removeListener(t, r)
    }
    async transportClose() {
        this.transportExplicitlyClosed = !0, this.connected && (await this.provider.disconnect(), this.events.emit(Ct.transport_closed))
    }
    async transportOpen(t) {
        if (this.transportExplicitlyClosed = !1, !this.reconnecting) {
            this.relayUrl = t || this.relayUrl, this.reconnecting = !0;
            try {
                await Promise.all([new Promise(r => {
                    this.initialized || r(), this.subscriber.once(ei.resubscribed, () => {
                        r()
                    })
                }), await Promise.race([new Promise(async (r, s) => {
                    await Ta(this.provider.connect(), 5e3, `Socket stalled when trying to connect to ${this.relayUrl}`).catch(o => s(o)).then(() => r()).finally(() => this.removeListener(Ct.transport_closed, this.rejectTransportOpen))
                }), new Promise(r => this.once(Ct.transport_closed, this.rejectTransportOpen))])])
            } catch (r) {
                this.logger.error(r);
                const s = r;
                if (!this.isConnectionStalled(s.message)) throw r;
                this.events.emit(Ct.transport_closed)
            } finally {
                this.reconnecting = !1
            }
        }
    }
    async restartTransport(t) {
        this.transportExplicitlyClosed || this.reconnecting || (this.relayUrl = t || this.relayUrl, this.connected && await Promise.all([new Promise(r => {
            this.provider.once(ts.disconnect, () => {
                r()
            })
        }), this.transportClose()]), await this.createProvider(), await this.transportOpen())
    }
    isConnectionStalled(t) {
        return this.staleConnectionErrors.some(r => t.includes(r))
    }
    rejectTransportOpen() {
        throw new Error("Attempt to connect to relay via `transportOpen` has stalled. Retrying...")
    }
    async createProvider() {
        const t = await this.core.crypto.signJWT(this.relayUrl);
        this.provider = new Ti(new r3(tw({
            sdkVersion: K6,
            protocol: this.protocol,
            version: this.version,
            relayUrl: this.relayUrl,
            projectId: this.projectId,
            auth: t,
            useOnCloseEvent: !0
        }))), this.registerProviderListeners()
    }
    async recordMessageEvent(t) {
        const {
            topic: r,
            message: s
        } = t;
        await this.messages.set(r, s)
    }
    async shouldIgnoreMessageEvent(t) {
        const {
            topic: r,
            message: s
        } = t;
        return await this.subscriber.isSubscribed(r) ? this.messages.has(r, s) : !0
    }
    async onProviderPayload(t) {
        if (this.logger.debug("Incoming Relay Payload"), this.logger.trace({
                type: "payload",
                direction: "incoming",
                payload: t
            }), nu(t)) {
            if (!t.method.endsWith(H6)) return;
            const r = t.params,
                {
                    topic: s,
                    message: o,
                    publishedAt: l
                } = r.data,
                d = {
                    topic: s,
                    message: o,
                    publishedAt: l
                };
            this.logger.debug("Emitting Relayer Payload"), this.logger.trace(yD({
                type: "event",
                event: r.id
            }, d)), this.events.emit(r.id, d), await this.acknowledgePayload(t), await this.onMessageEvent(d)
        } else su(t) && this.events.emit(Ct.message_ack, t)
    }
    async onMessageEvent(t) {
        await this.shouldIgnoreMessageEvent(t) || (this.events.emit(Ct.message, t), await this.recordMessageEvent(t))
    }
    async acknowledgePayload(t) {
        const r = au(t.id, !0);
        await this.provider.connection.send(r)
    }
    registerProviderListeners() {
        this.provider.on(ts.payload, t => this.onProviderPayload(t)), this.provider.on(ts.connect, () => {
            this.events.emit(Ct.connect)
        }), this.provider.on(ts.disconnect, () => {
            this.onProviderDisconnect()
        }), this.provider.on(ts.error, t => {
            this.logger.error(t), this.events.emit(Ct.error, t)
        })
    }
    registerEventListeners() {
        this.events.on(Ct.connection_stalled, async () => {
            await this.restartTransport()
        })
    }
    onProviderDisconnect() {
        this.events.emit(Ct.disconnect), this.attemptToReconnect()
    }
    attemptToReconnect() {
        this.transportExplicitlyClosed || setTimeout(async () => {
            await this.restartTransport()
        }, ye.toMiliseconds(B6))
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    async toEstablishConnection() {
        if (!this.connected) {
            if (this.connecting) return await new Promise(t => {
                const r = setInterval(() => {
                    this.connected && (clearInterval(r), t())
                }, this.connectionStatusPollingInterval)
            });
            await this.restartTransport()
        }
    }
}
var mD = Object.defineProperty,
    Cf = Object.getOwnPropertySymbols,
    bD = Object.prototype.hasOwnProperty,
    wD = Object.prototype.propertyIsEnumerable,
    Of = (n, t, r) => t in n ? mD(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    Af = (n, t) => {
        for (var r in t || (t = {})) bD.call(t, r) && Of(n, r, t[r]);
        if (Cf)
            for (var r of Cf(t)) wD.call(t, r) && Of(n, r, t[r]);
        return n
    };
class ka extends RE {
    constructor(t, r, s, o = Ni, l = void 0) {
        super(t, r, s, o), this.core = t, this.logger = r, this.name = s, this.map = new Map, this.version = V6, this.cached = [], this.initialized = !1, this.storagePrefix = Ni, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restore(), this.cached.forEach(d => {
                this.getKey && d !== null && !or(d) ? this.map.set(this.getKey(d), d) : Iw(d) ? this.map.set(d.id, d) : Sw(d) && this.map.set(d.topic, d)
            }), this.cached = [], this.initialized = !0)
        }, this.set = async (d, f) => {
            this.isInitialized(), this.map.has(d) ? await this.update(d, f) : (this.logger.debug("Setting value"), this.logger.trace({
                type: "method",
                method: "set",
                key: d,
                value: f
            }), this.map.set(d, f), await this.persist())
        }, this.get = d => (this.isInitialized(), this.logger.debug("Getting value"), this.logger.trace({
            type: "method",
            method: "get",
            key: d
        }), this.getData(d)), this.getAll = d => (this.isInitialized(), d ? this.values.filter(f => Object.keys(d).every(v => n3(f[v], d[v]))) : this.values), this.update = async (d, f) => {
            this.isInitialized(), this.logger.debug("Updating value"), this.logger.trace({
                type: "method",
                method: "update",
                key: d,
                update: f
            });
            const v = Af(Af({}, this.getData(d)), f);
            this.map.set(d, v), await this.persist()
        }, this.delete = async (d, f) => {
            this.isInitialized(), this.map.has(d) && (this.logger.debug("Deleting value"), this.logger.trace({
                type: "method",
                method: "delete",
                key: d,
                reason: f
            }), this.map.delete(d), await this.persist())
        }, this.logger = Qe.generateChildLogger(r, this.name), this.storagePrefix = o, this.getKey = l
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + "//" + this.name
    }
    get length() {
        return this.map.size
    }
    get keys() {
        return Array.from(this.map.keys())
    }
    get values() {
        return Array.from(this.map.values())
    }
    async setDataStore(t) {
        await this.core.storage.setItem(this.storageKey, t)
    }
    async getDataStore() {
        return await this.core.storage.getItem(this.storageKey)
    }
    getData(t) {
        const r = this.map.get(t);
        if (!r) {
            const {
                message: s
            } = ue("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw this.logger.error(s), new Error(s)
        }
        return r
    }
    async persist() {
        await this.setDataStore(this.values)
    }
    async restore() {
        try {
            const t = await this.getDataStore();
            if (typeof t > "u" || !t.length) return;
            if (this.map.size) {
                const {
                    message: r
                } = ue("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(r), new Error(r)
            }
            this.cached = t, this.logger.debug(`Successfully Restored value for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                value: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore value for ${this.name}`), this.logger.error(t)
        }
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class ED {
    constructor(t, r) {
        this.core = t, this.logger = r, this.name = X6, this.version = Z6, this.events = new ru, this.initialized = !1, this.storagePrefix = Ni, this.ignoredPayloadTypes = [tn], this.registeredMethods = [], this.init = async () => {
            this.initialized || (await this.pairings.init(), await this.cleanup(), this.registerRelayerEvents(), this.registerExpirerEvents(), this.initialized = !0, this.logger.trace("Initialized"))
        }, this.register = ({
            methods: s
        }) => {
            this.isInitialized(), this.registeredMethods = [...new Set([...this.registeredMethods, ...s])]
        }, this.create = async () => {
            this.isInitialized();
            const s = Gc(),
                o = await this.core.crypto.setSymKey(s),
                l = kr(ye.FIVE_MINUTES),
                d = {
                    protocol: Hp
                },
                f = {
                    topic: o,
                    expiry: l,
                    relay: d,
                    active: !1
                },
                v = dw({
                    protocol: this.core.protocol,
                    version: this.core.version,
                    topic: o,
                    symKey: s,
                    relay: d
                });
            return await this.pairings.set(o, f), await this.core.relayer.subscribe(o), this.core.expirer.set(o, l), {
                topic: o,
                uri: v
            }
        }, this.pair = async s => {
            this.isInitialized(), this.isValidPair(s);
            const {
                topic: o,
                symKey: l,
                relay: d
            } = lw(s.uri);
            if (this.pairings.keys.includes(o)) throw new Error(`Pairing already exists: ${o}`);
            if (this.core.crypto.hasKeys(o)) throw new Error(`Keychain already exists: ${o}`);
            const f = kr(ye.FIVE_MINUTES),
                v = {
                    topic: o,
                    relay: d,
                    expiry: f,
                    active: !1
                };
            return await this.pairings.set(o, v), await this.core.crypto.setSymKey(l, o), await this.core.relayer.subscribe(o, {
                relay: d
            }), this.core.expirer.set(o, f), s.activatePairing && await this.activate({
                topic: o
            }), v
        }, this.activate = async ({
            topic: s
        }) => {
            this.isInitialized();
            const o = kr(ye.THIRTY_DAYS);
            await this.pairings.update(s, {
                active: !0,
                expiry: o
            }), this.core.expirer.set(s, o)
        }, this.ping = async s => {
            this.isInitialized(), await this.isValidPing(s);
            const {
                topic: o
            } = s;
            if (this.pairings.keys.includes(o)) {
                const l = await this.sendRequest(o, "wc_pairingPing", {}),
                    {
                        done: d,
                        resolve: f,
                        reject: v
                    } = xn();
                this.events.once(qt("pairing_ping", l), ({
                    error: g
                }) => {
                    g ? v(g) : f()
                }), await d()
            }
        }, this.updateExpiry = async ({
            topic: s,
            expiry: o
        }) => {
            this.isInitialized(), await this.pairings.update(s, {
                expiry: o
            })
        }, this.updateMetadata = async ({
            topic: s,
            metadata: o
        }) => {
            this.isInitialized(), await this.pairings.update(s, {
                peerMetadata: o
            })
        }, this.getPairings = () => (this.isInitialized(), this.pairings.values), this.disconnect = async s => {
            this.isInitialized(), await this.isValidDisconnect(s);
            const {
                topic: o
            } = s;
            this.pairings.keys.includes(o) && (await this.sendRequest(o, "wc_pairingDelete", Tt("USER_DISCONNECTED")), await this.deletePairing(o))
        }, this.sendRequest = async (s, o, l) => {
            const d = ou(o, l),
                f = await this.core.crypto.encode(s, d),
                v = rs[o].req;
            return this.core.history.set(s, d), this.core.relayer.publish(s, f, v), d.id
        }, this.sendResult = async (s, o, l) => {
            const d = au(s, l),
                f = await this.core.crypto.encode(o, d),
                v = await this.core.history.get(o, s),
                g = rs[v.request.method].res;
            await this.core.relayer.publish(o, f, g), await this.core.history.resolve(d)
        }, this.sendError = async (s, o, l) => {
            const d = iu(s, l),
                f = await this.core.crypto.encode(o, d),
                v = await this.core.history.get(o, s),
                g = rs[v.request.method] ? rs[v.request.method].res : rs.unregistered_method.res;
            await this.core.relayer.publish(o, f, g), await this.core.history.resolve(d)
        }, this.deletePairing = async (s, o) => {
            await this.core.relayer.unsubscribe(s), await Promise.all([this.pairings.delete(s, Tt("USER_DISCONNECTED")), this.core.crypto.deleteSymKey(s), o ? Promise.resolve() : this.core.expirer.del(s)])
        }, this.cleanup = async () => {
            const s = this.pairings.getAll().filter(o => Ai(o.expiry));
            await Promise.all(s.map(o => this.deletePairing(o.topic)))
        }, this.onRelayEventRequest = s => {
            const {
                topic: o,
                payload: l
            } = s, d = l.method;
            if (this.pairings.keys.includes(o)) switch (d) {
                case "wc_pairingPing":
                    return this.onPairingPingRequest(o, l);
                case "wc_pairingDelete":
                    return this.onPairingDeleteRequest(o, l);
                default:
                    return this.onUnknownRpcMethodRequest(o, l)
            }
        }, this.onRelayEventResponse = async s => {
            const {
                topic: o,
                payload: l
            } = s, d = (await this.core.history.get(o, l.id)).request.method;
            if (this.pairings.keys.includes(o)) switch (d) {
                case "wc_pairingPing":
                    return this.onPairingPingResponse(o, l);
                default:
                    return this.onUnknownRpcMethodResponse(d)
            }
        }, this.onPairingPingRequest = async (s, o) => {
            const {
                id: l
            } = o;
            try {
                this.isValidPing({
                    topic: s
                }), await this.sendResult(l, s, !0), this.events.emit("pairing_ping", {
                    id: l,
                    topic: s
                })
            } catch (d) {
                await this.sendError(l, s, d), this.logger.error(d)
            }
        }, this.onPairingPingResponse = (s, o) => {
            const {
                id: l
            } = o;
            setTimeout(() => {
                Oi(o) ? this.events.emit(qt("pairing_ping", l), {}) : gi(o) && this.events.emit(qt("pairing_ping", l), {
                    error: o.error
                })
            }, 500)
        }, this.onPairingDeleteRequest = async (s, o) => {
            const {
                id: l
            } = o;
            try {
                this.isValidDisconnect({
                    topic: s
                }), await this.deletePairing(s), this.events.emit("pairing_delete", {
                    id: l,
                    topic: s
                })
            } catch (d) {
                await this.sendError(l, s, d), this.logger.error(d)
            }
        }, this.onUnknownRpcMethodRequest = async (s, o) => {
            const {
                id: l,
                method: d
            } = o;
            try {
                if (this.registeredMethods.includes(d)) return;
                const f = Tt("WC_METHOD_UNSUPPORTED", d);
                await this.sendError(l, s, f), this.logger.error(f)
            } catch (f) {
                await this.sendError(l, s, f), this.logger.error(f)
            }
        }, this.onUnknownRpcMethodResponse = s => {
            this.registeredMethods.includes(s) || this.logger.error(Tt("WC_METHOD_UNSUPPORTED", s))
        }, this.isValidPair = s => {
            if (!yr(s)) {
                const {
                    message: o
                } = ue("MISSING_OR_INVALID", `pair() params: ${s}`);
                throw new Error(o)
            }
            if (!Dw(s.uri)) {
                const {
                    message: o
                } = ue("MISSING_OR_INVALID", `pair() uri: ${s.uri}`);
                throw new Error(o)
            }
        }, this.isValidPing = async s => {
            if (!yr(s)) {
                const {
                    message: l
                } = ue("MISSING_OR_INVALID", `ping() params: ${s}`);
                throw new Error(l)
            }
            const {
                topic: o
            } = s;
            await this.isValidPairingTopic(o)
        }, this.isValidDisconnect = async s => {
            if (!yr(s)) {
                const {
                    message: l
                } = ue("MISSING_OR_INVALID", `disconnect() params: ${s}`);
                throw new Error(l)
            }
            const {
                topic: o
            } = s;
            await this.isValidPairingTopic(o)
        }, this.isValidPairingTopic = async s => {
            if (!Gt(s, !1)) {
                const {
                    message: o
                } = ue("MISSING_OR_INVALID", `pairing topic should be a string: ${s}`);
                throw new Error(o)
            }
            if (!this.pairings.keys.includes(s)) {
                const {
                    message: o
                } = ue("NO_MATCHING_KEY", `pairing topic doesn't exist: ${s}`);
                throw new Error(o)
            }
            if (Ai(this.pairings.get(s).expiry)) {
                await this.deletePairing(s);
                const {
                    message: o
                } = ue("EXPIRED", `pairing topic: ${s}`);
                throw new Error(o)
            }
        }, this.core = t, this.logger = Qe.generateChildLogger(r, this.name), this.pairings = new ka(this.core, this.logger, this.name, this.storagePrefix)
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    registerRelayerEvents() {
        this.core.relayer.on(Ct.message, async t => {
            const {
                topic: r,
                message: s
            } = t;
            if (this.ignoredPayloadTypes.includes(this.core.crypto.getPayloadType(s))) return;
            const o = await this.core.crypto.decode(r, s);
            nu(o) ? (this.core.history.set(r, o), this.onRelayEventRequest({
                topic: r,
                payload: o
            })) : su(o) && (await this.core.history.resolve(o), await this.onRelayEventResponse({
                topic: r,
                payload: o
            }), this.core.history.delete(r, o.id))
        })
    }
    registerExpirerEvents() {
        this.core.expirer.on(Lr.expired, async t => {
            const {
                topic: r
            } = _p(t.target);
            r && this.pairings.keys.includes(r) && (await this.deletePairing(r, !0), this.events.emit("pairing_expire", {
                topic: r
            }))
        })
    }
}
class DD extends AE {
    constructor(t, r) {
        super(t, r), this.core = t, this.logger = r, this.records = new Map, this.events = new ri.EventEmitter, this.name = Q6, this.version = eD, this.cached = [], this.initialized = !1, this.storagePrefix = Ni, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restore(), this.cached.forEach(s => this.records.set(s.id, s)), this.cached = [], this.registerEventListeners(), this.initialized = !0)
        }, this.set = (s, o, l) => {
            if (this.isInitialized(), this.logger.debug("Setting JSON-RPC request history record"), this.logger.trace({
                    type: "method",
                    method: "set",
                    topic: s,
                    request: o,
                    chainId: l
                }), this.records.has(o.id)) return;
            const d = {
                id: o.id,
                topic: s,
                request: {
                    method: o.method,
                    params: o.params || null
                },
                chainId: l,
                expiry: kr(ye.THIRTY_DAYS)
            };
            this.records.set(d.id, d), this.events.emit(Qr.created, d)
        }, this.resolve = async s => {
            if (this.isInitialized(), this.logger.debug("Updating JSON-RPC response history record"), this.logger.trace({
                    type: "method",
                    method: "update",
                    response: s
                }), !this.records.has(s.id)) return;
            const o = await this.getRecord(s.id);
            typeof o.response > "u" && (o.response = gi(s) ? {
                error: s.error
            } : {
                result: s.result
            }, this.records.set(o.id, o), this.events.emit(Qr.updated, o))
        }, this.get = async (s, o) => (this.isInitialized(), this.logger.debug("Getting record"), this.logger.trace({
            type: "method",
            method: "get",
            topic: s,
            id: o
        }), await this.getRecord(o)), this.delete = (s, o) => {
            this.isInitialized(), this.logger.debug("Deleting record"), this.logger.trace({
                type: "method",
                method: "delete",
                id: o
            }), this.values.forEach(l => {
                if (l.topic === s) {
                    if (typeof o < "u" && l.id !== o) return;
                    this.records.delete(l.id), this.events.emit(Qr.deleted, l)
                }
            })
        }, this.exists = async (s, o) => (this.isInitialized(), this.records.has(o) ? (await this.getRecord(o)).topic === s : !1), this.on = (s, o) => {
            this.events.on(s, o)
        }, this.once = (s, o) => {
            this.events.once(s, o)
        }, this.off = (s, o) => {
            this.events.off(s, o)
        }, this.removeListener = (s, o) => {
            this.events.removeListener(s, o)
        }, this.logger = Qe.generateChildLogger(r, this.name)
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + "//" + this.name
    }
    get size() {
        return this.records.size
    }
    get keys() {
        return Array.from(this.records.keys())
    }
    get values() {
        return Array.from(this.records.values())
    }
    get pending() {
        const t = [];
        return this.values.forEach(r => {
            if (typeof r.response < "u") return;
            const s = {
                topic: r.topic,
                request: ou(r.request.method, r.request.params, r.id),
                chainId: r.chainId
            };
            return t.push(s)
        }), t
    }
    async setJsonRpcRecords(t) {
        await this.core.storage.setItem(this.storageKey, t)
    }
    async getJsonRpcRecords() {
        return await this.core.storage.getItem(this.storageKey)
    }
    getRecord(t) {
        this.isInitialized();
        const r = this.records.get(t);
        if (!r) {
            const {
                message: s
            } = ue("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw new Error(s)
        }
        return r
    }
    async persist() {
        await this.setJsonRpcRecords(this.values), this.events.emit(Qr.sync)
    }
    async restore() {
        try {
            const t = await this.getJsonRpcRecords();
            if (typeof t > "u" || !t.length) return;
            if (this.records.size) {
                const {
                    message: r
                } = ue("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(r), new Error(r)
            }
            this.cached = t, this.logger.debug(`Successfully Restored records for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                records: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore records for ${this.name}`), this.logger.error(t)
        }
    }
    registerEventListeners() {
        this.events.on(Qr.created, t => {
            const r = Qr.created;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                record: t
            }), this.persist()
        }), this.events.on(Qr.updated, t => {
            const r = Qr.updated;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                record: t
            }), this.persist()
        }), this.events.on(Qr.deleted, t => {
            const r = Qr.deleted;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                record: t
            }), this.persist()
        }), this.core.heartbeat.on(Nn.HEARTBEAT_EVENTS.pulse, () => {
            this.cleanup()
        })
    }
    cleanup() {
        try {
            this.records.forEach(t => {
                ye.toMiliseconds(t.expiry || 0) - Date.now() <= 0 && (this.logger.info(`Deleting expired history log: ${t.id}`), this.delete(t.topic, t.id))
            })
        } catch (t) {
            this.logger.warn(t)
        }
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class ID extends UE {
    constructor(t, r) {
        super(t, r), this.core = t, this.logger = r, this.expirations = new Map, this.events = new ri.EventEmitter, this.name = tD, this.version = rD, this.cached = [], this.initialized = !1, this.storagePrefix = Ni, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restore(), this.cached.forEach(s => this.expirations.set(s.target, s)), this.cached = [], this.registerEventListeners(), this.initialized = !0)
        }, this.has = s => {
            try {
                const o = this.formatTarget(s);
                return typeof this.getExpiration(o) < "u"
            } catch {
                return !1
            }
        }, this.set = (s, o) => {
            this.isInitialized();
            const l = this.formatTarget(s),
                d = {
                    target: l,
                    expiry: o
                };
            this.expirations.set(l, d), this.checkExpiry(l, d), this.events.emit(Lr.created, {
                target: l,
                expiration: d
            })
        }, this.get = s => {
            this.isInitialized();
            const o = this.formatTarget(s);
            return this.getExpiration(o)
        }, this.del = s => {
            if (this.isInitialized(), this.has(s)) {
                const o = this.formatTarget(s),
                    l = this.getExpiration(o);
                this.expirations.delete(o), this.events.emit(Lr.deleted, {
                    target: o,
                    expiration: l
                })
            }
        }, this.on = (s, o) => {
            this.events.on(s, o)
        }, this.once = (s, o) => {
            this.events.once(s, o)
        }, this.off = (s, o) => {
            this.events.off(s, o)
        }, this.removeListener = (s, o) => {
            this.events.removeListener(s, o)
        }, this.logger = Qe.generateChildLogger(r, this.name)
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + "//" + this.name
    }
    get length() {
        return this.expirations.size
    }
    get keys() {
        return Array.from(this.expirations.keys())
    }
    get values() {
        return Array.from(this.expirations.values())
    }
    formatTarget(t) {
        if (typeof t == "string") return rw(t);
        if (typeof t == "number") return iw(t);
        const {
            message: r
        } = ue("UNKNOWN_TYPE", `Target type: ${typeof t}`);
        throw new Error(r)
    }
    async setExpirations(t) {
        await this.core.storage.setItem(this.storageKey, t)
    }
    async getExpirations() {
        return await this.core.storage.getItem(this.storageKey)
    }
    async persist() {
        await this.setExpirations(this.values), this.events.emit(Lr.sync)
    }
    async restore() {
        try {
            const t = await this.getExpirations();
            if (typeof t > "u" || !t.length) return;
            if (this.expirations.size) {
                const {
                    message: r
                } = ue("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(r), new Error(r)
            }
            this.cached = t, this.logger.debug(`Successfully Restored expirations for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                expirations: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore expirations for ${this.name}`), this.logger.error(t)
        }
    }
    getExpiration(t) {
        const r = this.expirations.get(t);
        if (!r) {
            const {
                message: s
            } = ue("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw this.logger.error(s), new Error(s)
        }
        return r
    }
    checkExpiry(t, r) {
        const {
            expiry: s
        } = r;
        ye.toMiliseconds(s) - Date.now() <= 0 && this.expire(t, r)
    }
    expire(t, r) {
        this.expirations.delete(t), this.events.emit(Lr.expired, {
            target: t,
            expiration: r
        })
    }
    checkExpirations() {
        this.core.relayer.connected && this.expirations.forEach((t, r) => this.checkExpiry(r, t))
    }
    registerEventListeners() {
        this.core.heartbeat.on(Nn.HEARTBEAT_EVENTS.pulse, () => this.checkExpirations()), this.events.on(Lr.created, t => {
            const r = Lr.created;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                data: t
            }), this.persist()
        }), this.events.on(Lr.expired, t => {
            const r = Lr.expired;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                data: t
            }), this.persist()
        }), this.events.on(Lr.deleted, t => {
            const r = Lr.deleted;
            this.logger.info(`Emitting ${r}`), this.logger.debug({
                type: "event",
                event: r,
                data: t
            }), this.persist()
        })
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class SD extends $E {
    constructor(t, r) {
        super(t, r), this.projectId = t, this.logger = r, this.name = Nc, this.initialized = !1, this.init = async s => {
            dp() || !gu() || (this.verifyUrl = (s == null ? void 0 : s.verifyUrl) || Ef, await this.createIframe())
        }, this.register = async s => {
            var o;
            if (this.initialized || await this.init(), !!this.iframe) try {
                (o = this.iframe.contentWindow) == null || o.postMessage(s.attestationId, this.verifyUrl), this.logger.info(`postMessage sent: ${s.attestationId} ${this.verifyUrl}`)
            } catch {}
        }, this.resolve = async s => {
            var o;
            if (this.isDevEnv) return "";
            this.logger.info(`resolving attestation: ${s.attestationId}`);
            const l = this.startAbortTimer(ye.FIVE_SECONDS),
                d = await fetch(`${this.verifyUrl}/attestation/${s.attestationId}`, {
                    signal: this.abortController.signal
                });
            return clearTimeout(l), d.status === 200 ? (o = await d.json()) == null ? void 0 : o.origin : ""
        }, this.createIframe = async () => {
            try {
                await Promise.race([new Promise((s, o) => {
                    if (document.getElementById(Nc)) return s();
                    const l = document.createElement("iframe");
                    l.setAttribute("id", Nc), l.setAttribute("src", `${this.verifyUrl}/${this.projectId}`), l.style.display = "none", l.addEventListener("load", () => {
                        this.initialized = !0, s()
                    }), l.addEventListener("error", d => {
                        o(d)
                    }), document.body.append(l), this.iframe = l
                }), new Promise(s => {
                    setTimeout(() => s("iframe load timeout"), ye.toMiliseconds(ye.ONE_SECOND / 2))
                })])
            } catch (s) {
                this.logger.error(`Verify iframe failed to load: ${this.verifyUrl}`), this.logger.error(s)
            }
        }, this.logger = Qe.generateChildLogger(r, this.name), this.verifyUrl = Ef, this.abortController = new AbortController, this.isDevEnv = du() && {}.IS_VITEST
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    startAbortTimer(t) {
        return setTimeout(() => this.abortController.abort(), ye.toMiliseconds(t))
    }
}
var xD = Object.defineProperty,
    Pf = Object.getOwnPropertySymbols,
    CD = Object.prototype.hasOwnProperty,
    OD = Object.prototype.propertyIsEnumerable,
    Nf = (n, t, r) => t in n ? xD(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    Tf = (n, t) => {
        for (var r in t || (t = {})) CD.call(t, r) && Nf(n, r, t[r]);
        if (Pf)
            for (var r of Pf(t)) OD.call(t, r) && Nf(n, r, t[r]);
        return n
    };
class wu extends OE {
    constructor(t) {
        super(t), this.protocol = qp, this.version = A6, this.name = bu, this.events = new ri.EventEmitter, this.initialized = !1, this.on = (s, o) => this.events.on(s, o), this.once = (s, o) => this.events.once(s, o), this.off = (s, o) => this.events.off(s, o), this.removeListener = (s, o) => this.events.removeListener(s, o), this.projectId = t == null ? void 0 : t.projectId, this.relayUrl = (t == null ? void 0 : t.relayUrl) || Bp;
        const r = typeof(t == null ? void 0 : t.logger) < "u" && typeof(t == null ? void 0 : t.logger) != "string" ? t.logger : Qe.pino(Qe.getDefaultLoggerOptions({
            level: (t == null ? void 0 : t.logger) || P6.logger
        }));
        this.logger = Qe.generateChildLogger(r, this.name), this.heartbeat = new Nn.HeartBeat, this.crypto = new nD(this, this.logger, t == null ? void 0 : t.keychain), this.history = new DD(this, this.logger), this.expirer = new ID(this, this.logger), this.storage = t != null && t.storage ? t.storage : new mE(Tf(Tf({}, N6), t == null ? void 0 : t.storageOptions)), this.relayer = new _D({
            core: this,
            logger: this.logger,
            relayUrl: this.relayUrl,
            projectId: this.projectId
        }), this.pairing = new ED(this, this.logger), this.verify = new SD(this.projectId || "", this.logger)
    }
    static async init(t) {
        const r = new wu(t);
        await r.initialize();
        const s = await r.crypto.getClientId();
        return await r.storage.setItem(G6, s), r
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    async start() {
        this.initialized || await this.initialize()
    }
    async initialize() {
        this.logger.trace("Initialized");
        try {
            await this.crypto.init(), await this.history.init(), await this.expirer.init(), await this.relayer.init(), await this.heartbeat.init(), await this.pairing.init(), this.initialized = !0, this.logger.info("Core Initialization Success")
        } catch (t) {
            throw this.logger.warn(`Core Initialization Failure at epoch ${Date.now()}`, t), this.logger.error(t.message), t
        }
    }
}
const AD = wu,
    Kp = "wc",
    kp = 2,
    Vp = "client",
    Eu = `${Kp}@${kp}:${Vp}:`,
    Rc = {
        name: Vp,
        logger: "error",
        controller: !1,
        relayUrl: "wss://relay.walletconnect.com"
    },
    PD = "WALLETCONNECT_DEEPLINK_CHOICE",
    ND = "proposal",
    Gp = "Proposal expired",
    TD = "session",
    wa = ye.SEVEN_DAYS,
    RD = "engine",
    ns = {
        wc_sessionPropose: {
            req: {
                ttl: ye.FIVE_MINUTES,
                prompt: !0,
                tag: 1100
            },
            res: {
                ttl: ye.FIVE_MINUTES,
                prompt: !1,
                tag: 1101
            }
        },
        wc_sessionSettle: {
            req: {
                ttl: ye.FIVE_MINUTES,
                prompt: !1,
                tag: 1102
            },
            res: {
                ttl: ye.FIVE_MINUTES,
                prompt: !1,
                tag: 1103
            }
        },
        wc_sessionUpdate: {
            req: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1104
            },
            res: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1105
            }
        },
        wc_sessionExtend: {
            req: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1106
            },
            res: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1107
            }
        },
        wc_sessionRequest: {
            req: {
                ttl: ye.FIVE_MINUTES,
                prompt: !0,
                tag: 1108
            },
            res: {
                ttl: ye.FIVE_MINUTES,
                prompt: !1,
                tag: 1109
            }
        },
        wc_sessionEvent: {
            req: {
                ttl: ye.FIVE_MINUTES,
                prompt: !0,
                tag: 1110
            },
            res: {
                ttl: ye.FIVE_MINUTES,
                prompt: !1,
                tag: 1111
            }
        },
        wc_sessionDelete: {
            req: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1112
            },
            res: {
                ttl: ye.ONE_DAY,
                prompt: !1,
                tag: 1113
            }
        },
        wc_sessionPing: {
            req: {
                ttl: ye.THIRTY_SECONDS,
                prompt: !1,
                tag: 1114
            },
            res: {
                ttl: ye.THIRTY_SECONDS,
                prompt: !1,
                tag: 1115
            }
        }
    },
    Fc = {
        min: ye.FIVE_MINUTES,
        max: ye.SEVEN_DAYS
    },
    FD = "request",
    UD = ["wc_sessionPropose", "wc_sessionRequest", "wc_authRequest"];
var $D = Object.defineProperty,
    LD = Object.defineProperties,
    MD = Object.getOwnPropertyDescriptors,
    Rf = Object.getOwnPropertySymbols,
    jD = Object.prototype.hasOwnProperty,
    zD = Object.prototype.propertyIsEnumerable,
    Ff = (n, t, r) => t in n ? $D(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    $r = (n, t) => {
        for (var r in t || (t = {})) jD.call(t, r) && Ff(n, r, t[r]);
        if (Rf)
            for (var r of Rf(t)) zD.call(t, r) && Ff(n, r, t[r]);
        return n
    },
    Uc = (n, t) => LD(n, MD(t));
class qD extends ME {
    constructor(t) {
        super(t), this.name = RD, this.events = new ru, this.initialized = !1, this.ignoredPayloadTypes = [tn], this.init = async () => {
            this.initialized || (await this.cleanup(), this.registerRelayerEvents(), this.registerExpirerEvents(), this.client.core.pairing.register({
                methods: Object.keys(ns)
            }), this.initialized = !0)
        }, this.connect = async r => {
            this.isInitialized();
            const s = Uc($r({}, r), {
                requiredNamespaces: r.requiredNamespaces || {},
                optionalNamespaces: r.optionalNamespaces || {}
            });
            await this.isValidConnect(s);
            const {
                pairingTopic: o,
                requiredNamespaces: l,
                optionalNamespaces: d,
                sessionProperties: f,
                relays: v
            } = s;
            let g = o,
                b, S = !1;
            if (g && (S = this.client.core.pairing.pairings.get(g).active), !g || !S) {
                const {
                    topic: L,
                    uri: I
                } = await this.client.core.pairing.create();
                g = L, b = I
            }
            const O = await this.client.core.crypto.generateKeyPair(),
                P = $r({
                    requiredNamespaces: l,
                    optionalNamespaces: d,
                    relays: v ? ? [{
                        protocol: Hp
                    }],
                    proposer: {
                        publicKey: O,
                        metadata: this.client.metadata
                    }
                }, f && {
                    sessionProperties: f
                }),
                {
                    reject: N,
                    resolve: H,
                    done: G
                } = xn(ye.FIVE_MINUTES, Gp);
            if (this.events.once(qt("session_connect"), async ({
                    error: L,
                    session: I
                }) => {
                    if (L) N(L);
                    else if (I) {
                        I.self.publicKey = O;
                        const C = Uc($r({}, I), {
                            requiredNamespaces: I.requiredNamespaces,
                            optionalNamespaces: I.optionalNamespaces
                        });
                        await this.client.session.set(I.topic, C), await this.setExpiry(I.topic, I.expiry), g && await this.client.core.pairing.updateMetadata({
                            topic: g,
                            metadata: I.peer.metadata
                        }), H(C)
                    }
                }), !g) {
                const {
                    message: L
                } = ue("NO_MATCHING_KEY", `connect() pairing topic: ${g}`);
                throw new Error(L)
            }
            const ie = await this.sendRequest(g, "wc_sessionPropose", P),
                T = kr(ye.FIVE_MINUTES);
            return await this.setProposal(ie, $r({
                id: ie,
                expiry: T
            }, P)), {
                uri: b,
                approval: G
            }
        }, this.pair = async r => (this.isInitialized(), await this.client.core.pairing.pair(r)), this.approve = async r => {
            this.isInitialized(), await this.isValidApprove(r);
            const {
                id: s,
                relayProtocol: o,
                namespaces: l,
                sessionProperties: d
            } = r, f = this.client.proposal.get(s);
            let {
                pairingTopic: v,
                proposer: g,
                requiredNamespaces: b,
                optionalNamespaces: S
            } = f;
            v = v || "", On(b) || (b = _w(l, "approve()"));
            const O = await this.client.core.crypto.generateKeyPair(),
                P = g.publicKey,
                N = await this.client.core.crypto.generateSharedKey(O, P);
            v && s && (await this.client.core.pairing.updateMetadata({
                topic: v,
                metadata: g.metadata
            }), await this.sendResult(s, v, {
                relay: {
                    protocol: o ? ? "irn"
                },
                responderPublicKey: O
            }), await this.client.proposal.delete(s, Tt("USER_DISCONNECTED")), await this.client.core.pairing.activate({
                topic: v
            }));
            const H = $r({
                relay: {
                    protocol: o ? ? "irn"
                },
                namespaces: l,
                requiredNamespaces: b,
                optionalNamespaces: S,
                pairingTopic: v,
                controller: {
                    publicKey: O,
                    metadata: this.client.metadata
                },
                expiry: kr(wa)
            }, d && {
                sessionProperties: d
            });
            await this.client.core.relayer.subscribe(N), await this.sendRequest(N, "wc_sessionSettle", H);
            const G = Uc($r({}, H), {
                topic: N,
                pairingTopic: v,
                acknowledged: !1,
                self: H.controller,
                peer: {
                    publicKey: g.publicKey,
                    metadata: g.metadata
                },
                controller: O
            });
            return await this.client.session.set(N, G), await this.setExpiry(N, kr(wa)), {
                topic: N,
                acknowledged: () => new Promise(ie => setTimeout(() => ie(this.client.session.get(N)), 500))
            }
        }, this.reject = async r => {
            this.isInitialized(), await this.isValidReject(r);
            const {
                id: s,
                reason: o
            } = r, {
                pairingTopic: l
            } = this.client.proposal.get(s);
            l && (await this.sendError(s, l, o), await this.client.proposal.delete(s, Tt("USER_DISCONNECTED")))
        }, this.update = async r => {
            this.isInitialized(), await this.isValidUpdate(r);
            const {
                topic: s,
                namespaces: o
            } = r, l = await this.sendRequest(s, "wc_sessionUpdate", {
                namespaces: o
            }), {
                done: d,
                resolve: f,
                reject: v
            } = xn();
            return this.events.once(qt("session_update", l), ({
                error: g
            }) => {
                g ? v(g) : f()
            }), await this.client.session.update(s, {
                namespaces: o
            }), {
                acknowledged: d
            }
        }, this.extend = async r => {
            this.isInitialized(), await this.isValidExtend(r);
            const {
                topic: s
            } = r, o = await this.sendRequest(s, "wc_sessionExtend", {}), {
                done: l,
                resolve: d,
                reject: f
            } = xn();
            return this.events.once(qt("session_extend", o), ({
                error: v
            }) => {
                v ? f(v) : d()
            }), await this.setExpiry(s, kr(wa)), {
                acknowledged: l
            }
        }, this.request = async r => {
            this.isInitialized(), await this.isValidRequest(r);
            const {
                chainId: s,
                request: o,
                topic: l,
                expiry: d
            } = r, f = await this.sendRequest(l, "wc_sessionRequest", {
                request: o,
                chainId: s
            }, d), {
                done: v,
                resolve: g,
                reject: b
            } = xn(d);
            this.events.once(qt("session_request", f), ({
                error: O,
                result: P
            }) => {
                O ? b(O) : g(P)
            }), this.client.events.emit("session_request_sent", {
                topic: l,
                request: o,
                chainId: s,
                id: f
            });
            const S = await this.client.core.storage.getItem(PD);
            return nw({
                id: f,
                topic: l,
                wcDeepLink: S
            }), await v()
        }, this.respond = async r => {
            this.isInitialized(), await this.isValidRespond(r);
            const {
                topic: s,
                response: o
            } = r, {
                id: l
            } = o;
            Oi(o) ? await this.sendResult(l, s, o.result) : gi(o) && await this.sendError(l, s, o.error), this.deletePendingSessionRequest(r.response.id, {
                message: "fulfilled",
                code: 0
            })
        }, this.ping = async r => {
            this.isInitialized(), await this.isValidPing(r);
            const {
                topic: s
            } = r;
            if (this.client.session.keys.includes(s)) {
                const o = await this.sendRequest(s, "wc_sessionPing", {}),
                    {
                        done: l,
                        resolve: d,
                        reject: f
                    } = xn();
                this.events.once(qt("session_ping", o), ({
                    error: v
                }) => {
                    v ? f(v) : d()
                }), await l()
            } else this.client.core.pairing.pairings.keys.includes(s) && await this.client.core.pairing.ping({
                topic: s
            })
        }, this.emit = async r => {
            this.isInitialized(), await this.isValidEmit(r);
            const {
                topic: s,
                event: o,
                chainId: l
            } = r;
            await this.sendRequest(s, "wc_sessionEvent", {
                event: o,
                chainId: l
            })
        }, this.disconnect = async r => {
            this.isInitialized(), await this.isValidDisconnect(r);
            const {
                topic: s
            } = r;
            if (this.client.session.keys.includes(s)) {
                const o = Vf().toString();
                let l;
                const d = f => {
                    (f == null ? void 0 : f.id.toString()) === o && (this.client.core.relayer.events.removeListener(Ct.message_ack, d), l())
                };
                await Promise.all([new Promise(f => {
                    l = f, this.client.core.relayer.on(Ct.message_ack, d)
                }), this.sendRequest(s, "wc_sessionDelete", Tt("USER_DISCONNECTED"), void 0, o)]), await this.deleteSession(s)
            } else await this.client.core.pairing.disconnect({
                topic: s
            })
        }, this.find = r => (this.isInitialized(), this.client.session.getAll().filter(s => ww(s, r))), this.getPendingSessionRequests = () => (this.isInitialized(), this.client.pendingRequest.getAll()), this.cleanupDuplicatePairings = async r => {
            if (r.pairingTopic) try {
                const s = this.client.core.pairing.pairings.get(r.pairingTopic),
                    o = this.client.core.pairing.pairings.getAll().filter(l => {
                        var d, f;
                        return ((d = l.peerMetadata) == null ? void 0 : d.url) && ((f = l.peerMetadata) == null ? void 0 : f.url) === r.peer.metadata.url && l.topic && l.topic !== s.topic
                    });
                if (o.length === 0) return;
                this.client.logger.info(`Cleaning up ${o.length} duplicate pairing(s)`), await Promise.all(o.map(l => this.client.core.pairing.disconnect({
                    topic: l.topic
                }))), this.client.logger.info("Duplicate pairings clean up finished")
            } catch (s) {
                this.client.logger.error(s)
            }
        }, this.deleteSession = async (r, s) => {
            const {
                self: o
            } = this.client.session.get(r);
            await this.client.core.relayer.unsubscribe(r), this.client.session.delete(r, Tt("USER_DISCONNECTED")), this.client.core.crypto.keychain.has(o.publicKey) && await this.client.core.crypto.deleteKeyPair(o.publicKey), this.client.core.crypto.keychain.has(r) && await this.client.core.crypto.deleteSymKey(r), s || this.client.core.expirer.del(r)
        }, this.deleteProposal = async (r, s) => {
            await Promise.all([this.client.proposal.delete(r, Tt("USER_DISCONNECTED")), s ? Promise.resolve() : this.client.core.expirer.del(r)])
        }, this.deletePendingSessionRequest = async (r, s, o = !1) => {
            await Promise.all([this.client.pendingRequest.delete(r, s), o ? Promise.resolve() : this.client.core.expirer.del(r)])
        }, this.setExpiry = async (r, s) => {
            this.client.session.keys.includes(r) && await this.client.session.update(r, {
                expiry: s
            }), this.client.core.expirer.set(r, s)
        }, this.setProposal = async (r, s) => {
            await this.client.proposal.set(r, s), this.client.core.expirer.set(r, s.expiry)
        }, this.setPendingSessionRequest = async r => {
            const s = ns.wc_sessionRequest.req.ttl,
                {
                    id: o,
                    topic: l,
                    params: d
                } = r;
            await this.client.pendingRequest.set(o, {
                id: o,
                topic: l,
                params: d
            }), s && this.client.core.expirer.set(o, kr(s))
        }, this.sendRequest = async (r, s, o, l, d) => {
            const f = ou(s, o);
            if (gu() && UD.includes(s)) {
                const b = Cn(JSON.stringify(f));
                await this.client.core.verify.register({
                    attestationId: b
                })
            }
            const v = await this.client.core.crypto.encode(r, f),
                g = ns[s].req;
            return l && (g.ttl = l), d && (g.id = d), this.client.core.history.set(r, f), this.client.core.relayer.publish(r, v, g), f.id
        }, this.sendResult = async (r, s, o) => {
            const l = au(r, o),
                d = await this.client.core.crypto.encode(s, l),
                f = await this.client.core.history.get(s, r),
                v = ns[f.request.method].res;
            this.client.core.relayer.publish(s, d, v), await this.client.core.history.resolve(l)
        }, this.sendError = async (r, s, o) => {
            const l = iu(r, o),
                d = await this.client.core.crypto.encode(s, l),
                f = await this.client.core.history.get(s, r),
                v = ns[f.request.method].res;
            this.client.core.relayer.publish(s, d, v), await this.client.core.history.resolve(l)
        }, this.cleanup = async () => {
            const r = [],
                s = [];
            this.client.session.getAll().forEach(o => {
                Ai(o.expiry) && r.push(o.topic)
            }), this.client.proposal.getAll().forEach(o => {
                Ai(o.expiry) && s.push(o.id)
            }), await Promise.all([...r.map(o => this.deleteSession(o)), ...s.map(o => this.deleteProposal(o))])
        }, this.onRelayEventRequest = r => {
            const {
                topic: s,
                payload: o
            } = r, l = o.method;
            switch (l) {
                case "wc_sessionPropose":
                    return this.onSessionProposeRequest(s, o);
                case "wc_sessionSettle":
                    return this.onSessionSettleRequest(s, o);
                case "wc_sessionUpdate":
                    return this.onSessionUpdateRequest(s, o);
                case "wc_sessionExtend":
                    return this.onSessionExtendRequest(s, o);
                case "wc_sessionPing":
                    return this.onSessionPingRequest(s, o);
                case "wc_sessionDelete":
                    return this.onSessionDeleteRequest(s, o);
                case "wc_sessionRequest":
                    return this.onSessionRequest(s, o);
                case "wc_sessionEvent":
                    return this.onSessionEventRequest(s, o);
                default:
                    return this.client.logger.info(`Unsupported request method ${l}`)
            }
        }, this.onRelayEventResponse = async r => {
            const {
                topic: s,
                payload: o
            } = r, l = (await this.client.core.history.get(s, o.id)).request.method;
            switch (l) {
                case "wc_sessionPropose":
                    return this.onSessionProposeResponse(s, o);
                case "wc_sessionSettle":
                    return this.onSessionSettleResponse(s, o);
                case "wc_sessionUpdate":
                    return this.onSessionUpdateResponse(s, o);
                case "wc_sessionExtend":
                    return this.onSessionExtendResponse(s, o);
                case "wc_sessionPing":
                    return this.onSessionPingResponse(s, o);
                case "wc_sessionRequest":
                    return this.onSessionRequestResponse(s, o);
                default:
                    return this.client.logger.info(`Unsupported response method ${l}`)
            }
        }, this.onRelayEventUnknownPayload = r => {
            const {
                topic: s
            } = r, {
                message: o
            } = ue("MISSING_OR_INVALID", `Decoded payload on topic ${s} is not identifiable as a JSON-RPC request or a response.`);
            throw new Error(o)
        }, this.onSessionProposeRequest = async (r, s) => {
            const {
                params: o,
                id: l
            } = s;
            try {
                this.isValidConnect($r({}, s.params));
                const d = kr(ye.FIVE_MINUTES),
                    f = $r({
                        id: l,
                        pairingTopic: r,
                        expiry: d
                    }, o);
                await this.setProposal(l, f);
                const v = Cn(JSON.stringify(s)),
                    g = await this.getVerifyContext(v, f.proposer.metadata);
                this.client.events.emit("session_proposal", {
                    id: l,
                    params: f,
                    verifyContext: g
                })
            } catch (d) {
                await this.sendError(l, r, d), this.client.logger.error(d)
            }
        }, this.onSessionProposeResponse = async (r, s) => {
            const {
                id: o
            } = s;
            if (Oi(s)) {
                const {
                    result: l
                } = s;
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    result: l
                });
                const d = this.client.proposal.get(o);
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    proposal: d
                });
                const f = d.proposer.publicKey;
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    selfPublicKey: f
                });
                const v = l.responderPublicKey;
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    peerPublicKey: v
                });
                const g = await this.client.core.crypto.generateSharedKey(f, v);
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    sessionTopic: g
                });
                const b = await this.client.core.relayer.subscribe(g);
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    subscriptionId: b
                }), await this.client.core.pairing.activate({
                    topic: r
                })
            } else gi(s) && (await this.client.proposal.delete(o, Tt("USER_DISCONNECTED")), this.events.emit(qt("session_connect"), {
                error: s.error
            }))
        }, this.onSessionSettleRequest = async (r, s) => {
            const {
                id: o,
                params: l
            } = s;
            try {
                this.isValidSessionSettleRequest(l);
                const {
                    relay: d,
                    controller: f,
                    expiry: v,
                    namespaces: g,
                    requiredNamespaces: b,
                    optionalNamespaces: S,
                    sessionProperties: O,
                    pairingTopic: P
                } = s.params, N = $r({
                    topic: r,
                    relay: d,
                    expiry: v,
                    namespaces: g,
                    acknowledged: !0,
                    pairingTopic: P,
                    requiredNamespaces: b,
                    optionalNamespaces: S,
                    controller: f.publicKey,
                    self: {
                        publicKey: "",
                        metadata: this.client.metadata
                    },
                    peer: {
                        publicKey: f.publicKey,
                        metadata: f.metadata
                    }
                }, O && {
                    sessionProperties: O
                });
                await this.sendResult(s.id, r, !0), this.events.emit(qt("session_connect"), {
                    session: N
                }), this.cleanupDuplicatePairings(N)
            } catch (d) {
                await this.sendError(o, r, d), this.client.logger.error(d)
            }
        }, this.onSessionSettleResponse = async (r, s) => {
            const {
                id: o
            } = s;
            Oi(s) ? (await this.client.session.update(r, {
                acknowledged: !0
            }), this.events.emit(qt("session_approve", o), {})) : gi(s) && (await this.client.session.delete(r, Tt("USER_DISCONNECTED")), this.events.emit(qt("session_approve", o), {
                error: s.error
            }))
        }, this.onSessionUpdateRequest = async (r, s) => {
            const {
                params: o,
                id: l
            } = s;
            try {
                this.isValidUpdate($r({
                    topic: r
                }, o)), await this.client.session.update(r, {
                    namespaces: o.namespaces
                }), await this.sendResult(l, r, !0), this.client.events.emit("session_update", {
                    id: l,
                    topic: r,
                    params: o
                })
            } catch (d) {
                await this.sendError(l, r, d), this.client.logger.error(d)
            }
        }, this.onSessionUpdateResponse = (r, s) => {
            const {
                id: o
            } = s;
            Oi(s) ? this.events.emit(qt("session_update", o), {}) : gi(s) && this.events.emit(qt("session_update", o), {
                error: s.error
            })
        }, this.onSessionExtendRequest = async (r, s) => {
            const {
                id: o
            } = s;
            try {
                this.isValidExtend({
                    topic: r
                }), await this.setExpiry(r, kr(wa)), await this.sendResult(o, r, !0), this.client.events.emit("session_extend", {
                    id: o,
                    topic: r
                })
            } catch (l) {
                await this.sendError(o, r, l), this.client.logger.error(l)
            }
        }, this.onSessionExtendResponse = (r, s) => {
            const {
                id: o
            } = s;
            Oi(s) ? this.events.emit(qt("session_extend", o), {}) : gi(s) && this.events.emit(qt("session_extend", o), {
                error: s.error
            })
        }, this.onSessionPingRequest = async (r, s) => {
            const {
                id: o
            } = s;
            try {
                this.isValidPing({
                    topic: r
                }), await this.sendResult(o, r, !0), this.client.events.emit("session_ping", {
                    id: o,
                    topic: r
                })
            } catch (l) {
                await this.sendError(o, r, l), this.client.logger.error(l)
            }
        }, this.onSessionPingResponse = (r, s) => {
            const {
                id: o
            } = s;
            setTimeout(() => {
                Oi(s) ? this.events.emit(qt("session_ping", o), {}) : gi(s) && this.events.emit(qt("session_ping", o), {
                    error: s.error
                })
            }, 500)
        }, this.onSessionDeleteRequest = async (r, s) => {
            const {
                id: o
            } = s;
            try {
                this.isValidDisconnect({
                    topic: r,
                    reason: s.params
                }), await Promise.all([new Promise(l => {
                    this.client.core.relayer.once(Ct.publish, async () => {
                        l(await this.deleteSession(r))
                    })
                }), this.sendResult(o, r, !0)]), this.client.events.emit("session_delete", {
                    id: o,
                    topic: r
                })
            } catch (l) {
                this.client.logger.error(l)
            }
        }, this.onSessionRequest = async (r, s) => {
            const {
                id: o,
                params: l
            } = s;
            try {
                this.isValidRequest($r({
                    topic: r
                }, l)), await this.setPendingSessionRequest({
                    id: o,
                    topic: r,
                    params: l
                });
                const d = Cn(JSON.stringify(s)),
                    f = this.client.session.get(r),
                    v = await this.getVerifyContext(d, f.peer.metadata);
                this.client.events.emit("session_request", {
                    id: o,
                    topic: r,
                    params: l,
                    verifyContext: v
                })
            } catch (d) {
                await this.sendError(o, r, d), this.client.logger.error(d)
            }
        }, this.onSessionRequestResponse = (r, s) => {
            const {
                id: o
            } = s;
            Oi(s) ? this.events.emit(qt("session_request", o), {
                result: s.result
            }) : gi(s) && this.events.emit(qt("session_request", o), {
                error: s.error
            })
        }, this.onSessionEventRequest = async (r, s) => {
            const {
                id: o,
                params: l
            } = s;
            try {
                this.isValidEmit($r({
                    topic: r
                }, l)), this.client.events.emit("session_event", {
                    id: o,
                    topic: r,
                    params: l
                })
            } catch (d) {
                await this.sendError(o, r, d), this.client.logger.error(d)
            }
        }, this.isValidConnect = async r => {
            if (!yr(r)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `connect() params: ${JSON.stringify(r)}`);
                throw new Error(v)
            }
            const {
                pairingTopic: s,
                requiredNamespaces: o,
                optionalNamespaces: l,
                sessionProperties: d,
                relays: f
            } = r;
            if (or(s) || await this.isValidPairingTopic(s), !Rw(f, !0)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `connect() relays: ${f}`);
                throw new Error(v)
            }!or(o) && On(o) !== 0 && this.validateNamespaces(o, "requiredNamespaces"), !or(l) && On(l) !== 0 && this.validateNamespaces(l, "optionalNamespaces"), or(d) || this.validateSessionProps(d, "sessionProperties")
        }, this.validateNamespaces = (r, s) => {
            const o = Tw(r, "connect()", s);
            if (o) throw new Error(o.message)
        }, this.isValidApprove = async r => {
            if (!yr(r)) throw new Error(ue("MISSING_OR_INVALID", `approve() params: ${r}`).message);
            const {
                id: s,
                namespaces: o,
                relayProtocol: l,
                sessionProperties: d
            } = r;
            await this.isValidProposalId(s);
            const f = this.client.proposal.get(s),
                v = xa(o, "approve()");
            if (v) throw new Error(v.message);
            const g = Wl(f.requiredNamespaces, o, "approve()");
            if (g) throw new Error(g.message);
            if (!Gt(l, !0)) {
                const {
                    message: b
                } = ue("MISSING_OR_INVALID", `approve() relayProtocol: ${l}`);
                throw new Error(b)
            }
            or(d) || this.validateSessionProps(d, "sessionProperties")
        }, this.isValidReject = async r => {
            if (!yr(r)) {
                const {
                    message: l
                } = ue("MISSING_OR_INVALID", `reject() params: ${r}`);
                throw new Error(l)
            }
            const {
                id: s,
                reason: o
            } = r;
            if (await this.isValidProposalId(s), !Uw(o)) {
                const {
                    message: l
                } = ue("MISSING_OR_INVALID", `reject() reason: ${JSON.stringify(o)}`);
                throw new Error(l)
            }
        }, this.isValidSessionSettleRequest = r => {
            if (!yr(r)) {
                const {
                    message: g
                } = ue("MISSING_OR_INVALID", `onSessionSettleRequest() params: ${r}`);
                throw new Error(g)
            }
            const {
                relay: s,
                controller: o,
                namespaces: l,
                expiry: d
            } = r;
            if (!bp(s)) {
                const {
                    message: g
                } = ue("MISSING_OR_INVALID", "onSessionSettleRequest() relay protocol should be a string");
                throw new Error(g)
            }
            const f = xw(o, "onSessionSettleRequest()");
            if (f) throw new Error(f.message);
            const v = xa(l, "onSessionSettleRequest()");
            if (v) throw new Error(v.message);
            if (Ai(d)) {
                const {
                    message: g
                } = ue("EXPIRED", "onSessionSettleRequest()");
                throw new Error(g)
            }
        }, this.isValidUpdate = async r => {
            if (!yr(r)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `update() params: ${r}`);
                throw new Error(v)
            }
            const {
                topic: s,
                namespaces: o
            } = r;
            await this.isValidSessionTopic(s);
            const l = this.client.session.get(s),
                d = xa(o, "update()");
            if (d) throw new Error(d.message);
            const f = Wl(l.requiredNamespaces, o, "update()");
            if (f) throw new Error(f.message)
        }, this.isValidExtend = async r => {
            if (!yr(r)) {
                const {
                    message: o
                } = ue("MISSING_OR_INVALID", `extend() params: ${r}`);
                throw new Error(o)
            }
            const {
                topic: s
            } = r;
            await this.isValidSessionTopic(s)
        }, this.isValidRequest = async r => {
            if (!yr(r)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `request() params: ${r}`);
                throw new Error(v)
            }
            const {
                topic: s,
                request: o,
                chainId: l,
                expiry: d
            } = r;
            await this.isValidSessionTopic(s);
            const {
                namespaces: f
            } = this.client.session.get(s);
            if (!Gl(f, l)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `request() chainId: ${l}`);
                throw new Error(v)
            }
            if (!$w(o)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `request() ${JSON.stringify(o)}`);
                throw new Error(v)
            }
            if (!jw(f, l, o.method)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `request() method: ${o.method}`);
                throw new Error(v)
            }
            if (d && !Bw(d, Fc)) {
                const {
                    message: v
                } = ue("MISSING_OR_INVALID", `request() expiry: ${d}. Expiry must be a number (in seconds) between ${Fc.min} and ${Fc.max}`);
                throw new Error(v)
            }
        }, this.isValidRespond = async r => {
            if (!yr(r)) {
                const {
                    message: l
                } = ue("MISSING_OR_INVALID", `respond() params: ${r}`);
                throw new Error(l)
            }
            const {
                topic: s,
                response: o
            } = r;
            if (await this.isValidSessionTopic(s), !Lw(o)) {
                const {
                    message: l
                } = ue("MISSING_OR_INVALID", `respond() response: ${JSON.stringify(o)}`);
                throw new Error(l)
            }
        }, this.isValidPing = async r => {
            if (!yr(r)) {
                const {
                    message: o
                } = ue("MISSING_OR_INVALID", `ping() params: ${r}`);
                throw new Error(o)
            }
            const {
                topic: s
            } = r;
            await this.isValidSessionOrPairingTopic(s)
        }, this.isValidEmit = async r => {
            if (!yr(r)) {
                const {
                    message: f
                } = ue("MISSING_OR_INVALID", `emit() params: ${r}`);
                throw new Error(f)
            }
            const {
                topic: s,
                event: o,
                chainId: l
            } = r;
            await this.isValidSessionTopic(s);
            const {
                namespaces: d
            } = this.client.session.get(s);
            if (!Gl(d, l)) {
                const {
                    message: f
                } = ue("MISSING_OR_INVALID", `emit() chainId: ${l}`);
                throw new Error(f)
            }
            if (!Mw(o)) {
                const {
                    message: f
                } = ue("MISSING_OR_INVALID", `emit() event: ${JSON.stringify(o)}`);
                throw new Error(f)
            }
            if (!zw(d, l, o.name)) {
                const {
                    message: f
                } = ue("MISSING_OR_INVALID", `emit() event: ${JSON.stringify(o)}`);
                throw new Error(f)
            }
        }, this.isValidDisconnect = async r => {
            if (!yr(r)) {
                const {
                    message: o
                } = ue("MISSING_OR_INVALID", `disconnect() params: ${r}`);
                throw new Error(o)
            }
            const {
                topic: s
            } = r;
            await this.isValidSessionOrPairingTopic(s)
        }, this.getVerifyContext = async (r, s) => {
            const o = {
                verified: {
                    verifyUrl: s.verifyUrl || "",
                    validation: "UNKNOWN",
                    origin: s.url || ""
                }
            };
            try {
                const l = await this.client.core.verify.resolve({
                    attestationId: r,
                    verifyUrl: s.verifyUrl
                });
                l && (o.verified.origin = l, o.verified.validation = l === s.url ? "VALID" : "INVALID")
            } catch (l) {
                this.client.logger.error(l)
            }
            return this.client.logger.info(`Verify context: ${JSON.stringify(o)}`), o
        }, this.validateSessionProps = (r, s) => {
            Object.values(r).forEach(o => {
                if (!Gt(o, !1)) {
                    const {
                        message: l
                    } = ue("MISSING_OR_INVALID", `${s} must be in Record<string, string> format. Received: ${JSON.stringify(o)}`);
                    throw new Error(l)
                }
            })
        }
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = ue("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    registerRelayerEvents() {
        this.client.core.relayer.on(Ct.message, async t => {
            const {
                topic: r,
                message: s
            } = t;
            if (this.ignoredPayloadTypes.includes(this.client.core.crypto.getPayloadType(s))) return;
            const o = await this.client.core.crypto.decode(r, s);
            nu(o) ? (this.client.core.history.set(r, o), this.onRelayEventRequest({
                topic: r,
                payload: o
            })) : su(o) ? (await this.client.core.history.resolve(o), await this.onRelayEventResponse({
                topic: r,
                payload: o
            }), this.client.core.history.delete(r, o.id)) : this.onRelayEventUnknownPayload({
                topic: r,
                payload: o
            })
        })
    }
    registerExpirerEvents() {
        this.client.core.expirer.on(Lr.expired, async t => {
            const {
                topic: r,
                id: s
            } = _p(t.target);
            if (s && this.client.pendingRequest.keys.includes(s)) return await this.deletePendingSessionRequest(s, ue("EXPIRED"), !0);
            r ? this.client.session.keys.includes(r) && (await this.deleteSession(r, !0), this.client.events.emit("session_expire", {
                topic: r
            })) : s && (await this.deleteProposal(s, !0), this.client.events.emit("proposal_expire", {
                id: s
            }))
        })
    }
    isValidPairingTopic(t) {
        if (!Gt(t, !1)) {
            const {
                message: r
            } = ue("MISSING_OR_INVALID", `pairing topic should be a string: ${t}`);
            throw new Error(r)
        }
        if (!this.client.core.pairing.pairings.keys.includes(t)) {
            const {
                message: r
            } = ue("NO_MATCHING_KEY", `pairing topic doesn't exist: ${t}`);
            throw new Error(r)
        }
        if (Ai(this.client.core.pairing.pairings.get(t).expiry)) {
            const {
                message: r
            } = ue("EXPIRED", `pairing topic: ${t}`);
            throw new Error(r)
        }
    }
    async isValidSessionTopic(t) {
        if (!Gt(t, !1)) {
            const {
                message: r
            } = ue("MISSING_OR_INVALID", `session topic should be a string: ${t}`);
            throw new Error(r)
        }
        if (!this.client.session.keys.includes(t)) {
            const {
                message: r
            } = ue("NO_MATCHING_KEY", `session topic doesn't exist: ${t}`);
            throw new Error(r)
        }
        if (Ai(this.client.session.get(t).expiry)) {
            await this.deleteSession(t);
            const {
                message: r
            } = ue("EXPIRED", `session topic: ${t}`);
            throw new Error(r)
        }
    }
    async isValidSessionOrPairingTopic(t) {
        if (this.client.session.keys.includes(t)) await this.isValidSessionTopic(t);
        else if (this.client.core.pairing.pairings.keys.includes(t)) this.isValidPairingTopic(t);
        else if (Gt(t, !1)) {
            const {
                message: r
            } = ue("NO_MATCHING_KEY", `session or pairing topic doesn't exist: ${t}`);
            throw new Error(r)
        } else {
            const {
                message: r
            } = ue("MISSING_OR_INVALID", `session or pairing topic should be a string: ${t}`);
            throw new Error(r)
        }
    }
    async isValidProposalId(t) {
        if (!Fw(t)) {
            const {
                message: r
            } = ue("MISSING_OR_INVALID", `proposal id should be a number: ${t}`);
            throw new Error(r)
        }
        if (!this.client.proposal.keys.includes(t)) {
            const {
                message: r
            } = ue("NO_MATCHING_KEY", `proposal id doesn't exist: ${t}`);
            throw new Error(r)
        }
        if (Ai(this.client.proposal.get(t).expiry)) {
            await this.deleteProposal(t);
            const {
                message: r
            } = ue("EXPIRED", `proposal id: ${t}`);
            throw new Error(r)
        }
    }
}
class HD extends ka {
    constructor(t, r) {
        super(t, r, ND, Eu), this.core = t, this.logger = r
    }
}
class BD extends ka {
    constructor(t, r) {
        super(t, r, TD, Eu), this.core = t, this.logger = r
    }
}
class KD extends ka {
    constructor(t, r) {
        super(t, r, FD, Eu, s => s.id), this.core = t, this.logger = r
    }
}
let kD = class Wp extends LE {
    constructor(t) {
        super(t), this.protocol = Kp, this.version = kp, this.name = Rc.name, this.events = new ri.EventEmitter, this.on = (s, o) => this.events.on(s, o), this.once = (s, o) => this.events.once(s, o), this.off = (s, o) => this.events.off(s, o), this.removeListener = (s, o) => this.events.removeListener(s, o), this.removeAllListeners = s => this.events.removeAllListeners(s), this.connect = async s => {
            try {
                return await this.engine.connect(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.pair = async s => {
            try {
                return await this.engine.pair(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.approve = async s => {
            try {
                return await this.engine.approve(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.reject = async s => {
            try {
                return await this.engine.reject(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.update = async s => {
            try {
                return await this.engine.update(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.extend = async s => {
            try {
                return await this.engine.extend(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.request = async s => {
            try {
                return await this.engine.request(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.respond = async s => {
            try {
                return await this.engine.respond(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.ping = async s => {
            try {
                return await this.engine.ping(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.emit = async s => {
            try {
                return await this.engine.emit(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.disconnect = async s => {
            try {
                return await this.engine.disconnect(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.find = s => {
            try {
                return this.engine.find(s)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.getPendingSessionRequests = () => {
            try {
                return this.engine.getPendingSessionRequests()
            } catch (s) {
                throw this.logger.error(s.message), s
            }
        }, this.name = (t == null ? void 0 : t.name) || Rc.name, this.metadata = (t == null ? void 0 : t.metadata) || Xb();
        const r = typeof(t == null ? void 0 : t.logger) < "u" && typeof(t == null ? void 0 : t.logger) != "string" ? t.logger : Qe.pino(Qe.getDefaultLoggerOptions({
            level: (t == null ? void 0 : t.logger) || Rc.logger
        }));
        this.core = (t == null ? void 0 : t.core) || new AD(t), this.logger = Qe.generateChildLogger(r, this.name), this.session = new BD(this.core, this.logger), this.proposal = new HD(this.core, this.logger), this.pendingRequest = new KD(this.core, this.logger), this.engine = new qD(this)
    }
    static async init(t) {
        const r = new Wp(t);
        return await r.initialize(), r
    }
    get context() {
        return Qe.getLoggerContext(this.logger)
    }
    get pairing() {
        return this.core.pairing.pairings
    }
    async initialize() {
        this.logger.trace("Initialized");
        try {
            await this.core.start(), await this.session.init(), await this.proposal.init(), await this.pendingRequest.init(), await this.engine.init(), this.core.verify.init({
                verifyUrl: this.metadata.verifyUrl
            }), this.logger.info("SignClient Initialization Success")
        } catch (t) {
            throw this.logger.info("SignClient Initialization Failure"), this.logger.error(t.message), t
        }
    }
};
const Uf = "error",
    VD = "wss://relay.walletconnect.com",
    GD = "wc",
    WD = "universal_provider",
    $f = `${GD}@2:${WD}:`,
    YD = "https://rpc.walletconnect.com/v1",
    Fi = {
        DEFAULT_CHAIN_CHANGED: "default_chain_changed"
    };
var ss = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof _r < "u" ? _r : typeof self < "u" ? self : {},
    Zc = {
        exports: {}
    };
/**
 * @license
 * Lodash <https://lodash.com/>
 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */
(function(n, t) {
    (function() {
        var r, s = "4.17.21",
            o = 200,
            l = "Unsupported core-js use. Try https://npms.io/search?q=ponyfill.",
            d = "Expected a function",
            f = "Invalid `variable` option passed into `_.template`",
            v = "__lodash_hash_undefined__",
            g = 500,
            b = "__lodash_placeholder__",
            S = 1,
            O = 2,
            P = 4,
            N = 1,
            H = 2,
            G = 1,
            ie = 2,
            T = 4,
            L = 8,
            I = 16,
            C = 32,
            w = 64,
            c = 128,
            m = 256,
            K = 512,
            V = 30,
            ae = "...",
            ce = 800,
            ge = 16,
            F = 1,
            q = 2,
            le = 3,
            te = 1 / 0,
            W = 9007199254740991,
            ee = 17976931348623157e292,
            Y = 0 / 0,
            re = 4294967295,
            xe = re - 1,
            ne = re >>> 1,
            be = [
                ["ary", c],
                ["bind", G],
                ["bindKey", ie],
                ["curry", L],
                ["curryRight", I],
                ["flip", K],
                ["partial", C],
                ["partialRight", w],
                ["rearg", m]
            ],
            he = "[object Arguments]",
            _e = "[object Array]",
            z = "[object AsyncFunction]",
            j = "[object Boolean]",
            R = "[object Date]",
            h = "[object DOMException]",
            x = "[object Error]",
            se = "[object Function]",
            fe = "[object GeneratorFunction]",
            Ie = "[object Map]",
            He = "[object Number]",
            ke = "[object Null]",
            Le = "[object Object]",
            pt = "[object Promise]",
            dt = "[object Proxy]",
            je = "[object RegExp]",
            Se = "[object Set]",
            Re = "[object String]",
            Fe = "[object Symbol]",
            ze = "[object Undefined]",
            Oe = "[object WeakMap]",
            Ue = "[object WeakSet]",
            De = "[object ArrayBuffer]",
            Ae = "[object DataView]",
            Be = "[object Float32Array]",
            Ce = "[object Float64Array]",
            Ve = "[object Int8Array]",
            We = "[object Int16Array]",
            et = "[object Int32Array]",
            tt = "[object Uint8Array]",
            Je = "[object Uint8ClampedArray]",
            er = "[object Uint16Array]",
            hr = "[object Uint32Array]",
            Vr = /\b__p \+= '';/g,
            tr = /\b(__p \+=) '' \+/g,
            ii = /(__e\(.*?\)|\b__t\)) \+\n'';/g,
            yi = /&(?:amp|lt|gt|quot|#39);/g,
            Ui = /[&<>"']/g,
            bt = RegExp(yi.source),
            gt = RegExp(Ui.source),
            wt = /<%-([\s\S]+?)%>/g,
            Et = /<%([\s\S]+?)%>/g,
            _t = /<%=([\s\S]+?)%>/g,
            vt = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            Ft = /^\w*$/,
            Ut = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            Dt = /[\\^$.*+?()[\]{}|]/g,
            $t = RegExp(Dt.source),
            It = /^\s+/,
            Ot = /\s/,
            St = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,
            ht = /\{\n\/\* \[wrapped with (.+)\] \*/,
            Lt = /,? & /,
            Mt = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,
            Va = /[()=,{}\[\]\/\s]/,
            Ga = /\\(\\)?/g,
            Wa = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
            Cr = /\w*$/,
            Ya = /^[-+]0x[0-9a-f]+$/i,
            Ja = /^0b[01]+$/i,
            Xa = /^\[object .+?Constructor\]$/,
            Za = /^0o[0-7]+$/i,
            Qa = /^(?:0|[1-9]\d*)$/,
            ni = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,
            sn = /($^)/,
            eo = /['\n\r\u2028\u2029\\]/g,
            an = "\\ud800-\\udfff",
            to = "\\u0300-\\u036f",
            ro = "\\ufe20-\\ufe2f",
            on = "\\u20d0-\\u20ff",
            ds = to + ro + on,
            gs = "\\u2700-\\u27bf",
            jr = "a-z\\xdf-\\xf6\\xf8-\\xff",
            io = "\\xac\\xb1\\xd7\\xf7",
            no = "\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",
            so = "\\u2000-\\u206f",
            ao = " \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",
            vs = "A-Z\\xc0-\\xd6\\xd8-\\xde",
            ys = "\\ufe0e\\ufe0f",
            $i = io + no + so + ao,
            Tn = "['’]",
            Li = "[" + an + "]",
            Rn = "[" + $i + "]",
            Mi = "[" + ds + "]",
            _s = "\\d+",
            oo = "[" + gs + "]",
            ms = "[" + jr + "]",
            bs = "[^" + an + $i + _s + gs + jr + vs + "]",
            cn = "\\ud83c[\\udffb-\\udfff]",
            co = "(?:" + Mi + "|" + cn + ")",
            ws = "[^" + an + "]",
            un = "(?:\\ud83c[\\udde6-\\uddff]){2}",
            _i = "[\\ud800-\\udbff][\\udc00-\\udfff]",
            br = "[" + vs + "]",
            Es = "\\u200d",
            Ds = "(?:" + ms + "|" + bs + ")",
            Gr = "(?:" + br + "|" + bs + ")",
            Is = "(?:" + Tn + "(?:d|ll|m|re|s|t|ve))?",
            Ss = "(?:" + Tn + "(?:D|LL|M|RE|S|T|VE))?",
            xs = co + "?",
            Cs = "[" + ys + "]?",
            uo = "(?:" + Es + "(?:" + [ws, un, _i].join("|") + ")" + Cs + xs + ")*",
            si = "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",
            Os = "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",
            As = Cs + xs + uo,
            hn = "(?:" + [oo, un, _i].join("|") + ")" + As,
            ho = "(?:" + [ws + Mi + "?", Mi, un, _i, Li].join("|") + ")",
            Fn = RegExp(Tn, "g"),
            lo = RegExp(Mi, "g"),
            ln = RegExp(cn + "(?=" + cn + ")|" + ho + As, "g"),
            Ps = RegExp([br + "?" + ms + "+" + Is + "(?=" + [Rn, br, "$"].join("|") + ")", Gr + "+" + Ss + "(?=" + [Rn, br + Ds, "$"].join("|") + ")", br + "?" + Ds + "+" + Is, br + "+" + Ss, Os, si, _s, hn].join("|"), "g"),
            Ns = RegExp("[" + Es + an + ds + ys + "]"),
            ji = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,
            Ts = ["Array", "Buffer", "DataView", "Date", "Error", "Float32Array", "Float64Array", "Function", "Int8Array", "Int16Array", "Int32Array", "Map", "Math", "Object", "Promise", "RegExp", "Set", "String", "Symbol", "TypeError", "Uint8Array", "Uint8ClampedArray", "Uint16Array", "Uint32Array", "WeakMap", "_", "clearTimeout", "isFinite", "parseInt", "setTimeout"],
            fo = -1,
            at = {};
        at[Be] = at[Ce] = at[Ve] = at[We] = at[et] = at[tt] = at[Je] = at[er] = at[hr] = !0, at[he] = at[_e] = at[De] = at[j] = at[Ae] = at[R] = at[x] = at[se] = at[Ie] = at[He] = at[Le] = at[je] = at[Se] = at[Re] = at[Oe] = !1;
        var st = {};
        st[he] = st[_e] = st[De] = st[Ae] = st[j] = st[R] = st[Be] = st[Ce] = st[Ve] = st[We] = st[et] = st[Ie] = st[He] = st[Le] = st[je] = st[Se] = st[Re] = st[Fe] = st[tt] = st[Je] = st[er] = st[hr] = !0, st[x] = st[se] = st[Oe] = !1;
        var E = {
                À: "A",
                Á: "A",
                Â: "A",
                Ã: "A",
                Ä: "A",
                Å: "A",
                à: "a",
                á: "a",
                â: "a",
                ã: "a",
                ä: "a",
                å: "a",
                Ç: "C",
                ç: "c",
                Ð: "D",
                ð: "d",
                È: "E",
                É: "E",
                Ê: "E",
                Ë: "E",
                è: "e",
                é: "e",
                ê: "e",
                ë: "e",
                Ì: "I",
                Í: "I",
                Î: "I",
                Ï: "I",
                ì: "i",
                í: "i",
                î: "i",
                ï: "i",
                Ñ: "N",
                ñ: "n",
                Ò: "O",
                Ó: "O",
                Ô: "O",
                Õ: "O",
                Ö: "O",
                Ø: "O",
                ò: "o",
                ó: "o",
                ô: "o",
                õ: "o",
                ö: "o",
                ø: "o",
                Ù: "U",
                Ú: "U",
                Û: "U",
                Ü: "U",
                ù: "u",
                ú: "u",
                û: "u",
                ü: "u",
                Ý: "Y",
                ý: "y",
                ÿ: "y",
                Æ: "Ae",
                æ: "ae",
                Þ: "Th",
                þ: "th",
                ß: "ss",
                Ā: "A",
                Ă: "A",
                Ą: "A",
                ā: "a",
                ă: "a",
                ą: "a",
                Ć: "C",
                Ĉ: "C",
                Ċ: "C",
                Č: "C",
                ć: "c",
                ĉ: "c",
                ċ: "c",
                č: "c",
                Ď: "D",
                Đ: "D",
                ď: "d",
                đ: "d",
                Ē: "E",
                Ĕ: "E",
                Ė: "E",
                Ę: "E",
                Ě: "E",
                ē: "e",
                ĕ: "e",
                ė: "e",
                ę: "e",
                ě: "e",
                Ĝ: "G",
                Ğ: "G",
                Ġ: "G",
                Ģ: "G",
                ĝ: "g",
                ğ: "g",
                ġ: "g",
                ģ: "g",
                Ĥ: "H",
                Ħ: "H",
                ĥ: "h",
                ħ: "h",
                Ĩ: "I",
                Ī: "I",
                Ĭ: "I",
                Į: "I",
                İ: "I",
                ĩ: "i",
                ī: "i",
                ĭ: "i",
                į: "i",
                ı: "i",
                Ĵ: "J",
                ĵ: "j",
                Ķ: "K",
                ķ: "k",
                ĸ: "k",
                Ĺ: "L",
                Ļ: "L",
                Ľ: "L",
                Ŀ: "L",
                Ł: "L",
                ĺ: "l",
                ļ: "l",
                ľ: "l",
                ŀ: "l",
                ł: "l",
                Ń: "N",
                Ņ: "N",
                Ň: "N",
                Ŋ: "N",
                ń: "n",
                ņ: "n",
                ň: "n",
                ŋ: "n",
                Ō: "O",
                Ŏ: "O",
                Ő: "O",
                ō: "o",
                ŏ: "o",
                ő: "o",
                Ŕ: "R",
                Ŗ: "R",
                Ř: "R",
                ŕ: "r",
                ŗ: "r",
                ř: "r",
                Ś: "S",
                Ŝ: "S",
                Ş: "S",
                Š: "S",
                ś: "s",
                ŝ: "s",
                ş: "s",
                š: "s",
                Ţ: "T",
                Ť: "T",
                Ŧ: "T",
                ţ: "t",
                ť: "t",
                ŧ: "t",
                Ũ: "U",
                Ū: "U",
                Ŭ: "U",
                Ů: "U",
                Ű: "U",
                Ų: "U",
                ũ: "u",
                ū: "u",
                ŭ: "u",
                ů: "u",
                ű: "u",
                ų: "u",
                Ŵ: "W",
                ŵ: "w",
                Ŷ: "Y",
                ŷ: "y",
                Ÿ: "Y",
                Ź: "Z",
                Ż: "Z",
                Ž: "Z",
                ź: "z",
                ż: "z",
                ž: "z",
                Ĳ: "IJ",
                ĳ: "ij",
                Œ: "Oe",
                œ: "oe",
                ŉ: "'n",
                ſ: "s"
            },
            U = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            },
            Z = {
                "&amp;": "&",
                "&lt;": "<",
                "&gt;": ">",
                "&quot;": '"',
                "&#39;": "'"
            },
            pe = {
                "\\": "\\",
                "'": "'",
                "\n": "n",
                "\r": "r",
                "\u2028": "u2028",
                "\u2029": "u2029"
            },
            ot = parseFloat,
            Ne = parseInt,
            lt = typeof ss == "object" && ss && ss.Object === Object && ss,
            jt = typeof self == "object" && self && self.Object === Object && self,
            Xe = lt || jt || Function("return this")(),
            ct = t && !t.nodeType && t,
            At = ct && !0 && n && !n.nodeType && n,
            lr = At && At.exports === ct,
            zt = lr && lt.process,
            ft = function() {
                try {
                    var $ = At && At.require && At.require("util").types;
                    return $ || zt && zt.binding && zt.binding("util")
                } catch {}
            }(),
            rr = ft && ft.isArrayBuffer,
            zr = ft && ft.isDate,
            Or = ft && ft.isMap,
            Wr = ft && ft.isRegExp,
            Un = ft && ft.isSet,
            zi = ft && ft.isTypedArray;

        function Kt($, k, B) {
            switch (B.length) {
                case 0:
                    return $.call(k);
                case 1:
                    return $.call(k, B[0]);
                case 2:
                    return $.call(k, B[0], B[1]);
                case 3:
                    return $.call(k, B[0], B[1], B[2])
            }
            return $.apply(k, B)
        }

        function Xp($, k, B, de) {
            for (var Pe = -1, rt = $ == null ? 0 : $.length; ++Pe < rt;) {
                var Ht = $[Pe];
                k(de, Ht, B(Ht), $)
            }
            return de
        }

        function Ar($, k) {
            for (var B = -1, de = $ == null ? 0 : $.length; ++B < de && k($[B], B, $) !== !1;);
            return $
        }

        function Zp($, k) {
            for (var B = $ == null ? 0 : $.length; B-- && k($[B], B, $) !== !1;);
            return $
        }

        function Su($, k) {
            for (var B = -1, de = $ == null ? 0 : $.length; ++B < de;)
                if (!k($[B], B, $)) return !1;
            return !0
        }

        function mi($, k) {
            for (var B = -1, de = $ == null ? 0 : $.length, Pe = 0, rt = []; ++B < de;) {
                var Ht = $[B];
                k(Ht, B, $) && (rt[Pe++] = Ht)
            }
            return rt
        }

        function Rs($, k) {
            var B = $ == null ? 0 : $.length;
            return !!B && fn($, k, 0) > -1
        }

        function po($, k, B) {
            for (var de = -1, Pe = $ == null ? 0 : $.length; ++de < Pe;)
                if (B(k, $[de])) return !0;
            return !1
        }

        function yt($, k) {
            for (var B = -1, de = $ == null ? 0 : $.length, Pe = Array(de); ++B < de;) Pe[B] = k($[B], B, $);
            return Pe
        }

        function bi($, k) {
            for (var B = -1, de = k.length, Pe = $.length; ++B < de;) $[Pe + B] = k[B];
            return $
        }

        function go($, k, B, de) {
            var Pe = -1,
                rt = $ == null ? 0 : $.length;
            for (de && rt && (B = $[++Pe]); ++Pe < rt;) B = k(B, $[Pe], Pe, $);
            return B
        }

        function Qp($, k, B, de) {
            var Pe = $ == null ? 0 : $.length;
            for (de && Pe && (B = $[--Pe]); Pe--;) B = k(B, $[Pe], Pe, $);
            return B
        }

        function vo($, k) {
            for (var B = -1, de = $ == null ? 0 : $.length; ++B < de;)
                if (k($[B], B, $)) return !0;
            return !1
        }
        var ed = yo("length");

        function td($) {
            return $.split("")
        }

        function rd($) {
            return $.match(Mt) || []
        }

        function xu($, k, B) {
            var de;
            return B($, function(Pe, rt, Ht) {
                if (k(Pe, rt, Ht)) return de = rt, !1
            }), de
        }

        function Fs($, k, B, de) {
            for (var Pe = $.length, rt = B + (de ? 1 : -1); de ? rt-- : ++rt < Pe;)
                if (k($[rt], rt, $)) return rt;
            return -1
        }

        function fn($, k, B) {
            return k === k ? dd($, k, B) : Fs($, Cu, B)
        }

        function id($, k, B, de) {
            for (var Pe = B - 1, rt = $.length; ++Pe < rt;)
                if (de($[Pe], k)) return Pe;
            return -1
        }

        function Cu($) {
            return $ !== $
        }

        function Ou($, k) {
            var B = $ == null ? 0 : $.length;
            return B ? mo($, k) / B : Y
        }

        function yo($) {
            return function(k) {
                return k == null ? r : k[$]
            }
        }

        function _o($) {
            return function(k) {
                return $ == null ? r : $[k]
            }
        }

        function Au($, k, B, de, Pe) {
            return Pe($, function(rt, Ht, ut) {
                B = de ? (de = !1, rt) : k(B, rt, Ht, ut)
            }), B
        }

        function nd($, k) {
            var B = $.length;
            for ($.sort(k); B--;) $[B] = $[B].value;
            return $
        }

        function mo($, k) {
            for (var B, de = -1, Pe = $.length; ++de < Pe;) {
                var rt = k($[de]);
                rt !== r && (B = B === r ? rt : B + rt)
            }
            return B
        }

        function bo($, k) {
            for (var B = -1, de = Array($); ++B < $;) de[B] = k(B);
            return de
        }

        function sd($, k) {
            return yt(k, function(B) {
                return [B, $[B]]
            })
        }

        function Pu($) {
            return $ && $.slice(0, Fu($) + 1).replace(It, "")
        }

        function wr($) {
            return function(k) {
                return $(k)
            }
        }

        function wo($, k) {
            return yt(k, function(B) {
                return $[B]
            })
        }

        function $n($, k) {
            return $.has(k)
        }

        function Nu($, k) {
            for (var B = -1, de = $.length; ++B < de && fn(k, $[B], 0) > -1;);
            return B
        }

        function Tu($, k) {
            for (var B = $.length; B-- && fn(k, $[B], 0) > -1;);
            return B
        }

        function ad($, k) {
            for (var B = $.length, de = 0; B--;) $[B] === k && ++de;
            return de
        }
        var od = _o(E),
            cd = _o(U);

        function ud($) {
            return "\\" + pe[$]
        }

        function hd($, k) {
            return $ == null ? r : $[k]
        }

        function pn($) {
            return Ns.test($)
        }

        function ld($) {
            return ji.test($)
        }

        function fd($) {
            for (var k, B = []; !(k = $.next()).done;) B.push(k.value);
            return B
        }

        function Eo($) {
            var k = -1,
                B = Array($.size);
            return $.forEach(function(de, Pe) {
                B[++k] = [Pe, de]
            }), B
        }

        function Ru($, k) {
            return function(B) {
                return $(k(B))
            }
        }

        function wi($, k) {
            for (var B = -1, de = $.length, Pe = 0, rt = []; ++B < de;) {
                var Ht = $[B];
                (Ht === k || Ht === b) && ($[B] = b, rt[Pe++] = B)
            }
            return rt
        }

        function Us($) {
            var k = -1,
                B = Array($.size);
            return $.forEach(function(de) {
                B[++k] = de
            }), B
        }

        function pd($) {
            var k = -1,
                B = Array($.size);
            return $.forEach(function(de) {
                B[++k] = [de, de]
            }), B
        }

        function dd($, k, B) {
            for (var de = B - 1, Pe = $.length; ++de < Pe;)
                if ($[de] === k) return de;
            return -1
        }

        function gd($, k, B) {
            for (var de = B + 1; de--;)
                if ($[de] === k) return de;
            return de
        }

        function dn($) {
            return pn($) ? yd($) : ed($)
        }

        function qr($) {
            return pn($) ? _d($) : td($)
        }

        function Fu($) {
            for (var k = $.length; k-- && Ot.test($.charAt(k)););
            return k
        }
        var vd = _o(Z);

        function yd($) {
            for (var k = ln.lastIndex = 0; ln.test($);) ++k;
            return k
        }

        function _d($) {
            return $.match(ln) || []
        }

        function md($) {
            return $.match(Ps) || []
        }
        var bd = function $(k) {
                k = k == null ? Xe : gn.defaults(Xe.Object(), k, gn.pick(Xe, Ts));
                var B = k.Array,
                    de = k.Date,
                    Pe = k.Error,
                    rt = k.Function,
                    Ht = k.Math,
                    ut = k.Object,
                    Do = k.RegExp,
                    wd = k.String,
                    Pr = k.TypeError,
                    $s = B.prototype,
                    Ed = rt.prototype,
                    vn = ut.prototype,
                    Ls = k["__core-js_shared__"],
                    Ms = Ed.toString,
                    nt = vn.hasOwnProperty,
                    Dd = 0,
                    Uu = function() {
                        var e = /[^.]+$/.exec(Ls && Ls.keys && Ls.keys.IE_PROTO || "");
                        return e ? "Symbol(src)_1." + e : ""
                    }(),
                    js = vn.toString,
                    Id = Ms.call(ut),
                    Sd = Xe._,
                    xd = Do("^" + Ms.call(nt).replace(Dt, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                    zs = lr ? k.Buffer : r,
                    Ei = k.Symbol,
                    qs = k.Uint8Array,
                    $u = zs ? zs.allocUnsafe : r,
                    Hs = Ru(ut.getPrototypeOf, ut),
                    Lu = ut.create,
                    Mu = vn.propertyIsEnumerable,
                    Bs = $s.splice,
                    ju = Ei ? Ei.isConcatSpreadable : r,
                    Ln = Ei ? Ei.iterator : r,
                    qi = Ei ? Ei.toStringTag : r,
                    Ks = function() {
                        try {
                            var e = Vi(ut, "defineProperty");
                            return e({}, "", {}), e
                        } catch {}
                    }(),
                    Cd = k.clearTimeout !== Xe.clearTimeout && k.clearTimeout,
                    Od = de && de.now !== Xe.Date.now && de.now,
                    Ad = k.setTimeout !== Xe.setTimeout && k.setTimeout,
                    ks = Ht.ceil,
                    Vs = Ht.floor,
                    Io = ut.getOwnPropertySymbols,
                    Pd = zs ? zs.isBuffer : r,
                    zu = k.isFinite,
                    Nd = $s.join,
                    Td = Ru(ut.keys, ut),
                    Bt = Ht.max,
                    Xt = Ht.min,
                    Rd = de.now,
                    Fd = k.parseInt,
                    qu = Ht.random,
                    Ud = $s.reverse,
                    So = Vi(k, "DataView"),
                    Mn = Vi(k, "Map"),
                    xo = Vi(k, "Promise"),
                    yn = Vi(k, "Set"),
                    jn = Vi(k, "WeakMap"),
                    zn = Vi(ut, "create"),
                    Gs = jn && new jn,
                    _n = {},
                    $d = Gi(So),
                    Ld = Gi(Mn),
                    Md = Gi(xo),
                    jd = Gi(yn),
                    zd = Gi(jn),
                    Ws = Ei ? Ei.prototype : r,
                    qn = Ws ? Ws.valueOf : r,
                    Hu = Ws ? Ws.toString : r;

                function y(e) {
                    if (xt(e) && !Te(e) && !(e instanceof Ye)) {
                        if (e instanceof Nr) return e;
                        if (nt.call(e, "__wrapped__")) return Bh(e)
                    }
                    return new Nr(e)
                }
                var mn = function() {
                    function e() {}
                    return function(i) {
                        if (!mt(i)) return {};
                        if (Lu) return Lu(i);
                        e.prototype = i;
                        var a = new e;
                        return e.prototype = r, a
                    }
                }();

                function Ys() {}

                function Nr(e, i) {
                    this.__wrapped__ = e, this.__actions__ = [], this.__chain__ = !!i, this.__index__ = 0, this.__values__ = r
                }
                y.templateSettings = {
                    escape: wt,
                    evaluate: Et,
                    interpolate: _t,
                    variable: "",
                    imports: {
                        _: y
                    }
                }, y.prototype = Ys.prototype, y.prototype.constructor = y, Nr.prototype = mn(Ys.prototype), Nr.prototype.constructor = Nr;

                function Ye(e) {
                    this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = re, this.__views__ = []
                }

                function qd() {
                    var e = new Ye(this.__wrapped__);
                    return e.__actions__ = fr(this.__actions__), e.__dir__ = this.__dir__, e.__filtered__ = this.__filtered__, e.__iteratees__ = fr(this.__iteratees__), e.__takeCount__ = this.__takeCount__, e.__views__ = fr(this.__views__), e
                }

                function Hd() {
                    if (this.__filtered__) {
                        var e = new Ye(this);
                        e.__dir__ = -1, e.__filtered__ = !0
                    } else e = this.clone(), e.__dir__ *= -1;
                    return e
                }

                function Bd() {
                    var e = this.__wrapped__.value(),
                        i = this.__dir__,
                        a = Te(e),
                        u = i < 0,
                        p = a ? e.length : 0,
                        _ = t0(0, p, this.__views__),
                        D = _.start,
                        A = _.end,
                        M = A - D,
                        J = u ? A : D - 1,
                        X = this.__iteratees__,
                        Q = X.length,
                        oe = 0,
                        ve = Xt(M, this.__takeCount__);
                    if (!a || !u && p == M && ve == M) return fh(e, this.__actions__);
                    var we = [];
                    e: for (; M-- && oe < ve;) {
                        J += i;
                        for (var qe = -1, Ee = e[J]; ++qe < Q;) {
                            var Ge = X[qe],
                                Ze = Ge.iteratee,
                                Ir = Ge.type,
                                sr = Ze(Ee);
                            if (Ir == q) Ee = sr;
                            else if (!sr) {
                                if (Ir == F) continue e;
                                break e
                            }
                        }
                        we[oe++] = Ee
                    }
                    return we
                }
                Ye.prototype = mn(Ys.prototype), Ye.prototype.constructor = Ye;

                function Hi(e) {
                    var i = -1,
                        a = e == null ? 0 : e.length;
                    for (this.clear(); ++i < a;) {
                        var u = e[i];
                        this.set(u[0], u[1])
                    }
                }

                function Kd() {
                    this.__data__ = zn ? zn(null) : {}, this.size = 0
                }

                function kd(e) {
                    var i = this.has(e) && delete this.__data__[e];
                    return this.size -= i ? 1 : 0, i
                }

                function Vd(e) {
                    var i = this.__data__;
                    if (zn) {
                        var a = i[e];
                        return a === v ? r : a
                    }
                    return nt.call(i, e) ? i[e] : r
                }

                function Gd(e) {
                    var i = this.__data__;
                    return zn ? i[e] !== r : nt.call(i, e)
                }

                function Wd(e, i) {
                    var a = this.__data__;
                    return this.size += this.has(e) ? 0 : 1, a[e] = zn && i === r ? v : i, this
                }
                Hi.prototype.clear = Kd, Hi.prototype.delete = kd, Hi.prototype.get = Vd, Hi.prototype.has = Gd, Hi.prototype.set = Wd;

                function ai(e) {
                    var i = -1,
                        a = e == null ? 0 : e.length;
                    for (this.clear(); ++i < a;) {
                        var u = e[i];
                        this.set(u[0], u[1])
                    }
                }

                function Yd() {
                    this.__data__ = [], this.size = 0
                }

                function Jd(e) {
                    var i = this.__data__,
                        a = Js(i, e);
                    if (a < 0) return !1;
                    var u = i.length - 1;
                    return a == u ? i.pop() : Bs.call(i, a, 1), --this.size, !0
                }

                function Xd(e) {
                    var i = this.__data__,
                        a = Js(i, e);
                    return a < 0 ? r : i[a][1]
                }

                function Zd(e) {
                    return Js(this.__data__, e) > -1
                }

                function Qd(e, i) {
                    var a = this.__data__,
                        u = Js(a, e);
                    return u < 0 ? (++this.size, a.push([e, i])) : a[u][1] = i, this
                }
                ai.prototype.clear = Yd, ai.prototype.delete = Jd, ai.prototype.get = Xd, ai.prototype.has = Zd, ai.prototype.set = Qd;

                function oi(e) {
                    var i = -1,
                        a = e == null ? 0 : e.length;
                    for (this.clear(); ++i < a;) {
                        var u = e[i];
                        this.set(u[0], u[1])
                    }
                }

                function eg() {
                    this.size = 0, this.__data__ = {
                        hash: new Hi,
                        map: new(Mn || ai),
                        string: new Hi
                    }
                }

                function tg(e) {
                    var i = ca(this, e).delete(e);
                    return this.size -= i ? 1 : 0, i
                }

                function rg(e) {
                    return ca(this, e).get(e)
                }

                function ig(e) {
                    return ca(this, e).has(e)
                }

                function ng(e, i) {
                    var a = ca(this, e),
                        u = a.size;
                    return a.set(e, i), this.size += a.size == u ? 0 : 1, this
                }
                oi.prototype.clear = eg, oi.prototype.delete = tg, oi.prototype.get = rg, oi.prototype.has = ig, oi.prototype.set = ng;

                function Bi(e) {
                    var i = -1,
                        a = e == null ? 0 : e.length;
                    for (this.__data__ = new oi; ++i < a;) this.add(e[i])
                }

                function sg(e) {
                    return this.__data__.set(e, v), this
                }

                function ag(e) {
                    return this.__data__.has(e)
                }
                Bi.prototype.add = Bi.prototype.push = sg, Bi.prototype.has = ag;

                function Hr(e) {
                    var i = this.__data__ = new ai(e);
                    this.size = i.size
                }

                function og() {
                    this.__data__ = new ai, this.size = 0
                }

                function cg(e) {
                    var i = this.__data__,
                        a = i.delete(e);
                    return this.size = i.size, a
                }

                function ug(e) {
                    return this.__data__.get(e)
                }

                function hg(e) {
                    return this.__data__.has(e)
                }

                function lg(e, i) {
                    var a = this.__data__;
                    if (a instanceof ai) {
                        var u = a.__data__;
                        if (!Mn || u.length < o - 1) return u.push([e, i]), this.size = ++a.size, this;
                        a = this.__data__ = new oi(u)
                    }
                    return a.set(e, i), this.size = a.size, this
                }
                Hr.prototype.clear = og, Hr.prototype.delete = cg, Hr.prototype.get = ug, Hr.prototype.has = hg, Hr.prototype.set = lg;

                function Bu(e, i) {
                    var a = Te(e),
                        u = !a && Wi(e),
                        p = !a && !u && Ci(e),
                        _ = !a && !u && !p && Dn(e),
                        D = a || u || p || _,
                        A = D ? bo(e.length, wd) : [],
                        M = A.length;
                    for (var J in e)(i || nt.call(e, J)) && !(D && (J == "length" || p && (J == "offset" || J == "parent") || _ && (J == "buffer" || J == "byteLength" || J == "byteOffset") || li(J, M))) && A.push(J);
                    return A
                }

                function Ku(e) {
                    var i = e.length;
                    return i ? e[Lo(0, i - 1)] : r
                }

                function fg(e, i) {
                    return ua(fr(e), Ki(i, 0, e.length))
                }

                function pg(e) {
                    return ua(fr(e))
                }

                function Co(e, i, a) {
                    (a !== r && !Br(e[i], a) || a === r && !(i in e)) && ci(e, i, a)
                }

                function Hn(e, i, a) {
                    var u = e[i];
                    (!(nt.call(e, i) && Br(u, a)) || a === r && !(i in e)) && ci(e, i, a)
                }

                function Js(e, i) {
                    for (var a = e.length; a--;)
                        if (Br(e[a][0], i)) return a;
                    return -1
                }

                function dg(e, i, a, u) {
                    return Di(e, function(p, _, D) {
                        i(u, p, a(p), D)
                    }), u
                }

                function ku(e, i) {
                    return e && Jr(i, kt(i), e)
                }

                function gg(e, i) {
                    return e && Jr(i, dr(i), e)
                }

                function ci(e, i, a) {
                    i == "__proto__" && Ks ? Ks(e, i, {
                        configurable: !0,
                        enumerable: !0,
                        value: a,
                        writable: !0
                    }) : e[i] = a
                }

                function Oo(e, i) {
                    for (var a = -1, u = i.length, p = B(u), _ = e == null; ++a < u;) p[a] = _ ? r : cc(e, i[a]);
                    return p
                }

                function Ki(e, i, a) {
                    return e === e && (a !== r && (e = e <= a ? e : a), i !== r && (e = e >= i ? e : i)), e
                }

                function Tr(e, i, a, u, p, _) {
                    var D, A = i & S,
                        M = i & O,
                        J = i & P;
                    if (a && (D = p ? a(e, u, p, _) : a(e)), D !== r) return D;
                    if (!mt(e)) return e;
                    var X = Te(e);
                    if (X) {
                        if (D = i0(e), !A) return fr(e, D)
                    } else {
                        var Q = Zt(e),
                            oe = Q == se || Q == fe;
                        if (Ci(e)) return gh(e, A);
                        if (Q == Le || Q == he || oe && !p) {
                            if (D = M || oe ? {} : Fh(e), !A) return M ? Vg(e, gg(D, e)) : kg(e, ku(D, e))
                        } else {
                            if (!st[Q]) return p ? e : {};
                            D = n0(e, Q, A)
                        }
                    }
                    _ || (_ = new Hr);
                    var ve = _.get(e);
                    if (ve) return ve;
                    _.set(e, D), ul(e) ? e.forEach(function(Ee) {
                        D.add(Tr(Ee, i, a, Ee, e, _))
                    }) : ol(e) && e.forEach(function(Ee, Ge) {
                        D.set(Ge, Tr(Ee, i, a, Ge, e, _))
                    });
                    var we = J ? M ? Wo : Go : M ? dr : kt,
                        qe = X ? r : we(e);
                    return Ar(qe || e, function(Ee, Ge) {
                        qe && (Ge = Ee, Ee = e[Ge]), Hn(D, Ge, Tr(Ee, i, a, Ge, e, _))
                    }), D
                }

                function vg(e) {
                    var i = kt(e);
                    return function(a) {
                        return Vu(a, e, i)
                    }
                }

                function Vu(e, i, a) {
                    var u = a.length;
                    if (e == null) return !u;
                    for (e = ut(e); u--;) {
                        var p = a[u],
                            _ = i[p],
                            D = e[p];
                        if (D === r && !(p in e) || !_(D)) return !1
                    }
                    return !0
                }

                function Gu(e, i, a) {
                    if (typeof e != "function") throw new Pr(d);
                    return Yn(function() {
                        e.apply(r, a)
                    }, i)
                }

                function Bn(e, i, a, u) {
                    var p = -1,
                        _ = Rs,
                        D = !0,
                        A = e.length,
                        M = [],
                        J = i.length;
                    if (!A) return M;
                    a && (i = yt(i, wr(a))), u ? (_ = po, D = !1) : i.length >= o && (_ = $n, D = !1, i = new Bi(i));
                    e: for (; ++p < A;) {
                        var X = e[p],
                            Q = a == null ? X : a(X);
                        if (X = u || X !== 0 ? X : 0, D && Q === Q) {
                            for (var oe = J; oe--;)
                                if (i[oe] === Q) continue e;
                            M.push(X)
                        } else _(i, Q, u) || M.push(X)
                    }
                    return M
                }
                var Di = bh(Yr),
                    Wu = bh(Po, !0);

                function yg(e, i) {
                    var a = !0;
                    return Di(e, function(u, p, _) {
                        return a = !!i(u, p, _), a
                    }), a
                }

                function Xs(e, i, a) {
                    for (var u = -1, p = e.length; ++u < p;) {
                        var _ = e[u],
                            D = i(_);
                        if (D != null && (A === r ? D === D && !Dr(D) : a(D, A))) var A = D,
                            M = _
                    }
                    return M
                }

                function _g(e, i, a, u) {
                    var p = e.length;
                    for (a = Me(a), a < 0 && (a = -a > p ? 0 : p + a), u = u === r || u > p ? p : Me(u), u < 0 && (u += p), u = a > u ? 0 : ll(u); a < u;) e[a++] = i;
                    return e
                }

                function Yu(e, i) {
                    var a = [];
                    return Di(e, function(u, p, _) {
                        i(u, p, _) && a.push(u)
                    }), a
                }

                function Wt(e, i, a, u, p) {
                    var _ = -1,
                        D = e.length;
                    for (a || (a = a0), p || (p = []); ++_ < D;) {
                        var A = e[_];
                        i > 0 && a(A) ? i > 1 ? Wt(A, i - 1, a, u, p) : bi(p, A) : u || (p[p.length] = A)
                    }
                    return p
                }
                var Ao = wh(),
                    Ju = wh(!0);

                function Yr(e, i) {
                    return e && Ao(e, i, kt)
                }

                function Po(e, i) {
                    return e && Ju(e, i, kt)
                }

                function Zs(e, i) {
                    return mi(i, function(a) {
                        return fi(e[a])
                    })
                }

                function ki(e, i) {
                    i = Si(i, e);
                    for (var a = 0, u = i.length; e != null && a < u;) e = e[Xr(i[a++])];
                    return a && a == u ? e : r
                }

                function Xu(e, i, a) {
                    var u = i(e);
                    return Te(e) ? u : bi(u, a(e))
                }

                function ir(e) {
                    return e == null ? e === r ? ze : ke : qi && qi in ut(e) ? e0(e) : p0(e)
                }

                function No(e, i) {
                    return e > i
                }

                function mg(e, i) {
                    return e != null && nt.call(e, i)
                }

                function bg(e, i) {
                    return e != null && i in ut(e)
                }

                function wg(e, i, a) {
                    return e >= Xt(i, a) && e < Bt(i, a)
                }

                function To(e, i, a) {
                    for (var u = a ? po : Rs, p = e[0].length, _ = e.length, D = _, A = B(_), M = 1 / 0, J = []; D--;) {
                        var X = e[D];
                        D && i && (X = yt(X, wr(i))), M = Xt(X.length, M), A[D] = !a && (i || p >= 120 && X.length >= 120) ? new Bi(D && X) : r
                    }
                    X = e[0];
                    var Q = -1,
                        oe = A[0];
                    e: for (; ++Q < p && J.length < M;) {
                        var ve = X[Q],
                            we = i ? i(ve) : ve;
                        if (ve = a || ve !== 0 ? ve : 0, !(oe ? $n(oe, we) : u(J, we, a))) {
                            for (D = _; --D;) {
                                var qe = A[D];
                                if (!(qe ? $n(qe, we) : u(e[D], we, a))) continue e
                            }
                            oe && oe.push(we), J.push(ve)
                        }
                    }
                    return J
                }

                function Eg(e, i, a, u) {
                    return Yr(e, function(p, _, D) {
                        i(u, a(p), _, D)
                    }), u
                }

                function Kn(e, i, a) {
                    i = Si(i, e), e = Mh(e, i);
                    var u = e == null ? e : e[Xr(Fr(i))];
                    return u == null ? r : Kt(u, e, a)
                }

                function Zu(e) {
                    return xt(e) && ir(e) == he
                }

                function Dg(e) {
                    return xt(e) && ir(e) == De
                }

                function Ig(e) {
                    return xt(e) && ir(e) == R
                }

                function kn(e, i, a, u, p) {
                    return e === i ? !0 : e == null || i == null || !xt(e) && !xt(i) ? e !== e && i !== i : Sg(e, i, a, u, kn, p)
                }

                function Sg(e, i, a, u, p, _) {
                    var D = Te(e),
                        A = Te(i),
                        M = D ? _e : Zt(e),
                        J = A ? _e : Zt(i);
                    M = M == he ? Le : M, J = J == he ? Le : J;
                    var X = M == Le,
                        Q = J == Le,
                        oe = M == J;
                    if (oe && Ci(e)) {
                        if (!Ci(i)) return !1;
                        D = !0, X = !1
                    }
                    if (oe && !X) return _ || (_ = new Hr), D || Dn(e) ? Nh(e, i, a, u, p, _) : Zg(e, i, M, a, u, p, _);
                    if (!(a & N)) {
                        var ve = X && nt.call(e, "__wrapped__"),
                            we = Q && nt.call(i, "__wrapped__");
                        if (ve || we) {
                            var qe = ve ? e.value() : e,
                                Ee = we ? i.value() : i;
                            return _ || (_ = new Hr), p(qe, Ee, a, u, _)
                        }
                    }
                    return oe ? (_ || (_ = new Hr), Qg(e, i, a, u, p, _)) : !1
                }

                function xg(e) {
                    return xt(e) && Zt(e) == Ie
                }

                function Ro(e, i, a, u) {
                    var p = a.length,
                        _ = p,
                        D = !u;
                    if (e == null) return !_;
                    for (e = ut(e); p--;) {
                        var A = a[p];
                        if (D && A[2] ? A[1] !== e[A[0]] : !(A[0] in e)) return !1
                    }
                    for (; ++p < _;) {
                        A = a[p];
                        var M = A[0],
                            J = e[M],
                            X = A[1];
                        if (D && A[2]) {
                            if (J === r && !(M in e)) return !1
                        } else {
                            var Q = new Hr;
                            if (u) var oe = u(J, X, M, e, i, Q);
                            if (!(oe === r ? kn(X, J, N | H, u, Q) : oe)) return !1
                        }
                    }
                    return !0
                }

                function Qu(e) {
                    if (!mt(e) || c0(e)) return !1;
                    var i = fi(e) ? xd : Xa;
                    return i.test(Gi(e))
                }

                function Cg(e) {
                    return xt(e) && ir(e) == je
                }

                function Og(e) {
                    return xt(e) && Zt(e) == Se
                }

                function Ag(e) {
                    return xt(e) && ga(e.length) && !!at[ir(e)]
                }

                function eh(e) {
                    return typeof e == "function" ? e : e == null ? gr : typeof e == "object" ? Te(e) ? ih(e[0], e[1]) : rh(e) : El(e)
                }

                function Fo(e) {
                    if (!Wn(e)) return Td(e);
                    var i = [];
                    for (var a in ut(e)) nt.call(e, a) && a != "constructor" && i.push(a);
                    return i
                }

                function Pg(e) {
                    if (!mt(e)) return f0(e);
                    var i = Wn(e),
                        a = [];
                    for (var u in e) u == "constructor" && (i || !nt.call(e, u)) || a.push(u);
                    return a
                }

                function Uo(e, i) {
                    return e < i
                }

                function th(e, i) {
                    var a = -1,
                        u = pr(e) ? B(e.length) : [];
                    return Di(e, function(p, _, D) {
                        u[++a] = i(p, _, D)
                    }), u
                }

                function rh(e) {
                    var i = Jo(e);
                    return i.length == 1 && i[0][2] ? $h(i[0][0], i[0][1]) : function(a) {
                        return a === e || Ro(a, e, i)
                    }
                }

                function ih(e, i) {
                    return Zo(e) && Uh(i) ? $h(Xr(e), i) : function(a) {
                        var u = cc(a, e);
                        return u === r && u === i ? uc(a, e) : kn(i, u, N | H)
                    }
                }

                function Qs(e, i, a, u, p) {
                    e !== i && Ao(i, function(_, D) {
                        if (p || (p = new Hr), mt(_)) Ng(e, i, D, a, Qs, u, p);
                        else {
                            var A = u ? u(ec(e, D), _, D + "", e, i, p) : r;
                            A === r && (A = _), Co(e, D, A)
                        }
                    }, dr)
                }

                function Ng(e, i, a, u, p, _, D) {
                    var A = ec(e, a),
                        M = ec(i, a),
                        J = D.get(M);
                    if (J) {
                        Co(e, a, J);
                        return
                    }
                    var X = _ ? _(A, M, a + "", e, i, D) : r,
                        Q = X === r;
                    if (Q) {
                        var oe = Te(M),
                            ve = !oe && Ci(M),
                            we = !oe && !ve && Dn(M);
                        X = M, oe || ve || we ? Te(A) ? X = A : Pt(A) ? X = fr(A) : ve ? (Q = !1, X = gh(M, !0)) : we ? (Q = !1, X = vh(M, !0)) : X = [] : Jn(M) || Wi(M) ? (X = A, Wi(A) ? X = fl(A) : (!mt(A) || fi(A)) && (X = Fh(M))) : Q = !1
                    }
                    Q && (D.set(M, X), p(X, M, u, _, D), D.delete(M)), Co(e, a, X)
                }

                function nh(e, i) {
                    var a = e.length;
                    if (a) return i += i < 0 ? a : 0, li(i, a) ? e[i] : r
                }

                function sh(e, i, a) {
                    i.length ? i = yt(i, function(_) {
                        return Te(_) ? function(D) {
                            return ki(D, _.length === 1 ? _[0] : _)
                        } : _
                    }) : i = [gr];
                    var u = -1;
                    i = yt(i, wr(me()));
                    var p = th(e, function(_, D, A) {
                        var M = yt(i, function(J) {
                            return J(_)
                        });
                        return {
                            criteria: M,
                            index: ++u,
                            value: _
                        }
                    });
                    return nd(p, function(_, D) {
                        return Kg(_, D, a)
                    })
                }

                function Tg(e, i) {
                    return ah(e, i, function(a, u) {
                        return uc(e, u)
                    })
                }

                function ah(e, i, a) {
                    for (var u = -1, p = i.length, _ = {}; ++u < p;) {
                        var D = i[u],
                            A = ki(e, D);
                        a(A, D) && Vn(_, Si(D, e), A)
                    }
                    return _
                }

                function Rg(e) {
                    return function(i) {
                        return ki(i, e)
                    }
                }

                function $o(e, i, a, u) {
                    var p = u ? id : fn,
                        _ = -1,
                        D = i.length,
                        A = e;
                    for (e === i && (i = fr(i)), a && (A = yt(e, wr(a))); ++_ < D;)
                        for (var M = 0, J = i[_], X = a ? a(J) : J;
                            (M = p(A, X, M, u)) > -1;) A !== e && Bs.call(A, M, 1), Bs.call(e, M, 1);
                    return e
                }

                function oh(e, i) {
                    for (var a = e ? i.length : 0, u = a - 1; a--;) {
                        var p = i[a];
                        if (a == u || p !== _) {
                            var _ = p;
                            li(p) ? Bs.call(e, p, 1) : zo(e, p)
                        }
                    }
                    return e
                }

                function Lo(e, i) {
                    return e + Vs(qu() * (i - e + 1))
                }

                function Fg(e, i, a, u) {
                    for (var p = -1, _ = Bt(ks((i - e) / (a || 1)), 0), D = B(_); _--;) D[u ? _ : ++p] = e, e += a;
                    return D
                }

                function Mo(e, i) {
                    var a = "";
                    if (!e || i < 1 || i > W) return a;
                    do i % 2 && (a += e), i = Vs(i / 2), i && (e += e); while (i);
                    return a
                }

                function Ke(e, i) {
                    return tc(Lh(e, i, gr), e + "")
                }

                function Ug(e) {
                    return Ku(In(e))
                }

                function $g(e, i) {
                    var a = In(e);
                    return ua(a, Ki(i, 0, a.length))
                }

                function Vn(e, i, a, u) {
                    if (!mt(e)) return e;
                    i = Si(i, e);
                    for (var p = -1, _ = i.length, D = _ - 1, A = e; A != null && ++p < _;) {
                        var M = Xr(i[p]),
                            J = a;
                        if (M === "__proto__" || M === "constructor" || M === "prototype") return e;
                        if (p != D) {
                            var X = A[M];
                            J = u ? u(X, M, A) : r, J === r && (J = mt(X) ? X : li(i[p + 1]) ? [] : {})
                        }
                        Hn(A, M, J), A = A[M]
                    }
                    return e
                }
                var ch = Gs ? function(e, i) {
                        return Gs.set(e, i), e
                    } : gr,
                    Lg = Ks ? function(e, i) {
                        return Ks(e, "toString", {
                            configurable: !0,
                            enumerable: !1,
                            value: lc(i),
                            writable: !0
                        })
                    } : gr;

                function Mg(e) {
                    return ua(In(e))
                }

                function Rr(e, i, a) {
                    var u = -1,
                        p = e.length;
                    i < 0 && (i = -i > p ? 0 : p + i), a = a > p ? p : a, a < 0 && (a += p), p = i > a ? 0 : a - i >>> 0, i >>>= 0;
                    for (var _ = B(p); ++u < p;) _[u] = e[u + i];
                    return _
                }

                function jg(e, i) {
                    var a;
                    return Di(e, function(u, p, _) {
                        return a = i(u, p, _), !a
                    }), !!a
                }

                function ea(e, i, a) {
                    var u = 0,
                        p = e == null ? u : e.length;
                    if (typeof i == "number" && i === i && p <= ne) {
                        for (; u < p;) {
                            var _ = u + p >>> 1,
                                D = e[_];
                            D !== null && !Dr(D) && (a ? D <= i : D < i) ? u = _ + 1 : p = _
                        }
                        return p
                    }
                    return jo(e, i, gr, a)
                }

                function jo(e, i, a, u) {
                    var p = 0,
                        _ = e == null ? 0 : e.length;
                    if (_ === 0) return 0;
                    i = a(i);
                    for (var D = i !== i, A = i === null, M = Dr(i), J = i === r; p < _;) {
                        var X = Vs((p + _) / 2),
                            Q = a(e[X]),
                            oe = Q !== r,
                            ve = Q === null,
                            we = Q === Q,
                            qe = Dr(Q);
                        if (D) var Ee = u || we;
                        else J ? Ee = we && (u || oe) : A ? Ee = we && oe && (u || !ve) : M ? Ee = we && oe && !ve && (u || !qe) : ve || qe ? Ee = !1 : Ee = u ? Q <= i : Q < i;
                        Ee ? p = X + 1 : _ = X
                    }
                    return Xt(_, xe)
                }

                function uh(e, i) {
                    for (var a = -1, u = e.length, p = 0, _ = []; ++a < u;) {
                        var D = e[a],
                            A = i ? i(D) : D;
                        if (!a || !Br(A, M)) {
                            var M = A;
                            _[p++] = D === 0 ? 0 : D
                        }
                    }
                    return _
                }

                function hh(e) {
                    return typeof e == "number" ? e : Dr(e) ? Y : +e
                }

                function Er(e) {
                    if (typeof e == "string") return e;
                    if (Te(e)) return yt(e, Er) + "";
                    if (Dr(e)) return Hu ? Hu.call(e) : "";
                    var i = e + "";
                    return i == "0" && 1 / e == -te ? "-0" : i
                }

                function Ii(e, i, a) {
                    var u = -1,
                        p = Rs,
                        _ = e.length,
                        D = !0,
                        A = [],
                        M = A;
                    if (a) D = !1, p = po;
                    else if (_ >= o) {
                        var J = i ? null : Jg(e);
                        if (J) return Us(J);
                        D = !1, p = $n, M = new Bi
                    } else M = i ? [] : A;
                    e: for (; ++u < _;) {
                        var X = e[u],
                            Q = i ? i(X) : X;
                        if (X = a || X !== 0 ? X : 0, D && Q === Q) {
                            for (var oe = M.length; oe--;)
                                if (M[oe] === Q) continue e;
                            i && M.push(Q), A.push(X)
                        } else p(M, Q, a) || (M !== A && M.push(Q), A.push(X))
                    }
                    return A
                }

                function zo(e, i) {
                    return i = Si(i, e), e = Mh(e, i), e == null || delete e[Xr(Fr(i))]
                }

                function lh(e, i, a, u) {
                    return Vn(e, i, a(ki(e, i)), u)
                }

                function ta(e, i, a, u) {
                    for (var p = e.length, _ = u ? p : -1;
                        (u ? _-- : ++_ < p) && i(e[_], _, e););
                    return a ? Rr(e, u ? 0 : _, u ? _ + 1 : p) : Rr(e, u ? _ + 1 : 0, u ? p : _)
                }

                function fh(e, i) {
                    var a = e;
                    return a instanceof Ye && (a = a.value()), go(i, function(u, p) {
                        return p.func.apply(p.thisArg, bi([u], p.args))
                    }, a)
                }

                function qo(e, i, a) {
                    var u = e.length;
                    if (u < 2) return u ? Ii(e[0]) : [];
                    for (var p = -1, _ = B(u); ++p < u;)
                        for (var D = e[p], A = -1; ++A < u;) A != p && (_[p] = Bn(_[p] || D, e[A], i, a));
                    return Ii(Wt(_, 1), i, a)
                }

                function ph(e, i, a) {
                    for (var u = -1, p = e.length, _ = i.length, D = {}; ++u < p;) {
                        var A = u < _ ? i[u] : r;
                        a(D, e[u], A)
                    }
                    return D
                }

                function Ho(e) {
                    return Pt(e) ? e : []
                }

                function Bo(e) {
                    return typeof e == "function" ? e : gr
                }

                function Si(e, i) {
                    return Te(e) ? e : Zo(e, i) ? [e] : Hh(it(e))
                }
                var zg = Ke;

                function xi(e, i, a) {
                    var u = e.length;
                    return a = a === r ? u : a, !i && a >= u ? e : Rr(e, i, a)
                }
                var dh = Cd || function(e) {
                    return Xe.clearTimeout(e)
                };

                function gh(e, i) {
                    if (i) return e.slice();
                    var a = e.length,
                        u = $u ? $u(a) : new e.constructor(a);
                    return e.copy(u), u
                }

                function Ko(e) {
                    var i = new e.constructor(e.byteLength);
                    return new qs(i).set(new qs(e)), i
                }

                function qg(e, i) {
                    var a = i ? Ko(e.buffer) : e.buffer;
                    return new e.constructor(a, e.byteOffset, e.byteLength)
                }

                function Hg(e) {
                    var i = new e.constructor(e.source, Cr.exec(e));
                    return i.lastIndex = e.lastIndex, i
                }

                function Bg(e) {
                    return qn ? ut(qn.call(e)) : {}
                }

                function vh(e, i) {
                    var a = i ? Ko(e.buffer) : e.buffer;
                    return new e.constructor(a, e.byteOffset, e.length)
                }

                function yh(e, i) {
                    if (e !== i) {
                        var a = e !== r,
                            u = e === null,
                            p = e === e,
                            _ = Dr(e),
                            D = i !== r,
                            A = i === null,
                            M = i === i,
                            J = Dr(i);
                        if (!A && !J && !_ && e > i || _ && D && M && !A && !J || u && D && M || !a && M || !p) return 1;
                        if (!u && !_ && !J && e < i || J && a && p && !u && !_ || A && a && p || !D && p || !M) return -1
                    }
                    return 0
                }

                function Kg(e, i, a) {
                    for (var u = -1, p = e.criteria, _ = i.criteria, D = p.length, A = a.length; ++u < D;) {
                        var M = yh(p[u], _[u]);
                        if (M) {
                            if (u >= A) return M;
                            var J = a[u];
                            return M * (J == "desc" ? -1 : 1)
                        }
                    }
                    return e.index - i.index
                }

                function _h(e, i, a, u) {
                    for (var p = -1, _ = e.length, D = a.length, A = -1, M = i.length, J = Bt(_ - D, 0), X = B(M + J), Q = !u; ++A < M;) X[A] = i[A];
                    for (; ++p < D;)(Q || p < _) && (X[a[p]] = e[p]);
                    for (; J--;) X[A++] = e[p++];
                    return X
                }

                function mh(e, i, a, u) {
                    for (var p = -1, _ = e.length, D = -1, A = a.length, M = -1, J = i.length, X = Bt(_ - A, 0), Q = B(X + J), oe = !u; ++p < X;) Q[p] = e[p];
                    for (var ve = p; ++M < J;) Q[ve + M] = i[M];
                    for (; ++D < A;)(oe || p < _) && (Q[ve + a[D]] = e[p++]);
                    return Q
                }

                function fr(e, i) {
                    var a = -1,
                        u = e.length;
                    for (i || (i = B(u)); ++a < u;) i[a] = e[a];
                    return i
                }

                function Jr(e, i, a, u) {
                    var p = !a;
                    a || (a = {});
                    for (var _ = -1, D = i.length; ++_ < D;) {
                        var A = i[_],
                            M = u ? u(a[A], e[A], A, a, e) : r;
                        M === r && (M = e[A]), p ? ci(a, A, M) : Hn(a, A, M)
                    }
                    return a
                }

                function kg(e, i) {
                    return Jr(e, Xo(e), i)
                }

                function Vg(e, i) {
                    return Jr(e, Th(e), i)
                }

                function ra(e, i) {
                    return function(a, u) {
                        var p = Te(a) ? Xp : dg,
                            _ = i ? i() : {};
                        return p(a, e, me(u, 2), _)
                    }
                }

                function bn(e) {
                    return Ke(function(i, a) {
                        var u = -1,
                            p = a.length,
                            _ = p > 1 ? a[p - 1] : r,
                            D = p > 2 ? a[2] : r;
                        for (_ = e.length > 3 && typeof _ == "function" ? (p--, _) : r, D && nr(a[0], a[1], D) && (_ = p < 3 ? r : _, p = 1), i = ut(i); ++u < p;) {
                            var A = a[u];
                            A && e(i, A, u, _)
                        }
                        return i
                    })
                }

                function bh(e, i) {
                    return function(a, u) {
                        if (a == null) return a;
                        if (!pr(a)) return e(a, u);
                        for (var p = a.length, _ = i ? p : -1, D = ut(a);
                            (i ? _-- : ++_ < p) && u(D[_], _, D) !== !1;);
                        return a
                    }
                }

                function wh(e) {
                    return function(i, a, u) {
                        for (var p = -1, _ = ut(i), D = u(i), A = D.length; A--;) {
                            var M = D[e ? A : ++p];
                            if (a(_[M], M, _) === !1) break
                        }
                        return i
                    }
                }

                function Gg(e, i, a) {
                    var u = i & G,
                        p = Gn(e);

                    function _() {
                        var D = this && this !== Xe && this instanceof _ ? p : e;
                        return D.apply(u ? a : this, arguments)
                    }
                    return _
                }

                function Eh(e) {
                    return function(i) {
                        i = it(i);
                        var a = pn(i) ? qr(i) : r,
                            u = a ? a[0] : i.charAt(0),
                            p = a ? xi(a, 1).join("") : i.slice(1);
                        return u[e]() + p
                    }
                }

                function wn(e) {
                    return function(i) {
                        return go(bl(ml(i).replace(Fn, "")), e, "")
                    }
                }

                function Gn(e) {
                    return function() {
                        var i = arguments;
                        switch (i.length) {
                            case 0:
                                return new e;
                            case 1:
                                return new e(i[0]);
                            case 2:
                                return new e(i[0], i[1]);
                            case 3:
                                return new e(i[0], i[1], i[2]);
                            case 4:
                                return new e(i[0], i[1], i[2], i[3]);
                            case 5:
                                return new e(i[0], i[1], i[2], i[3], i[4]);
                            case 6:
                                return new e(i[0], i[1], i[2], i[3], i[4], i[5]);
                            case 7:
                                return new e(i[0], i[1], i[2], i[3], i[4], i[5], i[6])
                        }
                        var a = mn(e.prototype),
                            u = e.apply(a, i);
                        return mt(u) ? u : a
                    }
                }

                function Wg(e, i, a) {
                    var u = Gn(e);

                    function p() {
                        for (var _ = arguments.length, D = B(_), A = _, M = En(p); A--;) D[A] = arguments[A];
                        var J = _ < 3 && D[0] !== M && D[_ - 1] !== M ? [] : wi(D, M);
                        if (_ -= J.length, _ < a) return Ch(e, i, ia, p.placeholder, r, D, J, r, r, a - _);
                        var X = this && this !== Xe && this instanceof p ? u : e;
                        return Kt(X, this, D)
                    }
                    return p
                }

                function Dh(e) {
                    return function(i, a, u) {
                        var p = ut(i);
                        if (!pr(i)) {
                            var _ = me(a, 3);
                            i = kt(i), a = function(A) {
                                return _(p[A], A, p)
                            }
                        }
                        var D = e(i, a, u);
                        return D > -1 ? p[_ ? i[D] : D] : r
                    }
                }

                function Ih(e) {
                    return hi(function(i) {
                        var a = i.length,
                            u = a,
                            p = Nr.prototype.thru;
                        for (e && i.reverse(); u--;) {
                            var _ = i[u];
                            if (typeof _ != "function") throw new Pr(d);
                            if (p && !D && oa(_) == "wrapper") var D = new Nr([], !0)
                        }
                        for (u = D ? u : a; ++u < a;) {
                            _ = i[u];
                            var A = oa(_),
                                M = A == "wrapper" ? Yo(_) : r;
                            M && Qo(M[0]) && M[1] == (c | L | C | m) && !M[4].length && M[9] == 1 ? D = D[oa(M[0])].apply(D, M[3]) : D = _.length == 1 && Qo(_) ? D[A]() : D.thru(_)
                        }
                        return function() {
                            var J = arguments,
                                X = J[0];
                            if (D && J.length == 1 && Te(X)) return D.plant(X).value();
                            for (var Q = 0, oe = a ? i[Q].apply(this, J) : X; ++Q < a;) oe = i[Q].call(this, oe);
                            return oe
                        }
                    })
                }

                function ia(e, i, a, u, p, _, D, A, M, J) {
                    var X = i & c,
                        Q = i & G,
                        oe = i & ie,
                        ve = i & (L | I),
                        we = i & K,
                        qe = oe ? r : Gn(e);

                    function Ee() {
                        for (var Ge = arguments.length, Ze = B(Ge), Ir = Ge; Ir--;) Ze[Ir] = arguments[Ir];
                        if (ve) var sr = En(Ee),
                            Sr = ad(Ze, sr);
                        if (u && (Ze = _h(Ze, u, p, ve)), _ && (Ze = mh(Ze, _, D, ve)), Ge -= Sr, ve && Ge < J) {
                            var Nt = wi(Ze, sr);
                            return Ch(e, i, ia, Ee.placeholder, a, Ze, Nt, A, M, J - Ge)
                        }
                        var Kr = Q ? a : this,
                            di = oe ? Kr[e] : e;
                        return Ge = Ze.length, A ? Ze = d0(Ze, A) : we && Ge > 1 && Ze.reverse(), X && M < Ge && (Ze.length = M), this && this !== Xe && this instanceof Ee && (di = qe || Gn(di)), di.apply(Kr, Ze)
                    }
                    return Ee
                }

                function Sh(e, i) {
                    return function(a, u) {
                        return Eg(a, e, i(u), {})
                    }
                }

                function na(e, i) {
                    return function(a, u) {
                        var p;
                        if (a === r && u === r) return i;
                        if (a !== r && (p = a), u !== r) {
                            if (p === r) return u;
                            typeof a == "string" || typeof u == "string" ? (a = Er(a), u = Er(u)) : (a = hh(a), u = hh(u)), p = e(a, u)
                        }
                        return p
                    }
                }

                function ko(e) {
                    return hi(function(i) {
                        return i = yt(i, wr(me())), Ke(function(a) {
                            var u = this;
                            return e(i, function(p) {
                                return Kt(p, u, a)
                            })
                        })
                    })
                }

                function sa(e, i) {
                    i = i === r ? " " : Er(i);
                    var a = i.length;
                    if (a < 2) return a ? Mo(i, e) : i;
                    var u = Mo(i, ks(e / dn(i)));
                    return pn(i) ? xi(qr(u), 0, e).join("") : u.slice(0, e)
                }

                function Yg(e, i, a, u) {
                    var p = i & G,
                        _ = Gn(e);

                    function D() {
                        for (var A = -1, M = arguments.length, J = -1, X = u.length, Q = B(X + M), oe = this && this !== Xe && this instanceof D ? _ : e; ++J < X;) Q[J] = u[J];
                        for (; M--;) Q[J++] = arguments[++A];
                        return Kt(oe, p ? a : this, Q)
                    }
                    return D
                }

                function xh(e) {
                    return function(i, a, u) {
                        return u && typeof u != "number" && nr(i, a, u) && (a = u = r), i = pi(i), a === r ? (a = i, i = 0) : a = pi(a), u = u === r ? i < a ? 1 : -1 : pi(u), Fg(i, a, u, e)
                    }
                }

                function aa(e) {
                    return function(i, a) {
                        return typeof i == "string" && typeof a == "string" || (i = Ur(i), a = Ur(a)), e(i, a)
                    }
                }

                function Ch(e, i, a, u, p, _, D, A, M, J) {
                    var X = i & L,
                        Q = X ? D : r,
                        oe = X ? r : D,
                        ve = X ? _ : r,
                        we = X ? r : _;
                    i |= X ? C : w, i &= ~(X ? w : C), i & T || (i &= ~(G | ie));
                    var qe = [e, i, p, ve, Q, we, oe, A, M, J],
                        Ee = a.apply(r, qe);
                    return Qo(e) && jh(Ee, qe), Ee.placeholder = u, zh(Ee, e, i)
                }

                function Vo(e) {
                    var i = Ht[e];
                    return function(a, u) {
                        if (a = Ur(a), u = u == null ? 0 : Xt(Me(u), 292), u && zu(a)) {
                            var p = (it(a) + "e").split("e"),
                                _ = i(p[0] + "e" + (+p[1] + u));
                            return p = (it(_) + "e").split("e"), +(p[0] + "e" + (+p[1] - u))
                        }
                        return i(a)
                    }
                }
                var Jg = yn && 1 / Us(new yn([, -0]))[1] == te ? function(e) {
                    return new yn(e)
                } : dc;

                function Oh(e) {
                    return function(i) {
                        var a = Zt(i);
                        return a == Ie ? Eo(i) : a == Se ? pd(i) : sd(i, e(i))
                    }
                }

                function ui(e, i, a, u, p, _, D, A) {
                    var M = i & ie;
                    if (!M && typeof e != "function") throw new Pr(d);
                    var J = u ? u.length : 0;
                    if (J || (i &= ~(C | w), u = p = r), D = D === r ? D : Bt(Me(D), 0), A = A === r ? A : Me(A), J -= p ? p.length : 0, i & w) {
                        var X = u,
                            Q = p;
                        u = p = r
                    }
                    var oe = M ? r : Yo(e),
                        ve = [e, i, a, u, p, X, Q, _, D, A];
                    if (oe && l0(ve, oe), e = ve[0], i = ve[1], a = ve[2], u = ve[3], p = ve[4], A = ve[9] = ve[9] === r ? M ? 0 : e.length : Bt(ve[9] - J, 0), !A && i & (L | I) && (i &= ~(L | I)), !i || i == G) var we = Gg(e, i, a);
                    else i == L || i == I ? we = Wg(e, i, A) : (i == C || i == (G | C)) && !p.length ? we = Yg(e, i, a, u) : we = ia.apply(r, ve);
                    var qe = oe ? ch : jh;
                    return zh(qe(we, ve), e, i)
                }

                function Ah(e, i, a, u) {
                    return e === r || Br(e, vn[a]) && !nt.call(u, a) ? i : e
                }

                function Ph(e, i, a, u, p, _) {
                    return mt(e) && mt(i) && (_.set(i, e), Qs(e, i, r, Ph, _), _.delete(i)), e
                }

                function Xg(e) {
                    return Jn(e) ? r : e
                }

                function Nh(e, i, a, u, p, _) {
                    var D = a & N,
                        A = e.length,
                        M = i.length;
                    if (A != M && !(D && M > A)) return !1;
                    var J = _.get(e),
                        X = _.get(i);
                    if (J && X) return J == i && X == e;
                    var Q = -1,
                        oe = !0,
                        ve = a & H ? new Bi : r;
                    for (_.set(e, i), _.set(i, e); ++Q < A;) {
                        var we = e[Q],
                            qe = i[Q];
                        if (u) var Ee = D ? u(qe, we, Q, i, e, _) : u(we, qe, Q, e, i, _);
                        if (Ee !== r) {
                            if (Ee) continue;
                            oe = !1;
                            break
                        }
                        if (ve) {
                            if (!vo(i, function(Ge, Ze) {
                                    if (!$n(ve, Ze) && (we === Ge || p(we, Ge, a, u, _))) return ve.push(Ze)
                                })) {
                                oe = !1;
                                break
                            }
                        } else if (!(we === qe || p(we, qe, a, u, _))) {
                            oe = !1;
                            break
                        }
                    }
                    return _.delete(e), _.delete(i), oe
                }

                function Zg(e, i, a, u, p, _, D) {
                    switch (a) {
                        case Ae:
                            if (e.byteLength != i.byteLength || e.byteOffset != i.byteOffset) return !1;
                            e = e.buffer, i = i.buffer;
                        case De:
                            return !(e.byteLength != i.byteLength || !_(new qs(e), new qs(i)));
                        case j:
                        case R:
                        case He:
                            return Br(+e, +i);
                        case x:
                            return e.name == i.name && e.message == i.message;
                        case je:
                        case Re:
                            return e == i + "";
                        case Ie:
                            var A = Eo;
                        case Se:
                            var M = u & N;
                            if (A || (A = Us), e.size != i.size && !M) return !1;
                            var J = D.get(e);
                            if (J) return J == i;
                            u |= H, D.set(e, i);
                            var X = Nh(A(e), A(i), u, p, _, D);
                            return D.delete(e), X;
                        case Fe:
                            if (qn) return qn.call(e) == qn.call(i)
                    }
                    return !1
                }

                function Qg(e, i, a, u, p, _) {
                    var D = a & N,
                        A = Go(e),
                        M = A.length,
                        J = Go(i),
                        X = J.length;
                    if (M != X && !D) return !1;
                    for (var Q = M; Q--;) {
                        var oe = A[Q];
                        if (!(D ? oe in i : nt.call(i, oe))) return !1
                    }
                    var ve = _.get(e),
                        we = _.get(i);
                    if (ve && we) return ve == i && we == e;
                    var qe = !0;
                    _.set(e, i), _.set(i, e);
                    for (var Ee = D; ++Q < M;) {
                        oe = A[Q];
                        var Ge = e[oe],
                            Ze = i[oe];
                        if (u) var Ir = D ? u(Ze, Ge, oe, i, e, _) : u(Ge, Ze, oe, e, i, _);
                        if (!(Ir === r ? Ge === Ze || p(Ge, Ze, a, u, _) : Ir)) {
                            qe = !1;
                            break
                        }
                        Ee || (Ee = oe == "constructor")
                    }
                    if (qe && !Ee) {
                        var sr = e.constructor,
                            Sr = i.constructor;
                        sr != Sr && "constructor" in e && "constructor" in i && !(typeof sr == "function" && sr instanceof sr && typeof Sr == "function" && Sr instanceof Sr) && (qe = !1)
                    }
                    return _.delete(e), _.delete(i), qe
                }

                function hi(e) {
                    return tc(Lh(e, r, Vh), e + "")
                }

                function Go(e) {
                    return Xu(e, kt, Xo)
                }

                function Wo(e) {
                    return Xu(e, dr, Th)
                }
                var Yo = Gs ? function(e) {
                    return Gs.get(e)
                } : dc;

                function oa(e) {
                    for (var i = e.name + "", a = _n[i], u = nt.call(_n, i) ? a.length : 0; u--;) {
                        var p = a[u],
                            _ = p.func;
                        if (_ == null || _ == e) return p.name
                    }
                    return i
                }

                function En(e) {
                    var i = nt.call(y, "placeholder") ? y : e;
                    return i.placeholder
                }

                function me() {
                    var e = y.iteratee || fc;
                    return e = e === fc ? eh : e, arguments.length ? e(arguments[0], arguments[1]) : e
                }

                function ca(e, i) {
                    var a = e.__data__;
                    return o0(i) ? a[typeof i == "string" ? "string" : "hash"] : a.map
                }

                function Jo(e) {
                    for (var i = kt(e), a = i.length; a--;) {
                        var u = i[a],
                            p = e[u];
                        i[a] = [u, p, Uh(p)]
                    }
                    return i
                }

                function Vi(e, i) {
                    var a = hd(e, i);
                    return Qu(a) ? a : r
                }

                function e0(e) {
                    var i = nt.call(e, qi),
                        a = e[qi];
                    try {
                        e[qi] = r;
                        var u = !0
                    } catch {}
                    var p = js.call(e);
                    return u && (i ? e[qi] = a : delete e[qi]), p
                }
                var Xo = Io ? function(e) {
                        return e == null ? [] : (e = ut(e), mi(Io(e), function(i) {
                            return Mu.call(e, i)
                        }))
                    } : gc,
                    Th = Io ? function(e) {
                        for (var i = []; e;) bi(i, Xo(e)), e = Hs(e);
                        return i
                    } : gc,
                    Zt = ir;
                (So && Zt(new So(new ArrayBuffer(1))) != Ae || Mn && Zt(new Mn) != Ie || xo && Zt(xo.resolve()) != pt || yn && Zt(new yn) != Se || jn && Zt(new jn) != Oe) && (Zt = function(e) {
                    var i = ir(e),
                        a = i == Le ? e.constructor : r,
                        u = a ? Gi(a) : "";
                    if (u) switch (u) {
                        case $d:
                            return Ae;
                        case Ld:
                            return Ie;
                        case Md:
                            return pt;
                        case jd:
                            return Se;
                        case zd:
                            return Oe
                    }
                    return i
                });

                function t0(e, i, a) {
                    for (var u = -1, p = a.length; ++u < p;) {
                        var _ = a[u],
                            D = _.size;
                        switch (_.type) {
                            case "drop":
                                e += D;
                                break;
                            case "dropRight":
                                i -= D;
                                break;
                            case "take":
                                i = Xt(i, e + D);
                                break;
                            case "takeRight":
                                e = Bt(e, i - D);
                                break
                        }
                    }
                    return {
                        start: e,
                        end: i
                    }
                }

                function r0(e) {
                    var i = e.match(ht);
                    return i ? i[1].split(Lt) : []
                }

                function Rh(e, i, a) {
                    i = Si(i, e);
                    for (var u = -1, p = i.length, _ = !1; ++u < p;) {
                        var D = Xr(i[u]);
                        if (!(_ = e != null && a(e, D))) break;
                        e = e[D]
                    }
                    return _ || ++u != p ? _ : (p = e == null ? 0 : e.length, !!p && ga(p) && li(D, p) && (Te(e) || Wi(e)))
                }

                function i0(e) {
                    var i = e.length,
                        a = new e.constructor(i);
                    return i && typeof e[0] == "string" && nt.call(e, "index") && (a.index = e.index, a.input = e.input), a
                }

                function Fh(e) {
                    return typeof e.constructor == "function" && !Wn(e) ? mn(Hs(e)) : {}
                }

                function n0(e, i, a) {
                    var u = e.constructor;
                    switch (i) {
                        case De:
                            return Ko(e);
                        case j:
                        case R:
                            return new u(+e);
                        case Ae:
                            return qg(e, a);
                        case Be:
                        case Ce:
                        case Ve:
                        case We:
                        case et:
                        case tt:
                        case Je:
                        case er:
                        case hr:
                            return vh(e, a);
                        case Ie:
                            return new u;
                        case He:
                        case Re:
                            return new u(e);
                        case je:
                            return Hg(e);
                        case Se:
                            return new u;
                        case Fe:
                            return Bg(e)
                    }
                }

                function s0(e, i) {
                    var a = i.length;
                    if (!a) return e;
                    var u = a - 1;
                    return i[u] = (a > 1 ? "& " : "") + i[u], i = i.join(a > 2 ? ", " : " "), e.replace(St, `{
/* [wrapped with ` + i + `] */
`)
                }

                function a0(e) {
                    return Te(e) || Wi(e) || !!(ju && e && e[ju])
                }

                function li(e, i) {
                    var a = typeof e;
                    return i = i ? ? W, !!i && (a == "number" || a != "symbol" && Qa.test(e)) && e > -1 && e % 1 == 0 && e < i
                }

                function nr(e, i, a) {
                    if (!mt(a)) return !1;
                    var u = typeof i;
                    return (u == "number" ? pr(a) && li(i, a.length) : u == "string" && i in a) ? Br(a[i], e) : !1
                }

                function Zo(e, i) {
                    if (Te(e)) return !1;
                    var a = typeof e;
                    return a == "number" || a == "symbol" || a == "boolean" || e == null || Dr(e) ? !0 : Ft.test(e) || !vt.test(e) || i != null && e in ut(i)
                }

                function o0(e) {
                    var i = typeof e;
                    return i == "string" || i == "number" || i == "symbol" || i == "boolean" ? e !== "__proto__" : e === null
                }

                function Qo(e) {
                    var i = oa(e),
                        a = y[i];
                    if (typeof a != "function" || !(i in Ye.prototype)) return !1;
                    if (e === a) return !0;
                    var u = Yo(a);
                    return !!u && e === u[0]
                }

                function c0(e) {
                    return !!Uu && Uu in e
                }
                var u0 = Ls ? fi : vc;

                function Wn(e) {
                    var i = e && e.constructor,
                        a = typeof i == "function" && i.prototype || vn;
                    return e === a
                }

                function Uh(e) {
                    return e === e && !mt(e)
                }

                function $h(e, i) {
                    return function(a) {
                        return a == null ? !1 : a[e] === i && (i !== r || e in ut(a))
                    }
                }

                function h0(e) {
                    var i = pa(e, function(u) {
                            return a.size === g && a.clear(), u
                        }),
                        a = i.cache;
                    return i
                }

                function l0(e, i) {
                    var a = e[1],
                        u = i[1],
                        p = a | u,
                        _ = p < (G | ie | c),
                        D = u == c && a == L || u == c && a == m && e[7].length <= i[8] || u == (c | m) && i[7].length <= i[8] && a == L;
                    if (!(_ || D)) return e;
                    u & G && (e[2] = i[2], p |= a & G ? 0 : T);
                    var A = i[3];
                    if (A) {
                        var M = e[3];
                        e[3] = M ? _h(M, A, i[4]) : A, e[4] = M ? wi(e[3], b) : i[4]
                    }
                    return A = i[5], A && (M = e[5], e[5] = M ? mh(M, A, i[6]) : A, e[6] = M ? wi(e[5], b) : i[6]), A = i[7], A && (e[7] = A), u & c && (e[8] = e[8] == null ? i[8] : Xt(e[8], i[8])), e[9] == null && (e[9] = i[9]), e[0] = i[0], e[1] = p, e
                }

                function f0(e) {
                    var i = [];
                    if (e != null)
                        for (var a in ut(e)) i.push(a);
                    return i
                }

                function p0(e) {
                    return js.call(e)
                }

                function Lh(e, i, a) {
                    return i = Bt(i === r ? e.length - 1 : i, 0),
                        function() {
                            for (var u = arguments, p = -1, _ = Bt(u.length - i, 0), D = B(_); ++p < _;) D[p] = u[i + p];
                            p = -1;
                            for (var A = B(i + 1); ++p < i;) A[p] = u[p];
                            return A[i] = a(D), Kt(e, this, A)
                        }
                }

                function Mh(e, i) {
                    return i.length < 2 ? e : ki(e, Rr(i, 0, -1))
                }

                function d0(e, i) {
                    for (var a = e.length, u = Xt(i.length, a), p = fr(e); u--;) {
                        var _ = i[u];
                        e[u] = li(_, a) ? p[_] : r
                    }
                    return e
                }

                function ec(e, i) {
                    if (!(i === "constructor" && typeof e[i] == "function") && i != "__proto__") return e[i]
                }
                var jh = qh(ch),
                    Yn = Ad || function(e, i) {
                        return Xe.setTimeout(e, i)
                    },
                    tc = qh(Lg);

                function zh(e, i, a) {
                    var u = i + "";
                    return tc(e, s0(u, g0(r0(u), a)))
                }

                function qh(e) {
                    var i = 0,
                        a = 0;
                    return function() {
                        var u = Rd(),
                            p = ge - (u - a);
                        if (a = u, p > 0) {
                            if (++i >= ce) return arguments[0]
                        } else i = 0;
                        return e.apply(r, arguments)
                    }
                }

                function ua(e, i) {
                    var a = -1,
                        u = e.length,
                        p = u - 1;
                    for (i = i === r ? u : i; ++a < i;) {
                        var _ = Lo(a, p),
                            D = e[_];
                        e[_] = e[a], e[a] = D
                    }
                    return e.length = i, e
                }
                var Hh = h0(function(e) {
                    var i = [];
                    return e.charCodeAt(0) === 46 && i.push(""), e.replace(Ut, function(a, u, p, _) {
                        i.push(p ? _.replace(Ga, "$1") : u || a)
                    }), i
                });

                function Xr(e) {
                    if (typeof e == "string" || Dr(e)) return e;
                    var i = e + "";
                    return i == "0" && 1 / e == -te ? "-0" : i
                }

                function Gi(e) {
                    if (e != null) {
                        try {
                            return Ms.call(e)
                        } catch {}
                        try {
                            return e + ""
                        } catch {}
                    }
                    return ""
                }

                function g0(e, i) {
                    return Ar(be, function(a) {
                        var u = "_." + a[0];
                        i & a[1] && !Rs(e, u) && e.push(u)
                    }), e.sort()
                }

                function Bh(e) {
                    if (e instanceof Ye) return e.clone();
                    var i = new Nr(e.__wrapped__, e.__chain__);
                    return i.__actions__ = fr(e.__actions__), i.__index__ = e.__index__, i.__values__ = e.__values__, i
                }

                function v0(e, i, a) {
                    (a ? nr(e, i, a) : i === r) ? i = 1: i = Bt(Me(i), 0);
                    var u = e == null ? 0 : e.length;
                    if (!u || i < 1) return [];
                    for (var p = 0, _ = 0, D = B(ks(u / i)); p < u;) D[_++] = Rr(e, p, p += i);
                    return D
                }

                function y0(e) {
                    for (var i = -1, a = e == null ? 0 : e.length, u = 0, p = []; ++i < a;) {
                        var _ = e[i];
                        _ && (p[u++] = _)
                    }
                    return p
                }

                function _0() {
                    var e = arguments.length;
                    if (!e) return [];
                    for (var i = B(e - 1), a = arguments[0], u = e; u--;) i[u - 1] = arguments[u];
                    return bi(Te(a) ? fr(a) : [a], Wt(i, 1))
                }
                var m0 = Ke(function(e, i) {
                        return Pt(e) ? Bn(e, Wt(i, 1, Pt, !0)) : []
                    }),
                    b0 = Ke(function(e, i) {
                        var a = Fr(i);
                        return Pt(a) && (a = r), Pt(e) ? Bn(e, Wt(i, 1, Pt, !0), me(a, 2)) : []
                    }),
                    w0 = Ke(function(e, i) {
                        var a = Fr(i);
                        return Pt(a) && (a = r), Pt(e) ? Bn(e, Wt(i, 1, Pt, !0), r, a) : []
                    });

                function E0(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    return u ? (i = a || i === r ? 1 : Me(i), Rr(e, i < 0 ? 0 : i, u)) : []
                }

                function D0(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    return u ? (i = a || i === r ? 1 : Me(i), i = u - i, Rr(e, 0, i < 0 ? 0 : i)) : []
                }

                function I0(e, i) {
                    return e && e.length ? ta(e, me(i, 3), !0, !0) : []
                }

                function S0(e, i) {
                    return e && e.length ? ta(e, me(i, 3), !0) : []
                }

                function x0(e, i, a, u) {
                    var p = e == null ? 0 : e.length;
                    return p ? (a && typeof a != "number" && nr(e, i, a) && (a = 0, u = p), _g(e, i, a, u)) : []
                }

                function Kh(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    if (!u) return -1;
                    var p = a == null ? 0 : Me(a);
                    return p < 0 && (p = Bt(u + p, 0)), Fs(e, me(i, 3), p)
                }

                function kh(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    if (!u) return -1;
                    var p = u - 1;
                    return a !== r && (p = Me(a), p = a < 0 ? Bt(u + p, 0) : Xt(p, u - 1)), Fs(e, me(i, 3), p, !0)
                }

                function Vh(e) {
                    var i = e == null ? 0 : e.length;
                    return i ? Wt(e, 1) : []
                }

                function C0(e) {
                    var i = e == null ? 0 : e.length;
                    return i ? Wt(e, te) : []
                }

                function O0(e, i) {
                    var a = e == null ? 0 : e.length;
                    return a ? (i = i === r ? 1 : Me(i), Wt(e, i)) : []
                }

                function A0(e) {
                    for (var i = -1, a = e == null ? 0 : e.length, u = {}; ++i < a;) {
                        var p = e[i];
                        u[p[0]] = p[1]
                    }
                    return u
                }

                function Gh(e) {
                    return e && e.length ? e[0] : r
                }

                function P0(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    if (!u) return -1;
                    var p = a == null ? 0 : Me(a);
                    return p < 0 && (p = Bt(u + p, 0)), fn(e, i, p)
                }

                function N0(e) {
                    var i = e == null ? 0 : e.length;
                    return i ? Rr(e, 0, -1) : []
                }
                var T0 = Ke(function(e) {
                        var i = yt(e, Ho);
                        return i.length && i[0] === e[0] ? To(i) : []
                    }),
                    R0 = Ke(function(e) {
                        var i = Fr(e),
                            a = yt(e, Ho);
                        return i === Fr(a) ? i = r : a.pop(), a.length && a[0] === e[0] ? To(a, me(i, 2)) : []
                    }),
                    F0 = Ke(function(e) {
                        var i = Fr(e),
                            a = yt(e, Ho);
                        return i = typeof i == "function" ? i : r, i && a.pop(), a.length && a[0] === e[0] ? To(a, r, i) : []
                    });

                function U0(e, i) {
                    return e == null ? "" : Nd.call(e, i)
                }

                function Fr(e) {
                    var i = e == null ? 0 : e.length;
                    return i ? e[i - 1] : r
                }

                function $0(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    if (!u) return -1;
                    var p = u;
                    return a !== r && (p = Me(a), p = p < 0 ? Bt(u + p, 0) : Xt(p, u - 1)), i === i ? gd(e, i, p) : Fs(e, Cu, p, !0)
                }

                function L0(e, i) {
                    return e && e.length ? nh(e, Me(i)) : r
                }
                var M0 = Ke(Wh);

                function Wh(e, i) {
                    return e && e.length && i && i.length ? $o(e, i) : e
                }

                function j0(e, i, a) {
                    return e && e.length && i && i.length ? $o(e, i, me(a, 2)) : e
                }

                function z0(e, i, a) {
                    return e && e.length && i && i.length ? $o(e, i, r, a) : e
                }
                var q0 = hi(function(e, i) {
                    var a = e == null ? 0 : e.length,
                        u = Oo(e, i);
                    return oh(e, yt(i, function(p) {
                        return li(p, a) ? +p : p
                    }).sort(yh)), u
                });

                function H0(e, i) {
                    var a = [];
                    if (!(e && e.length)) return a;
                    var u = -1,
                        p = [],
                        _ = e.length;
                    for (i = me(i, 3); ++u < _;) {
                        var D = e[u];
                        i(D, u, e) && (a.push(D), p.push(u))
                    }
                    return oh(e, p), a
                }

                function rc(e) {
                    return e == null ? e : Ud.call(e)
                }

                function B0(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    return u ? (a && typeof a != "number" && nr(e, i, a) ? (i = 0, a = u) : (i = i == null ? 0 : Me(i), a = a === r ? u : Me(a)), Rr(e, i, a)) : []
                }

                function K0(e, i) {
                    return ea(e, i)
                }

                function k0(e, i, a) {
                    return jo(e, i, me(a, 2))
                }

                function V0(e, i) {
                    var a = e == null ? 0 : e.length;
                    if (a) {
                        var u = ea(e, i);
                        if (u < a && Br(e[u], i)) return u
                    }
                    return -1
                }

                function G0(e, i) {
                    return ea(e, i, !0)
                }

                function W0(e, i, a) {
                    return jo(e, i, me(a, 2), !0)
                }

                function Y0(e, i) {
                    var a = e == null ? 0 : e.length;
                    if (a) {
                        var u = ea(e, i, !0) - 1;
                        if (Br(e[u], i)) return u
                    }
                    return -1
                }

                function J0(e) {
                    return e && e.length ? uh(e) : []
                }

                function X0(e, i) {
                    return e && e.length ? uh(e, me(i, 2)) : []
                }

                function Z0(e) {
                    var i = e == null ? 0 : e.length;
                    return i ? Rr(e, 1, i) : []
                }

                function Q0(e, i, a) {
                    return e && e.length ? (i = a || i === r ? 1 : Me(i), Rr(e, 0, i < 0 ? 0 : i)) : []
                }

                function e1(e, i, a) {
                    var u = e == null ? 0 : e.length;
                    return u ? (i = a || i === r ? 1 : Me(i), i = u - i, Rr(e, i < 0 ? 0 : i, u)) : []
                }

                function t1(e, i) {
                    return e && e.length ? ta(e, me(i, 3), !1, !0) : []
                }

                function r1(e, i) {
                    return e && e.length ? ta(e, me(i, 3)) : []
                }
                var i1 = Ke(function(e) {
                        return Ii(Wt(e, 1, Pt, !0))
                    }),
                    n1 = Ke(function(e) {
                        var i = Fr(e);
                        return Pt(i) && (i = r), Ii(Wt(e, 1, Pt, !0), me(i, 2))
                    }),
                    s1 = Ke(function(e) {
                        var i = Fr(e);
                        return i = typeof i == "function" ? i : r, Ii(Wt(e, 1, Pt, !0), r, i)
                    });

                function a1(e) {
                    return e && e.length ? Ii(e) : []
                }

                function o1(e, i) {
                    return e && e.length ? Ii(e, me(i, 2)) : []
                }

                function c1(e, i) {
                    return i = typeof i == "function" ? i : r, e && e.length ? Ii(e, r, i) : []
                }

                function ic(e) {
                    if (!(e && e.length)) return [];
                    var i = 0;
                    return e = mi(e, function(a) {
                        if (Pt(a)) return i = Bt(a.length, i), !0
                    }), bo(i, function(a) {
                        return yt(e, yo(a))
                    })
                }

                function Yh(e, i) {
                    if (!(e && e.length)) return [];
                    var a = ic(e);
                    return i == null ? a : yt(a, function(u) {
                        return Kt(i, r, u)
                    })
                }
                var u1 = Ke(function(e, i) {
                        return Pt(e) ? Bn(e, i) : []
                    }),
                    h1 = Ke(function(e) {
                        return qo(mi(e, Pt))
                    }),
                    l1 = Ke(function(e) {
                        var i = Fr(e);
                        return Pt(i) && (i = r), qo(mi(e, Pt), me(i, 2))
                    }),
                    f1 = Ke(function(e) {
                        var i = Fr(e);
                        return i = typeof i == "function" ? i : r, qo(mi(e, Pt), r, i)
                    }),
                    p1 = Ke(ic);

                function d1(e, i) {
                    return ph(e || [], i || [], Hn)
                }

                function g1(e, i) {
                    return ph(e || [], i || [], Vn)
                }
                var v1 = Ke(function(e) {
                    var i = e.length,
                        a = i > 1 ? e[i - 1] : r;
                    return a = typeof a == "function" ? (e.pop(), a) : r, Yh(e, a)
                });

                function Jh(e) {
                    var i = y(e);
                    return i.__chain__ = !0, i
                }

                function y1(e, i) {
                    return i(e), e
                }

                function ha(e, i) {
                    return i(e)
                }
                var _1 = hi(function(e) {
                    var i = e.length,
                        a = i ? e[0] : 0,
                        u = this.__wrapped__,
                        p = function(_) {
                            return Oo(_, e)
                        };
                    return i > 1 || this.__actions__.length || !(u instanceof Ye) || !li(a) ? this.thru(p) : (u = u.slice(a, +a + (i ? 1 : 0)), u.__actions__.push({
                        func: ha,
                        args: [p],
                        thisArg: r
                    }), new Nr(u, this.__chain__).thru(function(_) {
                        return i && !_.length && _.push(r), _
                    }))
                });

                function m1() {
                    return Jh(this)
                }

                function b1() {
                    return new Nr(this.value(), this.__chain__)
                }

                function w1() {
                    this.__values__ === r && (this.__values__ = hl(this.value()));
                    var e = this.__index__ >= this.__values__.length,
                        i = e ? r : this.__values__[this.__index__++];
                    return {
                        done: e,
                        value: i
                    }
                }

                function E1() {
                    return this
                }

                function D1(e) {
                    for (var i, a = this; a instanceof Ys;) {
                        var u = Bh(a);
                        u.__index__ = 0, u.__values__ = r, i ? p.__wrapped__ = u : i = u;
                        var p = u;
                        a = a.__wrapped__
                    }
                    return p.__wrapped__ = e, i
                }

                function I1() {
                    var e = this.__wrapped__;
                    if (e instanceof Ye) {
                        var i = e;
                        return this.__actions__.length && (i = new Ye(this)), i = i.reverse(), i.__actions__.push({
                            func: ha,
                            args: [rc],
                            thisArg: r
                        }), new Nr(i, this.__chain__)
                    }
                    return this.thru(rc)
                }

                function S1() {
                    return fh(this.__wrapped__, this.__actions__)
                }
                var x1 = ra(function(e, i, a) {
                    nt.call(e, a) ? ++e[a] : ci(e, a, 1)
                });

                function C1(e, i, a) {
                    var u = Te(e) ? Su : yg;
                    return a && nr(e, i, a) && (i = r), u(e, me(i, 3))
                }

                function O1(e, i) {
                    var a = Te(e) ? mi : Yu;
                    return a(e, me(i, 3))
                }
                var A1 = Dh(Kh),
                    P1 = Dh(kh);

                function N1(e, i) {
                    return Wt(la(e, i), 1)
                }

                function T1(e, i) {
                    return Wt(la(e, i), te)
                }

                function R1(e, i, a) {
                    return a = a === r ? 1 : Me(a), Wt(la(e, i), a)
                }

                function Xh(e, i) {
                    var a = Te(e) ? Ar : Di;
                    return a(e, me(i, 3))
                }

                function Zh(e, i) {
                    var a = Te(e) ? Zp : Wu;
                    return a(e, me(i, 3))
                }
                var F1 = ra(function(e, i, a) {
                    nt.call(e, a) ? e[a].push(i) : ci(e, a, [i])
                });

                function U1(e, i, a, u) {
                    e = pr(e) ? e : In(e), a = a && !u ? Me(a) : 0;
                    var p = e.length;
                    return a < 0 && (a = Bt(p + a, 0)), va(e) ? a <= p && e.indexOf(i, a) > -1 : !!p && fn(e, i, a) > -1
                }
                var $1 = Ke(function(e, i, a) {
                        var u = -1,
                            p = typeof i == "function",
                            _ = pr(e) ? B(e.length) : [];
                        return Di(e, function(D) {
                            _[++u] = p ? Kt(i, D, a) : Kn(D, i, a)
                        }), _
                    }),
                    L1 = ra(function(e, i, a) {
                        ci(e, a, i)
                    });

                function la(e, i) {
                    var a = Te(e) ? yt : th;
                    return a(e, me(i, 3))
                }

                function M1(e, i, a, u) {
                    return e == null ? [] : (Te(i) || (i = i == null ? [] : [i]), a = u ? r : a, Te(a) || (a = a == null ? [] : [a]), sh(e, i, a))
                }
                var j1 = ra(function(e, i, a) {
                    e[a ? 0 : 1].push(i)
                }, function() {
                    return [
                        [],
                        []
                    ]
                });

                function z1(e, i, a) {
                    var u = Te(e) ? go : Au,
                        p = arguments.length < 3;
                    return u(e, me(i, 4), a, p, Di)
                }

                function q1(e, i, a) {
                    var u = Te(e) ? Qp : Au,
                        p = arguments.length < 3;
                    return u(e, me(i, 4), a, p, Wu)
                }

                function H1(e, i) {
                    var a = Te(e) ? mi : Yu;
                    return a(e, da(me(i, 3)))
                }

                function B1(e) {
                    var i = Te(e) ? Ku : Ug;
                    return i(e)
                }

                function K1(e, i, a) {
                    (a ? nr(e, i, a) : i === r) ? i = 1: i = Me(i);
                    var u = Te(e) ? fg : $g;
                    return u(e, i)
                }

                function k1(e) {
                    var i = Te(e) ? pg : Mg;
                    return i(e)
                }

                function V1(e) {
                    if (e == null) return 0;
                    if (pr(e)) return va(e) ? dn(e) : e.length;
                    var i = Zt(e);
                    return i == Ie || i == Se ? e.size : Fo(e).length
                }

                function G1(e, i, a) {
                    var u = Te(e) ? vo : jg;
                    return a && nr(e, i, a) && (i = r), u(e, me(i, 3))
                }
                var W1 = Ke(function(e, i) {
                        if (e == null) return [];
                        var a = i.length;
                        return a > 1 && nr(e, i[0], i[1]) ? i = [] : a > 2 && nr(i[0], i[1], i[2]) && (i = [i[0]]), sh(e, Wt(i, 1), [])
                    }),
                    fa = Od || function() {
                        return Xe.Date.now()
                    };

                function Y1(e, i) {
                    if (typeof i != "function") throw new Pr(d);
                    return e = Me(e),
                        function() {
                            if (--e < 1) return i.apply(this, arguments)
                        }
                }

                function Qh(e, i, a) {
                    return i = a ? r : i, i = e && i == null ? e.length : i, ui(e, c, r, r, r, r, i)
                }

                function el(e, i) {
                    var a;
                    if (typeof i != "function") throw new Pr(d);
                    return e = Me(e),
                        function() {
                            return --e > 0 && (a = i.apply(this, arguments)), e <= 1 && (i = r), a
                        }
                }
                var nc = Ke(function(e, i, a) {
                        var u = G;
                        if (a.length) {
                            var p = wi(a, En(nc));
                            u |= C
                        }
                        return ui(e, u, i, a, p)
                    }),
                    tl = Ke(function(e, i, a) {
                        var u = G | ie;
                        if (a.length) {
                            var p = wi(a, En(tl));
                            u |= C
                        }
                        return ui(i, u, e, a, p)
                    });

                function rl(e, i, a) {
                    i = a ? r : i;
                    var u = ui(e, L, r, r, r, r, r, i);
                    return u.placeholder = rl.placeholder, u
                }

                function il(e, i, a) {
                    i = a ? r : i;
                    var u = ui(e, I, r, r, r, r, r, i);
                    return u.placeholder = il.placeholder, u
                }

                function nl(e, i, a) {
                    var u, p, _, D, A, M, J = 0,
                        X = !1,
                        Q = !1,
                        oe = !0;
                    if (typeof e != "function") throw new Pr(d);
                    i = Ur(i) || 0, mt(a) && (X = !!a.leading, Q = "maxWait" in a, _ = Q ? Bt(Ur(a.maxWait) || 0, i) : _, oe = "trailing" in a ? !!a.trailing : oe);

                    function ve(Nt) {
                        var Kr = u,
                            di = p;
                        return u = p = r, J = Nt, D = e.apply(di, Kr), D
                    }

                    function we(Nt) {
                        return J = Nt, A = Yn(Ge, i), X ? ve(Nt) : D
                    }

                    function qe(Nt) {
                        var Kr = Nt - M,
                            di = Nt - J,
                            Dl = i - Kr;
                        return Q ? Xt(Dl, _ - di) : Dl
                    }

                    function Ee(Nt) {
                        var Kr = Nt - M,
                            di = Nt - J;
                        return M === r || Kr >= i || Kr < 0 || Q && di >= _
                    }

                    function Ge() {
                        var Nt = fa();
                        if (Ee(Nt)) return Ze(Nt);
                        A = Yn(Ge, qe(Nt))
                    }

                    function Ze(Nt) {
                        return A = r, oe && u ? ve(Nt) : (u = p = r, D)
                    }

                    function Ir() {
                        A !== r && dh(A), J = 0, u = M = p = A = r
                    }

                    function sr() {
                        return A === r ? D : Ze(fa())
                    }

                    function Sr() {
                        var Nt = fa(),
                            Kr = Ee(Nt);
                        if (u = arguments, p = this, M = Nt, Kr) {
                            if (A === r) return we(M);
                            if (Q) return dh(A), A = Yn(Ge, i), ve(M)
                        }
                        return A === r && (A = Yn(Ge, i)), D
                    }
                    return Sr.cancel = Ir, Sr.flush = sr, Sr
                }
                var J1 = Ke(function(e, i) {
                        return Gu(e, 1, i)
                    }),
                    X1 = Ke(function(e, i, a) {
                        return Gu(e, Ur(i) || 0, a)
                    });

                function Z1(e) {
                    return ui(e, K)
                }

                function pa(e, i) {
                    if (typeof e != "function" || i != null && typeof i != "function") throw new Pr(d);
                    var a = function() {
                        var u = arguments,
                            p = i ? i.apply(this, u) : u[0],
                            _ = a.cache;
                        if (_.has(p)) return _.get(p);
                        var D = e.apply(this, u);
                        return a.cache = _.set(p, D) || _, D
                    };
                    return a.cache = new(pa.Cache || oi), a
                }
                pa.Cache = oi;

                function da(e) {
                    if (typeof e != "function") throw new Pr(d);
                    return function() {
                        var i = arguments;
                        switch (i.length) {
                            case 0:
                                return !e.call(this);
                            case 1:
                                return !e.call(this, i[0]);
                            case 2:
                                return !e.call(this, i[0], i[1]);
                            case 3:
                                return !e.call(this, i[0], i[1], i[2])
                        }
                        return !e.apply(this, i)
                    }
                }

                function Q1(e) {
                    return el(2, e)
                }
                var ev = zg(function(e, i) {
                        i = i.length == 1 && Te(i[0]) ? yt(i[0], wr(me())) : yt(Wt(i, 1), wr(me()));
                        var a = i.length;
                        return Ke(function(u) {
                            for (var p = -1, _ = Xt(u.length, a); ++p < _;) u[p] = i[p].call(this, u[p]);
                            return Kt(e, this, u)
                        })
                    }),
                    sc = Ke(function(e, i) {
                        var a = wi(i, En(sc));
                        return ui(e, C, r, i, a)
                    }),
                    sl = Ke(function(e, i) {
                        var a = wi(i, En(sl));
                        return ui(e, w, r, i, a)
                    }),
                    tv = hi(function(e, i) {
                        return ui(e, m, r, r, r, i)
                    });

                function rv(e, i) {
                    if (typeof e != "function") throw new Pr(d);
                    return i = i === r ? i : Me(i), Ke(e, i)
                }

                function iv(e, i) {
                    if (typeof e != "function") throw new Pr(d);
                    return i = i == null ? 0 : Bt(Me(i), 0), Ke(function(a) {
                        var u = a[i],
                            p = xi(a, 0, i);
                        return u && bi(p, u), Kt(e, this, p)
                    })
                }

                function nv(e, i, a) {
                    var u = !0,
                        p = !0;
                    if (typeof e != "function") throw new Pr(d);
                    return mt(a) && (u = "leading" in a ? !!a.leading : u, p = "trailing" in a ? !!a.trailing : p), nl(e, i, {
                        leading: u,
                        maxWait: i,
                        trailing: p
                    })
                }

                function sv(e) {
                    return Qh(e, 1)
                }

                function av(e, i) {
                    return sc(Bo(i), e)
                }

                function ov() {
                    if (!arguments.length) return [];
                    var e = arguments[0];
                    return Te(e) ? e : [e]
                }

                function cv(e) {
                    return Tr(e, P)
                }

                function uv(e, i) {
                    return i = typeof i == "function" ? i : r, Tr(e, P, i)
                }

                function hv(e) {
                    return Tr(e, S | P)
                }

                function lv(e, i) {
                    return i = typeof i == "function" ? i : r, Tr(e, S | P, i)
                }

                function fv(e, i) {
                    return i == null || Vu(e, i, kt(i))
                }

                function Br(e, i) {
                    return e === i || e !== e && i !== i
                }
                var pv = aa(No),
                    dv = aa(function(e, i) {
                        return e >= i
                    }),
                    Wi = Zu(function() {
                        return arguments
                    }()) ? Zu : function(e) {
                        return xt(e) && nt.call(e, "callee") && !Mu.call(e, "callee")
                    },
                    Te = B.isArray,
                    gv = rr ? wr(rr) : Dg;

                function pr(e) {
                    return e != null && ga(e.length) && !fi(e)
                }

                function Pt(e) {
                    return xt(e) && pr(e)
                }

                function vv(e) {
                    return e === !0 || e === !1 || xt(e) && ir(e) == j
                }
                var Ci = Pd || vc,
                    yv = zr ? wr(zr) : Ig;

                function _v(e) {
                    return xt(e) && e.nodeType === 1 && !Jn(e)
                }

                function mv(e) {
                    if (e == null) return !0;
                    if (pr(e) && (Te(e) || typeof e == "string" || typeof e.splice == "function" || Ci(e) || Dn(e) || Wi(e))) return !e.length;
                    var i = Zt(e);
                    if (i == Ie || i == Se) return !e.size;
                    if (Wn(e)) return !Fo(e).length;
                    for (var a in e)
                        if (nt.call(e, a)) return !1;
                    return !0
                }

                function bv(e, i) {
                    return kn(e, i)
                }

                function wv(e, i, a) {
                    a = typeof a == "function" ? a : r;
                    var u = a ? a(e, i) : r;
                    return u === r ? kn(e, i, r, a) : !!u
                }

                function ac(e) {
                    if (!xt(e)) return !1;
                    var i = ir(e);
                    return i == x || i == h || typeof e.message == "string" && typeof e.name == "string" && !Jn(e)
                }

                function Ev(e) {
                    return typeof e == "number" && zu(e)
                }

                function fi(e) {
                    if (!mt(e)) return !1;
                    var i = ir(e);
                    return i == se || i == fe || i == z || i == dt
                }

                function al(e) {
                    return typeof e == "number" && e == Me(e)
                }

                function ga(e) {
                    return typeof e == "number" && e > -1 && e % 1 == 0 && e <= W
                }

                function mt(e) {
                    var i = typeof e;
                    return e != null && (i == "object" || i == "function")
                }

                function xt(e) {
                    return e != null && typeof e == "object"
                }
                var ol = Or ? wr(Or) : xg;

                function Dv(e, i) {
                    return e === i || Ro(e, i, Jo(i))
                }

                function Iv(e, i, a) {
                    return a = typeof a == "function" ? a : r, Ro(e, i, Jo(i), a)
                }

                function Sv(e) {
                    return cl(e) && e != +e
                }

                function xv(e) {
                    if (u0(e)) throw new Pe(l);
                    return Qu(e)
                }

                function Cv(e) {
                    return e === null
                }

                function Ov(e) {
                    return e == null
                }

                function cl(e) {
                    return typeof e == "number" || xt(e) && ir(e) == He
                }

                function Jn(e) {
                    if (!xt(e) || ir(e) != Le) return !1;
                    var i = Hs(e);
                    if (i === null) return !0;
                    var a = nt.call(i, "constructor") && i.constructor;
                    return typeof a == "function" && a instanceof a && Ms.call(a) == Id
                }
                var oc = Wr ? wr(Wr) : Cg;

                function Av(e) {
                    return al(e) && e >= -W && e <= W
                }
                var ul = Un ? wr(Un) : Og;

                function va(e) {
                    return typeof e == "string" || !Te(e) && xt(e) && ir(e) == Re
                }

                function Dr(e) {
                    return typeof e == "symbol" || xt(e) && ir(e) == Fe
                }
                var Dn = zi ? wr(zi) : Ag;

                function Pv(e) {
                    return e === r
                }

                function Nv(e) {
                    return xt(e) && Zt(e) == Oe
                }

                function Tv(e) {
                    return xt(e) && ir(e) == Ue
                }
                var Rv = aa(Uo),
                    Fv = aa(function(e, i) {
                        return e <= i
                    });

                function hl(e) {
                    if (!e) return [];
                    if (pr(e)) return va(e) ? qr(e) : fr(e);
                    if (Ln && e[Ln]) return fd(e[Ln]());
                    var i = Zt(e),
                        a = i == Ie ? Eo : i == Se ? Us : In;
                    return a(e)
                }

                function pi(e) {
                    if (!e) return e === 0 ? e : 0;
                    if (e = Ur(e), e === te || e === -te) {
                        var i = e < 0 ? -1 : 1;
                        return i * ee
                    }
                    return e === e ? e : 0
                }

                function Me(e) {
                    var i = pi(e),
                        a = i % 1;
                    return i === i ? a ? i - a : i : 0
                }

                function ll(e) {
                    return e ? Ki(Me(e), 0, re) : 0
                }

                function Ur(e) {
                    if (typeof e == "number") return e;
                    if (Dr(e)) return Y;
                    if (mt(e)) {
                        var i = typeof e.valueOf == "function" ? e.valueOf() : e;
                        e = mt(i) ? i + "" : i
                    }
                    if (typeof e != "string") return e === 0 ? e : +e;
                    e = Pu(e);
                    var a = Ja.test(e);
                    return a || Za.test(e) ? Ne(e.slice(2), a ? 2 : 8) : Ya.test(e) ? Y : +e
                }

                function fl(e) {
                    return Jr(e, dr(e))
                }

                function Uv(e) {
                    return e ? Ki(Me(e), -W, W) : e === 0 ? e : 0
                }

                function it(e) {
                    return e == null ? "" : Er(e)
                }
                var $v = bn(function(e, i) {
                        if (Wn(i) || pr(i)) {
                            Jr(i, kt(i), e);
                            return
                        }
                        for (var a in i) nt.call(i, a) && Hn(e, a, i[a])
                    }),
                    pl = bn(function(e, i) {
                        Jr(i, dr(i), e)
                    }),
                    ya = bn(function(e, i, a, u) {
                        Jr(i, dr(i), e, u)
                    }),
                    Lv = bn(function(e, i, a, u) {
                        Jr(i, kt(i), e, u)
                    }),
                    Mv = hi(Oo);

                function jv(e, i) {
                    var a = mn(e);
                    return i == null ? a : ku(a, i)
                }
                var zv = Ke(function(e, i) {
                        e = ut(e);
                        var a = -1,
                            u = i.length,
                            p = u > 2 ? i[2] : r;
                        for (p && nr(i[0], i[1], p) && (u = 1); ++a < u;)
                            for (var _ = i[a], D = dr(_), A = -1, M = D.length; ++A < M;) {
                                var J = D[A],
                                    X = e[J];
                                (X === r || Br(X, vn[J]) && !nt.call(e, J)) && (e[J] = _[J])
                            }
                        return e
                    }),
                    qv = Ke(function(e) {
                        return e.push(r, Ph), Kt(dl, r, e)
                    });

                function Hv(e, i) {
                    return xu(e, me(i, 3), Yr)
                }

                function Bv(e, i) {
                    return xu(e, me(i, 3), Po)
                }

                function Kv(e, i) {
                    return e == null ? e : Ao(e, me(i, 3), dr)
                }

                function kv(e, i) {
                    return e == null ? e : Ju(e, me(i, 3), dr)
                }

                function Vv(e, i) {
                    return e && Yr(e, me(i, 3))
                }

                function Gv(e, i) {
                    return e && Po(e, me(i, 3))
                }

                function Wv(e) {
                    return e == null ? [] : Zs(e, kt(e))
                }

                function Yv(e) {
                    return e == null ? [] : Zs(e, dr(e))
                }

                function cc(e, i, a) {
                    var u = e == null ? r : ki(e, i);
                    return u === r ? a : u
                }

                function Jv(e, i) {
                    return e != null && Rh(e, i, mg)
                }

                function uc(e, i) {
                    return e != null && Rh(e, i, bg)
                }
                var Xv = Sh(function(e, i, a) {
                        i != null && typeof i.toString != "function" && (i = js.call(i)), e[i] = a
                    }, lc(gr)),
                    Zv = Sh(function(e, i, a) {
                        i != null && typeof i.toString != "function" && (i = js.call(i)), nt.call(e, i) ? e[i].push(a) : e[i] = [a]
                    }, me),
                    Qv = Ke(Kn);

                function kt(e) {
                    return pr(e) ? Bu(e) : Fo(e)
                }

                function dr(e) {
                    return pr(e) ? Bu(e, !0) : Pg(e)
                }

                function ey(e, i) {
                    var a = {};
                    return i = me(i, 3), Yr(e, function(u, p, _) {
                        ci(a, i(u, p, _), u)
                    }), a
                }

                function ty(e, i) {
                    var a = {};
                    return i = me(i, 3), Yr(e, function(u, p, _) {
                        ci(a, p, i(u, p, _))
                    }), a
                }
                var ry = bn(function(e, i, a) {
                        Qs(e, i, a)
                    }),
                    dl = bn(function(e, i, a, u) {
                        Qs(e, i, a, u)
                    }),
                    iy = hi(function(e, i) {
                        var a = {};
                        if (e == null) return a;
                        var u = !1;
                        i = yt(i, function(_) {
                            return _ = Si(_, e), u || (u = _.length > 1), _
                        }), Jr(e, Wo(e), a), u && (a = Tr(a, S | O | P, Xg));
                        for (var p = i.length; p--;) zo(a, i[p]);
                        return a
                    });

                function ny(e, i) {
                    return gl(e, da(me(i)))
                }
                var sy = hi(function(e, i) {
                    return e == null ? {} : Tg(e, i)
                });

                function gl(e, i) {
                    if (e == null) return {};
                    var a = yt(Wo(e), function(u) {
                        return [u]
                    });
                    return i = me(i), ah(e, a, function(u, p) {
                        return i(u, p[0])
                    })
                }

                function ay(e, i, a) {
                    i = Si(i, e);
                    var u = -1,
                        p = i.length;
                    for (p || (p = 1, e = r); ++u < p;) {
                        var _ = e == null ? r : e[Xr(i[u])];
                        _ === r && (u = p, _ = a), e = fi(_) ? _.call(e) : _
                    }
                    return e
                }

                function oy(e, i, a) {
                    return e == null ? e : Vn(e, i, a)
                }

                function cy(e, i, a, u) {
                    return u = typeof u == "function" ? u : r, e == null ? e : Vn(e, i, a, u)
                }
                var vl = Oh(kt),
                    yl = Oh(dr);

                function uy(e, i, a) {
                    var u = Te(e),
                        p = u || Ci(e) || Dn(e);
                    if (i = me(i, 4), a == null) {
                        var _ = e && e.constructor;
                        p ? a = u ? new _ : [] : mt(e) ? a = fi(_) ? mn(Hs(e)) : {} : a = {}
                    }
                    return (p ? Ar : Yr)(e, function(D, A, M) {
                        return i(a, D, A, M)
                    }), a
                }

                function hy(e, i) {
                    return e == null ? !0 : zo(e, i)
                }

                function ly(e, i, a) {
                    return e == null ? e : lh(e, i, Bo(a))
                }

                function fy(e, i, a, u) {
                    return u = typeof u == "function" ? u : r, e == null ? e : lh(e, i, Bo(a), u)
                }

                function In(e) {
                    return e == null ? [] : wo(e, kt(e))
                }

                function py(e) {
                    return e == null ? [] : wo(e, dr(e))
                }

                function dy(e, i, a) {
                    return a === r && (a = i, i = r), a !== r && (a = Ur(a), a = a === a ? a : 0), i !== r && (i = Ur(i), i = i === i ? i : 0), Ki(Ur(e), i, a)
                }

                function gy(e, i, a) {
                    return i = pi(i), a === r ? (a = i, i = 0) : a = pi(a), e = Ur(e), wg(e, i, a)
                }

                function vy(e, i, a) {
                    if (a && typeof a != "boolean" && nr(e, i, a) && (i = a = r), a === r && (typeof i == "boolean" ? (a = i, i = r) : typeof e == "boolean" && (a = e, e = r)), e === r && i === r ? (e = 0, i = 1) : (e = pi(e), i === r ? (i = e, e = 0) : i = pi(i)), e > i) {
                        var u = e;
                        e = i, i = u
                    }
                    if (a || e % 1 || i % 1) {
                        var p = qu();
                        return Xt(e + p * (i - e + ot("1e-" + ((p + "").length - 1))), i)
                    }
                    return Lo(e, i)
                }
                var yy = wn(function(e, i, a) {
                    return i = i.toLowerCase(), e + (a ? _l(i) : i)
                });

                function _l(e) {
                    return hc(it(e).toLowerCase())
                }

                function ml(e) {
                    return e = it(e), e && e.replace(ni, od).replace(lo, "")
                }

                function _y(e, i, a) {
                    e = it(e), i = Er(i);
                    var u = e.length;
                    a = a === r ? u : Ki(Me(a), 0, u);
                    var p = a;
                    return a -= i.length, a >= 0 && e.slice(a, p) == i
                }

                function my(e) {
                    return e = it(e), e && gt.test(e) ? e.replace(Ui, cd) : e
                }

                function by(e) {
                    return e = it(e), e && $t.test(e) ? e.replace(Dt, "\\$&") : e
                }
                var wy = wn(function(e, i, a) {
                        return e + (a ? "-" : "") + i.toLowerCase()
                    }),
                    Ey = wn(function(e, i, a) {
                        return e + (a ? " " : "") + i.toLowerCase()
                    }),
                    Dy = Eh("toLowerCase");

                function Iy(e, i, a) {
                    e = it(e), i = Me(i);
                    var u = i ? dn(e) : 0;
                    if (!i || u >= i) return e;
                    var p = (i - u) / 2;
                    return sa(Vs(p), a) + e + sa(ks(p), a)
                }

                function Sy(e, i, a) {
                    e = it(e), i = Me(i);
                    var u = i ? dn(e) : 0;
                    return i && u < i ? e + sa(i - u, a) : e
                }

                function xy(e, i, a) {
                    e = it(e), i = Me(i);
                    var u = i ? dn(e) : 0;
                    return i && u < i ? sa(i - u, a) + e : e
                }

                function Cy(e, i, a) {
                    return a || i == null ? i = 0 : i && (i = +i), Fd(it(e).replace(It, ""), i || 0)
                }

                function Oy(e, i, a) {
                    return (a ? nr(e, i, a) : i === r) ? i = 1 : i = Me(i), Mo(it(e), i)
                }

                function Ay() {
                    var e = arguments,
                        i = it(e[0]);
                    return e.length < 3 ? i : i.replace(e[1], e[2])
                }
                var Py = wn(function(e, i, a) {
                    return e + (a ? "_" : "") + i.toLowerCase()
                });

                function Ny(e, i, a) {
                    return a && typeof a != "number" && nr(e, i, a) && (i = a = r), a = a === r ? re : a >>> 0, a ? (e = it(e), e && (typeof i == "string" || i != null && !oc(i)) && (i = Er(i), !i && pn(e)) ? xi(qr(e), 0, a) : e.split(i, a)) : []
                }
                var Ty = wn(function(e, i, a) {
                    return e + (a ? " " : "") + hc(i)
                });

                function Ry(e, i, a) {
                    return e = it(e), a = a == null ? 0 : Ki(Me(a), 0, e.length), i = Er(i), e.slice(a, a + i.length) == i
                }

                function Fy(e, i, a) {
                    var u = y.templateSettings;
                    a && nr(e, i, a) && (i = r), e = it(e), i = ya({}, i, u, Ah);
                    var p = ya({}, i.imports, u.imports, Ah),
                        _ = kt(p),
                        D = wo(p, _),
                        A, M, J = 0,
                        X = i.interpolate || sn,
                        Q = "__p += '",
                        oe = Do((i.escape || sn).source + "|" + X.source + "|" + (X === _t ? Wa : sn).source + "|" + (i.evaluate || sn).source + "|$", "g"),
                        ve = "//# sourceURL=" + (nt.call(i, "sourceURL") ? (i.sourceURL + "").replace(/\s/g, " ") : "lodash.templateSources[" + ++fo + "]") + `
`;
                    e.replace(oe, function(Ee, Ge, Ze, Ir, sr, Sr) {
                        return Ze || (Ze = Ir), Q += e.slice(J, Sr).replace(eo, ud), Ge && (A = !0, Q += `' +
__e(` + Ge + `) +
'`), sr && (M = !0, Q += `';
` + sr + `;
__p += '`), Ze && (Q += `' +
((__t = (` + Ze + `)) == null ? '' : __t) +
'`), J = Sr + Ee.length, Ee
                    }), Q += `';
`;
                    var we = nt.call(i, "variable") && i.variable;
                    if (!we) Q = `with (obj) {
` + Q + `
}
`;
                    else if (Va.test(we)) throw new Pe(f);
                    Q = (M ? Q.replace(Vr, "") : Q).replace(tr, "$1").replace(ii, "$1;"), Q = "function(" + (we || "obj") + `) {
` + (we ? "" : `obj || (obj = {});
`) + "var __t, __p = ''" + (A ? ", __e = _.escape" : "") + (M ? `, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
` : `;
`) + Q + `return __p
}`;
                    var qe = wl(function() {
                        return rt(_, ve + "return " + Q).apply(r, D)
                    });
                    if (qe.source = Q, ac(qe)) throw qe;
                    return qe
                }

                function Uy(e) {
                    return it(e).toLowerCase()
                }

                function $y(e) {
                    return it(e).toUpperCase()
                }

                function Ly(e, i, a) {
                    if (e = it(e), e && (a || i === r)) return Pu(e);
                    if (!e || !(i = Er(i))) return e;
                    var u = qr(e),
                        p = qr(i),
                        _ = Nu(u, p),
                        D = Tu(u, p) + 1;
                    return xi(u, _, D).join("")
                }

                function My(e, i, a) {
                    if (e = it(e), e && (a || i === r)) return e.slice(0, Fu(e) + 1);
                    if (!e || !(i = Er(i))) return e;
                    var u = qr(e),
                        p = Tu(u, qr(i)) + 1;
                    return xi(u, 0, p).join("")
                }

                function jy(e, i, a) {
                    if (e = it(e), e && (a || i === r)) return e.replace(It, "");
                    if (!e || !(i = Er(i))) return e;
                    var u = qr(e),
                        p = Nu(u, qr(i));
                    return xi(u, p).join("")
                }

                function zy(e, i) {
                    var a = V,
                        u = ae;
                    if (mt(i)) {
                        var p = "separator" in i ? i.separator : p;
                        a = "length" in i ? Me(i.length) : a, u = "omission" in i ? Er(i.omission) : u
                    }
                    e = it(e);
                    var _ = e.length;
                    if (pn(e)) {
                        var D = qr(e);
                        _ = D.length
                    }
                    if (a >= _) return e;
                    var A = a - dn(u);
                    if (A < 1) return u;
                    var M = D ? xi(D, 0, A).join("") : e.slice(0, A);
                    if (p === r) return M + u;
                    if (D && (A += M.length - A), oc(p)) {
                        if (e.slice(A).search(p)) {
                            var J, X = M;
                            for (p.global || (p = Do(p.source, it(Cr.exec(p)) + "g")), p.lastIndex = 0; J = p.exec(X);) var Q = J.index;
                            M = M.slice(0, Q === r ? A : Q)
                        }
                    } else if (e.indexOf(Er(p), A) != A) {
                        var oe = M.lastIndexOf(p);
                        oe > -1 && (M = M.slice(0, oe))
                    }
                    return M + u
                }

                function qy(e) {
                    return e = it(e), e && bt.test(e) ? e.replace(yi, vd) : e
                }
                var Hy = wn(function(e, i, a) {
                        return e + (a ? " " : "") + i.toUpperCase()
                    }),
                    hc = Eh("toUpperCase");

                function bl(e, i, a) {
                    return e = it(e), i = a ? r : i, i === r ? ld(e) ? md(e) : rd(e) : e.match(i) || []
                }
                var wl = Ke(function(e, i) {
                        try {
                            return Kt(e, r, i)
                        } catch (a) {
                            return ac(a) ? a : new Pe(a)
                        }
                    }),
                    By = hi(function(e, i) {
                        return Ar(i, function(a) {
                            a = Xr(a), ci(e, a, nc(e[a], e))
                        }), e
                    });

                function Ky(e) {
                    var i = e == null ? 0 : e.length,
                        a = me();
                    return e = i ? yt(e, function(u) {
                        if (typeof u[1] != "function") throw new Pr(d);
                        return [a(u[0]), u[1]]
                    }) : [], Ke(function(u) {
                        for (var p = -1; ++p < i;) {
                            var _ = e[p];
                            if (Kt(_[0], this, u)) return Kt(_[1], this, u)
                        }
                    })
                }

                function ky(e) {
                    return vg(Tr(e, S))
                }

                function lc(e) {
                    return function() {
                        return e
                    }
                }

                function Vy(e, i) {
                    return e == null || e !== e ? i : e
                }
                var Gy = Ih(),
                    Wy = Ih(!0);

                function gr(e) {
                    return e
                }

                function fc(e) {
                    return eh(typeof e == "function" ? e : Tr(e, S))
                }

                function Yy(e) {
                    return rh(Tr(e, S))
                }

                function Jy(e, i) {
                    return ih(e, Tr(i, S))
                }
                var Xy = Ke(function(e, i) {
                        return function(a) {
                            return Kn(a, e, i)
                        }
                    }),
                    Zy = Ke(function(e, i) {
                        return function(a) {
                            return Kn(e, a, i)
                        }
                    });

                function pc(e, i, a) {
                    var u = kt(i),
                        p = Zs(i, u);
                    a == null && !(mt(i) && (p.length || !u.length)) && (a = i, i = e, e = this, p = Zs(i, kt(i)));
                    var _ = !(mt(a) && "chain" in a) || !!a.chain,
                        D = fi(e);
                    return Ar(p, function(A) {
                        var M = i[A];
                        e[A] = M, D && (e.prototype[A] = function() {
                            var J = this.__chain__;
                            if (_ || J) {
                                var X = e(this.__wrapped__),
                                    Q = X.__actions__ = fr(this.__actions__);
                                return Q.push({
                                    func: M,
                                    args: arguments,
                                    thisArg: e
                                }), X.__chain__ = J, X
                            }
                            return M.apply(e, bi([this.value()], arguments))
                        })
                    }), e
                }

                function Qy() {
                    return Xe._ === this && (Xe._ = Sd), this
                }

                function dc() {}

                function e_(e) {
                    return e = Me(e), Ke(function(i) {
                        return nh(i, e)
                    })
                }
                var t_ = ko(yt),
                    r_ = ko(Su),
                    i_ = ko(vo);

                function El(e) {
                    return Zo(e) ? yo(Xr(e)) : Rg(e)
                }

                function n_(e) {
                    return function(i) {
                        return e == null ? r : ki(e, i)
                    }
                }
                var s_ = xh(),
                    a_ = xh(!0);

                function gc() {
                    return []
                }

                function vc() {
                    return !1
                }

                function o_() {
                    return {}
                }

                function c_() {
                    return ""
                }

                function u_() {
                    return !0
                }

                function h_(e, i) {
                    if (e = Me(e), e < 1 || e > W) return [];
                    var a = re,
                        u = Xt(e, re);
                    i = me(i), e -= re;
                    for (var p = bo(u, i); ++a < e;) i(a);
                    return p
                }

                function l_(e) {
                    return Te(e) ? yt(e, Xr) : Dr(e) ? [e] : fr(Hh(it(e)))
                }

                function f_(e) {
                    var i = ++Dd;
                    return it(e) + i
                }
                var p_ = na(function(e, i) {
                        return e + i
                    }, 0),
                    d_ = Vo("ceil"),
                    g_ = na(function(e, i) {
                        return e / i
                    }, 1),
                    v_ = Vo("floor");

                function y_(e) {
                    return e && e.length ? Xs(e, gr, No) : r
                }

                function __(e, i) {
                    return e && e.length ? Xs(e, me(i, 2), No) : r
                }

                function m_(e) {
                    return Ou(e, gr)
                }

                function b_(e, i) {
                    return Ou(e, me(i, 2))
                }

                function w_(e) {
                    return e && e.length ? Xs(e, gr, Uo) : r
                }

                function E_(e, i) {
                    return e && e.length ? Xs(e, me(i, 2), Uo) : r
                }
                var D_ = na(function(e, i) {
                        return e * i
                    }, 1),
                    I_ = Vo("round"),
                    S_ = na(function(e, i) {
                        return e - i
                    }, 0);

                function x_(e) {
                    return e && e.length ? mo(e, gr) : 0
                }

                function C_(e, i) {
                    return e && e.length ? mo(e, me(i, 2)) : 0
                }
                return y.after = Y1, y.ary = Qh, y.assign = $v, y.assignIn = pl, y.assignInWith = ya, y.assignWith = Lv, y.at = Mv, y.before = el, y.bind = nc, y.bindAll = By, y.bindKey = tl, y.castArray = ov, y.chain = Jh, y.chunk = v0, y.compact = y0, y.concat = _0, y.cond = Ky, y.conforms = ky, y.constant = lc, y.countBy = x1, y.create = jv, y.curry = rl, y.curryRight = il, y.debounce = nl, y.defaults = zv, y.defaultsDeep = qv, y.defer = J1, y.delay = X1, y.difference = m0, y.differenceBy = b0, y.differenceWith = w0, y.drop = E0, y.dropRight = D0, y.dropRightWhile = I0, y.dropWhile = S0, y.fill = x0, y.filter = O1, y.flatMap = N1, y.flatMapDeep = T1, y.flatMapDepth = R1, y.flatten = Vh, y.flattenDeep = C0, y.flattenDepth = O0, y.flip = Z1, y.flow = Gy, y.flowRight = Wy, y.fromPairs = A0, y.functions = Wv, y.functionsIn = Yv, y.groupBy = F1, y.initial = N0, y.intersection = T0, y.intersectionBy = R0, y.intersectionWith = F0, y.invert = Xv, y.invertBy = Zv, y.invokeMap = $1, y.iteratee = fc, y.keyBy = L1, y.keys = kt, y.keysIn = dr, y.map = la, y.mapKeys = ey, y.mapValues = ty, y.matches = Yy, y.matchesProperty = Jy, y.memoize = pa, y.merge = ry, y.mergeWith = dl, y.method = Xy, y.methodOf = Zy, y.mixin = pc, y.negate = da, y.nthArg = e_, y.omit = iy, y.omitBy = ny, y.once = Q1, y.orderBy = M1, y.over = t_, y.overArgs = ev, y.overEvery = r_, y.overSome = i_, y.partial = sc, y.partialRight = sl, y.partition = j1, y.pick = sy, y.pickBy = gl, y.property = El, y.propertyOf = n_, y.pull = M0, y.pullAll = Wh, y.pullAllBy = j0, y.pullAllWith = z0, y.pullAt = q0, y.range = s_, y.rangeRight = a_, y.rearg = tv, y.reject = H1, y.remove = H0, y.rest = rv, y.reverse = rc, y.sampleSize = K1, y.set = oy, y.setWith = cy, y.shuffle = k1, y.slice = B0, y.sortBy = W1, y.sortedUniq = J0, y.sortedUniqBy = X0, y.split = Ny, y.spread = iv, y.tail = Z0, y.take = Q0, y.takeRight = e1, y.takeRightWhile = t1, y.takeWhile = r1, y.tap = y1, y.throttle = nv, y.thru = ha, y.toArray = hl, y.toPairs = vl, y.toPairsIn = yl, y.toPath = l_, y.toPlainObject = fl, y.transform = uy, y.unary = sv, y.union = i1, y.unionBy = n1, y.unionWith = s1, y.uniq = a1, y.uniqBy = o1, y.uniqWith = c1, y.unset = hy, y.unzip = ic, y.unzipWith = Yh, y.update = ly, y.updateWith = fy, y.values = In, y.valuesIn = py, y.without = u1, y.words = bl, y.wrap = av, y.xor = h1, y.xorBy = l1, y.xorWith = f1, y.zip = p1, y.zipObject = d1, y.zipObjectDeep = g1, y.zipWith = v1, y.entries = vl, y.entriesIn = yl, y.extend = pl, y.extendWith = ya, pc(y, y), y.add = p_, y.attempt = wl, y.camelCase = yy, y.capitalize = _l, y.ceil = d_, y.clamp = dy, y.clone = cv, y.cloneDeep = hv, y.cloneDeepWith = lv, y.cloneWith = uv, y.conformsTo = fv, y.deburr = ml, y.defaultTo = Vy, y.divide = g_, y.endsWith = _y, y.eq = Br, y.escape = my, y.escapeRegExp = by, y.every = C1, y.find = A1, y.findIndex = Kh, y.findKey = Hv, y.findLast = P1, y.findLastIndex = kh, y.findLastKey = Bv, y.floor = v_, y.forEach = Xh, y.forEachRight = Zh, y.forIn = Kv, y.forInRight = kv, y.forOwn = Vv, y.forOwnRight = Gv, y.get = cc, y.gt = pv, y.gte = dv, y.has = Jv, y.hasIn = uc, y.head = Gh, y.identity = gr, y.includes = U1, y.indexOf = P0, y.inRange = gy, y.invoke = Qv, y.isArguments = Wi, y.isArray = Te, y.isArrayBuffer = gv, y.isArrayLike = pr, y.isArrayLikeObject = Pt, y.isBoolean = vv, y.isBuffer = Ci, y.isDate = yv, y.isElement = _v, y.isEmpty = mv, y.isEqual = bv, y.isEqualWith = wv, y.isError = ac, y.isFinite = Ev, y.isFunction = fi, y.isInteger = al, y.isLength = ga, y.isMap = ol, y.isMatch = Dv, y.isMatchWith = Iv, y.isNaN = Sv, y.isNative = xv, y.isNil = Ov, y.isNull = Cv, y.isNumber = cl, y.isObject = mt, y.isObjectLike = xt, y.isPlainObject = Jn, y.isRegExp = oc, y.isSafeInteger = Av, y.isSet = ul, y.isString = va, y.isSymbol = Dr, y.isTypedArray = Dn, y.isUndefined = Pv, y.isWeakMap = Nv, y.isWeakSet = Tv, y.join = U0, y.kebabCase = wy, y.last = Fr, y.lastIndexOf = $0, y.lowerCase = Ey, y.lowerFirst = Dy, y.lt = Rv, y.lte = Fv, y.max = y_, y.maxBy = __, y.mean = m_, y.meanBy = b_, y.min = w_, y.minBy = E_, y.stubArray = gc, y.stubFalse = vc, y.stubObject = o_, y.stubString = c_, y.stubTrue = u_, y.multiply = D_, y.nth = L0, y.noConflict = Qy, y.noop = dc, y.now = fa, y.pad = Iy, y.padEnd = Sy, y.padStart = xy, y.parseInt = Cy, y.random = vy, y.reduce = z1, y.reduceRight = q1, y.repeat = Oy, y.replace = Ay, y.result = ay, y.round = I_, y.runInContext = $, y.sample = B1, y.size = V1, y.snakeCase = Py, y.some = G1, y.sortedIndex = K0, y.sortedIndexBy = k0, y.sortedIndexOf = V0, y.sortedLastIndex = G0, y.sortedLastIndexBy = W0, y.sortedLastIndexOf = Y0, y.startCase = Ty, y.startsWith = Ry, y.subtract = S_, y.sum = x_, y.sumBy = C_, y.template = Fy, y.times = h_, y.toFinite = pi, y.toInteger = Me, y.toLength = ll, y.toLower = Uy, y.toNumber = Ur, y.toSafeInteger = Uv, y.toString = it, y.toUpper = $y, y.trim = Ly, y.trimEnd = My, y.trimStart = jy, y.truncate = zy, y.unescape = qy, y.uniqueId = f_, y.upperCase = Hy, y.upperFirst = hc, y.each = Xh, y.eachRight = Zh, y.first = Gh, pc(y, function() {
                    var e = {};
                    return Yr(y, function(i, a) {
                        nt.call(y.prototype, a) || (e[a] = i)
                    }), e
                }(), {
                    chain: !1
                }), y.VERSION = s, Ar(["bind", "bindKey", "curry", "curryRight", "partial", "partialRight"], function(e) {
                    y[e].placeholder = y
                }), Ar(["drop", "take"], function(e, i) {
                    Ye.prototype[e] = function(a) {
                        a = a === r ? 1 : Bt(Me(a), 0);
                        var u = this.__filtered__ && !i ? new Ye(this) : this.clone();
                        return u.__filtered__ ? u.__takeCount__ = Xt(a, u.__takeCount__) : u.__views__.push({
                            size: Xt(a, re),
                            type: e + (u.__dir__ < 0 ? "Right" : "")
                        }), u
                    }, Ye.prototype[e + "Right"] = function(a) {
                        return this.reverse()[e](a).reverse()
                    }
                }), Ar(["filter", "map", "takeWhile"], function(e, i) {
                    var a = i + 1,
                        u = a == F || a == le;
                    Ye.prototype[e] = function(p) {
                        var _ = this.clone();
                        return _.__iteratees__.push({
                            iteratee: me(p, 3),
                            type: a
                        }), _.__filtered__ = _.__filtered__ || u, _
                    }
                }), Ar(["head", "last"], function(e, i) {
                    var a = "take" + (i ? "Right" : "");
                    Ye.prototype[e] = function() {
                        return this[a](1).value()[0]
                    }
                }), Ar(["initial", "tail"], function(e, i) {
                    var a = "drop" + (i ? "" : "Right");
                    Ye.prototype[e] = function() {
                        return this.__filtered__ ? new Ye(this) : this[a](1)
                    }
                }), Ye.prototype.compact = function() {
                    return this.filter(gr)
                }, Ye.prototype.find = function(e) {
                    return this.filter(e).head()
                }, Ye.prototype.findLast = function(e) {
                    return this.reverse().find(e)
                }, Ye.prototype.invokeMap = Ke(function(e, i) {
                    return typeof e == "function" ? new Ye(this) : this.map(function(a) {
                        return Kn(a, e, i)
                    })
                }), Ye.prototype.reject = function(e) {
                    return this.filter(da(me(e)))
                }, Ye.prototype.slice = function(e, i) {
                    e = Me(e);
                    var a = this;
                    return a.__filtered__ && (e > 0 || i < 0) ? new Ye(a) : (e < 0 ? a = a.takeRight(-e) : e && (a = a.drop(e)), i !== r && (i = Me(i), a = i < 0 ? a.dropRight(-i) : a.take(i - e)), a)
                }, Ye.prototype.takeRightWhile = function(e) {
                    return this.reverse().takeWhile(e).reverse()
                }, Ye.prototype.toArray = function() {
                    return this.take(re)
                }, Yr(Ye.prototype, function(e, i) {
                    var a = /^(?:filter|find|map|reject)|While$/.test(i),
                        u = /^(?:head|last)$/.test(i),
                        p = y[u ? "take" + (i == "last" ? "Right" : "") : i],
                        _ = u || /^find/.test(i);
                    p && (y.prototype[i] = function() {
                        var D = this.__wrapped__,
                            A = u ? [1] : arguments,
                            M = D instanceof Ye,
                            J = A[0],
                            X = M || Te(D),
                            Q = function(Ge) {
                                var Ze = p.apply(y, bi([Ge], A));
                                return u && oe ? Ze[0] : Ze
                            };
                        X && a && typeof J == "function" && J.length != 1 && (M = X = !1);
                        var oe = this.__chain__,
                            ve = !!this.__actions__.length,
                            we = _ && !oe,
                            qe = M && !ve;
                        if (!_ && X) {
                            D = qe ? D : new Ye(this);
                            var Ee = e.apply(D, A);
                            return Ee.__actions__.push({
                                func: ha,
                                args: [Q],
                                thisArg: r
                            }), new Nr(Ee, oe)
                        }
                        return we && qe ? e.apply(this, A) : (Ee = this.thru(Q), we ? u ? Ee.value()[0] : Ee.value() : Ee)
                    })
                }), Ar(["pop", "push", "shift", "sort", "splice", "unshift"], function(e) {
                    var i = $s[e],
                        a = /^(?:push|sort|unshift)$/.test(e) ? "tap" : "thru",
                        u = /^(?:pop|shift)$/.test(e);
                    y.prototype[e] = function() {
                        var p = arguments;
                        if (u && !this.__chain__) {
                            var _ = this.value();
                            return i.apply(Te(_) ? _ : [], p)
                        }
                        return this[a](function(D) {
                            return i.apply(Te(D) ? D : [], p)
                        })
                    }
                }), Yr(Ye.prototype, function(e, i) {
                    var a = y[i];
                    if (a) {
                        var u = a.name + "";
                        nt.call(_n, u) || (_n[u] = []), _n[u].push({
                            name: i,
                            func: a
                        })
                    }
                }), _n[ia(r, ie).name] = [{
                    name: "wrapper",
                    func: r
                }], Ye.prototype.clone = qd, Ye.prototype.reverse = Hd, Ye.prototype.value = Bd, y.prototype.at = _1, y.prototype.chain = m1, y.prototype.commit = b1, y.prototype.next = w1, y.prototype.plant = D1, y.prototype.reverse = I1, y.prototype.toJSON = y.prototype.valueOf = y.prototype.value = S1, y.prototype.first = y.prototype.head, Ln && (y.prototype[Ln] = E1), y
            },
            gn = bd();
        At ? ((At.exports = gn)._ = gn, ct._ = gn) : Xe._ = gn
    }).call(ss)
})(Zc, Zc.exports);
var JD = Object.defineProperty,
    XD = Object.defineProperties,
    ZD = Object.getOwnPropertyDescriptors,
    Lf = Object.getOwnPropertySymbols,
    QD = Object.prototype.hasOwnProperty,
    e2 = Object.prototype.propertyIsEnumerable,
    Mf = (n, t, r) => t in n ? JD(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    Ea = (n, t) => {
        for (var r in t || (t = {})) QD.call(t, r) && Mf(n, r, t[r]);
        if (Lf)
            for (var r of Lf(t)) e2.call(t, r) && Mf(n, r, t[r]);
        return n
    },
    t2 = (n, t) => XD(n, ZD(t));

function Mr(n, t, r) {
    let s;
    const o = Qc(n);
    return t.rpcMap && (s = t.rpcMap[o]), s || (s = `${YD}?chainId=eip155:${o}&projectId=${r}`), s
}

function Qc(n) {
    return n.includes("eip155") ? Number(n.split(":")[1]) : Number(n)
}

function Yp(n) {
    return n.map(t => `${t.split(":")[0]}:${t.split(":")[1]}`)
}

function r2(n, t) {
    const r = Object.keys(t.namespaces).filter(o => o.includes(n));
    if (!r.length) return [];
    const s = [];
    return r.forEach(o => {
        const l = t.namespaces[o].accounts;
        s.push(...l)
    }), s
}

function i2(n = {}, t = {}) {
    const r = jf(n),
        s = jf(t);
    return Zc.exports.merge(r, s)
}

function jf(n) {
    var t, r, s, o;
    const l = {};
    if (!On(n)) return l;
    for (const [d, f] of Object.entries(n)) {
        const v = yu(d) ? [d] : f.chains,
            g = f.methods || [],
            b = f.events || [],
            S = f.rpcMap || {},
            O = Sa(d);
        l[O] = t2(Ea(Ea({}, l[O]), f), {
            chains: Dc(v, (t = l[O]) == null ? void 0 : t.chains),
            methods: Dc(g, (r = l[O]) == null ? void 0 : r.methods),
            events: Dc(b, (s = l[O]) == null ? void 0 : s.events),
            rpcMap: Ea(Ea({}, S), (o = l[O]) == null ? void 0 : o.rpcMap)
        })
    }
    return l
}

function n2(n) {
    return n.includes(":") ? n.split(":")[2] : n
}

function s2(n) {
    const t = {};
    for (const [r, s] of Object.entries(n)) {
        const o = s.methods || [],
            l = s.events || [],
            d = s.accounts || [],
            f = yu(r) ? [r] : s.chains ? s.chains : Yp(s.accounts);
        t[r] = {
            chains: f,
            methods: o,
            events: l,
            accounts: d
        }
    }
    return t
}
const Jp = {},
    Rt = n => Jp[n],
    $c = (n, t) => {
        Jp[n] = t
    };
class a2 {
    constructor(t) {
        this.name = "polkadot", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, r) {
        if (this.chainId = t, !this.httpProviders[t]) {
            const s = r || Mr(`${this.name}:${t}`, this.namespace);
            if (!s) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, s)
        }
        this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]) || [] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            var s;
            t[r] = this.createHttpProvider(r, (s = this.namespace.rpcMap) == null ? void 0 : s[r])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProvider(t, r) {
        const s = r || Mr(t, this.namespace);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
}
class o2 {
    constructor(t) {
        this.name = "eip155", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.httpProviders = this.createHttpProviders(), this.chainId = parseInt(this.getDefaultChain())
    }
    async request(t) {
        switch (t.request.method) {
            case "eth_requestAccounts":
                return this.getAccounts();
            case "eth_accounts":
                return this.getAccounts();
            case "wallet_switchEthereumChain":
                return await this.handleSwitchChain(t);
            case "eth_chainId":
                return parseInt(this.getDefaultChain())
        }
        return this.namespace.methods.includes(t.request.method) ? await this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    setDefaultChain(t, r) {
        const s = Qc(t);
        if (!this.httpProviders[s]) {
            const o = r || Mr(`${this.name}:${s}`, this.namespace, this.client.core.projectId);
            if (!o) throw new Error(`No RPC url provided for chainId: ${s}`);
            this.setHttpProvider(s, o)
        }
        this.chainId = s, this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${s}`)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId.toString();
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    createHttpProvider(t, r) {
        const s = r || Mr(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            var s;
            const o = Qc(r);
            t[o] = this.createHttpProvider(o, (s = this.namespace.rpcMap) == null ? void 0 : s[r])
        }), t
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]))] : []
    }
    getHttpProvider() {
        const t = this.chainId,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    async handleSwitchChain(t) {
        var r, s;
        let o = t.request.params ? (r = t.request.params[0]) == null ? void 0 : r.chainId : "0x0";
        o = o.startsWith("0x") ? o : `0x${o}`;
        const l = parseInt(o, 16);
        if (this.isChainApproved(l)) this.setDefaultChain(`${l}`);
        else if (this.namespace.methods.includes("wallet_switchEthereumChain")) await this.client.request({
            topic: t.topic,
            request: {
                method: t.request.method,
                params: [{
                    chainId: o
                }]
            },
            chainId: (s = this.namespace.chains) == null ? void 0 : s[0]
        }), this.setDefaultChain(`${l}`);
        else throw new Error(`Failed to switch to chain 'eip155:${l}'. The chain is not approved or the wallet does not support 'wallet_switchEthereumChain' method.`);
        return null
    }
    isChainApproved(t) {
        return this.namespace.chains.includes(`${this.name}:${t}`)
    }
}
class c2 {
    constructor(t) {
        this.name = "solana", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, r) {
        if (!this.httpProviders[t]) {
            const s = r || Mr(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
            if (!s) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, s)
        }
        this.chainId = t, this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            var s;
            t[r] = this.createHttpProvider(r, (s = this.namespace.rpcMap) == null ? void 0 : s[r])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProvider(t, r) {
        const s = r || Mr(t, this.namespace, this.client.core.projectId);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
}
class u2 {
    constructor(t) {
        this.name = "cosmos", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, r) {
        if (this.chainId = t, !this.httpProviders[t]) {
            const s = r || Mr(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
            if (!s) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, s)
        }
        this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            var s;
            t[r] = this.createHttpProvider(r, (s = this.namespace.rpcMap) == null ? void 0 : s[r])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProvider(t, r) {
        const s = r || Mr(t, this.namespace, this.client.core.projectId);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
}
class h2 {
    constructor(t) {
        this.name = "cip34", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, r) {
        if (this.chainId = t, !this.httpProviders[t]) {
            const s = r || this.getCardanoRPCUrl(t);
            if (!s) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, s)
        }
        this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            const s = this.getCardanoRPCUrl(r);
            t[r] = this.createHttpProvider(r, s)
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    getCardanoRPCUrl(t) {
        const r = this.namespace.rpcMap;
        if (r) return r[t]
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProvider(t, r) {
        const s = r || this.getCardanoRPCUrl(t);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
}
class l2 {
    constructor(t) {
        this.name = "elrond", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, r) {
        if (!this.httpProviders[t]) {
            const s = r || Mr(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
            if (!s) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, s)
        }
        this.chainId = t, this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            var s;
            t[r] = this.createHttpProvider(r, (s = this.namespace.rpcMap) == null ? void 0 : s[r])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProvider(t, r) {
        const s = r || Mr(t, this.namespace, this.client.core.projectId);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
}
class f2 {
    constructor(t) {
        this.name = "multiversx", this.namespace = t.namespace, this.events = Rt("events"), this.client = Rt("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, r) {
        if (!this.httpProviders[t]) {
            const s = r || Mr(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
            if (!s) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, s)
        }
        this.chainId = t, this.events.emit(Fi.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(r => r.split(":")[1] === this.chainId.toString()).map(r => r.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(r => {
            var s;
            t[r] = this.createHttpProvider(r, (s = this.namespace.rpcMap) == null ? void 0 : s[r])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            r = this.httpProviders[t];
        if (typeof r > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return r
    }
    setHttpProvider(t, r) {
        const s = this.createHttpProvider(t, r);
        s && (this.httpProviders[t] = s)
    }
    createHttpProvider(t, r) {
        const s = r || Mr(t, this.namespace, this.client.core.projectId);
        return typeof s > "u" ? void 0 : new Ti(new en(s, Rt("disableProviderPing")))
    }
}
var p2 = Object.defineProperty,
    d2 = Object.defineProperties,
    g2 = Object.getOwnPropertyDescriptors,
    zf = Object.getOwnPropertySymbols,
    v2 = Object.prototype.hasOwnProperty,
    y2 = Object.prototype.propertyIsEnumerable,
    qf = (n, t, r) => t in n ? p2(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    Da = (n, t) => {
        for (var r in t || (t = {})) v2.call(t, r) && qf(n, r, t[r]);
        if (zf)
            for (var r of zf(t)) y2.call(t, r) && qf(n, r, t[r]);
        return n
    },
    Lc = (n, t) => d2(n, g2(t));
class Du {
    constructor(t) {
        this.events = new ru, this.rpcProviders = {}, this.shouldAbortPairingAttempt = !1, this.maxPairingAttempts = 10, this.disableProviderPing = !1, this.providerOpts = t, this.logger = typeof(t == null ? void 0 : t.logger) < "u" && typeof(t == null ? void 0 : t.logger) != "string" ? t.logger : Qe.pino(Qe.getDefaultLoggerOptions({
            level: (t == null ? void 0 : t.logger) || Uf
        })), this.disableProviderPing = (t == null ? void 0 : t.disableProviderPing) || !1
    }
    static async init(t) {
        const r = new Du(t);
        return await r.initialize(), r
    }
    async request(t, r) {
        const [s, o] = this.validateChain(r);
        if (!this.session) throw new Error("Please call connect() before request()");
        return await this.getProvider(s).request({
            request: Da({}, t),
            chainId: `${s}:${o}`,
            topic: this.session.topic
        })
    }
    sendAsync(t, r, s) {
        this.request(t, s).then(o => r(null, o)).catch(o => r(o, void 0))
    }
    async enable() {
        if (!this.client) throw new Error("Sign Client not initialized");
        return this.session || await this.connect({
            namespaces: this.namespaces,
            optionalNamespaces: this.optionalNamespaces,
            sessionProperties: this.sessionProperties
        }), await this.requestAccounts()
    }
    async disconnect() {
        var t;
        if (!this.session) throw new Error("Please call connect() before enable()");
        await this.client.disconnect({
            topic: (t = this.session) == null ? void 0 : t.topic,
            reason: Tt("USER_DISCONNECTED")
        }), await this.cleanup()
    }
    async connect(t) {
        if (!this.client) throw new Error("Sign Client not initialized");
        if (this.setNamespaces(t), await this.cleanupPendingPairings(), !t.skipPairing) return await this.pair(t.pairingTopic)
    }
    on(t, r) {
        this.events.on(t, r)
    }
    once(t, r) {
        this.events.once(t, r)
    }
    removeListener(t, r) {
        this.events.removeListener(t, r)
    }
    off(t, r) {
        this.events.off(t, r)
    }
    get isWalletConnect() {
        return !0
    }
    async pair(t) {
        this.shouldAbortPairingAttempt = !1;
        let r = 0;
        do {
            if (this.shouldAbortPairingAttempt) throw new Error("Pairing aborted");
            if (r >= this.maxPairingAttempts) throw new Error("Max auto pairing attempts reached");
            const {
                uri: s,
                approval: o
            } = await this.client.connect({
                pairingTopic: t,
                requiredNamespaces: this.namespaces,
                optionalNamespaces: this.optionalNamespaces,
                sessionProperties: this.sessionProperties
            });
            s && (this.uri = s, this.events.emit("display_uri", s)), await o().then(l => {
                this.session = l, this.namespaces || (this.namespaces = s2(l.namespaces), this.persist("namespaces", this.namespaces))
            }).catch(l => {
                if (l.message !== Gp) throw l;
                r++
            })
        } while (!this.session);
        return this.onConnect(), this.session
    }
    setDefaultChain(t, r) {
        try {
            if (!this.session) return;
            const [s, o] = this.validateChain(t);
            this.getProvider(s).setDefaultChain(o, r)
        } catch (s) {
            if (!/Please call connect/.test(s.message)) throw s
        }
    }
    async cleanupPendingPairings(t = {}) {
        this.logger.info("Cleaning up inactive pairings...");
        const r = this.client.pairing.getAll();
        if (ti(r)) {
            for (const s of r) t.deletePairings ? this.client.core.expirer.set(s.topic, 0) : await this.client.core.relayer.subscriber.unsubscribe(s.topic);
            this.logger.info(`Inactive pairings cleared: ${r.length}`)
        }
    }
    abortPairingAttempt() {
        this.shouldAbortPairingAttempt = !0
    }
    async checkStorage() {
        if (this.namespaces = await this.getFromStore("namespaces"), this.optionalNamespaces = await this.getFromStore("optionalNamespaces") || {}, this.client.session.length) {
            const t = this.client.session.keys.length - 1;
            this.session = this.client.session.get(this.client.session.keys[t]), this.createProviders()
        }
    }
    async initialize() {
        this.logger.trace("Initialized"), await this.createClient(), await this.checkStorage(), this.registerEventListeners()
    }
    async createClient() {
        this.client = this.providerOpts.client || await kD.init({
            logger: this.providerOpts.logger || Uf,
            relayUrl: this.providerOpts.relayUrl || VD,
            projectId: this.providerOpts.projectId,
            metadata: this.providerOpts.metadata,
            storageOptions: this.providerOpts.storageOptions,
            name: this.providerOpts.name
        }), this.logger.trace("SignClient Initialized")
    }
    createProviders() {
        if (!this.client) throw new Error("Sign Client not initialized");
        if (!this.session) throw new Error("Session not initialized. Please call connect() before enable()");
        const t = [...new Set(Object.keys(this.session.namespaces).map(r => Sa(r)))];
        $c("client", this.client), $c("events", this.events), $c("disableProviderPing", this.disableProviderPing), t.forEach(r => {
            if (!this.session) return;
            const s = r2(r, this.session),
                o = Yp(s),
                l = i2(this.namespaces, this.optionalNamespaces),
                d = Lc(Da({}, l[r]), {
                    accounts: s,
                    chains: o
                });
            switch (r) {
                case "eip155":
                    this.rpcProviders[r] = new o2({
                        namespace: d
                    });
                    break;
                case "solana":
                    this.rpcProviders[r] = new c2({
                        namespace: d
                    });
                    break;
                case "cosmos":
                    this.rpcProviders[r] = new u2({
                        namespace: d
                    });
                    break;
                case "polkadot":
                    this.rpcProviders[r] = new a2({
                        namespace: d
                    });
                    break;
                case "cip34":
                    this.rpcProviders[r] = new h2({
                        namespace: d
                    });
                    break;
                case "elrond":
                    this.rpcProviders[r] = new l2({
                        namespace: d
                    });
                    break;
                case "multiversx":
                    this.rpcProviders[r] = new f2({
                        namespace: d
                    });
                    break
            }
        })
    }
    registerEventListeners() {
        if (typeof this.client > "u") throw new Error("Sign Client is not initialized");
        this.client.on("session_ping", t => {
            this.events.emit("session_ping", t)
        }), this.client.on("session_event", t => {
            const {
                params: r
            } = t, {
                event: s
            } = r;
            if (s.name === "accountsChanged") {
                const o = s.data;
                o && ti(o) && this.events.emit("accountsChanged", o.map(n2))
            } else s.name === "chainChanged" ? this.onChainChanged(r.chainId) : this.events.emit(s.name, s.data);
            this.events.emit("session_event", t)
        }), this.client.on("session_update", ({
            topic: t,
            params: r
        }) => {
            var s;
            const {
                namespaces: o
            } = r, l = (s = this.client) == null ? void 0 : s.session.get(t);
            this.session = Lc(Da({}, l), {
                namespaces: o
            }), this.onSessionUpdate(), this.events.emit("session_update", {
                topic: t,
                params: r
            })
        }), this.client.on("session_delete", async t => {
            await this.cleanup(), this.events.emit("session_delete", t), this.events.emit("disconnect", Lc(Da({}, Tt("USER_DISCONNECTED")), {
                data: t.topic
            }))
        }), this.on(Fi.DEFAULT_CHAIN_CHANGED, t => {
            this.onChainChanged(t, !0)
        })
    }
    getProvider(t) {
        if (!this.rpcProviders[t]) throw new Error(`Provider not found: ${t}`);
        return this.rpcProviders[t]
    }
    onSessionUpdate() {
        Object.keys(this.rpcProviders).forEach(t => {
            var r;
            this.getProvider(t).updateNamespace((r = this.session) == null ? void 0 : r.namespaces[t])
        })
    }
    setNamespaces(t) {
        const {
            namespaces: r,
            optionalNamespaces: s,
            sessionProperties: o
        } = t;
        r && Object.keys(r).length && (this.namespaces = r), s && Object.keys(s).length && (this.optionalNamespaces = s), this.sessionProperties = o, this.persist("namespaces", r), this.persist("optionalNamespaces", s)
    }
    validateChain(t) {
        const [r, s] = (t == null ? void 0 : t.split(":")) || ["", ""];
        if (!this.namespaces || !Object.keys(this.namespaces).length) return [r, s];
        if (r && !Object.keys(this.namespaces || {}).map(d => Sa(d)).includes(r)) throw new Error(`Namespace '${r}' is not configured. Please call connect() first with namespace config.`);
        if (r && s) return [r, s];
        const o = Sa(Object.keys(this.namespaces)[0]),
            l = this.rpcProviders[o].getDefaultChain();
        return [o, l]
    }
    async requestAccounts() {
        const [t] = this.validateChain();
        return await this.getProvider(t).requestAccounts()
    }
    onChainChanged(t, r = !1) {
        var s;
        if (!this.namespaces) return;
        const [o, l] = this.validateChain(t);
        r || this.getProvider(o).setDefaultChain(l), ((s = this.namespaces[o]) != null ? s : this.namespaces[`${o}:${l}`]).defaultChain = l, this.persist("namespaces", this.namespaces), this.events.emit("chainChanged", l)
    }
    onConnect() {
        this.createProviders(), this.events.emit("connect", {
            session: this.session
        })
    }
    async cleanup() {
        this.session = void 0, this.namespaces = void 0, this.optionalNamespaces = void 0, this.sessionProperties = void 0, this.persist("namespaces", void 0), this.persist("optionalNamespaces", void 0), this.persist("sessionProperties", void 0), await this.cleanupPendingPairings({
            deletePairings: !0
        })
    }
    persist(t, r) {
        this.client.core.storage.setItem(`${$f}/${t}`, r)
    }
    async getFromStore(t) {
        return await this.client.core.storage.getItem(`${$f}/${t}`)
    }
}
const _2 = Du,
    m2 = "wc",
    b2 = "ethereum_provider",
    w2 = `${m2}@2:${b2}:`,
    E2 = "https://rpc.walletconnect.com/v1/",
    eu = ["eth_sendTransaction", "personal_sign"],
    D2 = ["eth_accounts", "eth_requestAccounts", "eth_sendRawTransaction", "eth_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "wallet_switchEthereumChain", "wallet_addEthereumChain", "wallet_getPermissions", "wallet_requestPermissions", "wallet_registerOnboarding", "wallet_watchAsset", "wallet_scanQRCode"],
    tu = ["chainChanged", "accountsChanged"],
    I2 = ["message", "disconnect", "connect"];
var S2 = Object.defineProperty,
    x2 = Object.defineProperties,
    C2 = Object.getOwnPropertyDescriptors,
    Hf = Object.getOwnPropertySymbols,
    O2 = Object.prototype.hasOwnProperty,
    A2 = Object.prototype.propertyIsEnumerable,
    Bf = (n, t, r) => t in n ? S2(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    as = (n, t) => {
        for (var r in t || (t = {})) O2.call(t, r) && Bf(n, r, t[r]);
        if (Hf)
            for (var r of Hf(t)) A2.call(t, r) && Bf(n, r, t[r]);
        return n
    },
    Kf = (n, t) => x2(n, C2(t));

function $a(n) {
    return Number(n[0].split(":")[1])
}

function Mc(n) {
    return `0x${n.toString(16)}`
}

function P2(n) {
    const {
        chains: t,
        optionalChains: r,
        methods: s,
        optionalMethods: o,
        events: l,
        optionalEvents: d,
        rpcMap: f
    } = n;
    if (!ti(t)) throw new Error("Invalid chains");
    const v = {
            chains: t,
            methods: s || eu,
            events: l || tu,
            rpcMap: as({}, t.length ? {
                [$a(t)]: f[$a(t)]
            } : {})
        },
        g = l == null ? void 0 : l.filter(P => !tu.includes(P)),
        b = s == null ? void 0 : s.filter(P => !eu.includes(P));
    if (!r && !d && !o && !(g != null && g.length) && !(b != null && b.length)) return {
        required: t.length ? v : void 0
    };
    const S = (g == null ? void 0 : g.length) && (b == null ? void 0 : b.length) || !r,
        O = {
            chains: [...new Set(S ? v.chains.concat(r || []) : r)],
            methods: [...new Set(v.methods.concat(o != null && o.length ? o : D2))],
            events: [...new Set(v.events.concat(d || I2))],
            rpcMap: f
        };
    return {
        required: t.length ? v : void 0,
        optional: r.length ? O : void 0
    }
}
class Iu {
    constructor() {
        this.events = new ri.EventEmitter, this.namespace = "eip155", this.accounts = [], this.chainId = 1, this.STORAGE_KEY = w2, this.on = (t, r) => (this.events.on(t, r), this), this.once = (t, r) => (this.events.once(t, r), this), this.removeListener = (t, r) => (this.events.removeListener(t, r), this), this.off = (t, r) => (this.events.off(t, r), this), this.parseAccount = t => this.isCompatibleChainId(t) ? this.parseAccountId(t).address : t, this.signer = {}, this.rpc = {}
    }
    static async init(t) {
        const r = new Iu;
        return await r.initialize(t), r
    }
    async request(t) {
        return await this.signer.request(t, this.formatChainId(this.chainId))
    }
    sendAsync(t, r) {
        this.signer.sendAsync(t, r, this.formatChainId(this.chainId))
    }
    get connected() {
        return this.signer.client ? this.signer.client.core.relayer.connected : !1
    }
    get connecting() {
        return this.signer.client ? this.signer.client.core.relayer.connecting : !1
    }
    async enable() {
        return this.session || await this.connect(), await this.request({
            method: "eth_requestAccounts"
        })
    }
    async connect(t) {
        if (!this.signer.client) throw new Error("Provider not initialized. Call init() first");
        this.loadConnectOpts(t);
        const {
            required: r,
            optional: s
        } = P2(this.rpc);
        try {
            const o = await new Promise(async (d, f) => {
                var v;
                this.rpc.showQrModal && ((v = this.modal) == null || v.subscribeModal(g => {
                    !g.open && !this.signer.session && (this.signer.abortPairingAttempt(), f(new Error("Connection request reset. Please try again.")))
                })), await this.signer.connect(Kf(as({
                    namespaces: as({}, r && {
                        [this.namespace]: r
                    })
                }, s && {
                    optionalNamespaces: {
                        [this.namespace]: s
                    }
                }), {
                    pairingTopic: t == null ? void 0 : t.pairingTopic
                })).then(g => {
                    d(g)
                }).catch(g => {
                    f(new Error(g.message))
                })
            });
            if (!o) return;
            this.setChainIds(this.rpc.chains);
            const l = Ub(o.namespaces, [this.namespace]);
            this.setAccounts(l), this.events.emit("connect", {
                chainId: Mc(this.chainId)
            })
        } catch (o) {
            throw this.signer.logger.error(o), o
        } finally {
            this.modal && this.modal.closeModal()
        }
    }
    async disconnect() {
        this.session && await this.signer.disconnect(), this.reset()
    }
    get isWalletConnect() {
        return !0
    }
    get session() {
        return this.signer.session
    }
    registerEventListeners() {
        this.signer.on("session_event", t => {
            const {
                params: r
            } = t, {
                event: s
            } = r;
            s.name === "accountsChanged" ? (this.accounts = this.parseAccounts(s.data), this.events.emit("accountsChanged", this.accounts)) : s.name === "chainChanged" ? this.setChainId(this.formatChainId(s.data)) : this.events.emit(s.name, s.data), this.events.emit("session_event", t)
        }), this.signer.on("chainChanged", t => {
            const r = parseInt(t);
            this.chainId = r, this.events.emit("chainChanged", Mc(this.chainId)), this.persist()
        }), this.signer.on("session_update", t => {
            this.events.emit("session_update", t)
        }), this.signer.on("session_delete", t => {
            this.reset(), this.events.emit("session_delete", t), this.events.emit("disconnect", Kf(as({}, Tt("USER_DISCONNECTED")), {
                data: t.topic,
                name: "USER_DISCONNECTED"
            }))
        }), this.signer.on("display_uri", t => {
            var r, s;
            this.rpc.showQrModal && ((r = this.modal) == null || r.closeModal(), (s = this.modal) == null || s.openModal({
                uri: t
            })), this.events.emit("display_uri", t)
        })
    }
    switchEthereumChain(t) {
        this.request({
            method: "wallet_switchEthereumChain",
            params: [{
                chainId: t.toString(16)
            }]
        })
    }
    isCompatibleChainId(t) {
        return typeof t == "string" ? t.startsWith(`${this.namespace}:`) : !1
    }
    formatChainId(t) {
        return `${this.namespace}:${t}`
    }
    parseChainId(t) {
        return Number(t.split(":")[1])
    }
    setChainIds(t) {
        const r = t.filter(s => this.isCompatibleChainId(s)).map(s => this.parseChainId(s));
        r.length && (this.chainId = r[0], this.events.emit("chainChanged", Mc(this.chainId)), this.persist())
    }
    setChainId(t) {
        if (this.isCompatibleChainId(t)) {
            const r = this.parseChainId(t);
            this.chainId = r, this.switchEthereumChain(r)
        }
    }
    parseAccountId(t) {
        const [r, s, o] = t.split(":");
        return {
            chainId: `${r}:${s}`,
            address: o
        }
    }
    setAccounts(t) {
        this.accounts = t.filter(r => this.parseChainId(this.parseAccountId(r).chainId) === this.chainId).map(r => this.parseAccountId(r).address), this.events.emit("accountsChanged", this.accounts)
    }
    getRpcConfig(t) {
        var r, s;
        const o = (r = t == null ? void 0 : t.chains) != null ? r : [],
            l = (s = t == null ? void 0 : t.optionalChains) != null ? s : [],
            d = o.concat(l);
        if (!d.length) throw new Error("No chains specified in either `chains` or `optionalChains`");
        const f = o.length ? (t == null ? void 0 : t.methods) || eu : [],
            v = o.length ? (t == null ? void 0 : t.events) || tu : [],
            g = (t == null ? void 0 : t.optionalMethods) || [],
            b = (t == null ? void 0 : t.optionalEvents) || [],
            S = (t == null ? void 0 : t.rpcMap) || this.buildRpcMap(d, t.projectId),
            O = (t == null ? void 0 : t.qrModalOptions) || void 0;
        return {
            chains: o == null ? void 0 : o.map(P => this.formatChainId(P)),
            optionalChains: l.map(P => this.formatChainId(P)),
            methods: f,
            events: v,
            optionalMethods: g,
            optionalEvents: b,
            rpcMap: S,
            showQrModal: !!(t != null && t.showQrModal),
            qrModalOptions: O,
            projectId: t.projectId,
            metadata: t.metadata
        }
    }
    buildRpcMap(t, r) {
        const s = {};
        return t.forEach(o => {
            s[o] = this.getRpcUrl(o, r)
        }), s
    }
    async initialize(t) {
        if (this.rpc = this.getRpcConfig(t), this.chainId = this.rpc.chains.length ? $a(this.rpc.chains) : $a(this.rpc.optionalChains), this.signer = await _2.init({
                projectId: this.rpc.projectId,
                metadata: this.rpc.metadata,
                disableProviderPing: t.disableProviderPing,
                relayUrl: t.relayUrl,
                storageOptions: t.storageOptions
            }), this.registerEventListeners(), await this.loadPersistedSession(), this.rpc.showQrModal) {
            let r;
            try {
                const {
                    WalletConnectModal: s
                } = await N_(() =>
                    import ("./index-418056fa.js").then(o => o.i), ["assets/index-418056fa.js", "assets/index-95ae70b2.js", "assets/index-2ebb5e00.css"]);
                r = s
            } catch {
                throw new Error("To use QR modal, please install @walletconnect/modal package")
            }
            if (r) try {
                this.modal = new r(as({
                    walletConnectVersion: 2,
                    projectId: this.rpc.projectId,
                    standaloneChains: this.rpc.chains
                }, this.rpc.qrModalOptions))
            } catch (s) {
                throw this.signer.logger.error(s), new Error("Could not generate WalletConnectModal Instance")
            }
        }
    }
    loadConnectOpts(t) {
        if (!t) return;
        const {
            chains: r,
            optionalChains: s,
            rpcMap: o
        } = t;
        r && ti(r) && (this.rpc.chains = r.map(l => this.formatChainId(l)), r.forEach(l => {
            this.rpc.rpcMap[l] = (o == null ? void 0 : o[l]) || this.getRpcUrl(l)
        })), s && ti(s) && (this.rpc.optionalChains = [], this.rpc.optionalChains = s == null ? void 0 : s.map(l => this.formatChainId(l)), s.forEach(l => {
            this.rpc.rpcMap[l] = (o == null ? void 0 : o[l]) || this.getRpcUrl(l)
        }))
    }
    getRpcUrl(t, r) {
        var s;
        return ((s = this.rpc.rpcMap) == null ? void 0 : s[t]) || `${E2}?chainId=eip155:${t}&projectId=${r||this.rpc.projectId}`
    }
    async loadPersistedSession() {
        if (!this.session) return;
        const t = await this.signer.client.core.storage.getItem(`${this.STORAGE_KEY}/chainId`),
            r = this.session.namespaces[`${this.namespace}:${t}`] ? this.session.namespaces[`${this.namespace}:${t}`] : this.session.namespaces[this.namespace];
        this.setChainIds(t ? [this.formatChainId(t)] : r == null ? void 0 : r.accounts), this.setAccounts(r == null ? void 0 : r.accounts)
    }
    reset() {
        this.chainId = 1, this.accounts = []
    }
    persist() {
        this.session && this.signer.client.core.storage.setItem(`${this.STORAGE_KEY}/chainId`, this.chainId)
    }
    parseAccounts(t) {
        return typeof t == "string" || t instanceof String ? [this.parseAccount(t)] : t.map(r => this.parseAccount(r))
    }
}
const B2 = Iu;
export {
    B2 as EthereumProvider, I2 as OPTIONAL_EVENTS, D2 as OPTIONAL_METHODS, tu as REQUIRED_EVENTS, eu as REQUIRED_METHODS, Iu as
    default
};